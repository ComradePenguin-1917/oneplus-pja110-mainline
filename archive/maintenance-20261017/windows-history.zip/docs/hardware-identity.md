==========================================================================
EVIDENCE TABLE: what is this phone really using?
==========================================================================

item                   evidence                           conclusion
---------------------- ---------------------------------- --------------------
Panel driver           ABL: "DisplayDxe: Detected panel:  AA536_P_3_A0001
Panel (cmdline)        msm_drm.dsi_display0=qcom,mdss_dsi AA536_P_3_A0001
Panel native mode      /proc/bus/input + "wm size" -> 124 1240x2772
Touch controller       /proc/bus/input/devices: Phys=syna synaptics-s3910
Touch (cmdline)        oplus_bsp_tp_custom...:synaptics-s synaptics-s3910

==========================================================================
RESOLUTION of the apparent contradiction
==========================================================================

The DTBO ships SEVERAL panels because OPPO uses multiple display suppliers
for the same model. From the dtbo strings:

    dsi_oplus_xigua_boe_nt37705_1240_2772_dsc_cmd
    mdss_dsi_panel_AA536_P_3_A0001_dsc_cmd
    mdss_dsi_panel_AA536_P_3_A0001_dsc_cmd_2nd
    mdss_dsi_panel_samsung_amb670yf07_1440_3216_dsc_cmd
    mdss_dsi_panel_samsung_amb670yf07_cs_1440_3216_dsc_cmd
    mdss_dsi_panel_samsung_amb670yf07_fs_1440_3216_dsc_cmd
    mdss_dsi_panel_samsung_amb670yf08_cs_1440_3216_dsc_cmd
    mdss_dsi_panel_samsung_amb670yf08_fs_1440_3216_dsc_cmd

ABL reads a panel ID strap at boot (its log even shows "Detected panel
ID=[0x003C0000]") and selects ONE, rewriting the kernel cmdline. On THIS
unit it selected AA536_P_3_A0001 with a synaptics-s3910 touch controller.

So both of my earlier statements were partly right and partly wrong:
  * CORRECT: the panel is 1240x2772 (1.5K) -- matches the physical size
  * WRONG  : the panel driver is NOT a BOE/NT37705; it is AA536_P_3_A0001
  * WRONG  : the touch is NOT Goodix GT9916; it is Synaptics S3910

==========================================================================
WHY THIS MATTERS FOR THE PORT
==========================================================================

1) Panel: mainline has BOE/Novatek panels but no AA536_P_3_A0001 driver.
   "AA536" is a Samsung display part number. Closest mainline templates:
   panel-samsung-* (e.g. sofef00, s6e8fc0) if it is a Samsung DDIC, or
   panel-boe-td4320.c as a structural DSC example. Need the vendor driver
   (android_kernel_oneplus_sm8550 devicetree + techpack/display) for the
   real init sequence.

2) Touch: synaptics-s3910 uses the "synaptics,tcm-spi-hbp" binding, and
   mainline has NO Synaptics TCM driver. This is HARDER than the Goodix
   Berlin path I described earlier (which does exist upstream). It means
   writing a new driver, not just adding a DT node.

3) The enabling of touch in the live tree:
     synaptics_tcm_hbp@0   status=okay      <- the one in use
     synaptics_tcm@0       status=disabled
     goodix-berlin@5d      status=disabled  <- OPPO alternate


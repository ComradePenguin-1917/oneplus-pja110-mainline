# boot.img 打包与刷写（阶段 B：内存启动）

本文档说明如何为本机生成 boot.img，以及**为什么这样做是安全的**。

---

## 1. 为什么用 `fastboot boot`

`fastboot boot <img>` 把内核**加载到内存里跑**，不写任何分区。重启即恢复原样。

| 操作 | 是否写 flash | 变砖风险 |
| :-- | :-- | :-- |
| `fastboot boot boot-xigua.img` | ❌ 不写 | **几乎为零** |
| `fastboot flash boot boot-xigua.img` | ✅ 写 boot 分区 | 低（可刷回） |
| `fastboot erase dtbo` | ✅ 写 dtbo 分区 | 低（可刷回） |
| 动 `xbl`/`abl`/GPT | ✅ | **高，可能需 9008** |

DTS 迭代阶段**全程只用 `fastboot boot`**。

---

## 2. 逆向出的 boot.img 格式（本机实测）

用 `tools/bootimg.py parse boot-A14.img` 分析厂商线刷包，得到**这台机器真实**的布局：

```
偏移 0x0000   header v4，header_size = 1584（页内其余补零）
偏移 0x1000   kernel —— 原始 arm64 EFI-stub Image（开头是 "MZ"，不是 gzip！）
              kernel_size 字段 = 53238272 (50.77 MiB)
              arm64 image_size 字段 = 54984704 (52.44 MiB)
...           ramdisk_size = 0（本机没有 ramdisk）
...           AVB0 vbmeta 结构（仅原厂签名镜像有）
剩余 192 MiB  全零填充
```

关键事实：

- **`os_version = 0x1a000184`** —— 注意这**不符合** AOSP 的年份打包规则，
  所以我们的打包器**直接复制**这个值，不重新计算。
- **kernel 是未压缩的 arm64 Image**（不是 `Image.gz`）。
  AG 的 aston 脚本用 gzip，是因为 ABL 两种都吃；我们保持和厂商一致。
- **DTB 不是独立 section**。header v4 没有 dtb 字段，DTB 要**追加在 Image 后面**。
  这正是社区（Krzysztof 在邮件列表里说的）"standard setup — concatenated DTB"。

### 自校验

```bash
python tools/bootimg.py selftest boot-A14.img
```

输出：

```
stock: 201326592 bytes
repacked: 53243904 bytes
header+kernel region identical: True      <-- 字节级一致
stock tail beyond our output: 148082688 bytes (AVB footer + padding)
```

**我们的打包器能逐字节复现原厂 header+kernel 区域**，这是打包逻辑正确的强证据。

---

## 3. 打包

```bash
# 1) 准备内核 Image（arm64）
#    来自你自己的内核构建：arch/arm64/boot/Image

# 2) 打包（DTB 追加在 Image 后）
python tools/bootimg.py pack \
    --kernel Image \
    --dtb dts/sm8550-oneplus-xigua-16G.dtb \
    --stock boot-A14.img \
    -o boot-xigua.img
```

`--stock` 的作用：从原厂镜像继承 `os_version` 与 `header_version`，
避免踩到防回滚（os_version 低于设备值会导致 ABL 拒绝启动）。

打包器会**立即回读自校验**（`self-check: PASS`）。

### 参考：aston 的等效命令

```sh
cat Image sm8550-oneplus-aston.dtb > Image_w_dtb
gzip Image_w_dtb
mkbootimg --header_version 4 --base 0x0 \
          --os_version 15.0.0 --os_patch_level 2025-02 \
          --kernel Image_w_dtb.gz -o boot.img
```

差别：他们 gzip，我们保持 raw Image；两者 ABL 都接受。

---

## 4. ⚠️ ABL 的 DTBO 要求（重要，已解决）

这台机器的 ABL **在应用 DTBO 时**要求基础 DTB 里存在两个 label：

- 名为 **`qcom_tzlog`** 的 label（内容无所谓）
- timer 节点带 **`arch_timer`** label

否则 ABL **拒绝加载，直接退回 bootloader 菜单**。

这条来自上游邮件列表的实测讨论：
[\[PATCH v2\] arm64: dts: qcom: sm8550: Fix DTBO boot failure](https://patchew.org/linux/20260207-sm8550-abl-dtbo-v2-1-83afaa6f3ce9@gmail.com/)
（该补丁被 Bjorn/Krzysztof **拒绝**进入 `sm8550.dtsi`，理由：这是 ABL 的毛病、不是 SoC 属性，
要求放到具体机型的 DTS 里 —— 我们正是这么做的。）

### 两条路，我们都支持

**路线 1（推荐，社区标准做法）：不理会 DTBO**

```bash
fastboot erase dtbo
fastboot boot boot-xigua.img
```
ABL 没有 DTBO 要应用，就不触发这个 bug。postmarketOS 社区一直这么做。
Ace 3（aston）的移植就是这样。

**路线 2：让 ABL 也能应用 DTBO**

我们的 DTS 已经**内建**了这两个 label 的兼容处理，所以即使不擦 dtbo 也能启动：

```dts
qcom_tzlog: chosen { ... };        /* 带 label 的 chosen */
/ { arch_timer: timer { }; };      /* 给 timer 补 label */
```

⚠️ **必须用 `dtc -@` 编译**，否则 label 不会写进 `__symbols__`，兼容处理等于没做。
`tools/build_dts.py` 已经默认加上了 `-@`（这是实测发现的坑：
不加 `-@` 时，两个 label 在生成的 DTB 里**完全不存在**）。

验证：

```bash
python tools/check_abl_labels.py
#   qcom_tzlog       present in blob: True
#   arch_timer       present in blob: True
#   __symbols__ 里: qcom_tzlog = "/chosen";  arch_timer = "/timer";
```

---

## 5. 串口

厂商固件的 cmdline 是 **`console=ttynull`**（关掉了串口输出）：

```
console=ttynull loglevel=6 kpti=0 log_buf_len=1M swiotlb=noforce
kasan=off pcie_ports=compat irqaffinity=0-2 disable_dma32=on
cgroup.memory=nokmem,nosocket
```

我们用 `stdout-path = "serial0:115200n8"` 指到 **`&uart7`**
（厂商 `aliases/serial0` = `a9c000`，与上游 `uart7: serial@a9c000` 一致）。

需要真实串口日志时，打包时覆盖 cmdline：

```bash
python tools/bootimg.py pack --kernel Image --dtb ...dtb \
    --stock boot-A14.img \
    --cmdline "console=ttyMSM0,115200 loglevel=8 earlycon" \
    -o boot-xigua.img
```

（`ttyMSM0` 对应 `uart7`；实际登录需要 USB-TTL 接到主板的 UART 测试点。）

---

## 6. bring-up 检查清单

```bash
# 0) 关掉系统自动更新！（见 porting-status.md §2.4）

# 1) 确认手机在 fastboot
fastboot devices

# 2) 内存启动，不写 flash
fastboot boot boot-xigua.img

# 3) 观察：
#    - 屏幕：预期仍黑（面板驱动还没写）
#    - USB：插电脑看有没有出现网络设备 / adb
#    - 串口：有 UART 线的话看输出
```

**预期结果**：能进 shell（USB 网络），屏幕黑。这就代表 DTS 的内存图 + UFS + USB 是通的
—— 也就是阶段 0 的目标。

如果连 shell 都没有，按这个顺序怀疑：

1. **RAM 图不对**（最可能，见 `docs/dts-build.md` §5）
2. `os_version` 低于设备值 → ABL 拒绝
3. DTBO 兼容问题 → 试 `fastboot erase dtbo`
4. 内存图某条与固件冲突 → 用 `tools/verify_dts.py` 复查

---

## 7. 工具

```bash
python tools/bootimg.py parse boot-A14.img        # 解析布局
python tools/bootimg.py selftest boot-A14.img     # 打包器自校验
python tools/bootimg.py pack --help               # 打包
python tools/check_abl_labels.py                  # 验证 ABL label
python tools/verify_dts.py                        # 内存图对账
```

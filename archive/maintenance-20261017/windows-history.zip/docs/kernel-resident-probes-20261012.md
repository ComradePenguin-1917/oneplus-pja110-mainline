# 释放初始化内存之后的常驻探针

先前探针存放在 init 区对齐填充，不能用于 free_initmem 之后。当前构建 ELF 的 .text 区起于 ffff800080010000，长度 0xffd000，恰好结束于 __hyp_text_end（ffff80008100d000）；下一个 .rodata 起于 _etext（ffff800081010000）。链接脚本在二者之间只作 SEGMENT_ALIGN 对齐，原始 Image 对应填充全部为零。map_kernel.c 将 _stext 至 _etext 映射为可执行代码，覆盖这段 12 KiB 对齐填充。

新探针置于该填充起点（Image 偏移 16830464），共 68 字节。位置在 init_begin 之前，free_initmem 只释放 init_begin 至 init_end，不会释放此处；mark_rodata_ro 的 RO NX 区从 _etext 开始，也不覆盖探针。证据为 out/kernel-entry-probe-20261012/vmlinux-sections.txt、vmlinux.lds.S、map_kernel.c、free_initmem-disassembly.txt 和 mark_rodata_ro-disassembly.txt。

远端测试点为 kernel_init + 0x68（Image 偏移 16692292），替换读取初始用户态命令的 LDR。前一条 BL 解码核对为 do_sysctl_args。这是选择命令之前的共同路径，不会调用 run_init_process；阳性不能证明 /init 已执行，也不能把 rodata_enabled 控制的条件分支一概视为已执行。

实际 Image QEMU 验证退出码 0、记录含 SMC，耗时 50.647 秒，SHA256 c5772e0402386fd1b00a179ef03acbb0690279aeffb329810eed70d4e27a2425。boot SHA256 9b7731628dc58bf158ad62726d55a6eeee913b0cbf781e7f20df2e99a89a2367。仅修改一个分支与常驻零填充，Image 头和长度不变，其他三个 B 镜像沿用 ABL 已通过的对照。

镜像及实机证据分别保存于 out/kernel-before-userspace-probe-20261012/ 和 out/kernel-before-userspace-probe-experiment-20261012/。用户观察到自行重启，接近每 20 秒；周期为近似观察，未外部计时。实际 boot_b 前缀与其他三个 B 分区完整哈希均匹配测试输入，完整 8 MiB 引导历史已保存。结合 QEMU 验证、用户观察和读回，支持实机已到达选择初始用户态命令之前的共同路径。

已完成四个 B 分区恢复并返回 Android A，八个 A/B 启动分区哈希匹配本轮 preflight，结果保存于实验目录 result.json。尚无 /init 成功执行或用户态已运行的证据。

若远端未到达，可先回测 kernel_init + 0x34，即 free_initmem 返回后的第一条指令；若远端可达，可沿用常驻探针推进到 run_init_process 入口、exec 返回路径或用户态入口。探针已恢复代码区安全性，不再依赖 init 区继续有效。

下一轮建议先取 run_init_process +4，保留 PACIASP，替换栈帧建立指令并转到同一常驻探针；随后检查 kernel_execve 返回位置，按返回值区分 0 与错误码。只观察到函数返回不能等同于 /init 执行成功；即使 exec 成功返回，也仍需区分任务返回路径与真正的用户态执行。

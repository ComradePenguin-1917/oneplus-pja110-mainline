# PJA110 ADC5 Gen3 backport candidate

## Native-A sensor test passed

After the user's install, vendor_boot_a readback from B matched candidate SHA256 9cbff73044d6bed2d424298b3f1894b786715e185e099121ab55f645934c278d. B #24 was running, A was marked unsuccessful/unbootable, pstore was empty, and the A early-capture directories contained no new boot. This does not establish an ADC crash. Re-activating A through upstream qbootctl and rebooting once successfully started native A boot 067c98b1-9996-4219-ac4e-fb627708afe3.

The installed upstream ADC module automatically loaded, used the rootfs's existing qcom_vadc_common module, and bound adc@9000. IIO exposed subboard_temp at in_temp1868_input. Fifteen one-second readings all succeeded, ranging 29343 through 29424 millidegrees C (29.343–29.424 C). No matching ADC conversion-fault/timeout messages were found in the accessible kernel journal. Battery temperature was 29.8 C, capacity 4 percent, net current +164 mA at the end. This is a short successful sampling test, not calibrated sensor accuracy or a completed charging thermal policy.

A slot success marking remains to be checked and repaired before relying on repeated normal boots; do not classify the initial B selection as a proven ADC failure. No charging SET command was sent.

Upstream source is pinned to Linux commit 3857c2fe5449541e24afc5efdb0f81a8a8f9a3a0. Source hashes and the upstream binding are saved under out/native-install-20261017/adc-gen3. Only the include of linux/device/devres.h was removed for Linux 6.14 compatibility. Conversion, interrupt handling and scaling logic are unchanged.

The upstream qcom-spmi-adc5-gen3 module and Linux 6.14's own qcom-vadc-common module passed strict compilation and modpost against the prepared native-A build tree. No missing-symbol warnings were suppressed. This verifies build compatibility, not live ABI or sensor operation.

dts/sm8550-oneplus-xigua-adc-candidate.dtsi is an offline candidate appended to the existing board DTS for compilation. It uses PMK8550 SDAM addresses 0x9000/0x9100 and EOC IRQs from the upstream PMK8550 description, with the factory PJA110 PM8550B SID7 AMUX3 GPIO6 100k pull-up channel (0x74c), 200us settling, ratiometric calibration and the factory high-impedance GPIO6 pin state. It does not enable ADC threshold monitoring. Device-tree compilation passed; schema validation and live measurements remain pending.

The candidate was not added to the production board DTS or packaged into a boot image. No phone partitions were modified and no charging controls were sent. Before deployment, compare the actual native-A runtime PMIC nodes and SDAM ownership, confirm installed qcom-vadc-common module identity/dependencies, and choose a controlled boot test. After loading, verify plausible subboard temperatures and absence of conversion faults/timeouts before using the value in charging policy.

Native-A read-only preflight on boot a3251fd9-461e-4efd-89be-19bf3e3e9001 found no ADC node named adc@9000 and no matching ADC platform device. The rootfs already contains qcom-vadc-common.ko, qcom-spmi-vadc.ko and qcom-spmi-adc5.ko; these are not loaded. Therefore inserting the new driver alone cannot expose this sensor: the candidate ADC device-tree node must also be deployed. The broad address-name search also matched unrelated devices; these are not ADC devices. Evidence: out/native-install-20261017/adc-gen3/runtime-preflight.txt. Installed common-module ABI and SDAM ownership still need explicit verification before deployment.

# AA536 DSC 发包核对

基于 #20 实机寄存器与已固定原厂提交
`f034653c086942be9398171cfa7477ddbe2d9504`，确认存在 DSC 包化差异。

| 项目 | 当前主线实际值 | 原厂全屏公式预期值 |
| --- | --- | --- |
| 每 slice 数据 | 620 字节 | 620 字节 |
| 每包 slices | 1 | 2 |
| 每行包数 | 2 | 1 |
| 每包 DSC 数据 | 620 字节 | 1240 字节 |
| DCS word count（含命令字节） | 621 | 1241 |
| EOL 字节余数 | 1 | 1 |

原厂 `sde_dsc_populate_dsc_private_params()` 公式为
`bytes_per_pkt = bytes_in_slice * slice_per_pkt`、
`pkt_per_line = slice_per_intf / slice_per_pkt`。
原厂 `dsi_ctrl_hw_cmn.c` command mode 使用 `bytes_per_pkt+1` 写 stream
word count；压缩模式 packet count 位同步改变。压缩 slice width 寄存器
仍写单个 slice 字节数，不应倍增。widebus 整行宽度仍为 ceil(1240/6)=207。

当前实际 stream0 压缩控制低16位为 0x3951；两-slice 候选为 0x3911。
stream0 word count 控制为 0x026d0039；候选为 0x04d90039。
stream total 0x0ad400cf、slice width 0x026c（620）、PPS/RC 和 TE 应保持。
这些是原厂源码推导的预期值，未声称已读回 Android 原厂寄存器。

当前主线源码注释把一般包数公式写成乘法，但原厂明确使用除法。
当前固定每包1 slice 时不会造成数值差异；扩展为2时必须采用除法。
检查也没有理由把每包2 slice 改成 DSC slice 宽度1240或修改面板0x91。

已准备限定 AA536 命令模式的候选补丁，并保留不足两个 slice 的原厂
回退逻辑。文件为 `out/dsc-packet-audit-20261014/packet2-only.patch`，
完整候选源码和 `packet-comparison.json` 同目录保存。
本轮仅生成候选文件，未应用到构建树、未构建刷写，尚未确认是否消除花屏。

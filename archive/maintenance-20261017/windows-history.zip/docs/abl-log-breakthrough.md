# 突破：ABL 日志找到了缺失的观测通道

> 日期：2026-10-10 · 来源：`/proc/bootloader_log`（28 KB，ABL 自己的日志）

## 1. 这是什么

设备的 `/proc/bootloader_log` 保存着 **ABL（引导加载器）的完整运行日志**，
存在 `oplusreserve1` 保留区里，**能跨启动保留**。

```bash
adb shell su -c 'cp /proc/bootloader_log /data/local/tmp/bl.log'
adb pull /data/local/tmp/bl.log
```

**这就是我们之前缺的观测通道** —— 不需要拆机、不需要串口。

日志里记录了 ABL 做了什么、验证了什么、构造了什么 cmdline、如何移交内核。
其中一条足以解释我们全部的失败。

## 2. 决定性发现：ABL 自己会应用 DTBO

```
Apply Overlay total time: 323 ms
Update Device Tree total time: 60 ms
Add Base: 0x00000008C0000000 Available Length: 0x0000000140000000
Add Base: 0x0000000A00000000 Available Length: 0x0000000200000000
```

**ABL 会自己加载 `dtbo_a`、应用 overlay、然后 `Update Device Tree`。**

这直接推翻了我之前的假设。完整流程是：

| 顺序 | ABL 动作 | 来源 |
| --: | :-- | :-- |
| 1 | 加载 `vbmeta_a` + 验证 | 分区 |
| 2 | 加载 **`boot_a`**（内核） | 分区 |
| 3 | 加载 **`vendor_boot_a`** | 分区 |
| 4 | 加载 **`dtbo_a`** | 分区 |
| 5 | **`Apply Overlay`** + **`Update Device Tree`** | ABL 内部 |
| 6 | 构造 cmdline（含 OPPO 私有参数） | ABL |
| 7 | `Exit Boot Services` → 移交内核 | — |

**所以：DTB 不是我们塞在 Image 尾部、由内核自己找的；而是 ABL 用它在 flash 上
的 `dtbo_a` 拼好之后传给内核的。**

## 3. 这解释了我们为什么失败

我们的 boot.img 只替换了**第 2 步的 `boot_a`**（内核）。第 3、4 步仍然用设备上的
**原厂** `vendor_boot_a` 和 **原厂** `dtbo_a`：

| 项 | 我们提供的 | 实际生效的 |
| :-- | :-- | :-- |
| 内核 | ✅ 我们的 6.14 mainline | — |
| **DTB** | ❌ 我们拼在 Image 尾部（**从未被读取**） | **原厂 dtbo 的 4 个 DTB** |
| **initramfs** | ❌ 没提供 | **原厂 vendor_boot 的 16 MiB ramdisk** |

于是内核拿到的是**为 Android 5.15 定制的设备树**——设备节点、兼容字符串、
内存描述全是厂商版本。主线 6.14 内核在这个 DTB 上：

- 找不到匹配的驱动 → 大部分外设起不来
- 内存图按厂商 DTB 走 → 和我们精心实测的 `oplus_mem` 无关
- 没有可用 initramfs 挂载 → panic

**而且关键设备如 USB gadget 无法在无用户态时枚举**，所以完全看不见。
"内核健康"和"内核已死"在这个配置下**无法区分**。

## 4. 另一个重要发现：`msm_drm.dsi_display0` 暴露了真实面板

ABL 构造的 cmdline 里：

```
msm_drm.dsi_display0=qcom,mdss_dsi_panel_AA536_P_3_A0001_dsc_cmd:
oplus_bsp_tp_custom.dsi_display0=qcom,mdss_dsi_panel_AA536_P_3_A0001_dsc_cmd:synaptics-s3910
```

**这台机器实际用的是 `AA536_P_3_A0001` 面板 + `synaptics-s3910` 触摸屏**，
而不是我之前从 dtbo 字符串推测的 BOE NT37705 + Goodix GT9916！

之前看到 dtbo 里同时有多个面板/触摸驱动（OPPO 多供应商策略），我按分辨率猜了
NT37705。**ABL 的日志给出了唯一确定答案**：

| 部件 | 我之前推测 | **ABL 实际选择** |
| :-- | :-- | :-- |
| 面板 | BOE NT37705 1240×2772（**我的错误推测**） | **`AA536_P_3_A0001`**（三星料号，1240×2772） |
| 触摸 | Goodix GT9916 | **`synaptics-s3910`** |

⚠️ 这意味着**面板驱动的工作量和方向都要改**：`AA536_P_3_A0001` 是三星
2K 面板（1440×3216），不是 1.5K BOE。而且 synaptics-s3910 **主线没有驱动**，
比 Goodix Berlin 难得多。

## 5. 其他有用信息

### 分区加载顺序与验证结果

```
vendor_boot_a: Hash of data does not match digest in descriptor.   ← 已被改过
init_boot_a  : Hash of data does not match digest in descriptor.   ← 已被改过
VB2: Authenticate complete! boot state is: orange
```

`orange` = 已解锁（符合预期）。`vendor_boot` 和 `init_boot` 的哈希不匹配，
说明**这两个分区也被改过**（很可能是 KernelSU/root 相关，或换过版本）——
备份时要注意。

### ABL 版本

```
QC_IMAGE_VERSION_STRING=BOOT.MXF.2.1.1-00067-KAILUA-1.17626.13
IMAGE_VARIANT_STRING=SocKailuaLAA
Boot Interface: UFS
Secure Boot: On
```

芯片是 **Kailua**（SM8550 的另一个名字），安全启动开启。

### 内存图（ABL 喂给内核的）

```
Add Base: 0x00000008C0000000 Available Length: 0x0000000140000000
Add Base: 0x0000000A00000000 Available Length: 0x0000000200000000
```

与我们从 live DTB 实测的 `0x8c0000000 + 0x140000000`、`0xa00000000 + 0x200000000`
**完全一致** ✅ —— 我们 DTS 里的内存图是对的。

### 一个正在发生的坏消息

```
ERROR: ufs fw update more then 2 times!
ERROR: ufs fw head magic error!
ERROR: magic1 =0x0  magic2 =0x0!
```

UFS 固件更新反复失败。目前不影响启动（UFS 能用），但值得留意。

## 6. 这改变了下一步的做法

### 原来的思路（错的）

> 把 DTB 拼在 Image 后面，`fastboot boot` 让内核用它。

**行不通** —— ABL 根本不会读 Image 尾部的字节，它用 dtbo 分区拼自己的 DTB。

### 正确的思路

有两条路：

**路线 1：让 ABL 用我们的 DTB**
把我们的 DTB 做成一个 dtbo 镜像，**刷进 `dtbo_a`**。这样 ABL 会在第 5 步
应用它。需要满足 ABL 的格式要求（`qcom,msd-id`/`board-id` 匹配 + 那两个 label）。

**路线 2：内嵌 initramfs + 让内核忽略外部 DTB**
内嵌一个带 USB 网络的最小 initramfs，先建立观测能力。
但即使内核起来了，它用的还是厂商 DTB，外设仍然不会按我们的预期工作。

**路线 3（推荐）：两者结合**
1. 内嵌最小 initramfs（建立 adb 观测通道）
2. 把我们的 DTB 做成 dtbo 刷进 `dtbo_a`

这样内核既有正确的 DTB，又能被观察到。

> ⚠️ 刷 `dtbo_a` 是**真正写分区**了，不再是纯内存操作。但有备份
> （`backup/dtbo_a.img`，已确认与原厂一致）+ 已验证的恢复流程。

## 7. 立即可用的新工具

```bash
# 拉取 ABL 日志（每次启动后都可以看）
adb shell su -c 'cp /proc/bootloader_log /data/local/tmp/bl.log'
adb pull /data/local/tmp/bl.log
python tools/analyze_bootloader_log.py bootloader-log.txt
```

**这个通道以后每次上机实验都要用** —— 它是判断"ABL 做了什么"的唯一途径。

# AA536 生成版显示驱动实机复测（2026-10-14）

## 结果

修复 boot 镜像打包破坏 AVB 尾部的问题后，生成版驱动已实机启动。
运行内核为 `6.14.0-sm8550-xigua-r1 #15`，日志确认生成版驱动、面板
初始化完成和 Iris7 analog bypass。用户确认正常显示六色竖向彩条。
自动 NCM SSH、Aston S3910 触控模块及 rate code 3 初始化读回仍正常。
本轮未重新测量触控报告频率；240Hz 的测量依据仍是此前的触控验证。

## 复用范围

使用固定版本 `msm8916-mainline/linux-mdss-dsi-panel-driver-generator`
（`28c4df25628f6241ce925af15637a443ea2b3bb5`）生成 AA536 面板驱动。
保留生成器的命令结构、标准 DRM 面板接口、模式和背光实现；保留
PJA110 原厂 AA536 命令，以及已验证的 GPIO90、电源时序和 Iris7 旁路适配。
没有使用 Aston AA551 的面板参数。98 条开屏、2 条关屏命令及四条必须
使用 DCS long packet 的两字节命令，均由 `verify_generated_panel.py` 核对。

## 镜像和部署

结果目录：`out/display-generator-avb-retest-20261014/`。

- 完整 boot_b 镜像：`boot_b-generated-panel.img`，201326592 字节。
- SHA256：`7ffe926989eefb3963f733e5a3e105a79065c7adb9244b0d0007cb32405e59cc`。
- 从原厂 boot_b 保留 offset 53243904 起的全部尾部，包括 AVB 元数据和 footer。
- 恢复用完整 #14 镜像：
  `out/boot-recovery-diagnosis-20261014/boot_b-working-restored-avb.img`。
- 正确的 Aston 自动触控 init_boot 保持不变，来自
  `out/aston-touch-240hz-20261013/verified-autostart/`。

此次在运行中的 #14 Linux 下通过 SSH 部署。先核对八个启动分区与已恢复
基线完全一致，上传完整候选到手机 RAM 并校验 SHA256，再按唯一 PARTNAME
定位 boot_b 写入。写入后核对完整分区 SHA256，并确认其余七个分区不变，
最后普通重启。重启后的 `capture --avb-retest` 再次核对全部八个分区。
没有更改 A 槽、vendor_boot_b、init_boot_b 或 dtbo_b。

部署证据：`live-before.json`、`live-write-readback.txt`、
`live-after-write.json`、`device-after.json`、`device-after.txt`、
`deployment-manifest.json`。旧失败实验目录仍保留，不覆盖旧证据。
最终可启动组合及所有分区哈希记录在 `verified-combination.json`。

## 重启到 fastboot 的独立问题

设备树使用 nvmem-reboot-mode，但当前自动启动环境未加载对应模块，
SPMI SDAM provider 也未加载。构建并在 RAM 中加载未修改的上游
`qcom-spmi-sdam` 和 `nvmem-reboot-mode` 后，reboot-mode 成功绑定；
RESTART2("bootloader") 仍普通重启回主线。因此缺模块不是完整解释，
进入 fastboot 的重启原因传递问题尚未解决。本轮不为此修改设备树或分区。
misc+2048 的标准 AOSP bootloader_control 区域为空，未据此猜测或改写槽位。

## 运行验证

软件记录在本轮目录的 `runtime-validation/`：

- 亮度 64→128→512→1024→128：请求值与 actual_brightness 一致，恢复原值。
- 五次开关屏：GPIO90 关屏 low、开屏 high，重新提交彩条均完成。
  首次测试因 debugfs 未挂载停止，退出保护恢复亮屏；挂载 debugfs 后
  完整五次测试通过，工具已加入按需挂载。
- 用户确认亮度变化正常、每次恢复彩条。
- 一次普通重启：boot_id 改变，仍为生成版 #15，约 23.44 秒后自动 SSH
  恢复。重新绘制彩条后，用户再次确认正常显示。
- 重启后再次执行 capture，核对面板初始化、Iris7 旁路、Aston rate code 3
  和全部八个启动分区。

高刷新率、Iris7 插帧、长期稳定性及发行版桌面不属于本轮验证范围。

# PJA110 GPU 初步检查（2026-10-14）

当前运行已验证的生成版 AA536 显示内核 `6.14.0-sm8550-xigua-r1 #15`。
本轮仅检查，未刷写或重启，原厂 modem_a 临时以 vfat、ro 挂载并自动卸载。

## 实机结论

- `/soc@0/gpu@3d00000` 的 status 为 disabled，compatible 为
  `qcom,adreno-43050a01` / `qcom,adreno`，对应 Adreno 740。
- 内核日志明确报告 `msm_dpu ... no GPU device was found`。
- adreno 驱动已注册但没有绑定 GPU 设备。
- GPU 时钟控制器 `gpu_cc-sm8550` 已绑定，Adreno IOMMU 已绑定 arm-smmu。
- 存在 `/dev/dri/renderD128`，但上述证据说明它不能作为 GPU 加速就绪证明。
- 当前 initramfs 没有 `/lib/firmware` 和 Mesa 用户空间环境。
- GPU zap-shader memory-region 指向本机保留区
  `gpu-micro-code-region@9b09a000`，大小 0x2000；尚无 board firmware-name。

## 优先复用的实现

实际构建内核已有 `drivers/gpu/drm/msm/adreno/a6xx_catalog.c` 的
`0x43050a01` 支持项，使用现成 a6xx GPU 驱动，不需要另写 GPU 驱动。
该支持项需要 `a740_sqe.fw`、`gmu_gen70200.bin`，默认 zap 名称为
`a740_zap.mdt`。上游 sm8550-mtp 和 Aston 均通过板级 firmware-name
覆盖为对应设备的 `a740_zap.mbn`。

Aston 的 GPU 板级启用只设置 status=okay 和 zap firmware-name。
PJA110 可以复用此结构，但 zap 固件必须来自本机原厂版本，不能直接
借用 Aston 的签名固件。建议专用路径 `qcom/sm8550/xigua/a740_zap.mbn`。

只读查找 modem_a 中 a740/a730/gmu/zap/sqe 文件无结果，尚需检查本机
Android vendor 逻辑分区的固件文件。这不意味着手机所有原厂分区都没有
GPU 固件，也尚未验证固件认证。

## 后续实测顺序

1. 提取并记录本机固件的来源和 SHA256，准备标准 Mesa Freedreno 测试工具。
2. 在保持当前显示、触控、USB 配置的设备树上启用 GPU，并添加本机 zap 路径。
3. 启动后检查 GPU/GMU 绑定和固件认证，并用 DRM MSM 参数查询确认 GPU 740。
4. 用 Mesa EGL/GLES 做实际渲染与读回，确认 renderer 为 Adreno 而非软件渲染。

检查证据位于 `out/gpu-inspection-20261014/`，包括 live.dtb、
gpu-device-tree.json、device-state.txt、stock-firmware-list.txt 和 inspection.json。
当前阶段没有执行 GPU 渲染或压力测试。

后续本机 vendor_a 固件已提取完成，见
[GPU 固件提取记录](gpu-firmware-stock-20261014.md)。GPU 启用和固件认证仍待实测。

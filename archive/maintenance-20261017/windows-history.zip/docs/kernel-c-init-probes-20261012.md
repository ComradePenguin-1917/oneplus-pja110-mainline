# start_kernel 入口与 setup_arch 返回定位

## 本轮已到达的阶段

两份探针均通过同一实际测试 Image 的 QEMU 验证，并在实机出现用户观察到的约 5 秒自行反复重启：

| 探针 | 实机信号支持的结论 | 尚未覆盖 |
| --- | --- | --- |
| `start_kernel + 4`，保留 PACIASP | 汇编启动路径已完成任务、栈、TPIDR、异常向量、启动模式和 finalise_el2 设置，并调用 start_kernel | start_kernel 内的主要 C 初始化 |
| `start_kernel` 中 setup_arch 调用之后 | 初始 C 路径与 setup_arch 已返回 | jump_label_init、后续内存分配器、调度器、中断、控制台和驱动初始化 |

第二个探针是替换 setup_arch 返回后的 `bl jump_label_init`，并未执行 jump_label_init。前一条 BL 的目标已通过指令解码核对确实为本构建的 setup_arch。

同一构建的 setup_arch 源码包含早期 fixmap、设备树扫描、内存映射、按配置的设备树展开与 bootmem 初始化。本轮确认该函数返回，不能把所有可能的配置分支、设备属性或后续驱动探测都视为验证通过。

目前没有正常主线日志或用户态成功证据，不能宣称已经启动完成，也不能将故障精确归到 setup_arch 后的第一条指令。

## 镜像与位置

两轮均沿用可执行 init 区的对齐零填充探针位置 25451232，探针长度 68 字节，不使用 BSS。只有一条 4 字节分支与这段零填充变化；Image 头、长度和其他字节不变。vendor_boot、init_boot、DTBO 与已经通过 ABL 的对照完全相同；未写 logdump，未改 vbmeta。

- start_kernel 入口：替换偏移 24643748，原指令 `0xb0003380`，保留前一条 PACIASP。boot 镜像 SHA256 `6e034c3631be29e82751ca927c99eb5f427300ab24f6d831ed499e1875614d5c`。
- setup_arch 返回：替换偏移 24643856，原指令 `0x94006e45`。boot 镜像 SHA256 `b8fd67a0cbe77c45e6ed4113e360ab8f534148045ae564427b25004930f11002`。

QEMU 使用前述 PSCI SMC 后端和 `-no-reboot`，退出码均为 0，执行记录含 SMC 指令块。

| 版本 | QEMU 时长 | Image SHA256 |
| --- | --- | --- |
| start_kernel 入口 | 5.610 s | `938859009a1273ceb897aed424737b1e2a9739cc13b4b87fc158320c6591b93b` |
| setup_arch 返回 | 6.988 s | `dd75ef17e93430126a09a5389dc9282eabf548233724cb46763904b7cd7522b2` |

实机周期来自用户观察，没有外部精密计时。复位记录不是 PSCI 调用的唯一标识；结论综合探针延迟、QEMU 验证、实机输入读回及与无探针行为的差异。

## 中断、复测与采证

start_kernel 入口轮的首次采证遇到 ADB 断开，完整 8 MiB 引导历史读取不完整，未作为有效快照；当时恢复命令等候 fastboot 超时，没有完成写入。恢复 ADB 后补齐完整快照和实际测试镜像读回，再完成分区恢复及八分区哈希核对。

setup_arch 返回轮在用户离开期间已经完成刷写和启动，随后手机回到 Android A。因无人观察这一轮的重启节奏，没有仅凭回到 Android 就认定成功。用户回来后，核对仍驻留的测试镜像及 A 槽内容，仅重新切到 B 槽启动同一镜像，没有重复刷写。用户明确观察到约 5 秒自行重启后才记录为阳性阶段信号。

ADB 曾为 offline，使用 `adb reconnect offline` 恢复；失败的复测在读取状态时即退出，未切槽。复测后的完整引导历史另存为 `history-retest/`，保留首轮无人观察的 `history/`。

## 证据和恢复

- start_kernel：`out/kernel-start-kernel-probe-20261012/` 与 `out/kernel-start-kernel-probe-experiment-20261012/`。
- setup_arch 返回：`out/kernel-after-setup-arch-probe-20261012/` 与 `out/kernel-after-setup-arch-probe-experiment-20261012/`。
- 对应源码及反汇编：`out/kernel-entry-probe-20261012/start-kernel-disassembly.txt`、`init-main.c`、`arm64-setup.c`；读取前核对 WSL 构建 Image 与 r1 原始哈希一致。

采证核对实际 boot_b 前缀和其他三个 B 槽分区全哈希；A 槽保持本轮前的内容。最终恢复四个 B 分区、切回 Android A，八分区哈希与实验前值匹配。

下一轮可将阶段点推进到更后面的 C 初始化，例如调度器初始化完成或 rest_init 入口，再决定需要细分哪一段；不能依据本轮结果直接归因于 UFS 或某个驱动。

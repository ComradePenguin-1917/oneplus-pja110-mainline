# async_synchronize_full 返回点

上一轮 kernel_init_freeable 返回点已有实机阳性复位观察、镜像读回与恢复校验。本轮跨过接下来的 async_synchronize_full，替换 `kernel_init + 0x28`（Image 偏移 16692228）的 `mov w0,#2`。解码前一条 BL `0x97c39642` 并核对本构建 async_synchronize_full 符号。

位置仍在 free_initmem 之前，沿用未释放的 init 可执行区零填充探针。boot 镜像 SHA256 `e1992ad10602f768dc811ab849b6e16f14916e3cdbdfc7cfc666f42d2864250f`；实际 Image 经 QEMU 验证，退出码 0、执行记录含 SMC，时长 52.844 秒，SHA256 `d85c0cf28af6200289f44eac5ae34680d21b747de7b4b43bbf57e8ad5263b505`。

镜像与实机证据分别位于 `out/kernel-after-async-sync-probe-20261012/` 和 `out/kernel-after-async-sync-probe-experiment-20261012/`。

用户观察到仍自行反复重启，间隔接近 20 秒。完整 8 MiB 引导历史已读取，实际 boot_b 前缀及其他三个 B 分区哈希匹配测试输入。结合实际 Image 的 QEMU 验证与复位观察，支持实机已走到 async_synchronize_full 返回点；间隔是用户近似观察，未外部计时，也不能单独据此确定某个异步任务耗时。

已恢复 Android A，八个启动分区哈希均与本轮 preflight 相同。最终结果保存于证据目录 result.json。后续边界在 free_initmem、mark_rodata_ro 及 run_init_process 路径；free_initmem 之后不再允许使用当前 init 区探针，需要选择常驻可执行位置并重新验证。

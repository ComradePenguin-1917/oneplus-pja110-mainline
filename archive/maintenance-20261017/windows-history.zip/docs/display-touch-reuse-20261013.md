# 显示与触控驱动复用审查

2026-10-13。范围为源码复用审查和触控候选的原样外部模块构建；没有连接手机、加载候选模块或刷写分区。当前 #14 的已验证显示、触控、SSH 镜像保持原样。

## 结论

触控应优先采用 Aston 已移植的 Synaptics TouchCom 驱动，保留其协议核心、配置解释器和 input 实现；当前自写 `pja110-s3910.c` 作为已验证对照，待候选通过实测后替换。

显示没有在本次审查范围内找到匹配 AA536_P_3_A0001 的直接替换驱动。可复用现成面板生成器和标准 DRM panel 结构，但需要本机命令、供电和 Iris7 旁路适配；不能直接替换为 Aston 的 AA551 面板。不能把这个有限范围的结果表述为所有项目都没有支持。

## 源码版本与审查范围

| 来源 | 固定版本 | 审查内容 |
|---|---|---|
| Aston | `5d5c840896bb49291ae4578acefd5a3ec65524f6` | 完整 drivers 子树中的 panel、touchscreen、rmi4 文件清单，258 项；候选源码及 Aston 板级 DTS |
| 本次取得的 Linux master 快照 | `24a19b953e2a3d0ea5a8c4951a0ab8f32720c907` | 相同三个目录的完整文件清单，285 项；相关候选源码 |
| OnePlus 官方 Ace2Pro | `f034653c086942be9398171cfa7477ddbe2d9504` | 已保存的原厂 panel DT、Iris7 和 synaptics_hbp 源码 |
| linux-mdss-dsi-panel-driver-generator | `28c4df25628f6241ce925af15637a443ea2b3bb5` | 官方仓库顶层 Python 源码、README 和 COPYING，12 项 |

库存来自未截断的 GitHub drivers tree。候选下载与 tree 中 Git blob 校验；生成器也校验 Git blob。资料保存在 `out/display-touch-reuse-20261013/`。Aston 树版本与此前 USB 对照相同，没有将当前分支状态混入审查。

## 触控：现成候选值得采用

Aston 的以下三份文件组成一个现成主线移植候选，保留 Synaptics GPL 许可证及版权：

- `drivers/input/touchscreen/syna_tcm2.c`，Git blob `4255bb72b6fab1c26092d3353887dc99ae1e1a1d`。
- `drivers/input/touchscreen/syna_tcm2.h`，Git blob `2294f1e64f8060a4fdb329b6dd9a0884259d7e7d`。
- `drivers/input/touchscreen/syna_tcm2_spi.c`，Git blob `676f0bda4e60dcf38b2395773590530b9d55d395`。

匹配证据：

- SPI compatible 为 `synaptics,tcm-spi-hbp`，与本机原厂已启用节点一致。
- TCMv1 marker 0xa5、padding 0x5a、Identify、应用信息及报告配置解释器，与本机实测的 TCMv1 Application Firmware 匹配。
- Aston 板级 DTS 使用同一 SPI4、IRQ GPIO25、reset GPIO24、AVDD GPIO10、L4B 1.8V；SPI mode0，供电等待200ms，复位低10ms后等待80ms，均与本机已验证路径一致。
- 已有标准 input 多点输出及报告配置解析，不需要继续自行编写协议和触点解析器。
- 单靠这些证据不能确认其支持本机所有固件行为，尤其不能把原样编译当成触控实测通过。

### 原样构建结果

`tools/wsl_audit_aston_touch.sh` 将三份未经修改的文件编译成 `synaptics-aston-audit.ko`，在当前 Linux 6.14 #14 构建环境通过。构建前后 Image 与 .config SHA256 均相同，没有刷写或加载模块。

构建日志保留普通 Module.symvers 缺失警告；实际显式使用当前树的 `vmlinux.symvers` 解析导出符号，没有设置忽略 unresolved symbols 的选项。完整日志：`aston-touch-unmodified-build.log`。

### 替换前的必要修改与检查

1. 本机已验证的实现显式设置 `DC_CONTROL_LBP_HBP=2` 并启用标准 REPORT_TOUCH，未单独证明省略设置也能工作。Aston 的现成核心没有找到等价 LBP 设置；应复用 OnePlus 官方 `syna_dev_disable_hbp()` 的设置语义，通过现成 write_message 路径执行，不能假设上电默认输出足够。
2. Aston 使用 `touchpanel,panel-coords` 做坐标缩放，缺省为0；不能照搬其20224/44480。应采用本机实测的12399/27719并核对范围/端点，或改用标准 touchscreen 属性。
3. `syna_dev_disconnect()` 取消 `reflash_work`，但这份精简候选未找到对应 INIT_DELAYED_WORK。应修复这一遗留清理路径，再测试卸载/关闭。
4. `syna_spi_remove()` 在注销子 platform device 之前释放 GPIO/电源资源，而子驱动 disconnect 仍会访问它们；应核对并修正释放顺序。
5. SPI probe 多个直接失败返回未释放已分配 platform device/资源；core probe 失败路径重复销毁 mutex。应修复资源回滚。
6. application setup 失败后的 connect 分支可能继续注册 IRQ；应让失败正确传播。核对 max_objects、配置解析边界、workqueue 清理和 IRQ 排空。
7. 实机先只使用应用态与 RAM 报告配置，不引入固件自动升级。官方完整 HBP 默认有 STARTUP_REFLASH，不能直接全套照搬该默认行为。

这些是必要兼容和生命周期修改，应保留现成协议/解析逻辑和可审查的补丁。之后分别验证坐标、单双指、松手释放、重启与自动加载，再替换已验证模块。

本次 Linux master 清单没有找到 TouchComm/TCM 驱动。主线 RMI4 是不同协议，不能仅凭 Synaptics 品牌替代本机已确认的 TCMv1。另发现公开的 TCMv1 I2C 驱动投稿线索，它的总线与本机 SPI 不符，未作为可直接部署候选；不宣称其已合入或已验证。

## 显示：可复用结构，不能照搬其他面板数据

Aston DTS 实际引用 `panel,aa551-p-3-a0004-dsc`，对应 `panel-aa551-p-3-a0004-dsc.c`（Git blob `0313fabf6b531b15cb9039987055cd75b3aa02d7`）。该驱动注明由 linux-mdss-dsi-panel-driver-generator 生成。

| 参数 | PJA110 已验证 AA536 | Aston AA551 |
|---|---|---|
| 像素尺寸 | 1240×2772 | 1264×2780 |
| DSC | 1.1 SCR1、10bpc、8bpp | 1.2、10bpc、8bpp |
| slice宽×高 | 620×44 | 632×20 |
| 额外板级控制 | GPIO90 vout、Iris7模拟旁路 | 该 panel 文件没有对应 Iris7/vout 实现 |

AA551 的命令表、时序、DSC 和供电值不能直接用于 AA536。其标准 prepare/unprepare、backlight、DRM 注册结构可以参考复用。Aston 的 NT36532E 驱动则针对 Xiaomi Sheng，3048×2032、8bpc、slice762×16，不是本机候选。

本次主线 panel 清单未发现 AA536 的精确驱动。检索到的 Fairphone NT37705 投稿支持另一块1116×2484面板，也不能当成 AA536 支持；AA536 的型号字符串及相邻原厂 NT37705 文件不足以证明控制器完全相同。

### 生成器是可复用的现成基础

固定版本生成器能读取 Qualcomm 原厂 DT，生成 DRM panel 生命周期、供电、背光、初始化命令与 DSC 配置。源码 `panel.py` 解析 DSC，`driver.py` 设置 slice/bpc/bpp，`mipi.py` 区分 DCS 与 generic 写。

仍有明确边界：`driver.py` 的 slice_per_pkt 留有 TODO；生成器不包含本机 Iris7、GPIO90 vout 或当前6.14 MSM 的10bpc/SCR1兼容补丁。多模式、包类型、VC、等待时间及vendor batching语义需与已逐字节核验的原厂命令重新对照。未在本轮生成、编译或部署 AA536 替代驱动。

建议以固定版本生成器作为标准结构基础，保留已验证的 AA536 原厂数据和必要板级适配，逐项核对差异后再对照实测。现有DSI速率补丁的必要性尚未被单独排除，不应在结构整理时顺带删除。

## 后续顺序

先适配和实测 Aston 触控候选，替换收益更明确；显示保持已验证版本，准备生成器对照和补丁整理。此审查不表示已完成驱动替换或上游化。

源码链接：[Aston触控核心](https://github.com/jiganomegsdfdf/aston-mainline/blob/5d5c840896bb49291ae4578acefd5a3ec65524f6/drivers/input/touchscreen/syna_tcm2.c)、[Aston面板](https://github.com/jiganomegsdfdf/aston-mainline/blob/5d5c840896bb49291ae4578acefd5a3ec65524f6/drivers/gpu/drm/panel/panel-aa551-p-3-a0004-dsc.c)、[现成面板生成器](https://github.com/msm8916-mainline/linux-mdss-dsi-panel-driver-generator/tree/28c4df25628f6241ce925af15637a443ea2b3bb5)、[NT37705投稿](https://lore.gitlab.freedesktop.org/drm-ai-reviews/20260501-fp6-panel-v1-2-e09cb05651cc%40fairphone.com/)。

# 2026-10-12 命令行修正实验

## 预检

- ADB 序列号 `bc7a542e`，root 可用；A 槽 Android 正常启动，电量 31%。
- fastboot：解锁，当前槽 a，a 标记成功，b 非 unbootable。
- 当前 `boot_b` 与历史备份不同，已保存完整 192 MiB 副本到 `out/cmdline-experiment-20261012/boot_b-before.img` 并与设备 SHA-256 校验一致。
- `vendor_boot_b`、`dtbo_b`、`init_boot_b` 与历史备份一致。
- `boot_b-norootcmdline.img` 的 kernel 段与修正后的 Image 完全相同。
- 新旧 Image 只差三处相同命令行字面量：移除 `root=PARTLABEL=win rootwait ... quiet splash`，替换为串口调试参数并以零填充保持长度。
- Image 包含当前 initramfs 压缩归档的完整字节，归档包含预期 poweroff 逻辑。

## 计划

仅实验 B 槽：写自定义 vendor_boot、修正命令行的 boot，擦除 dtbo，切换 B 并观察。第一次保持 init_boot 不变。

## 传输中断及恢复

第一次 fastboot 调用的标准错误被 PowerShell 的 Stop 错误处理捕获并终止；改用 Python subprocess 后，重新发送 vendor_boot 时发生 `Write to device failed (no link)`，USB 连接消失。

该次中断时未执行 boot_b 写入、dtbo_b 擦除、set_active b 或实验重启。用户重新插拔 USB 后恢复 fastboot 连接，当前槽仍为 a；先成功刷回原厂 vendor_boot_b，再继续测试。

## 实验结果

- 成功写入测试 vendor_boot_b、boot_b，擦除 dtbo_b，set_active b 并 reboot。完整日志：`flash-test-retry.txt`。
- 重启后重新出现 Android ADB。回读为 `_a`、`sys.boot_completed=1`、内核 `5.15.123-android13-8-droidspaces`，pstore 为空。未获得主线内核输出或 shell。
- 回读 vendor_boot_b SHA-256 与测试镜像一致，dtbo_b SHA-256 为全零分区对应值。
- 额外检查发现：实验前保存的 boot_b 前缀已经与 `boot_b-norootcmdline.img` 完全相同。本次不是首次使用该命令行镜像，而是重新验证这一完整启动组合。此前没有记录不能证明此前没有执行过。

## 最终恢复

已刷回本次 boot_b 快照、原厂 vendor_boot_b 和 dtbo_b，设置 a 并重启。设备返回 A 槽 Android；boot_a、boot_b、vendor_boot_b、dtbo_b、init_boot_b 全部 SHA-256 与本次实验前一致。证据：`restore-final.txt`、`restored-device.txt`。

本次 boot_b 快照保存在 `out/cmdline-experiment-20261012/boot_b-before.img`，其内容与旧 backup/boot_b.img 不同。完整预检、实验和恢复日志保存在同一目录。

## 判读边界

回退到 Android 不能定位内核失败阶段。外部原厂 ramdisk 仍可能覆盖内嵌 /init，因此首次测试也不能单独验证 poweroff 信号的有效性。

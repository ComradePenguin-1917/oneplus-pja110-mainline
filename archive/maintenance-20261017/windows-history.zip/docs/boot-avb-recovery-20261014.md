# 显示复用实验后的启动回退：AVB 尾部损坏

2026-10-14。Android root 读取的完整 oplusreserve1 历史包含 B 槽错误：

```
boot_b: Error verifying vbmeta image: invalid vbmeta header
HandleActiveSlotUnbootable_vb2: Rebooting
```

这是进入 Linux 之前的引导校验失败。此前关于显示驱动、三分区不兼容、没有同时工作的基线或重试计数耗尽的断言没有证据支持，已被这次诊断纠正。USB、AA536 显示与 Aston 240Hz 在此前已同时实测成功。

直接原因：`package_generated_panel.py` 将生成版 boot 镜像零填充至整个192MiB分区，覆盖原有有效的 AVB 元数据和末尾 AVBf footer。随后刷入约34MiB旧 boot 仅覆盖前缀，无法恢复损坏的尾部，因此旧内核也在 ABL 阶段失败。生成版面板代码尚未获得本次实机验证，不能由这些回退判定它不工作。

修复：以备份 `backup/boot_b.img` 为底，只用已验证 round4 boot 替换前缀，保留其余字节，包括原厂 AVB0（偏移53243904，长度2432）和AVBf。保留签名不代表改后内容哈希有效；仍依赖已解锁设备允许内容哈希不匹配的既有行为。没有修改独立 vbmeta 分区。

同时纠正触控启动镜像选择：`touch-port/verified-autostart` 是旧 `mainline_touch_probe`，真正固定240Hz的 Aston 镜像在 `aston-touch-240hz-20261013/verified-autostart/init_boot_b-aston-240hz.img`。

恢复后的组合：

- boot_b：`out/boot-recovery-diagnosis-20261014/boot_b-working-restored-avb.img`
- vendor_boot_b：`out/touch-port-20261013/verified-autostart/vendor_boot_b-touch.img`
- init_boot_b：`out/aston-touch-240hz-20261013/verified-autostart/init_boot_b-aston-240hz.img`
- dtbo_b：原已验证内容，未修改。

恢复后 SSH实测 Linux6.14 #14，USB configured，Aston码3读回验证成功，DRM connected；用户确认正常六色彩条。完整八分区校验及启动日志保存于 `out/boot-recovery-diagnosis-20261014/`。

生成版打包脚本已改为保留原厂AVB尾部，不再零填充分区。后续显示复用实验必须使用修复后的打包方式和上述可复现基线。

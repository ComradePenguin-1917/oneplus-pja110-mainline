# init_boot 与 /init 执行验证：2026-10-12

## 结论

**通过 init_boot_b 控制实际执行的 /init，已在原厂 Android 5.15 内核上验证成功。** 主线 Linux 尚未在本轮测试，不能把这个结果当作主线进入用户态的证明。

证据分为两层：

1. 仅修改 init_boot ramdisk 的 build.prop，B 槽原厂 Android 完整启动后 `ro.bootimage.build.tags=x`。证明修改的 generic ramdisk 被使用。
2. 用不依赖解释器和动态库的 ARM64 ELF 替换 /init，调用 `setdomainname("pja110-init-executed", 20)`，随后以原 argv/envp 执行逐字节保留的 `/init.real`。B 槽原厂 Android 完整启动。

Android 启动后把 domainname 改回 `localdomain`，但固定长度 UTS 字段保留了旧字符串尾部。因此用 uname(2) 读取整个字段作对照：

```
原厂内核 + 原厂 init_boot：localdomain\0\0\0\0...（尾部全零）
同一原厂内核 + 包装 /init：localdomain\0executed\0\0...
```

包装探针是唯一设置该标记的代码，读取助手只调用 uname 和 write，不设置字段。同一 B 槽、同一原厂内核的原始 ramdisk 基线不含标记。这个正对照证明包装 /init 执行过。直接 cat `/proc/sys/kernel/domainname` 在无 root B 槽被拒绝，因此采用读取助手。

## 已解决的构建错误

旧 `build_init_marker_test.py` 的 make_entry 将新文件大小写入 CPIO `c_check`（fields[12]），未更新 `c_filesize`（fields[6]）。已修复并逐项重解析归档，核对未修改文件字节一致。此前生成器产出的旧标记镜像不能作为可靠对照。

包装镜像保留原厂 init 为 /init.real，新 /init 为静态 ELF。压缩流增长到 2331239 字节，仍在原 ramdisk 2334720 字节的页分配范围内；同步更新 header ramdisk_size，后续签名区域、文件大小不变。完整解压、CPIO 回读及 ARM64 指令反汇编均通过。

## 没有成立的信号

另一个原生 /init 直接调用 reboot(RESTART2, "bootloader")，未观察到预期 fastboot 连接，后来回到 A 槽。相同二进制在 A 槽正常 Android 中通过 root 执行，能够进入 fastboot；无 root shell 执行返回 EPERM。

**成熟 Android 中调用成功，不代表原厂内核的早期 PID1 阶段也能产生相同可见信号。** 本轮没有定位这一差异的原因，不能用其无信号结果判定 /init 未执行。该测试没有主线内核参与。

## 资产与复现

- `tools/build_init_marker_test.py`：原厂属性标记镜像。
- `tools/build_native_init_probe.py`：原生 reboot 探针，保留汇编验证。
- `tools/build_init_domain_probe.py`：原生包装 /init、UTS 读取助手及归档回读验证。
- 所有实验日志、反汇编、镜像、读回结果：`out/init-experiment-20261012/`。
- `domain-confirmation.txt`：包装实验输出，含 `localdomain\0executed`。
- `stock-B-domain-baseline.bin`：同一原厂内核基线，尾部全零。
- `marker-result.txt`、`marker-and-native-shell.txt`：属性标记。后一个文件的 probe_exit 字段受到宿主 PowerShell 插值影响，应忽略；有效的初次无 root 探针执行在终端中明确返回 `probe_exit=1`。

## 恢复与下一步

实验只写 B 槽 boot/init_boot。最终恢复 boot_b 为本次实验前快照（不是旧的原厂 backup/boot_b.img）、init_boot_b 为已校验原厂备份，切回 A 槽。最终分区哈希证据保存在 `restored-device-final.txt`。

下一步可以让主线内核通过这条已经验证的 init_boot generic ramdisk 路径获得明确的 /init，避免原厂 /init 覆盖内嵌归档。仍需对主线的观测信号做有效对照；本轮不证明主线内核曾执行指令，也不证明 USB/UFS 可用。

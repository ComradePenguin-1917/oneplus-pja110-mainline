# Aston 6.14 USB 补丁对照

检查时间：2026-10-13。仅下载和读取源码、配置及已打包的镜像；没有刷写或调整手机。

## 结论

在 `aston-6.14` 的固定提交中，没有发现相对原版 Linux 6.14 的 DWC3、USB gadget 或 Qualcomm USB PHY 修复。不能把我们的 ACM 大流量校验失败解释为“漏合入了 Aston 的 USB 驱动补丁”。这不证明控制器稳定，也不证明 Windows/ACM 是唯一原因。

## 比较对象与方法

- 原版 Linux 6.14：`38fec10eb60d687e30c8c6b5420d86e8149f7557`。
- Aston 分支快照：`5d5c840896bb49291ae4578acefd5a3ec65524f6`。
- 本地实际编译树：WSL `/home/comrade_penguin_desktop/workspace/PJA110-Mainline/linux`，Makefile 确认 6.14.0；Windows 下的局部 `linux/` 参考文件不作为编译树证据。
- 通过 GitHub Git Trees API 获取完整 `drivers/usb` 和 `drivers/phy/qualcomm` 文件清单，确认未截断，逐项比较 Git blob ID。本地使用 `SHA1("blob " + 长度 + NUL + 文件内容)` 对照。
- 补充比较 GCC、RPMh regulator/power domain、SM8550 interconnect、BCM voter、PMIC GLINK、PDR 和 Qualcomm ARM SMMU 驱动的文件内容。
- 直接比较最终提交的文件，避免将版本更新混入设备补丁。Aston 历史使用 tree-wide 源码更新；GitHub compare 返回 diverged、91 个 head 侧提交和 300 个截断文件，不能据此当作“基于 v6.14 的 91 个补丁”或完整差异清单。

固定上游：[Aston](https://github.com/jiganomegsdfdf/aston-mainline/tree/5d5c840896bb49291ae4578acefd5a3ec65524f6)、[Linux 6.14](https://github.com/torvalds/linux/tree/38fec10eb60d687e30c8c6b5420d86e8149f7557)。

## 源码结果

| 范围 | Aston 与原版 6.14 | 本地实际构建树 |
| --- | --- | --- |
| USB 的 861 个原有文件 | 全部相同，含 DWC3、ACM/u_serial、ECM、NCM、RNDIS、Type-C | 仅 ep0.c 和 u_serial.c 的诊断日志不同 |
| Qualcomm PHY 的 85 个文件 | 全部相同，含 eUSB2 repeater、SNPS eUSB2、QMP USB/DP | 全部相同 |
| 额外 `drivers/usb/gadget/u_f.h` | Aston 增加一个头文件；未发现 USB C/H 源码引用 | 不存在，原版也不存在 |
| GCC SM8550 | 两个 UFS GDSC 的 RETAIN_FF_ENABLE 改成 ALWAYS_ON | 使用原版；USB GDSC 未被 Aston 修改 |
| RPMh regulator | 增加 PMR735D regulator 匹配和 LDO 定义 | 使用原版；不是现有 USB 供电轨修改 |
| RPMh power domain、SM8550 interconnect、ICC RPMh、BCM voter | 相同 | 相同 |
| PMIC GLINK、altmode、PDR interface、Qualcomm ARM SMMU | 相同 | 相同 |

本地两处源码差异已导出 patch：ep0.c 增加 `PJA_USB_SETUP` 输出；u_serial.c 增加完成请求的 actual/length/zero 输出，没有控制逻辑改动。诊断输出本身可能改变时序，本次内容审计不能评估这种影响。

## 设备树结果

`sm8550.dtsi` 中完整 `usb_1`、`usb_1_hsphy`、`usb_dp_qmpphy`、`apps_smmu` 节点在 Aston、原版、本地三者间相同。`pm8550b.dtsi` 也相同。Aston 在 SoC DTSI 中还有 CPU/cache/DDR、相机等修改，但这些 USB/SMMU 节点未变。

Aston 和 xigua 板级 DTS 都启用 USB2 PHY、eUSB2 repeater 和 USB3/DP PHY，引用相同的五条 USB 电源轨，供电连接相同。Aston 没有额外的 repeater 调谐属性。

发现两处供电属性差异，并核对了当前诊断构建的已打包 vendor_boot 内 DTB：

| 属性 | Aston | 我们的打包 DTB |
| --- | --- | --- |
| repeater 的 vreg_l15b_1p8 | 1.8V，regulator-always-on | 1.8V，无 always-on |
| USB2 PHY 的 vreg_l1e_0p88 | 880000–912000 uV | 880000–880000 uV |

另外三条 USB 电源轨的电压范围一致。打包 vendor_boot SHA256：`ee860c10a2b8eea45e504ae4808edd813708670ae768af01e96f940cc5dac44a`，已与构建 manifest 匹配。本轮未重新读取手机分区，因此这里报告的是打包镜像内容，不是新的现场读回。

电压范围只描述允许值，不证明 Aston 实机正在使用 912mV。无 always-on 也不代表 USB 工作期间电源会关闭，启用的消费者通常会持有 regulator 引用。机型电气差异需要结合 xigua 原厂配置核对，不能直接照搬。

我们打包 DTB 还采用固定 peripheral/high-speed 的 bring-up 配置；Aston 板级树保留 Type-C/PMIC GLINK 动态拓扑。不能仅根据源码中的板级节点相同，就认定两边实机运行状态相同。

## 对下一轮实验的意义

1. 无需为了“补上 USB 修复”整体换用 Aston fork；本次没有找到这种补丁。
2. 优先在同一内核、同一线和接口上做 NCM 或 gadget SourceSink/Loopback 校验，与 ACM 对照，区分串口功能路径和共用 USB 路径。
3. 若共用路径仍失败，再做 USB runtime PM 对照，以及单独的供电保持实验。always-on 和电压范围差异只作为待验证线索，不合并改动，不直接提高电压。
4. 此次审计覆盖上述 USB 相关源码与依赖，不是 Aston 全内核补丁审查，也没有获得其长期 USB 压测证据。

## 可复现证据

- `tools/compare_aston_usb.ps1`：下载固定提交的树清单和不同文件、依赖文件。
- `tools/check_local_usb_sources.py`：WSL 只读核对实际编译树并导出本地文件。
- `tools/summarize_aston_usb.py`：离线生成差异、节点结果，并核对打包 DTB。
- `out/aston-usb-comparison-20261013/`：refs.json、两边树清单、different-files.json、local-comparison.json、summary.json、源码快照、diffs/。

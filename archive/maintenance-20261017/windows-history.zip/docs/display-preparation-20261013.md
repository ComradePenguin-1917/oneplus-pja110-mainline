# PJA110 显示移植准备

## 已取得的证据

- 原厂 ABL 日志与原厂运行时 DTB 指向 AA536_P_3_A0001 面板。型号字符串不能单独证明面板的控制器型号。
- 已解析原厂面板及相关供电节点共 20 个，导出 122 组命令表（包含空表）。原始字节、包类型、虚拟通道、vendor flags、发送后等待时间及 payload 均保留。经原厂 parser 核对，header[3] 是 flags，0x40 表示 batching，不是 ACK 请求。
- 分辨率 1240×2772，存在 60/90/120 Hz 时序及另一组 120 Hz 时序。参数位于 `qcom,mdss-dsi-display-timings` 子节点，旧脚本只读父节点会漏掉它们。
- DSC 1.1、SCR 1、10 bits/component、8 bits/pixel、slice 620×44、每包两片；原厂报告两个 DSC encoder。主线配置需按照主线 DPU/DSI 拓扑重新核对，不能直接复制 encoder 数量。
- 原厂 reset 序列：高 2 ms、低 5 ms、高 25 ms；原厂 DTB reset GPIO cells 为 `[31,133,0]`，首项是 phandle，必须解析控制器后再移植。
- 原厂 xigua 供电表记录 vddio 1.8 V、vci 3.0 V；实际 regulator 引用与启停顺序仍需核对。
- 当前主线实机 DTB 的 MDSS、DSI0/1、DSI PHY0/1 均 disabled，没有 panel 子节点；`/sys/class/drm` 只有 version。当前黑屏不构成面板驱动失败的证据，因为显示链路尚未启用。

## 官方源码

已下载并固定 [一加官方 Ace2Pro Android 14 分支](https://github.com/OnePlusOSS/android_kernel_modules_and_devicetree_oneplus_sm8550/tree/f034653c086942be9398171cfa7477ddbe2d9504)，提交 `f034653c086942be9398171cfa7477ddbe2d9504`。

`out/display-baseline-20261013/oneplus-source/manifest.json` 记录 16 个选定参考文件及 Git blob/SHA256。稀疏 checkout 另包含显示 DTS 和 DSI 解析代码。

- `panel/dsi-panel-AA536-P-3-A0001-dsc-cmd.dtsi`：面板模式和初始化命令。
- `xigua-22851-display-kalama-overlay.dtsi`：板级供电、TE 与时钟配置。
- `pxlw-xigua/dsi-panel-pxlw.dtsi`：Iris7 配置和主/次显示选择。
- `pxlw-iris7-kalama-common.dtsi`：Iris reset/wakeup/供电 GPIO 配置。
- `display-drivers/msm/dsi/dsi_panel.c`、`dsi_parser.c`、`dsi_display.c`：原厂命令及初始化语义参考。

Iris7 是负责插帧等显示处理的独立芯片。源码明确包含 Iris7 lightup 配置、供电和 reset/wakeup GPIO。其实际旁路路径、启动状态以及最小驱动需求尚未验证，不能假设只发送面板 DCS 命令即可点亮，也不能据此断言必须完整移植原厂 Iris 驱动。

## 下一次显示实验

1. 先核对原厂运行时 DTB 中面板/DSI 的 regulator、GPIO、端点和 Iris 旁路设置；比对下载源码与实机导出的命令字节。
2. 准备单一 60 Hz 模式的 DRM panel 驱动，保留原厂初始化命令的包类型和延迟。先处理供电、复位、DSC、睡眠退出/显示开启及最低亮度。
3. 为 MDSS、DSI0、DSI PHY0 建立主线供电与端点配置。不要同时开启全部 DSI/DP 输出，也不要把 DP aux_bridge 延迟探测直接视为内屏故障。
4. 用固定 NCM/SSH 镜像读日志；先确认 DRM connector 出现和 KMS 测试图像，再推进触控、高刷新、Iris 插帧和图形桌面。

本轮只做资料准备，没有启用显示硬件或修改显示设备树。

## 产物

- `out/display-baseline-20261013/vendor-display.json`：原厂节点与原始属性。
- `dsi-commands.json`：完整命令解码。
- `timings-dsc.json`：模式/DSC 参数。
- `mainline-live.dtb`、`mainline-state.txt`：本轮主线实机基线。
- `tools/extract_display_baseline.py`、`tools/fetch_display_sources.py`：可复现提取与源码固定脚本。

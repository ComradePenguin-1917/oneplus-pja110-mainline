# PJA110 stock ADSP offline audit

Scope: computer-only inspection. No phone connection, firmware installation,
remoteproc startup, partition write or charging parameter change in this audit.

Latest ownership finding: this firmware has a project-22851-specific branch
that disables the BQ initialization path before I2C setup and selects an ADC
voltage path. This qualifies the earlier unresolved-ownership discussion
below; see "Project 22851 guard" at the end. Actual current-boot SMEM contents
and charging behavior have not been verified.

Run `python tools/audit_stock_adsp.py` to verify the archived firmware and
prepare the unchanged split firmware files under
`out/battery-bringup-20261016/charger-source/firmware/qcom/sm8550/xigua/`.
The JSON report is `offline-adsp-audit.json` in the same charger-source directory.

## Confirmed

- All 63 firmware SHA256 values match the phone extraction manifest. This
  establishes transfer integrity, not independent firmware authenticity.
- ADSP has 59 program headers, including non-load metadata/hash entries.
  All required nonempty load-segment files exist with exact expected sizes.
  The load range is 0x9ea00000--0xa3280000, span 0x4880000 (72.5 MiB),
  exactly the first ADSP memory-region in the prepared battery DTB.
- ADSP DTB firmware loads at 0x9e980000; page-aligned end 0x9e983000,
  within its 0x80000-byte reservation. It contains an embedded FDT at
  offset 60 with 31 nodes, including original battery-manager configuration.
  The decoded properties are archived without changing their values.
- The local upstream Qualcomm MDT loader supports split MDT/bNN files;
  no conversion to a combined MBN is necessary for this candidate.
- The stock image contains `msm/adsp/charger_pd`, the exact domain requested
  by upstream pmic_glink.c. The compiled kernel config includes
  CONFIG_QCOM_PD_MAPPER=m; local qcom_pd_mapper.c already has the SM8550
  charger domain mapping. No new service mapper needs to be invented.
- Standard battery property IDs 0--23 and USB property IDs 0--9 agree
  between local upstream qcom_battmgr.c and pinned OnePlus SM8550 headers.

## Missing runtime path and limits

The currently prepared DT disables ADSP. Earlier runtime inventory showed
no remoteproc/rpmsg devices and only GPU firmware installed. The packaged
kernel config disables CONFIG_BATTERY_QCOM_BATTMGR. These are established
missing dependencies; they do not prove the sole cause of poor charging.

The upstream battmgr driver has no set_property callback. The OnePlus source
also implements OEM gauge initialization (BATT_ADSP_GAUGE_INIT), charging
enable (BATT_CHG_EN), authentication and VOOC-specific interfaces. Matching
standard query IDs therefore does not establish full OEM charging support.
Do not send guessed OEM writes or copy charging limits from another phone.

Firmware strings and embedded configuration are static evidence only.
Secure-monitor authentication, ADSP startup, service registration, live
telemetry, ownership of the direct I2C gauge, and sustained net charging
must be checked on-device before declaring this path usable.

Next candidate should retain this phone's original split firmware and DTB,
enable the existing SM8550 ADSP and standard battmgr dependencies, verify
the kernel/module ABI, and preserve rescue B. Before starting ADSP, check
shared gauge/I2C access: the firmware may access the same gauge as Linux.
No such candidate was flashed during this audit.

Primary local sources: qcom_q6v5_pas.c, mdt_loader.c, qcom_pd_mapper.c,
pmic_glink.c, qcom_battmgr.c, oplus_battery_sm8550.c/.h under the archived
charger-source directory; battery-0.dtb; the device package kernel config.

## Module identity and gauge ownership follow-up

The actual pmbootstrap `linux-oneplus-xigua-6.14-r0.apk` was inspected, not
the older debug #24 build. APK SHA256:
`82fdfd11887d839ba6b06e3c52b45876b04ab1305f7aa5bd01594805d723565d`.
Its vmlinuz SHA256 is
`c4c2ef266c6a98bec1b7f99b08db6af265a1a2e64a6111640886f4149d38357b`,
exactly matching the verified native-A preparation manifest.

All nine modules in the dependency closure of qcom_q6v5_pas,
qcom_pd_mapper and bq27xxx_battery_i2c are present in that same APK and have
`6.14.0-oneplus-xigua SMP preempt mod_unload aarch64` vermagic. The correct
SM8550 ADSP binding belongs to qcom_q6v5_pas, not qcom_q6v5_adsp (whose
aliases target other non-PAS devices). qcom_battmgr is absent, consistent
with the disabled build option.

This establishes baseline package consistency, not validation of a newly
built battmgr module. CONFIG_MODVERSIONS is disabled; matching vermagic by
itself cannot validate arbitrary foreign modules. A future module must be
built from the exact package source/config/toolchain or shipped with its
matching rebuilt kernel. The pmbootstrap build source tree and Module.symvers
were not found in the checked usual locations. The attempted live SSH module
inventory timed out; no fresh on-phone module hash comparison is claimed.

Gauge ownership has significant but incomplete evidence:

- PJA110 factory `oplus-chg-22851.dtsi` explicitly sets
  `oplus,adsp_chg_use_ap_gauge` and configures the AP I2C gauge at 0x55.
- In factory battery_chg_probe(), that property skips registration of the
  alternative gauge implementation whose operations read ADSP messages;
  probe instead requires an already registered gauge. This supports the
  AP gauge interpretation, but is not a DSP bus-access prohibition.
- Stock ADSP segment adsp.b18 contains BQ27541/BQ28 family I2C read/write,
  initialization and SMEM-related strings. These demonstrate included code
  paths, not that those paths execute on this device at runtime.
- The inspected upstream geni I2C driver has local spinlocks and no
  hwspinlock coordination; the factory AP gauge uses chip_mutex around its
  I2C accesses. Neither inspected lock proves cross-processor exclusion.
- The factory probe sends BATT_ADSP_GAUGE_INIT. Subsequent disassembly below
  identifies a BQ initialization handler, subject to a project guard. The
  command must not be treated as a generic telemetry subscription.

The AP-to-ADSP gauge-data handoff and the effective firmware-side ownership
selection remain unresolved. There is no confirmed live bus collision,
but simultaneous direct access is not cleared for testing. Do not disable
the existing low-battery monitor just to remove this uncertainty. Resolve
ownership/initialization first, then design a bounded single-owner test.

Evidence: `module-and-gauge-audit.json`, `packaged-module-audit.json`,
`packaged-kernel-identity.json`, `firmware-gauge-ownership-strings.json`,
and pinned factory gauge/charger source snapshots in charger-source.
Reproduce the package check with `tools/audit_charger_module_apk.py`.

## Firmware handler investigation

An offline Hexagon disassembly adds direct control-flow evidence beyond
strings. The original signed split firmware files remain unchanged. An
analysis-only ELF section wrapper maps adsp.b18 at its original virtual
address 0x60000000 so the already installed llvm-objdump-20 can decode it.
That wrapper is not a bootable firmware candidate and must not be installed.
The original MDT has no section/symbol table; function names below are
inferred from in-function logging references, not recovered debug symbols.

1. The factory battery enum assigns BATT_ADSP_GAUGE_INIT value 38 (0x26).
   The AP sends owner 32778, request type 1, opcode 0x31, battery ID 0,
   property 0x26 and value 1. No measured gauge data is in this request.
   It is called during probe and ADSP crash recovery, not just once at boot.
2. Inside the firmware's battery property setter (identified by its log
   references), 0x601a29bc compares property 0x26 and 0x601a29cc calls
   0x601a91d0. Logging inside the callee identifies it as bq27541_init.
3. The callee first checks a project-configuration byte and an existing
   gauge object; unsupported/already initialized paths return without the
   rest of initialization. When allowed, it allocates the gauge object,
   invokes bus setup with arguments 9 and 100, sets address 0x55 at
   0x601a93e4, then invokes I2C/hardware configuration helpers. Logs include
   `FG I2C Init Failed` and `FG BQ27541 Is Initialized.` This is evidence
   of active hardware initialization, not a transfer of AP sample values.
   The numeric bus argument has not been independently mapped to AP i2c8;
   equal slave addresses alone do not prove the physical buses are equal.
4. A second direct call at 0x601b38d0 lies in a function identified by logs
   as fg_stub_init. Its conditional path depends on an OS-type query whose
   logged enum names are BOOTLOADER/HLOS/INVALID. Therefore omitting the
   explicit OEM initialization command does not prove all initialization
   paths are avoided. Effective runtime OS-type/project flags remain unknown.
5. Factory AP gauge readers check oplus_vooc_get_allow_reading() and can
   return cached measurements while access is disallowed. This is a local
   VOOC-framework gate, not evidence of a cross-processor handshake.
   The inspected mainline bq27xxx driver has no matching vendor gate.

No live ADSP startup or OEM message was performed. The result rules out
treating BATT_ADSP_GAUGE_INIT as a harmless telemetry operation. It does not
prove an actual collision or identify the current effective project flags.
Next work must establish the project/boot state controlling the firmware
gauge owner and a complete ownership handoff. Merely adding the AP device
tree property cannot configure the closed firmware's ownership decision.

Evidence files: `adsp-charger-analysis-only.dis`, `gauge-init-annotated.dis`,
`gauge-init-direct-calls.dis`, `gauge-init-callgraph.json`, and
`charger-firmware-string-xrefs.json` under charger-source. Web search was
unavailable (proxy HTTP 500); the claims above rely on the pinned factory
source and this phone's firmware, not search-result summaries.

## Project 22851 guard

Reproduce and preserve the focused evidence with
`python tools/audit_adsp_project_guard.py`. It verifies the original b18
hash, checks the cited disassembly instructions, extracts only the project
number from the archived phone inventory, and writes
`project-22851-gauge-guard.json` and
`project-22851-gauge-guard-annotated.dis`. It neither contacts the phone nor
modifies firmware. Instruction checks are evidence consistency checks, not
a complete control-flow or runtime proof.

The archived phone command line identifies `oplusboot.prjname=22851`.
Firmware get_project (0x601a5950) obtains its project value from offset 4
of SMEM item 135 (0x87), via get_project_info at 0x601a5ad0. The pinned
factory qcom/oplus_project.c independently uses SMEM_PROJECT=135 and
ProjectInfoOCDT; its header places Version first, followed by
nDataBCDT.ProjectNo, consistent with that offset. Source snapshots are
`oplus_project_qcom.c` and `oplus_project_data_ocdt.h`, from commit
f034653c086942be9398171cfa7477ddbe2d9504. This agreement is not a readback
of the current boot's SMEM contents.

The project configuration initializer at 0x601a5d00 defaults byte 0 to 1.
At 0x601a5e24 it compares project 0x5943 (22851), then branches to
0x601a5ed8, which sets bytes 0 and 2 to zero and bytes 0x1c and 0x1d to
one. The configuration object is returned at 0x60365234.

The same byte 0 is checked at entry to bq27541_init, before allocation,
I2C bus setup or setting address 0x55. With zero, it logs unsupported and
jumps to the return path. Both previously identified callers enter this
guarded function; fg_stub_init is not evidence of an unconditional bypass.

The inspected voltage selection at 0x6004d520 also checks byte 0. For
zero, it calls 0x601b3910, identified by logs as fg_stub_get_voltage,
instead of bq27541_get_battery_voltage (0x601aeea0). The stub calls
0x600999d0 with channel argument 1; logging identifies that function as
battman_adc_read. The stub doubles the returned value. Physical ADC
mapping, units, calibration and runtime validity remain unverified.

Bytes 0x1c and 0x1d are consumed at 0x6004cdd4: enabled byte 0x1c selects
byte 0x1d as the final argument to 0x60096770 with arguments
0, 7, 0x2641, 0xff. Without the flag that final argument is 2. This is a
separate peripheral configuration operation, not evidence of AP gauge
sample transfer; the register's semantics are not yet established.

Consequences: included BQ code and the OEM initialization command alone
do not establish concurrent AP/DSP gauge access on PJA110. If SMEM reports
22851, the inspected initialization and voltage paths avoid direct BQ
access. This is substantially narrower than clearing every firmware path:
current SMEM must still be checked, independent access paths have not been
exhaustively excluded, and temperature/SOC sources and charger policy
requirements remain to be traced. No charging fix or safe live ADSP
startup is claimed from these offline findings.

## Temperature, SOC and charging-control follow-up

Reproduce focused instruction/source checks with
`python tools/audit_adsp_data_sources.py`. Evidence is saved as
`gauge-data-sources.json` and `gauge-data-sources-annotated.dis`.
These are offline consistency checks; no ADSP startup, OEM command or
charging register write was performed.

The log-identified BQ temperature getter at 0x601af430 checks the initialized
flag at 0x603672a8. When uninitialized, it stores raw 250 and returns success
without reaching the I2C read path (0x601af50c..0x601af518). The SOC getter
at 0x601b0fe0 similarly stores raw 5000 and returns success
(0x601b10bc..0x601b10c8). These are fixed fallback values, not measurements.
Their conventional interpretation is 25 C and 50 percent in the respective
scaled vendor interfaces; this does not assert that those values are the
currently exposed Linux power-supply properties. Project 22851 suppresses
the inspected BQ initialization path, so valid ADSP telemetry cannot be
assumed merely because a getter succeeds. Runtime state and the selected
platform/data path remain to be established.

Factory AP code computes oplus_chg_match_temp_for_chging() using gauge and,
depending on configuration, subboard/shell temperature. It writes OEM
BATT_SET_MATCH_TEMP=29. The firmware setter compares 0x1d at 0x601a2a10,
then calls 0x60068100, which stores the value in its VOOC object at offset
0x6c. Getter 0x600681f0 reads it back; a consumer at 0x601a5474 replaces
its local BQ-temperature result with that getter's result. This establishes
an AP-to-firmware temperature path, not its complete policy or the necessity
of this message for ordinary USB charging.

Important device-specific qualification: factory qcom,voocphy_support=2
maps to AP_SINGLE_CP_VOOCPHY in the pinned enum; ADSP_VOOCPHY is 1.
The periodic match-temperature send in oplus_charger.c is gated on value 1,
whereas the battery probe also contains a send outside that gate. Do not
describe the ADSP-only periodic loop as PJA110's established active path.
The factory DTS includes sc,sc8517-master at address 0x69 and an AP gauge;
that is source configuration, not live identification of every charger IC.
Fast-charge topology is not settled by enabling standard battmgr.

Factory charging_enable/disable write OEM BATT_CHG_EN=24. Firmware compares
0x18 at 0x601a1bb0 and calls 0x600aacc0 with arguments 7 and the requested
enable byte. Callee logs identify PmSchgChgr_SetEnableChargingForAP; its
backend dispatches through an indirect callback. The physical backend,
initial/default enable state and whether this message is required for basic
charging are not yet established. No unconditional enable command is
recommended from these observations.

The inspected mainline qcom_battmgr has no power-supply .set_property
callback and does not implement these OEM writes. Therefore bringing up
the standard read/notification interface alone does not reproduce the
factory charging-control stack. Separately, the firmware's
oplus_chg_smem_init requests item 127 (0x7f), distinct from project item
135; the inspected references alone do not establish a measured-gauge
handoff through that item.

Next priority is the ordinary 5V charge path and its actual backend/default
policy, while retaining AP gauge telemetry as the measurement reference.
Do not replace valid readings with firmware fallback constants, disable
battery protections, or assume the SC8517 fast-charge path is the basic
charger. Live SMEM/project verification is still outstanding.

## Ordinary charging versus fast charging: SC8517 source comparison

User requested a joint investigation until separate paths are established.
The pinned factory driver charger/voocphy/oplus_sc8517.c and header are
now archived locally from the same f034653c commit. Source comparison gives
specific evidence of different modes, without establishing a complete
physical schematic:

- sc8517_hw_setting selects separate SVOOC, VOOC, 5V2A and PDQC routines.
- sc8517_5v2a_hw_setting (line 1118) writes register 0x02=0x78,
  0x04=0x06 and 0x24=0x00. Factory comments describe disabling acdrv,
  watchdog and VOOC PHY. PDQC applies the same three values. The MOS
  disable interpretation is also corroborated by sc8517_set_chg_enable:
  enable writes 0x02=0x7b, disable writes 0x02=0x78.
- SVOOC/VOOC routines configure different watchdog values and leave VOOC
  mode management to the surrounding framework; these functions alone
  are not a complete fast-charge initialization sequence.
- Named fast/normal switch helpers select different pinctrl states and
  drive switch1 GPIO high/low respectively. The factory DTS associates
  that switch with PM8550B GPIO8. Without a schematic, do not assume this
  switch necessarily selects the power path rather than a signal path.
- Factory battery charger operations independently implement normal
  charging enable/input-current control through the ADSP message stack;
  the SC8517 driver implements VOOC PHY/MOS operations on AP I2C.

Thus ordinary 5V and VOOC/SVOOC are not one identical enable/negotiation
sequence. They share the USB/battery system and need coordinated mode
transitions; a normal-charge configuration explicitly turns off the
SC8517 VOOC/MOS function. This supports investigating common infrastructure
together but implementing/testing ordinary charging and proprietary fast
charging as distinct modes. It does not yet identify every physical
power-conversion stage, nor prove that all forms of PD/QC fast charging
use the VOOC power route. No listed register values were sent to hardware.

## Charger enable callback resolution and fast-charge handoff

`python tools/audit_charger_backend.py` decodes original firmware data
tables, preserves annotated disassembly and checks the pinned framework's
exit sequence. Reports: `charger-enable-backends.json` and
`charger-enable-backends-annotated.dis`. No hardware access occurs.

The previously indirect OEM enable call can now be narrowed. Property 24
calls PmSchgChgr_SetEnableChargingForAP with logical index 7; it loads the
registered operations pointer and calls operations offset 4. The
log-identified InitializePeripheralSchgChgr at 0x600c7800 chooses one of
four tables according to the detected model byte:

| Operations table | Enable callback | Register argument | Mask |
| --- | --- | --- | --- |
| 0x60273b44 | 0x600c46b0 | 0x1042 | 1 |
| 0x60273ae0 | 0x600c46b0 | 0x1042 | 1 |
| 0x60273ba8 | 0x600c5f60 | 0x2646 | 1 |
| 0x60273c0c | 0x600c5f60 | 0x2646 | 1 |

Both enable callbacks pass the requested byte to 0x60096770. Its decoded
logic reads the old byte when mask is not 0xff, combines
`(requested & mask) | (old & ~mask)`, and calls the write helper. This is
concrete evidence of PMIC register control, distinct from AP SC8517 I2C
operations. It is not authorization or a recipe to write these addresses
from Linux: runtime model, selected table, correct slave ID and existing
votes/default state are not verified.

The slave argument is read from the per-index table entry byte 1, populated
from initialization descriptor byte 6. The factory pm8550b.dtsi assigns
SPMI USID 7, but logical charger index 7 does not itself prove that the
firmware callback's slave argument is USID 7. Do not conflate the two.

The factory AP framework's oplus_voocphy_turn_off_fastchg() handles the
configured AP_SINGLE_CP/AP_DUAL_CP variants by switching to normal mode,
resetting VOOC PHY, clearing fast-charge state and finally suspending or
unsuspending the ordinary charger according to stop_chg. This establishes
coordination between the normal charger and fast-charge framework, rather
than two unrelated stacks. The helper alone does not define the entire
electrical power route or every adapter insertion path.

Remaining gate before choosing a live candidate: identify the runtime PMIC
descriptor/model and charger suspend/enable/default policy, then assess
SC8517's inactive state. Continue treating basic charging and proprietary
fast charging as distinct coordinated modes of the same overall system.

## Input suspend is separate from charger enable

The pinned AP battery driver exposes three distinct controls. Its normal
oplus_chg_hw_init() first calls smbchg_usb_suspend_disable() except in
RF/WLAN factory boot modes, then requests 500mA input current via
oplus_chg_set_input_current_with_no_aicl(500), then calls
smbchg_charging_enable(). This is the factory sequence, not a claim that
this sequence alone is sufficient or that 500mA necessarily becomes the
effective input limit.

smbchg_usb_suspend_enable() writes USB_INPUT_CURR_LIMIT (property 5) as
zero; suspend_disable writes 0xffffffff. That sentinel means an unsuspend
request in this interface, not a numerical current. Charge enable remains
the separate battery property 24 previously traced.

The actual firmware handler corroborates the distinction. At 0x601a2d80
it tests USB property 5, preserves minus-one without unit conversion, and
sends zero or minus-one to 0x601951d0 (log-identified
sw_uefi_or_ap_set_usb_icl). Subject to its battery-presence check, zero
passes register argument 0x2954, mask 1 and value 1 to 0x60194c30;
minus-one passes the same register/mask with value 0. The helper dispatches
by a runtime descriptor, with both PMIC and I2C transport branches. These
are decoded arguments, not instructions to write Linux registers directly.

Positive current requests take a separate route through 0x601a44a0
(BattMngrVoteForICL), then a registered platform callback via 0x6002cc50.
Thus input suspend, input-current voting and charger enable all need
separate state verification. Missing unsuspend/ICL initialization is a
plausible integration gap, not the proven cause of the phone's low current:
no current live suspend bit, winning vote or charger detection was read.

Reproduce with `python tools/audit_charger_suspend.py`; outputs
`usb-suspend-icl-audit.json` and `usb-suspend-icl-annotated.dis` preserve
the exact source functions and instruction evidence. The check passed
without phone access. Current PMIC model/descriptor selection remains
unverified; offline code paths must not be reported as current hardware
state. Standard battmgr's read-only interface cannot reproduce these
factory initialization writes by itself.

# PJA110 charger bring-up (2026-10-17)

## Runtime platform identity audit

- Live B rescue SSH confirmed kernel #24; saved `/sys/firmware/fdt` as `out/native-install-20261017/rescue-runtime.dtb`. Runtime root compatible is `qcom,kalama-mtp`, `qcom,kalama`, `qcom,mtp`, without `qcom,sm8550`.
- The prepared A vendor DTB has `oneplus,xigua`, `qcom,sm8550`. However, all four embedded DTBs in the copied A `charger-startup/dtbo_a.img` carry the stock Kalama root compatible and model, matching the B runtime values. Root identity replacement by the stock DTBO is the identified compatibility problem; A runtime root still needs direct capture.
- The audited saved qcom_pd_mapper.ko contains both `qcom,sm8550` and `msm/adsp/charger_pd`, with vermagic `6.14.0-oneplus-xigua SMP preempt mod_unload aarch64`. Adding duplicate SM8550 domain support is not justified. Exact A live module hash remains to be captured.
- Updated the early capture script to record runtime root compatible, module identity/hash and auxiliary driver bindings. WSL shell syntax check passed. Installed the updated script into A through B and unmounted/detached afterward; no reboot or charging-control write was performed.
- Next candidate should preserve stock DTBO selection/project information while correcting its root compatible for mainline. This addresses platform matching only; battmgr remains disabled in the flashed kernel and sustained charging is not established.

## Native test evidence after integrated image deployment

- A startup images and userdata were written and read back successfully; B startup images remained unchanged.
- A persistent journal was saved at `out/native-install-20261017/charger-a-logs.tar`.
- Journal entries associated by their ENTRY boot ID show ADSP up at 11.617 seconds and `poweroff requested from client PID 859 (upowerd)` at 58.023 seconds in the same boot. This establishes a userspace poweroff request, not proof of a brownout. The reason for subsequent B selection has not been established.
- The flashed kernel IKCONFIG confirms `CONFIG_BATTERY_QCOM_BATTMGR` is disabled. PD mapper is a module and PMIC GLINK is built in.
- Mainline PD mapper already has the SM8550 charger domain mapping.
- The actual A vendor DTB uses the split firmware names `adsp.mdt` and `adsp_dtb.mdt`; ADSP firmware loading succeeded. The source DTS still needs its older `.mbn` names reconciled before future packaging.
- The 6.14 qcom_battmgr driver reads properties and subscribes to notifications; enabling it alone does not implement the OEM charging-enable, input-suspend and current-vote initialization previously identified in the stock driver. Charging current and USB online state were not captured during this A boot.
- B rescue has no power-supply nodes and reports PMIC GLINK waiting for PDR. It is not a verified charging environment. No further reboot or charging-register writes were performed during this log audit.

Next: compare existing OEM initialization against reusable mainline interfaces, and collect battery/USB/charger state early in the next controlled A boot. Keep low-battery protection enabled; do not equate ADSP startup with working charging.

The running system exposed only `bq28z610-0` and reported `Discharging`, with no Type-C or charger power-supply node. The existing mainline PMIC-GLINK driver creates its battery/USB-C auxiliary devices only after the ADSP `charger_pd` service is available through QRTR/PDR.

The board DTS had all remote processors disabled. The Aston reference enables `remoteproc_adsp` with the firmware pair `adsp.mbn` and `adsp_dtb.mbn`. PJA110's extracted `modem_a` firmware is already available as the corresponding `adsp.mdt`/`adsp.bXX` and `adsp_dtb.mdt`/`adsp_dtb.bXX` split files; the qcom mdt-loader consumes these files directly.

Changes prepared:

- enable `remoteproc_adsp` in `dts/sm8550-oneplus-xigua.dts` with the xigua firmware path;
- add local `firmware-oneplus-xigua-adsp` package containing the verified split firmware;
- add qcom remoteproc modules to the device module-load list;
- make the device package depend on the ADSP firmware package;
- regenerate the kernel overlay and add the package to the integration profile.

The DTB compiles successfully. The next build must include the firmware APK and a kernel rebuilt from the regenerated overlay. Do not test charging on the phone until that image is installed; the current image still has no charger service.

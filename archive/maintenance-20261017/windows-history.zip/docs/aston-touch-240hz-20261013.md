# PJA110 Aston 触控：固定 240Hz

日期：2026-10-13。复用 Aston Synaptics TCM 消息核心、SPI 和 input 实现，在已验证的 Linux 6.14 #14 上进行 RAM 对照。

## 速率配置依据

一加官方 SM8550 源码固定提交 `f034653c086942be9398171cfa7477ddbe2d9504`，`vendor/oplus/kernel/touchpanel/oplus_touchscreen_v2/Synaptics/Syna_tcm_S3910/synaptics_tcm_S3910.h` 定义：120Hz=2、180Hz=4、240Hz=3、288Hz=5、360Hz=1、720Hz=9。对应 C 文件通过 `DC_SET_REPORT_FRE`（0xe6）设置动态配置。这是源码支持的配置范围，不代表本机所有档位已验证，也不是芯片硬件极限的证明。

另一 HBP 源文件的诊断字符串给出不同映射，因此没有直接套用。本机码2实测约123Hz；码3在中断修正后实测约237–239Hz，符合普通 S3910 的映射。

设置沿用 Aston 的 `write_message`：初始化时写码3，重新应用已验证的 LBP=2 和报告布局，然后读回速率码。只修改运行时配置，没有写触控固件 flash。模块默认参数仍为0，自动启动镜像显式传入 `report_rate_code=3`。

## 中断问题与修正

下降沿中断下，码3只收到一个触点报告。诊断显示中断仅处理一次、ATTN GPIO25持续低电平、读取和解析错误均为零。改用低电平中断后，现有线程化中断处理器能继续读取积压报告，无需重写协议或触控算法。

90秒修正验证（capture6）：5530帧，用户确认“持续正常，双指也正常”，最终触点全部释放，无 evdev 溢出。

60秒精确记录（capture7）：4379帧，连续区间4374个；平均4.221ms（236.887Hz），中位4.184ms（239.006Hz）。使用 `EVIOCSCLOCKID(CLOCK_MONOTONIC)` 的内核 evdev 时间戳，微秒精度；统计仅纳入 `0 < dt < 20ms`，排除停顿。用户确认正常；该轮实际记录最多一个触点，双指证据来自 capture6。

这是主机侧输入事件上报频率测量，并非芯片内部扫描率测量。目标设置为240Hz，实际交付事件存在 SPI、内核调度及内容变化带来的抖动。

卸载 Aston、恢复旧驱动、再卸载旧驱动并加载码3 Aston 的生命周期检查通过，SSH保持可用。RAM阶段八个启动分区校验值均未改变。

## 自动启动候选

产物位于 `out/aston-touch-240hz-20261013/`：

- `init_boot_b-aston-240hz.img`：在原触控自动启动镜像中替换触控模块和两个启动检查钩子；保留 SSH 身份和其余归档内容。
- `synaptics-aston.ko`：码3设置、读回验证、低电平中断。
- `physical-result6.json`、`physical-result7.json`：用户反馈和事件统计。
- `autostart-manifest.json`：候选校验值及实际刷入状态。

QEMU已验证归档解包、模块加载和 SSH 用户态；不模拟触控硬件。实机自动启动验证以 manifest 的 `phone_execution_confirmed` 为准，候选构建完成不等于已刷入。

## 实机刷入与启动验证完成

已只刷入 `init_boot_b`，SSH自动恢复，码3初始化设置及读回成功，中断确认为Level。新镜像读回SHA256匹配，A槽和其余B槽启动分区共七个分区与基线完全一致。

启动后60秒触控记录（capture8）收到1883帧，最多3个活动slots，全部最终释放，无evdev溢出。用户确认位置、方向和持续双指均正常。连续事件平均4.232ms（236.303Hz），中位4.178ms（239.378Hz）。固定240Hz目标已纳入开机配置，实测输入交付约236–239Hz。

完整产物、源码、启动日志、实机事件与校验值冻结于 `out/aston-touch-240hz-20261013/verified-autostart/`，索引为 `sha256.json`。本轮验证包含一次从fastboot启动和短时触控，没有声称已覆盖系统休眠唤醒、十指、长时间压力或桌面环境。

工具：`prepare_aston_touch_rate.py`、`wsl_build_aston_touch.sh`、`finalize_aston_touch_rate.py`、`package_aston_touch_autostart.py`、`test_aston_touch.py`。原120Hz RAM验证基线保存在 `out/aston-touch-20261013/verified-ram/`，未覆盖。

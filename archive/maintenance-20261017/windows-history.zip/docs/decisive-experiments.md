# 两个决定性实验：cmdline 会被采纳，追加的 DTB 不会

> 日期：2026-10-11 · 全部实验均为纯内存启动，分区零改动

## 实验一：cmdline 是否被采纳？

**方法**：原厂内核（保证能启动）+ boot.img 里写入唯一标记 `xiguaprobe=hello123`。
启动后读 `/proc/cmdline`。

**结果**：

```
stack_depot_disable=on ... console=ttynull loglevel=6 ... (厂商段)
video=vfb:640x400,... bootconfig buildvariant=user          (vendor_boot 段)
xiguaprobe=hello123 console=ttyMSM0,115200 loglevel=8 earlycon   ← 我们段 ✅
oplusboot.mode=normal ... rootwait ro init=/init            (厂商段)
```

✅ **我们的 cmdline 被正确合并**，位置在中间。

> ⚠️ **修正**：我在 `docs/third-boot-attempt.md` 里曾判断"ABL 用自己的 cmdline 覆盖了我们的"。
> **那是错的**，证据不足时不该下结论。实测证明 cmdline 是合并的。

### 但发现了一个真实问题

厂商段里有 **`console=ttynull`**，而我们的 `console=ttyMSM0,115200` 在它**后面**。

`console=ttynull` 是内核专门用来**关闭控制台输出**的机制
（源码注释：*"console=\"\" or console=null have been suggested as a way to
disable console output. Use ttynull that has been created for exactly this
purpose."*）。

`console=` 的处理是：多个 `console=` 会各自注册，**后者成为 preferred**。
所以理论上我们的 `ttyMSM0` 应该能拿到输出——**前提是 geni 串口驱动能 probe**。

而这又回到 compatible 问题：厂商 DTB 的时钟/pinctrl 节点用的
`qcom,kalama-gcc-v2` / `qcom,kalama-pinctrl-v2`，主线内核**都不认**，
所以串口硬件根本初始化不了，`ttyMSM0` 无法注册 → 无输出。

## 实验二：追加的 DTB 是否被使用？

**方法（设计成不可能误读）**：
1. 取**厂商自己的实时 DTB**（从手机 dump 的，保证内核能正常工作）
2. 在 `/chosen` 下加一个唯一属性 `xigua-marker = "XIGUA_MARKER_7f3a9c"`
3. 追加到**原厂内核**后面，打包启动
4. 启动后回读 `/sys/firmware/devicetree/base/chosen/`

这样两种情况都能正常启动，结果二值：

| 结果 | 含义 |
| :-- | :-- |
| 有 `xigua-marker` | ABL 用了追加的 DTB |
| 没有 | ABL 忽略了 |

**结果**：

```
$ ls /sys/firmware/devicetree/base/chosen/
bootargs  kaslr-seed  linux,initrd-end  linux,initrd-start  name  phandle

$ cat /sys/firmware/devicetree/base/chosen/xigua-marker
cat: ... No such file or directory          ← ❌ 标记不存在
```

同时 `/proc/cmdline` 里的 `xiguaprobe=markertest` **存在** ✅。

❌ **结论：ABL 忽略追加在 kernel Image 尾部的 DTB。**
它始终用 flash 上 `vendor_boot` + `dtbo_a` 组装设备树，并**覆盖** `/chosen`。

### 为什么之前的对照实验不足

我第一次用"原厂内核 + 我们的 DTB"做对照，看到能启动就下了"ABL 忽略 DTB"的结论。
**那个实验设计有缺陷**：原厂内核即使拿到我们的 DTB，`qcom,ufshc` 两边都认，
UFS 能工作，系统照样起得来。所以"能启动"证明不了任何事。

**现在这个标记实验没有这个缺陷**——标记存在与否是二值的、不可误读的。

## 综合结论

| 通道 | 是否可被我们控制 |
| :-- | :-- |
| **kernel 字段**（`boot.img`） | ✅ 完全可控 |
| **cmdline** | ✅ **会被合并**（但厂商参数也在，且 `console=ttynull` 在前） |
| **ramdisk** | ❓ 未验证（vendor_boot 有自己的） |
| **DTB** | ❌ **完全不可控** —— 只用 flash 上的 |

**所以：唯一能改设备树的办法是改 flash 上的 `dtbo` 分区。**

## 由此确定的技术路线

必须把我们的设备树做成 **`dtbo` 格式**，刷进 `dtbo_a`，让 ABL 在
`Apply Overlay` 阶段应用它。

### 但有一个必须先解决的设计问题

ABL 的 dtbo 是 **overlay（叠加）** 语义，在**厂商基础 DTB 之上**应用。
而我们的 DTS 是**完整替换**语义：

```dts
/delete-node/ &reserved_memory;   /* 基于上游 sm8550.dtsi 的 label */
```

这些 label（`&reserved_memory` 等）在**厂商 DTB 里不存在**，
所以直接套用会失败。

### 需要先查清三件事（在刷 dtbo_a 之前）

1. **ABL 的 overlay 用什么 target 语法**
   （标准 FDT `fragment@N/target-path`？还是我们观察到的预链接 `target=0xffffffff`？）
2. **能否整块替换** —— 某些 ABL 允许 dtbo 里放完整 DTB 并整块替换基础 DTB
3. **厂商 DTB 的节点路径清单** —— 若走 overlay 补丁路线，要知道改哪些节点

## 实验产物（可复现）

| 文件 | 用途 |
| :-- | :-- |
| `out/probe-cmdline.img` | 验证 cmdline 合并（原厂内核 + 标记） |
| `out/probe-marker.img` | 验证 DTB 是否被使用（厂商 DTB + 标记） |
| `out/probe-marker.dtb` | 带标记的厂商 DTB |
| `out/control-nodtb.img` | 基线（原厂内核，无 DTB） |
| `out/control-ourdtb.img` | 原厂内核 + 我们的 DTB |
| `tools/check_cmdline_overwrite.py` | cmdline 分析 |
| `tools/wsl_build_marker_probe.sh` | 标记探针构建 |

## 设备状态

- 分区零改动（`boot_a = 742105c6…`、`dtbo_a = 30b4002a…`，经 5 次实验验证）
- 全部备份完好
- 恢复流程已验证

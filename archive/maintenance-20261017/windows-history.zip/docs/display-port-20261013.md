# PJA110 首轮显示驱动移植

## 实现及来源

- 新增实验性 DRM panel 驱动 `drivers/gpu/drm/panel/panel-oneplus-aa536.c`，兼容 `oneplus,aa536-p-3-a0001`。
- 仅 1240×2772 / 60 Hz command mode，DSC 1.1 SCR1、10 bpc、8 bpp、slice 620×44、两片。
- 初始化 98 条包、1163 字节和关屏两条包来自原厂运行时 DTB；60 Hz 初始化数据与固定提交的官方源码逐字节一致。
- 每条保留原厂 packet type、VC、payload 和等待；原厂 0x40 batching flag 不映射成 ACK，初版同步逐条发送。
- 保留 1.8 V vddio、3.0 V vci、GPIO133 reset 的原厂电压和脉冲顺序。初始亮度为 128/4095。
- Iris7 只实现供电、参考时钟、复位、旁路状态读取；默认复位后旁路未就绪时才用原厂六脉冲 force analog bypass 命令，并检查 ready=1。未移植插帧、PQ 或 Iris firmware lightup。
- Iris vdd09=TLMM105、reset=109、one-wire wakeup=129、ready=181；参考时钟来自 RPMH_DIV_CLK1，通过 PMK8550 GPIO5 func2 输出。
- 原厂 Ace2Pro 的 project 22851 不使用 project 22811 专用 GPIO92 供电路径，因此未照搬该路径。
- 为显示时钟修正旧测试 DTB 的 PMK8550 GPIO base 0x8800 → 原厂及较新 PMK8550 DTS 的 0xb800，并同步节点名与 symbols。

## MSM DSI 兼容补丁

Linux 6.14 的 `dsi_populate_dsc_params()` 默认拒绝 bpc != 8，且只选择 PRE_SCR 参数。新增实验性 DT opt-in `oneplus,dsc-scr1`，仅该板可接受 10 bpc 并选 `DRM_DSC_1_2_444` RC 参数；既有面板默认行为保持不变。

原厂 `sde_dsc_helper.c` 明确将 SCR1 RGB444 和 DSC1.2 RGB444 参数共用。已逐项核对主线 10 bpc/8 bpp 的全部 15 组 RC min/max QP 与 BPG offset；initial delay/offset 和 quant/flatness 参数一致。详见 `dsc-rc-comparison.json`。

当前面板对象通过 panel Makefile 的 DRM_MIPI_DSI 条件编入；尚未整理独立 Kconfig、正式 DT binding 或提交上游。这是 bring-up 版本。

## 第一轮实机结果

内核 #11，已验证固定 SSH 保持可用，刷写镜像读回正确，除 B 槽 boot/vendor_boot 外六个启动分区未变。

- DPU hardware revision 0x90000000；DPU 绑定 DSI0，DRM msm 注册。
- `/dev/dri/card0`、`/dev/fb0`、`card0-DSI-1` 出现。
- DSI connector connected，mode 1240x2772。
- Iris7 reset 后 ready=1，analog bypass confirmed。
- 用户观察：持续黑屏。
- 第一条 DSI 包被驱动错误判失败：payload 长度 6，MSM 返回带封包/padding 的 DMA 长度 12。依据实际 MSM host 返回语义，修正为仅负返回值表示错误，不再比较返回值与 payload 长度。

第一轮产物与日志完整保存在 `out/display-port-20261013/round1/`，后续迭代不覆盖该证据。

## 第二轮

修正发送长度判断及 GPIO direction 错误处理，仍用相同设备树。仅更新 boot_b；跳过已读回匹配的 vendor_boot_b，保留 init_boot_b/DTBO 和原厂 A。

结果以当前目录的 `mainline-dmesg.txt`、`display-state.txt`、`fb-pattern-result.txt`、`dmesg-after-pattern.txt` 和用户实际屏幕观察为准。DRM connected 与 framebuffer 注册不能单独证明屏幕点亮。

## 可复现产物

- `tools/audit_display_wiring.py`：原厂 phandle/GPIO/regulator 解析和命令字节对照。
- `tools/generate_aa536_commands.py`：由实机 DTB 生成命令 header。
- `tools/wsl_build_display.sh`：实际 6.14 构建树编译及 opt-in DSC 补丁；内核 config 不变。
- `tools/package_display_port.py`：在已验证 USB DTB 上增添显示节点，保留 USB/UFS/memory 与原有 NCM initramfs。
- `dts/sm8550-oneplus-xigua-display.dtsi`：对应板级接线的源码草案；测试镜像使用 packer 生成 DTB，未将旧完整 DTS 重新编译后直接刷写。
- `tools/deploy_display_port.py`：校验、B 槽刷写、SSH 日志与完整分区读回。
- `tools/mainline_fb_pattern.c`、`draw_mainline_fb.py`：核对实际 framebuffer metadata 后仅向 RAM 绘制六色竖条。

尚未验证实际图像、亮度曲线、休眠/恢复、高刷新率、触控或 GPU 加速。日志显示 no GPU device；renderD128 节点存在不代表 GPU 已可用。

## 链路速率对照

第二轮初始化 98 条命令已完成，framebuffer 六色竖条写入成功，但用户仍观察到黑屏。亮度/actual_brightness=128、bl_power=0，DRM CRTC active=1，面板与 Iris 的供电和 reset 状态已启用。诊断 DCS read 的第一条 0x04 超时；后续请求也出现 DMA 超时，不能把这些错误直接当作面板返回了零值。

实际 clk_summary 显示 DSI bit clock 568299609 Hz，而原厂每个模式（包括 60 Hz）指定 1094400000 Hz。新增实验性 `oneplus,command-mode-lane-rate` 属性，将该板 command-mode DPHY 的 byte/pixel clock 对齐原厂固定速率，并同步 PHY 取时钟接口；其它板和 video/CPHY 模式保持原先计算。前两轮产物分别保存在 round1/round2。

本次中断恢复后，旧 #12 已连续运行约 11968 秒且 SSH 正常；随后启动原厂速率对照镜像。该 uptime 只说明这段运行未重启，不是完整稳定性认证。

## 第三轮：GPIO90 对照首次出现画面

原厂速率镜像 #13 的实际 DSI bit/byte/pixel clock 已读回为 1094400000 / 136800000 / 182400000 Hz。98 条初始化命令完成、彩条写入后，用户仍观察到持续黑屏。

原厂 DT 的 `qcom,platform-panel-vout-gpio` 指向 TLMM90，主线当时保持 output low。通过 GPIO character device 验证控制器为 `f100000.pinctrl`、211 lines、GPIO90 未被内核占用且为输出，再临时拉高 GPIO90，执行 framebuffer blank/unblank 重新初始化，并绘制六色竖向彩条。用户在 35 秒保持期间明确反馈“出现彩条或画面”。程序随后自动恢复 GPIO90 为 low，SSH 读回确认恢复成功。

本轮没有刷写分区。证据保存在 `out/display-port-20261013/round3/`，包括原厂速率镜像及 `vout-test-output.txt`、`dmesg-after-vout-test.txt`。这说明 GPIO90 拉高配合重新初始化能产生实际画面；尚未验证仅拉高是否足够，亦未单独排除原厂速率补丁的必要性。

下一版将 GPIO90 作为 active-high `vout-gpios` 纳入面板驱动：probe 保持 low，prepare 在供电后拉高，unprepare 和失败回滚拉低。固定 SSH 用户态保持不变，待完成启动及屏幕实测后再记录结果。

## 第四轮：驱动管理 GPIO90，开机后正常显示

内核 #14（2026-10-13 20:07:54 CST）已编入 GPIO90 使能控制；打包后的 DTB 增加 active-high `vout-gpios` 及 GPIO90 pinctrl，累计 66 项显示范围属性变化。编译通过，固定内核配置及 SSH initramfs 保持不变，QEMU SSH 用户态检查通过。

仅刷入 `boot_b` 与 `vendor_boot_b`，启动后自动 SSH 正常。完整分区校验及镜像读回通过，其余六个 A/B 启动分区与最初记录一致。实机日志显示 Iris7 analog bypass confirmed、AA536 初始化完成，GPIO90 自动为 output high / gpio function / 8mA。通过 RAM framebuffer 绘制六色竖向彩条后，用户明确确认“正常显示彩条”，无需额外用户态 GPIO 操作或 blank/unblank。

当前目录的 `manifest.json`、`device-after.json`、`mainline-dmesg.txt`、`display-state.txt`、`fb-pattern-result.txt` 和 `screen-observation.json` 记录这一可显示基线。首次点亮已确认；亮度范围、反复开关屏、休眠恢复、高刷新率、触控和 GPU 加速仍需后续单独验证。

## 第五轮：基础运行验证

继续使用 #14，不刷写任何分区。`tools/test_display_runtime.py` 在 `out/display-port-20261013/runtime-validation/` 保存软件结果与用户屏幕观察：

- 亮度依次为 64、128、512、1024、128，每档约 6 秒，`actual_brightness` 读回匹配；用户确认亮度明显变化、画面正常。结束恢复原始值 128。未验证整个 0–4095 范围及亮度曲线。
- 五次 framebuffer POWERDOWN/UNBLANK，每次关闭约 2 秒、显示约 3 秒。GPIO90 读回每次按 low/high 切换，全部重新完成 Iris bypass 和面板初始化；用户确认每次正常恢复彩条。这是开关屏测试，尚未测试系统 suspend/resume。
- 一次普通 `reboot -f`，boot_id 已改变，仍为同一个 #14 内核；自动 SSH 约 23.47 秒后恢复。重新上传并绘制 RAM 彩条后，用户确认正常显示。未做断电冷启动或长期压力测试。

推进建议：先完善基础显示与触控、GPU/动态图像测试。90/120 Hz 属于面板时序和 DRM/KMS 模式控制，不必等待完整发行版桌面，可先用独立 KMS 测试验证，再验证桌面模式选择。Iris7 MEMC 插帧与旁路显示是另外一条工作线，建议在高刷新率和动态图像基线稳定后进行；发行版桌面本身不是必要条件，独立视频测试也可作为验证输入。

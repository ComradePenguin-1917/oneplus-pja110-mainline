# Linux 6.14 内核重构建：2026-10-12

## 结果

**重新构建完成，最终 Image 已在 QEMU 中执行内嵌 /init，并正常关机（退出码 0）。** 版本为 `6.14.0-sm8550-xigua-r1`。

这确认了该内核与归档在 QEMU virt 平台上的通用启动和用户态执行路径。尚未刷入 PJA110，不能据此确认真机 UFS、USB、显示或其它硬件适配成功。

## 本轮修正

1. 从内核配置移除桌面用途的强制参数 `root=PARTLABEL=win ... quiet splash`，设置 CONFIG_CMDLINE=""。重新编译原始 Image，不再靠二进制字面量替换。
2. 初次 QEMU 验证可进入内核，但执行 /init 后 PID 1 因 SIGTRAP 退出。异常地址指向 BusyBox 静态 libc 的 abort 路径。同一个旧 BusyBox 在手机正常 Android 中运行 shell，报 `stack smashing detected`，证明旧用户态二进制存在实际故障。
3. ARM64 sysroot 缺少 Linux UAPI 头文件。以无 root 的 apt-get download 提取 `linux-libc-dev-arm64-cross` 到项目工具链目录，未安装系统包；用缓存 BusyBox 1.36.1 源码在新目录干净重编，显式指定完整 sysroot。没有通过关闭栈保护掩盖故障。
4. 新 BusyBox 在手机 Android 中执行 shell 和自身 uname applet 均成功；读取其实际 --list，补齐归档 applet 链接。旧归档缺 uname 等链接，实际 QEMU 日志曾显示 `uname: not found`。
5. 增加归档内的 /dev/console（字符设备 5:1）与 /dev/null（1:3），解决早期初始控制台不可打开的问题。最终归档共 457 条目。

旧 BusyBox 的具体生成过程未在本轮逐对象追溯；本轮证明了故障及干净重编后的修复，不能声称它已解释此前所有真机启动失败。

## 配置语义核查

Linux 6.14 arm64 Kconfig 的命令行选择项依赖 `CMDLINE != ""`。默认字符串为空时，CMDLINE_FROM_BOOTLOADER 和 CMDLINE_FORCE 都被隐藏；配置没有显式 `CONFIG_CMDLINE_FROM_BOOTLOADER=y` 是正常行为。已按实际 Kconfig 语义检查，而不是要求隐藏符号出现在 .config 中。

从最终 Image 的 IKCFG 段解压得到的配置，与导出的 kernel.config 完全相同；确认没有 CONFIG_CMDLINE_FORCE=y 或旧桌面 root 参数。Image.gz 解压后与 Image 逐字节一致；内嵌 gzip cpio 与导出归档完全一致。

## 最终启动验证

使用项目已有 QEMU 6.2.0，机器 virt、CPU cortex-a57、2 核、2 GiB RAM；直接 -kernel 加载 Image，不提供外部 initrd，让内核使用内嵌归档。命令行由 QEMU 提供：

```
console=ttyAMA0 earlycon=pl011,0x9000000 loglevel=7 rdinit=/init ignore_loglevel
```

关键日志：

```
[initramfs] boot: Linux (none) 6.14.0-sm8550-xigua-r1 #7 ... aarch64 GNU/Linux
[initramfs] === NO USB: /init RAN, so signalling that userspace was reached ===
reboot: Power down
```

QEMU virt 没有本测试需要的真实 USB UDC，所以归档按既定逻辑走关机路径。这个结果不验证 PJA110 上的 USB gadget 或关机信号。qemu-image.sha256 与最终 Image 哈希一致，避免把旧 Image 的成功日志当成新产物的验证。

## 产物

目录：`out/rebuild-20261012/`。

| 文件 | 用途 |
| --- | --- |
| Image / Image.gz | 原始及压缩内核 |
| kernel.config / System.map / kernel.release | 实际配置、符号表、版本 |
| initramfs.cpio.gz / busybox | 已验证的最小用户态 |
| sm8550-oneplus-xigua-16G.dtb | 16 GB 设备树，内存声明与此前构建产物一致 |
| boot-xigua-r1.img | header v4，原厂 os_version，原始 Image，不追加 DTB |
| vendor_boot_b-xigua-r1.img | 新 DTB 注入 entry0，附惰性节点 /xigua-rebuild-r1；其余 ramdisk/DTB/bootconfig 字节不变 |
| init_boot_b-xigua-r1.img | 与内嵌归档内容相同的 Android legacy LZ4 generic ramdisk |
| manifest.json / SHA256SUMS | 所有最终产物的大小、哈希和验证结果 |
| qemu-smoke.log | 最终成功启动日志 |
| qemu-smoke-before-fix.log / qemu-debug.log | 修复前故障日志 |

旧根目录 out/ 下的内核和测试镜像保留。修改前配置在新目录 config.before，旧归档在 initramfs-before.cpio.gz，旧 BusyBox 在 busybox-before。

三个分区镜像已分别回读验证：boot 的内核字段与 Image 完全相同；vendor_boot 修改仅限 entry0；init_boot LZ4 解压后与内嵌归档的原始 CPIO 完全相同。DTB 符号 qcom_tzlog/arch_timer 保留。

## 复现入口

Windows 工作区脚本通过已批准的 WSL 执行路径运行：

```
wsl -d Ubuntu-22.04 -- bash /mnt/h/workspace/PJA110-Mainline/tools/wsl_rebuild_verified.sh --rebuild-busybox
```

在手机正常 Android 中验证新 BusyBox、保存真实 applet 列表后，运行：

```
python tools/repack_verified_initramfs.py
wsl -d Ubuntu-22.04 -- bash /mnt/h/workspace/PJA110-Mainline/tools/wsl_rebuild_verified.sh
wsl -d Ubuntu-22.04 -- bash /mnt/h/workspace/PJA110-Mainline/tools/wsl_rebuild_verified.sh --qemu-smoke
python tools/package_verified_kernel.py
```

本轮只重新构建与验证，未修改手机启动分区。下一轮 B 槽试验应成套使用本目录的 boot/vendor_boot/init_boot，并按既有流程处理 B 槽 DTBO、保存当前状态及恢复校验。

# ABL 覆盖合并定位及有效入口

## 实机结果

沿用原厂 `target = <0xffffffff>` 和 `__fixups__` 的测试覆盖，已在 B 槽越过先前的 ABL 合并错误。保存的 B 槽记录包括：

```text
VB2: Authenticate complete! boot state is: orange
Apply Overlay total time: 30 ms
Update Device Tree total time: 231 ms
Shutting Down UEFI Boot Services: 3558 ms
```

另一份保留的 B 槽记录对应 31 ms / 225 ms / 3559 ms，同样没有合并失败。当前证据仅确认引导器越过覆盖合并、设备树更新并开始关闭启动服务；没有主线内核日志，不能宣称 Linux 已执行或用户态已启动。

手机持续黑屏，电脑未检测到 ADB 或 fastboot；观察超过一分钟，没有主线 USB 交互入口。用户通过按键恢复 fastboot 后，已切回 Android A 采证并恢复 B 槽。此轮没有写入 logdump。

## 对照路径

1. 完全去掉覆盖片段，只保留原厂根节点匹配属性、AVB 元数据，仍在主线基础树上出现 `ufdt apply overlay failed`。镜像和证据分别位于 `out/avb-empty-control-20261012/` 与 `out/avb-empty-experiment-20261012/`。
2. 保持该空覆盖、r1 内核和 init 不变，仅将 `vendor_boot_b` 换回原厂基础树，仍出现同一合并错误。只改一个分区的前置验证和日志在 `out/stock-base-overlay-experiment-20261012/`。因此原先制作的空覆盖在原厂基础树上也不能使用，不能将错误仅归因于主线基础树。
3. 构造原厂风格的 fixup 覆盖：`/fragment@0` 使用 `target`，`/__fixups__/soc` 为 `/fragment@0:target:0`。两棵基础树都导出 `soc` 标签。覆盖仅在该节点下添加无功能的 `xigua-avb-control` 标记，并保留原厂设备匹配属性、footer 和签名元数据。还提供空 `__symbols__` 与 `__local_fixups__` 节点。

第三步同时改变了目标引用方式和元数据节点布局，尚未逐项隔离手机内 libufdt 的具体兼容性要求。结果支持使用该布局作为后续测试入口，不支持将根因准确归为 `target-path` 单一字段。

## 有效镜像与核对

`out/avb-fixup-control-20261012/manifest.json` 记录四个输入镜像；DTBO SHA256 为 `3612836db59226cc199816db217033d8f3532c5df770cce78fef9e66e5116989`。

内核、init_boot、USB2 vendor_boot 与前两轮一致。WSL libfdt 的 fdtoverlay 将四份覆盖依次合并到 USB2 主线基础树，解析结果确认 `/soc@0/xigua-avb-control` 存在；该离线结果只作为辅助检查，实机 B 槽日志才是 ABL 通过的证据。

实机读回验证 boot_b 镜像前缀以及完整 vendor_boot_b、init_boot_b、dtbo_b 与本轮输入匹配；A 槽四分区保持原值。恢复后的全部八个分区哈希及 Android 完成启动状态保存在 `out/avb-fixup-experiment-20261012/restored-device.txt`。

AVB 元数据仍使用原厂签名，覆盖内容哈希不再匹配；本机解锁状态允许内容校验错误。这不是锁定状态下完整校验通过，没有修改任何 vbmeta 分区。

## 后续

`tools/prepare_avb_noop_dtbo.py` 无参数默认生成本轮成功的 fixup 布局；旧布局仅通过显式参数重现。此后主线实验应使用这个有效 DTBO，先复测既有落盘日志采集器。此前清空 DTBO 或覆盖合并失败的实验没有实际越过这两个入口阻塞，其空日志不能作为内核启动失败的证据。

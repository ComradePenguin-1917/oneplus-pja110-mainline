# 启动即有 SSH 的固定调试镜像

2026-10-13，PJA110 / xigua，原生 Linux 6.14，BusyBox RAM root，固定 NCM + Dropbear 2026.94。

## 实施

- 内嵌 initramfs 和 `init_boot_b` 外部 ramdisk 使用相同完整文件集。手机启动时外部 `/init` 会覆盖内嵌 `/init`，因此两者必须同步。
- USB ACM + NCM：VID 1d6b、PID 010a、serial PJA110-NCM，沿用已验证的描述符和固定 MAC。
- 手机自动配置 `169.254.42.1/16`，兼容 Windows 现有 link-local 地址；同时保留 `172.16.42.1/24`。没有修改电脑网卡设置、DNS 或默认网关。
- devpts、root passwd/group、root 授权公钥和 Dropbear 主机密钥随镜像启动。密码登录关闭；客户端私钥没有上传或嵌入镜像。
- 主机身份沿用之前经 ACM 校验的身份，现有严格 host key 校验和连接脚本继续有效。
- Dropbear 前台运行，由后台 shell 循环守护；ACM shell 独立保留。PID1 持续运行，不设置延迟重启探针。
- `/etc`、`/root/.ssh`、主机密钥与授权文件权限明确设置；CPIO 生成器验证所有新增路径的父目录存在且是目录。
- 当前仍是调试 initramfs，没有安装具体发行版或挂载用户数据分区。

## 实机结果

最终镜像：`out/debug-ncm-fixed-20261013/boot-xigua-r1.img`、`init_boot_b-xigua-r1.img`。

首次最终启动已验证：主线 `6.14.0-sm8550-xigua-r1 #10`、hostname pja110、root 公钥 SSH；USB configured；静态 Dropbear 2026.94。

- boot_b 镜像前缀读回 SHA256 与打包文件一致；init_boot_b 完整分区 SHA256 一致。
- A 槽 boot/vendor_boot/init_boot/dtbo 四分区完整 SHA256 与本轮前一致，且前置检查与原厂备份一致。
- B 槽 vendor_boot、dtbo 未变；没有恢复 B 或写入 vbmeta/userdata。
- SSH 1 MiB 二进制上传、手机 SHA256、读回逐字节一致。
- 普通重启复测通过：boot_id 已改变，约 22.59 秒后自动恢复严格主机身份校验的 root SSH；全过程未通过串口或 SSH 重新配置 gadget。结果记录在 `reboot-result.json`。

连接方法：

```powershell
.\tools\connect_mainline_ncm.ps1
.\tools\connect_mainline_ncm.ps1 -Command 'uname -a; id'
```

## 中间问题及修正

1. 首轮仅更新 boot_b，外部 ramdisk 的旧 `/init` 覆盖新脚本，仍枚举 ACM。通过 COM12 确认内核 #9，修正为同步更新 init_boot_b。
2. 新增 `/etc` 文件时漏父目录，NCM 成功但 host key/passwd 未解包。补父目录并加入完整父目录检查；QEMU 增加实际解析主机密钥、查找 root 和检查授权公钥，避免只测可执行文件。
3. 主线向 reboot syscall 传 bootloader 并未可靠进入 fastboot，需手动按键；普通重启是否正常由复测记录确认。这与自动 SSH 启动是不同问题。

## 验证范围与维护

QEMU 验证内嵌 PID1、账户及 Dropbear 主机密钥可以运行，不模拟手机 USB。实机证据位于 `device-before/after.json`、`device-after.txt`、`result.json`、`mainline-dmesg.txt`、`fastboot.log`。

调试镜像内含本设备专用 SSH 主机私钥，因此不是供多台设备共享身份的通用发行镜像。后续发行版安装应采用每设备主机身份的持久化方案。

本轮未实现 Android A/B 的 mark-boot-successful；连续重启次数仍受 bootloader 的 B 槽重试机制约束。后续用经过核对的 boot control 工具处理，避免混同为 USB 断连。

显示准备见 [显示移植准备](display-preparation-20261013.md)。当前调试镜像保持显示设备树不变。

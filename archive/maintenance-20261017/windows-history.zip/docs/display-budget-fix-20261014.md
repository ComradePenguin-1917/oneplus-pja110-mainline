# AA536 60Hz 命令模式性能预算修复

## 修改与适用范围

#23 在 #22 相同配置上只修改 `dpu_core_perf.c`。复用现有 core perf、ICC、OPP
调频路径，将 AA536 原厂6000us命令模式传输预算用于默认模式的时钟及带宽投票。
以原有帧平均预算乘以 `1000000 / (6000 * 60)`；瞬时带宽不低于分配到每条ICC
路径的平均带宽。原有514MHz驱动上限及OPP约束保持。

该实现是本项目的面板限定quirk：要求AA536节点、1240×2772、60Hz和CMD encoder
同时成立，其他模式保留原有预算。6000us来自已核对的原厂60Hz timing，尚未
引入通用的per-connector transfer-time接口，因此不应称为已完成的通用上游方案。
没有修改plane布局、DSC、TE、面板命令、GPIO90、Iris旁路、USB或触控源代码。

## 验证

- 同配置构建；QEMU验证当前SPI/Aston模块、GPU/SSH initramfs启动兼容性通过。
- 仅写boot_b，保留原厂AVB尾部；完整读回八个启动分区，其他七个哈希不变。
- 实机运行 `6.14.0-sm8550-xigua-r1 #23`；自动SSH、GPU固件、Aston code3读取验证。
- 重启后默认 `perf_mode=0`，`fix_core_clk_rate=0`、`fix_core_ab_vote=0`。
  默认预算自动请求OPP受限的514MHz，不依赖此前RAM锁频设置。
- 原生行号动态图案：用户确认396～439行无错位花屏。
- 重新载入Ubuntu24.04.5 ARM64 RAM用户空间，独立SSH2222、Mesa FD740四纯色
  及120帧离屏像素验证通过。
- Weston桌面、终端、触控和EGL旋转演示均运行。用户将旋转演示移到原故障区域，
  确认动态画面正常、触摸正常。当前保留桌面运行。

源代码前后副本、补丁、Image、System.map、配置、QEMU、镜像及读回证据在
`out/display-budget-20261014/`。默认预算计数采样在
`out/display-timing-20261014/counters/budget.csv`，不作为物理扫描相位测量。

## 重启流程的独立问题

从#22运行中的KMS动画发起普通重启时，旧内核在
`drm_atomic_helper_swap_state -> drm_atomic_helper_disable_all -> msm_kms_shutdown`
等待，未实际进入新内核。显示中断回调已注销；随后停止动画仍不能解除该等待。
不能把这一次等待记录成#23启动失败。

boot_b写入与同步已经完成、没有持久Ubuntu根文件系统挂载。本轮通过现有SysRq
紧急重启接口绕过旧内核关机死锁，成功进入#23。尚未证明#23普通重启路径正常；
正式持久安装前应单独修复并测试DRM关机。回退镜像为
`out/display-timing-20261014/boot_b-sdma.img`，当前init_boot无需随之更换。

# PJA110 r1 实机刷入实验（2026-10-12）

用户授权后，将 `out/rebuild-20261012/` 的三份配套镜像写入 B 槽，并清空 `dtbo_b`，设置 B 为启动槽后重启。A 槽的四个启动分区不写入。

## 镜像与恢复准备

预检确认 Android A 槽启动完成、设备已解锁、A 槽标记成功。构建清单全部文件哈希通过；记录 A/B 共八个启动分区哈希，并核对 B 槽恢复文件。

特别注意：实验前 `boot_b` 已包含之前的实验镜像，恢复使用 `out/cmdline-experiment-20261012/boot_b-before.img`，而不是最初的原厂 `backup/boot_b.img`。其他三个 B 分区恢复使用已核对哈希的 `backup/` 文件。

## 观察结果

- fastboot 对 `vendor_boot_b`、`boot_b`、`init_boot_b` 写入、清空 `dtbo_b`、切换 B 及重启全部返回成功。
- 随后 ADB 重新出现，系统槽位为 `_a`，`sys.boot_completed=1`，内核为既有的 `5.15.123-android13-8-droidspaces`。
- 在重启后的枚举快照中只有 Android ADB 接口，没有发现测试 initramfs 的 USB 网络接口。
- 从 Android 读回 `boot_b` 前 34,353,152 字节，SHA256 为 `807652559ec1e3b7d753827f6b7563c1527f249d5afa3a0a844a71f8569f5a03`，与此次 boot 镜像一致。
- `vendor_boot_b` 与 `init_boot_b` 全分区哈希分别匹配新镜像，`dtbo_b` 匹配全零分区哈希。A 槽四分区保持实验前哈希。
- 回到 Android 后 pstore 为空，已保存 dmesg 和命令行。bootloader_log 目标路径未返回日志内容。dmesg 是 Android 内核日志，不能作为主线内核执行进度证据。

本轮没有获得主线内核的交互入口或启动日志。可以确认完整配套镜像确实写入，并发起了 B 槽启动；不能据此确定是否进入内核、是否执行 `/init`，或具体失败位置。此前原厂内核对照也不能稳定产生 pstore/关机信号，不能凭这两项缺失判断早期崩溃。

## 恢复与证据

测试后已向 B 槽写回四份实验前恢复文件，设置 A 槽并重启。最终确认 Android 启动完成，A/B 共八个分区的哈希全部与实验前一致。恢复校验见 `out/boot-r1-experiment-20261012/restored-device.txt` 与 `result.json`。

证据目录 `out/boot-r1-experiment-20261012/` 包含预检哈希、fastboot 写入及恢复完整输出、实验后分区哈希、boot 前缀哈希、USB/网卡枚举及 Android 日志。构建产物仍保留在 `out/rebuild-20261012/`，可继续分析启动入口、设备树与日志通道。

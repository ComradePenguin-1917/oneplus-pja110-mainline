1) stock boot.img: kernel_size=53238272 ramdisk_size=0
   -> no ramdisk in the boot partition

2) the OTA has an init_boot partition (8 MiB) -> first-stage ramdisk lives there
   boot                       201,326,592  7
   vendor_boot                201,326,592  7
   init_boot                    8,388,608  7

3) vendor_boot: vendor_ramdisk_size=16741173 (16.0 MiB), dtb_size=2040970 (1.9 MiB)
   -> the ramdisk AND the DTB both come from vendor_boot

4) proof: the running stock system's /proc/cmdline contains
   "stack_depot_disable=on kasan.stacktrace=off kvm-arm.mode=protected"
   which are NOT in our boot.img cmdline; they come from vendor_boot's
   bootconfig. So ABL definitely merges vendor_boot at boot time.

====================================================================
CONCLUSION
====================================================================
Our hand-built boot.img replaced only the kernel. The DTB and ramdisk still
come from the device's vendor_boot, i.e. they are the VENDOR's, tuned for a
5.15 Android kernel. A mainline 6.14 kernel given that DTB will not probe
most devices, and with no initramfs it has nothing to run as userspace --
so it panics, and USB never enumerates. A perfectly healthy mainline kernel
and a dead one are indistinguishable in this setup.

FIX: embed our own initramfs whose /init sets up a USB network gadget.
That is exactly how postmarketOS brings up Qualcomm phones with no UART.
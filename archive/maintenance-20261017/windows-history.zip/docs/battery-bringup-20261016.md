# PJA110 battery telemetry: reuse audit and first candidate

## Verified reuse path

The pinned OnePlus factory source `oplus-chg-22851.dtsi` declares the fuel gauge
at I2C address 0x55 under qupv3_se8_i2c, with `qcom,batt_bq28z610` and GPIO0/1
using qup2_se0_l0_mirb/l1_mirb. The stock wrapper's compatible string is named
bq27541, but its explicit bq28z610 property identifies the intended variant.
This is source evidence, not a silicon-ID readback from the physical gauge.

Aston uses upstream `ti,bq28z610` at i2c8 address 0x55 and the same GPIO0/1 mux.
Its config enables BQ27XXX and BQ27XXX_I2C while disabling QCOM_BATTMGR.
The current PJA110 distro already has both bq27xxx modules installed, and the
kernel config disables BQ27XXX_DT_UPDATES_NVM. In the inspected upstream
implementation, bq28z610 has no data-memory update table. No new gauge driver,
calibration implementation, battery-monitor daemon or charging policy is added.

The running device has no I2C adapters or power_supply devices. The verified
PJA110 DTB disables i2c8 and selects reference-board GPIO56/57. These are the
specific missing connections addressed by this candidate.

Factory source:
https://github.com/OnePlusOSS/android_kernel_modules_and_devicetree_oneplus_sm8550/blob/f034653c086942be9398171cfa7477ddbe2d9504/kernel_platform/qcom/proprietary/devicetree/oplus/oplus_chg/oplus-chg-22851.dtsi

Aston reference:
https://github.com/jiganomegsdfdf/aston-mainline/blob/5d5c840896bb49291ae4578acefd5a3ec65524f6/arch/arm64/boot/dts/qcom/sm8550-oneplus-aston.dts

Web search was unavailable; the factory source was retrieved directly from the
already pinned official Git repository. Snapshot and hashes: references.json
and oplus-chg-22851.dtsi under out/battery-bringup-20261016.

## Candidate prepared, not installed or hardware-validated

Standard fdtput updates only the PJA110 DTB in the verified native vendor_boot_a:
enable i2c8 at 100 kHz, use GPIO0/1 with the factory/Aston mux, add the standard
ti,bq28z610 gauge node at 0x55. No battery design-voltage/capacity values are
copied from Aston. Existing pin pull-up and drive settings remain intact.

The exact eight changed properties were checked using a parsed tree comparison.
Memory reservations are unchanged. The other three Qualcomm fallback DTBs,
vendor ramdisk, container offsets and retained AVB tail are unchanged. As with
the currently booted image, retained metadata does not sign modified contents;
the unlocked bootloader is required. No kernel rebuild is necessary.

Candidate source fragment: dts/sm8550-oneplus-xigua-battery.dtsi. It is not yet
included in the known-working board source/package. After validation, integrate
the tested changes into the reproducible device package rather than silently
replacing its verified baseline blob now.

The image and guarded installer have been uploaded to
/home/penguin/battery-candidate. No partition writes have occurred in this stage.
To install from the phone terminal:

```sh
sudo sh /home/penguin/battery-candidate/install.sh
```

This requires existing penguin sudo authentication. It verifies the current
kernel, native systemd, boot LUN A, input image and all four rescue B hashes;
locates vendor_boot_a by unique live label, checks full size and old hash;
saves the old vendor_boot_a on the native root; writes only vendor_boot_a;
checks the full readback and unchanged B hashes; then requests standard reboot.
A write-started marker prevents blind reruns. No host packages are installed.

## Next hardware checks

After boot: inspect driver binding and kernel messages, power_supply capacity,
voltage/current/temperature/status and UPower/Phosh discovery. Check sample
plausibility and repeated readings. Test USB unplug/replug and charge trend
before claiming working charging. Gauge-reported battery charge/discharge
status alone is not proof of charger online reporting, negotiated power,
safe charging control or VOOC/UFCS fast charging support. The GLINK/ADSP
charger-reporting path is a separate dependency investigation if needed.

## First hardware result

The user executed the installer; the saved result confirms vendor_boot_a full
readback and unchanged B startup partitions. Native systemd rebooted with boot
ID `4d911811-dfc6-4827-be90-93fe70e513a2`, running with no failed services.
`bq28z610-0` is registered and UPower exposes a Battery and DisplayDevice.
No custom driver or battery daemon was needed.

Observed: pack voltage approximately 6.823--6.827 V, temperature 29.1 C,
117 cycles, full capacity 2272 mAh and design capacity 2290 mAh, remaining
capacity/SoC zero. Initial net current was positive 46 mA; subsequent minute-long
samples were 0 or -1 mA with Not charging/Discharging status. UPower detected
charging initially, but stable charging has NOT been established.

The upstream bq28z610 path maps its fully-discharged flag to HEALTH_DEAD; that
string is not by itself evidence of permanently damaged battery hardware.
The factory header and upstream register map agree on temperature 0x06,
voltage 0x08, remaining charge 0x10, full charge 0x12, current 0x14,
cycle count 0x2a and SoC 0x2c. Accuracy still needs real charge/discharge trend
validation and optionally physical chip identification; no fake percentage
or health override has been added.

Evidence: runtime-initial.txt, sample-0.txt through sample-4.txt, samples.json,
and the archived factory oplus_bq27541.h in out/battery-bringup-20261016.
A finite ten-minute, unprivileged sysfs recording is running for a requested
computer-USB vs original-wall-charger comparison. Its path is saved in
charger-observation-path.txt; that comparison has not yet completed.

## Repeated power-off investigation

After the user reported repeated restarts on the original charger, USB SSH
was reachable on the computer with boot ID
`28465ed6-bbc4-4380-89ad-20503ea8345e`. Battery voltage was 6.913--6.914 V,
temperature 31.1--31.5 C, remaining capacity 0, SoC 0%, current 0 mA.
UPower reports pending-charge and on-battery=no on this computer connection;
neither this nor voltage recovery proves sustained charging.

Previous boots -5, -4, -3 and -2 explicitly record logind poweroff requests
from upowerd at approximately 38, 39, 42 and 89 seconds of uptime, followed by
orderly systemd poweroff and filesystem unmount. This establishes a software
critical-battery shutdown in those boots, not a sudden brownout or panic.
Boot -1 instead records a gnome-session poweroff request following a power-key
event. Why the phone starts again after poweroff is not established by these
logs; externally powered boot behavior is a candidate explanation only.

The ten-minute observer file contains only SAMPLE and one uptime line; no
gauge readings or wall-charger comparison survived. Do not use that file to
claim measured charger performance. Its interruption cause is unconfirmed.

Only the direct I2C gauge is present; rpmsg and remoteproc class devices are
absent. The DT disables ADSP and the config disables QCOM_BATTMGR, so the
Qualcomm firmware charger-management path remains unavailable. No UPower
critical-action protections were disabled and no charging registers changed.

Evidence: shutdown-cause-audit.txt, reboot-history-1.txt through -7.txt,
charger-chain-audit.txt, charger-observation-downloaded.txt under the same
output directory. Next work must distinguish the missing charger-management
path from gauge interpretation and validate actual net charging before
attempting to suppress critical-battery shutdowns or advertise fast charging.

## Urgent low-charge follow-up

User reports continued depletion on USB and no recovery after ten minutes on
the original wall charger. On current boot acb169ce-a410-41c8-bfa4-6bad3ee4073a,
a short computer-USB series reports Charging but net current declines from
148 to 58, 33, 18 and 10 mA. Pack voltage is 6.956--6.971 V, SoC and remaining
charge remain zero, temperature 29.3--29.4 C. This does not establish useful
sustained charging, nor measure wall-charger current. No flashing or reboot
was performed. Raw evidence: urgent-battery-state.txt and urgent-battery-trend.json.
A read-only stock firmware extraction script has been staged at
/home/penguin/read-stock-charger-firmware.sh; execution still requires the
user to authenticate phone sudo. No firmware has been installed or started.

Stock firmware extraction was already complete when SSH authorization was
rechecked. Downloaded stock-charger-firmware.tar (36.5 MB payload); all 63
firmware hashes match the phone manifest. ADSP split MDT and adsp_dtb files
were recovered from modem_a/image. dsp_a did not mount as FAT; no fallback
mount was attempted. No firmware installed or remote processor started.

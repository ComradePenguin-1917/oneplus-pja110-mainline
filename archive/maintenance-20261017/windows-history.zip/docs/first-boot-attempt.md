# 首次真机启动：失败分析与关键发现

> 日期：2026-10-10 · 设备 PJA110 / ColorOS 14.0.0.701 / 16 GB
> 结论：**实验本身不可观测** —— 这是比 DTB 传递更根本的问题

---

## 1. 实验记录

| # | 镜像 | fastboot 响应 | 结果 |
| --: | :-- | :-- | :-- |
| 1 | `boot-xigua-16G-gz.img`（gzip + DTB） | `Booting OKAY` | 屏幕停在 Fastboot Mode，USB 不上线 |
| 2 | `boot-xigua-16G-raw.img`（未压缩 + DTB） | `Booting OKAY` | **症状逐秒一致** |

两次都：
- ABL **接受并移交**了镜像（`Booting OKAY`）
- 之后 75 秒内 adb / fastboot / 9008 **全无响应**
- 恢复路径：三键进 9008 → 电源键 20 秒 → 正常进系统（第二次是自行恢复）

**分区完整性（两次实验后均验证）**：

```
boot_a = 742105c6…  与实验前一致 ✅   (KernelSU 已 patch，已备份)
dtbo_a = 30b4002a…  与实验前一致 ✅   (原厂)
```

✅ **`fastboot boot` 确认零写入**——这是实证，不是假设。

## 2. 已排除的假设

**"ABL 不解压 gzip 内核"** —— **已排除**。
raw（未压缩）与 gzip 症状完全一致。压缩格式不是原因。

## 3. 🔴 核心发现：实验不可观测

这是本次最重要的结论。我们的 boot.img **即使内核完美工作，也和一个死掉的内核表现得一模一样**。原因有三层：

### 3.1 没有 initramfs → 内核必然 panic

原厂把 ramdisk 放在 `vendor_boot` 里，`boot` 分区本身 `ramdisk_size = 0`。我们照抄了这个布局：

```
原厂 boot-A14.img : kernel=53238272  ramdisk=0
我们的 boot.img   : kernel=12424418  ramdisk=0   ← 没有 initramfs
```

而 `CONFIG_INITRAMFS_SOURCE=""`（未嵌入 initramfs）。所以内核启动到根文件系统挂载阶段会：

```
Kernel panic - not syncing: VFS: Unable to mount root fs on unknown-block(0,0)
```

**这是必然的，与内存图对不对无关。**

### 3.2 没有显示驱动 → 屏幕保持 ABL 留下的画面

面板（`AA536_P_3_A0001`）驱动还没写，所以屏幕会**一直停在 ABL 移交时的最后一帧** —— 也就是我们看到的 Fastboot Mode 画面。它不代表"内核挂了"。

### 3.3 没有用户态 → USB gadget 永远不会出现

这是最容易被误判的一点：

```
CONFIG_USB_CONFIGFS=y          ← gadget 框架在
CONFIG_USB_CONFIGFS_RNDIS=y    ← RNDIS 函数在
CONFIG_USB_ETH is not set      ← 但没有 legacy g_ether
```

**configfs 型 gadget 需要用户态写 `/sys/kernel/config/usb_gadget/...` 才会枚举。** 没有 initramfs 就没有用户态 → **ADB 网络永远不会上线**，不管内核多健康。

所以"75 秒没等到 adb"这个观察**不构成任何关于内核是否启动的证据**。

## 4. 唯一现存的观测通道：串口

好消息是串口配置是齐的：

```
CONFIG_SERIAL_QCOM_GENI_CONSOLE=y
CONFIG_SERIAL_EARLYCON=y
CONFIG_SERIAL_CORE_CONSOLE=y
```

cmdline 也指向了它：`console=ttyMSM0,115200 earlycon`

**但需要物理接线**：USB-TTL 适配器接到主板的 UART 测试点（`&uart7` → `a0a9c000`）。

## 5. 已排除的 DTB 交付疑点（查证结果）

我逐个解剖了 bootloader 分区，结论是**无法从这些镜像里找到 Linux 启动逻辑**：

| 分区 | 大小 | 性质 |
| :-- | --: | :-- |
| `abl` | 221 KB | 32-bit ELF，**只有签名证书**（OPLUS Attestation CA 等），无引导字符串 |
| `uefi` | 3.15 MB | 64-bit ELF，**FDT 辅助库**（`fdt_get_node_handle` 等），无引导逻辑 |
| `xbl` | 1.2 MB | 有 `boot_pre_ddr_dtb_load`、`dtb_loader.c`、`DTBO:` —— 但那是 **XBL 自己的** pre-DDR 设备树，与 Linux 无关 |

**没有证据支持"ABL 会读取 boot.img 尾部追加的 DTB"**，但也没找到它明确不做。这条目前**证据不足，不能下定论**。

有效信息：
- 原厂 `boot-A14.img` **不含** DTB（`FDT magic: NONE`）
- 原厂 `vendor_boot-A14.img` **含** `dtb_size = 2040970`（4 个 DTB）
- 真机 `/sys/firmware/fdt` = 732665 字节
- `/chosen` 里有 `linux,initrd-start/end`、`kaslr-seed`，**没有** dtb 相关字段

## 6. ramoops：一个潜在的新观测通道

真机上存在 ramoops 保留区（Android 的崩溃日志区）：

```
/sys/firmware/devicetree/base/reserved-memory/ramoops_region
  compatible    = "ramoops"
  size          = 0x00240000  (2.25 MiB)
  console-size  = 0x00040000
  pmsg-size     = 0x00020000
  alloc-ranges  = <0x0 0x0 0xffffffff 0xffffffff>   ← 地址动态分配
  mem-type      = 2
```

真机 `/sys/fs/pstore/` 是**空的**——说明我们那两次失败**连内核崩溃记录都没留下**，进一步支持"失败发生在极早期"。

`alloc-ranges` 是动态的，所以**地址不固定**，需要从运行时读取。可以做一个 noretain-RAM 的 dump 通道，但优先级低于串口。

---

## 7. 下一步的正确做法

**不要再盲试镜像了。** 必须先建立观测能力，否则每次实验都得不到信息。

### 优先级

| 方案 | 成本 | 信息量 |
| :-- | --: | :-- |
| **A. 接串口**（USB-TTL → UART 测试点） | 需拆机 + 买个 USB-TTL（~10 元） | ⭐⭐⭐⭐⭐ 完整内核日志 |
| **B. 内嵌最小 initramfs** | 零硬件 | ⭐⭐⭐ 能跑起用户态、能配 USB gadget → adb 能上线 |
| **C. 用 ramoops 读崩溃日志** | 中 | ⭐⭐ 只能看到 panic 信息 |

**B 是最该先做的**：把内核内置一个最小 initramfs（busybox + 自动配置 RNDIS gadget），这样**内核一旦起来，adb 就会上线**，我们就有了完全不需要硬件的观测通道。

同时 B 也修复了 3.1 的必然 panic——内核能真正跑到底。

**A 是终极方案**：串口能看到从最早期（earlycon）开始的全部输出，包括内存图错误、DTB 解析失败这类"还没到 USB 就挂了"的问题。如果你愿意拆机接个线，这是信息量最大的一步。

### 关于"是否继续试镜像"

在建立观测之前，**继续换镜像试没有意义**——任何结果都可能是"内核没起来"或"内核起来了但看不见"，无法区分。

---

## 8. 附带产出的安全资产

- 校准分区备份（`backup/`，14 个分区）：`persist`、`modemst1/2`、`fsg`、`fsc`、`ocdt`、`cdt`、`devinfo`、`apdp`
- **`boot_a.img`（KernelSU patch 版，全网唯一）+ `boot_b.img`（原厂）+ `dtbo_a/b.img`**
- 已验证的恢复流程：**卡住 → 三键进 9008 → 电源键 20 秒 → 正常启动**

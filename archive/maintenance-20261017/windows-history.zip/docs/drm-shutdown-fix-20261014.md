# DRM / GPU 关机依赖修复

## 复现与等待链

#23已修复显示性能预算，但在直接KMS动画仍活动时执行普通`reboot -f`可复现
关机死锁。活动Ubuntu Weston桌面下的一次基线重启正常，不能据此认为直接KMS
场景已修复。

复现采到的线程栈显示：

- 显示提交工作线程等待 `dma_fence_default_wait -> drm_atomic_helper_wait_for_fences`。
- 重启线程等待 `drm_atomic_helper_swap_state -> drm_atomic_helper_disable_all -> msm_kms_shutdown`。
- GPU关机路径会停scheduler并等待已激活提交，之后显示新提交所依赖的GPU工作
  无法继续执行。DPU在无新frame后进入idle并注销IRQ是后续现象，不是单凭IRQ
  注销就能认定的根因。

等待期间设备已部分关机，UFS分区读取返回`No such device or address`。刷写工具
在前置读回失败时停止，候选尚未写入；通过SysRq恢复完整#23设备状态后才部署。

## #24 修复

核对固定的Aston提交与上游v6.18，相关shutdown回调仍相同，没有直接可搬的修复。
复用内核标准 `device_link_add(master, gpu_dev, DL_FLAG_STATELESS)`：在Adreno
组件bind成功时将KMS主设备声明为GPU供应设备的consumer，让driver core在关机
时先停KMS、后停GPU。unbind通过 `device_link_remove` 配对清理。

不跳过DRM关机、不伪造fence完成、不缩短等待超时，不添加自制电源键或重启
用户态策略。配置、性能预算、DSC/DSI、面板与触控模块保持。候选仅改变
`adreno_device.c`，#24是本地修补，尚未称作上游已有修复。

## 实测

| 场景 | #23 | #24 |
| --- | --- | --- |
| 活动直接KMS行号动画下普通重启 | 75秒后仍死锁，采到等待栈 | 约23.02秒SSH恢复，新boot ID |
| 活动Ubuntu Weston及GPU旋转演示下普通重启 | 一次通过 | 通过，新boot ID、SSH及240Hz触控恢复 |

QEMU验证现有initramfs/SSH/触控模块兼容性；实机启动日志确认device-link建立。
仅写boot_b且完整读回八个启动分区，其他七个哈希不变，AVB尾部保留。
boot SHA256 `ee338bebf5c9118d05df7e0333fefc09e224dbbb577611c45c5e96863ec1b6d8`。

最终恢复Ubuntu24.04.5 RAM桌面，Mesa FD740四纯色及120帧离屏像素验证通过。
用户确认动态画面经过原故障区域正常，触摸正常。当前运行#24，默认perf mode0，
保留#23的命令模式性能预算，不依赖固定锁频。

本轮验证了普通重启；没有测真实断电、系统挂起恢复、kexec或完整systemd关机。
这些不能由普通重启结果推定通过。Ubuntu仍是RAM chroot，没有新增持久根分区。

## 证据与回退

`out/drm-shutdown-20261014/`保存旧内核复现trace/stacks、固定源码参考、补丁、
构建/QEMU、分区读回和两种重启结果。`kernel/boot_b-sdma.img`是#24候选。
回退为 `out/display-budget-20261014/boot_b-sdma.img`，init_boot保持当前版本。

下一步可继续构建完整配置的Ubuntu根文件系统并验证systemd PID1；持久存储
方案仍需具体确定，不能覆盖Android userdata/super或日志分区作为默认选择。

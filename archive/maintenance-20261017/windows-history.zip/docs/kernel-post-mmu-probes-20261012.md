# MMU 开启与内核虚拟地址跳转定位

后续探针已支持确认 start_kernel 入口及 setup_arch 返回，见 [C 初始化记录](kernel-c-init-probes-20261012.md)。

## 实机结论

本轮两个 PSCI 重启探针均产生用户观察到的约 5 秒自行反复重启，结合实际 Image 的 QEMU 验证和实机输入读回，支持以下阶段已到达：

| 探针位置 | 支持确认的执行阶段 | 尚未验证 |
| --- | --- | --- |
| `__enable_mmu` 最后 ISB 之后、RET 之前 | 页大小检查、TTBR0/TTBR1 写入、SCTLR 更新、MMU 开启后的同步与后续取指 | 内核虚拟地址下的执行 |
| `__primary_switched + 4`，保留 BTI 入口 | `__pi_early_map_kernel` 返回，跳入内核虚拟地址下的 `__primary_switched` | init_task/栈/TPIDR 设置、异常向量设置、finalise_el2、start_kernel |

因此正常主线实验的无日志现象已经不能主要解释为 Image 入口没有执行，或完全卡在 MMU 开启/最初虚拟地址跳转之前。仍没有正常 Linux 日志、USB 或用户态成功证据，也不能据此断言故障就在后续某条指令。

时间来自用户观察，没有外部精密计时；约 5 秒周期与同一探针前两轮的实机行为和 QEMU 计时相符。底层复位记录本身不能唯一标识 PSCI 调用，阶段判断使用组合证据。

## 如何避免探针制造额外故障

前两轮探针附加在 Image 文件末尾的 BSS 范围，只能在 MMU 关闭、BSS 未被处理前使用。本轮没有复用该位置：

1. MMU 后探针放在 `__idmap_text_end` 到 `idmap_pg_dir` 之间的零填充，且与最后一段 idmap 代码位于同一个 4 KiB 页。位置 `0x177ba00`，替换 `__enable_mmu` 的 RET（文件偏移 24622324）；该页已由身份映射覆盖。
2. 虚拟地址探针放在 `__alt_instructions_end` 之后、`__inittext_end` 之前的对齐零填充。位置 25451232，替换 `__primary_switched + 4`（文件偏移 24685196），保留其入口 BTI。实际 `map_kernel.c` 将整个 `__inittext_begin..__inittext_end` 范围作为早期内核代码映射；该区域不会被 BSS 清零。

两轮均核对原指令编码、空闲字节与符号边界，只修改一条分支和 68 字节探针。Image 头、声明大小、文件长度以及其余所有原始字节不变。探针不依赖绝对地址，内核重定位不会破坏其内部相对分支。

符号、`__primary_switched` 反汇编、早期映射代码及链接脚本来自 WSL 的同一内核构建；读取前已核对编译 Image SHA256 等于 r1 原始值。

## QEMU 核对

两轮均使用 `virt,virtualization=on`、Cortex-A57、`-no-reboot` 验证同一实际测试 Image，执行日志包含 SMC 指令块，退出码 0。

| 版本 | QEMU 时长 | Image SHA256 |
| --- | --- | --- |
| MMU 后 | 5.291 s | `c18ff0a9e14194fda38d0a9aeaec5d1faa3b39bdb7b586bdf3a78d3c233827dc` |
| 虚拟地址跳转后 | 5.440 s | `23cacfd73008d6b3ad0b5f0cd63f0b325634b94e47ac278156d6c748d3a2f531` |

## 实机输入和恢复

基于 r1 内核和 ABL-success fixup 对照，只有 boot_b 内容不同。USB2 vendor_boot、fixup DTBO 和 r1 generic init_boot 完全一致。未写 logdump，未修改 vbmeta。

每轮都在 Android A 完成启动时核对八分区状态及恢复文件；采证时核对 boot_b 测试镜像前缀、完整 vendor_boot_b/init_boot_b/dtbo_b 的哈希。测试后恢复原先 B 槽四分区，切回 A，并核对八分区哈希及 Android 完成启动。

- MMU 后：`out/kernel-post-mmu-probe-20261012/` 与 `out/kernel-post-mmu-probe-experiment-20261012/`。
- 虚拟地址跳转后：`out/kernel-virtual-switch-probe-20261012/` 与 `out/kernel-virtual-switch-probe-experiment-20261012/`。
- 同一构建的启动代码与映射来源：`out/kernel-entry-probe-20261012/primary-switched-disassembly.txt`、`map_kernel.c`、`vmlinux.lds.S`。
- 生成工具：`tools/package_post_mmu_probe.py`，虚拟地址版本参数 `--virtual-switch`。

下一处可验证 `start_kernel` 入口，从而覆盖 `__primary_switched` 中 init_task、栈、异常向量、启动模式和 finalise_el2 的设置。当前已取得正常内核高虚拟地址执行的证据，但尚未取得 `start_kernel` 的执行证据。

# Image 入口与 MMU 开启前定位

后续实机探针已支持确认 MMU 开启后的执行及内核虚拟地址跳转，见 [后续记录](kernel-post-mmu-probes-20261012.md)。本文保留最初两轮的边界与证据。

## 已获得的阶段信号

两轮探针均在实机产生用户观察到的约 5 秒自行反复重启，符合探针的计时和 PSCI 重启行为。第一轮在原始 ARM64 Image 入口执行探针；第二轮保留原入口及 Linux 前置路径，将探针放在 `__enable_mmu` 的首个寄存器读取之前。

这些结果结合 QEMU 指令记录、实机镜像读回和 B 槽启动记录，支持以下阶段已到达：

1. ABL 执行 ARM64 Image 入口代码。
2. Linux `primary_entry`、启动参数保存、初始 idmap 页表创建、缓存维护、异常级设置与 `__cpu_setup` 已执行到 `__enable_mmu`。

第二轮探针在 `__enable_mmu + 4`，保留函数入口 BTI 指令，替换原 `mrs x3, id_aa64mmfr0_el1`。它发生在写入 TTBR/SCTLR 开启 MMU 之前，因此没有验证 MMU 成功开启、虚拟地址跳转、BSS 清零、`start_kernel`、UFS 或 `/init`。

约 5 秒信号来自用户观察，未使用硬件计时器外部仪器测量。PSHOLD 复位记录不是 PSCI 调用的唯一标识；本轮主要依靠探针指定延迟、与无探针时持续黑屏的差异、QEMU 验证和输入一致性构成证据。

## 探针实现

`tools/kernel_entry_probe.S` 为 68 字节 ARM64 汇编。仅屏蔽异常、读取 CNTFRQ/CNTPCT，等待 5 秒，调用 `SMC` 的 PSCI `SYSTEM_RESET`（`0x84000009`）。不使用栈、外设驱动或主动写入 RAM/日志分区；如果计数器频率为零则立即调用重启，如果调用返回则停留在 WFE 循环。计数器陷阱或固件不支持可能产生阴性结果，所以没有重启不能单独证明阶段未执行。

在已验证的 r1 Image 文件末尾附加这 68 字节，附加范围仍在原 Image 头 `image_size` 声明的范围内。只替换选定位置的一条 4 字节分支，Image 头和其余原始 Image 字节不变。该附加位置在常规内核 BSS 范围内，只用于 BSS 清零前、MMU 关闭时的探针；不能直接复用为开启 MMU之后或 `start_kernel` 的执行探针。

基础树、DTBO、generic init_boot 均使用已经通过 ABL 的 fixup 对照，只有 boot_b 内容变化。未写入 logdump，未更改 vbmeta。

## QEMU 与符号绑定

两轮使用同一实际测试 Image 在 QEMU `virt,virtualization=on` / Cortex-A57 上验证，`-no-reboot` 后约 5.29 秒退出，退出码 0，并记录含 SMC 的执行指令块。这个虚拟机使用 QEMU 提供的 PSCI SMC 后端。

入口探针 Image SHA256：`91bf6e47f4cdcd534e72f00329a3b6566f355794ad10816e36dca13de7e604d6`。

MMU 前探针 Image SHA256：`7814af74887483016f9633827a06cd4ad64bf868cc0464cccfbb812a28213940`。

第二轮符号来自 WSL 的 vmlinux，在导出之前核对同目录编译 Image SHA256 与 r1 原始 Image 一致。`_text=ffff800080000000`，`__enable_mmu=ffff80008177b4a8`，替换文件偏移为 24622252。原指令编码 `0xd5380703` 与反汇编一致。

最初启用 QEMU secure world 但没有 EL3 固件的验证失败，未用于通过证据；改用 QEMU 自带 PSCI 后端后通过。SMC 被 QEMU 后端处理不一定记录为异常，因此最终核对指令块及实际复位退出，未宣称观察到 SMC 异常。

## Image 与内存审计

`out/arm64-handoff-audit-20261012/result.json` 对比原厂与主线的 Image 头和当前 Android 实际 DTB 固定预留范围：两者均为原始 ARM64 Image，text_offset=0、flags=10，Image 头大小均大于实际文件大小。未发现固定预留区的明显遗漏；rmtfs 在主线单独声明为 2.5 MiB no-map 区，部分既有预留区在主线额外设置 no-map。实际内核加载地址尚未知，不能据此宣称完全排除内存映射问题。

## 证据与恢复

- 入口探针构建与 QEMU：`out/kernel-entry-probe-20261012/`。
- 入口探针实机与恢复：`out/kernel-entry-probe-experiment-20261012/`。
- MMU 前探针构建与 QEMU：`out/kernel-pre-mmu-probe-20261012/`。
- MMU 前探针实机与恢复：`out/kernel-pre-mmu-probe-experiment-20261012/`。

各轮 B 槽 boot 镜像前缀及其余三个分区全哈希读回核对，A 槽保持原内容。采证后恢复本轮前的四个 B 槽分区并切回 A；八分区哈希和 Android 完成启动状态通过恢复核对。

下一处应定位 MMU 开启后的首次执行。需要将探针放入正确映射的可执行代码段，保留已确认的 PSCI 信号机制；不能把当前 BSS 尾部的附加探针直接跳过去使用，否则可能因不可执行映射或 BSS 清零而制造额外故障。

参考：[ARM64 引导协议](https://docs.kernel.org/arch/arm64/booting.html)、[Arm Trusted Firmware PSCI 定义](https://github.com/ARM-software/arm-trusted-firmware/blob/master/include/lib/psci/psci.h)。实机结论依据本轮探针与记录。

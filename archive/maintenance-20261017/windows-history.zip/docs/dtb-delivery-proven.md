# 决定性实验：ABL 从不使用追加的 DTB

> 日期：2026-10-11 · 方法：对照实验（纯内存启动，零写入）

## 1. 实验设计

三次启动的**唯一变量**是 kernel 字段：

| 组 | kernel 内容 | 预期 |
| :-- | :-- | :-- |
| **D（基线）** | 原厂内核，**无** DTB | 应该正常启动 |
| **C（关键）** | 原厂内核 + **我们的 DTB** 追加 | 若 ABL 使用追加 DTB → 原厂 5.15 内核会因主线 compatible 而异常 |
| 之前 | 我们的内核 + 我们的 DTB | 无反应 |

## 2. 结果

```
D: 原厂内核 + 无 DTB      → 12 秒启动成功  ✅
C: 原厂内核 + 我们的 DTB  → 12 秒启动成功  ✅   ← 与 D 完全一致
```

**C 和 D 表现逐秒相同。**

## 3. 结论

> **ABL 完全忽略追加在 kernel Image 尾部的 DTB。**
> 设备树**始终**由 ABL 从 flash 上的 `vendor_boot` + `dtbo_a` 组装。

依据：

1. **C 组本应失败却成功了**。我们的 DTB 描述的是主线 compatible
   （`qcom,sm8550-gcc`、`qcom,sm8550-tlmm` 等），原厂 5.15 内核一个都不认。
   如果 ABL 真的把它喂给内核，原厂内核绝不可能正常启动。

2. **ABL 日志每次都显示从 flash 加载 dtbo**：
   ```
   Load Image dtbo_a total time: 9 ms
   Apply Overlay      total time: 322 ms
   Update Device Tree total time: 60 ms
   ```

3. 三次实验的分区哈希始终未变（`boot_a = 742105c6…`、`dtbo_a = 30b4002a…`）。

## 4. 这修正了我之前的一个错误判断

我曾在 `docs/abl-log-breakthrough.md` 里写：

> "DTB 不是我们塞在 Image 尾部、由内核自己找的；而是 ABL 用它在 flash 上的
> `dtbo_a` 拼好之后传给内核的。"

方向对了，但我当时**没有实验证据**，只是从日志推断，而且留了"证据不足"的尾巴。
**现在有了对照实验的硬证据。**

同时这也意味着：**之前所有镜像（gz / raw / initrd）里追加的 DTB 从未被使用**。
那些镜像实际跑的是"我们的内核 + 厂商的设备树"。

## 5. 为什么"我们的内核 + 厂商 DTB"必然失败

统计发现：厂商 DTB 里 `/soc` 下用了 **221 个** `qcom,` compatible，
其中**只有 23 个**能在主线内核里找到。缺失的包括关键项：

| 厂商 DTB 的 compatible | 主线要的 | 后果 |
| :-- | :-- | :-- |
| `qcom,kalama-gcc-v2` | `qcom,sm8550-gcc` | ❌ **时钟控制器不 probe** |
| `qcom,kalama-pinctrl-v2` | `qcom,sm8550-tlmm` | ❌ **pinctrl 不 probe** |
| `qcom,dwc-usb3-msm` | `qcom,dwc3` | ❌ **USB 控制器不 probe → 无 UDC → 无 gadget** |
| `qcom,kalama-*` 系列（noc/llcc/dispcc/gpucc…） | `qcom,sm8550-*` | ❌ 大量外设不 probe |
| `qcom,ufshc` | `qcom,ufshc`（通用回退） | ✅ **唯一匹配的** |

顺带修正另一处：我一度怀疑 **PSCI 缺失导致早死**，但实测厂商 DTB 把
`/soc/psci { method = "smc" }` 放在 `/soc` 下（内核全树搜索能找到），
与我们的 DTB 一致。**PSCI 不是问题**，那个假设是错的。

## 6. 现在唯一可行的路线

既然 ABL 只用 flash 上的设备树，就必须**改 flash 上的 dtbo**：

```
把我们的设备树做成 dtbo 镜像 → 刷入 dtbo_a → ABL 在 Apply Overlay 时会叠加上它
```

### 但这里有个必须先想清楚的技术障碍

ABL 的 dtbo 是**叠加（overlay）**语义，在**厂商基础 DTB 之上**应用。
而我们的 DTS 是"完整替换"语义：

```dts
/delete-node/ &reserved_memory;     /* 删掉上游定义，自己重新声明 */
...
```

做成 overlay 后，`/delete-node/` 之类操作会在厂商 DTB 上执行，
而厂商 DTB 的结构和上游 `sm8550.dtsi` **完全不同**——节点路径、label 名都不一样。
直接在厂商 DTB 上套我们的 overlay，**大概率不成立**。

### 因此需要先解决一个设计问题

| 方案 | 思路 | 难点 |
| :-- | :-- | :-- |
| **A. overlay 打补丁** | 写一个**针对厂商 DTB** 的 overlay，只改必要节点（时钟/pinctrl/USB 的 compatible） | 要把厂商 DTB 的节点路径摸清；改动面大时很脆弱 |
| **B. 完整替换** | 让 ABL 完全用我们的 DTB，不叠加 | 需要弄清 ABL 是否支持"dtbo 里放完整 DTB"这种用法 |
| **C. 绕过 ABL** | 让内核忽略外部 DTB，用内嵌的 | arm64 **没有** `CONFIG_BUILTIN_DTB`（已查证 `grep -rn BUILTIN_DTB arch/arm64/` 为空） |

**方案 C 已排除**（arm64 不支持内嵌 DTB）。

## 7. 下一步要查清的事

在动手刷 `dtbo_a` 之前，必须先弄清：

1. **ABL 的 overlay 到底怎么应用** —— 是标准 FDT overlay（`fragment@N/target-path`）
   还是 OPPO 私有格式？（我们已观察到 dtbo 里 fragment 的 `target = 0xffffffff`，
   是预链接状态）
2. **能否让 ABL 接受一个"完整 DTB 替换"** —— 有些 ABL 实现允许 dtbo 里放完整 DTB
   并整块替换
3. **厂商 DTB 的节点路径清单** —— 如果走 overlay 补丁路线，需要精确知道要改哪些节点

**在没有查清这些之前，不应刷 `dtbo_a`。**

## 8. 资产与状态

| 项 | 状态 |
| :-- | :-- |
| 设备 | ✅ 正常，分区零改动（已验证 4 次实验后） |
| 备份 | ✅ `boot_a`/`boot_b`/`dtbo_a`/`dtbo_b` + 14 个校准分区 |
| 恢复流程 | ✅ 已验证（三键进 9008 → 电源 20s） |
| 对照实验组 | ✅ `out/control-nodtb.img`、`out/control-ourdtb.img`（可复现） |
| ABL 日志 | ✅ 三份样本可对比 |
| **已确认的核心事实** | ✅ **ABL 只用 flash 上的设备树；追加 DTB 无效** |

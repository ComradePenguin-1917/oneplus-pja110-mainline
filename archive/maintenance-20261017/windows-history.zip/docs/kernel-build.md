# 内核编译与 boot.img 产出（阶段 B 完成）

> 日期：2026-10-10 · 内核：**Linux 6.14.0-sm8550**（主线 v6.14 + xigua DTS）
> 编译环境：WSL2 Ubuntu 22.04 · 工作区 `~/workspace/PJA110-Mainline`

---

## 1. 产出物（`out/`）

| 文件 | 大小 | 说明 |
| :-- | --: | :-- |
| `Image` | 31.6 MiB | arm64 内核（未压缩） |
| `Image.gz` | 11.8 MiB | 压缩版 |
| `Image_w_dtb` | 31.8 MiB | `Image` + DTB 拼接 |
| `Image_w_dtb.gz` | 11.9 MiB | 拼接后压缩 |
| **`boot-xigua-16G-gz.img`** | 11.9 MiB | ✅ **首选刷机镜像**（gzip + DTB） |
| **`boot-xigua-16G-raw.img`** | 31.8 MiB | ✅ 备选（未压缩 + DTB） |
| `sm8550-oneplus-xigua.dtb` | 143 KB | 保守 RAM 图 |
| `sm8550-oneplus-xigua-16G.dtb` | 143 KB | **实测 16 GB 内存图** |
| `config-6.14-xigua` | 234 KB | 完整内核配置 |
| `System.map` | 5.3 MiB | 符号表（调试用） |

两个 boot.img 都已**独立回读验证**：header v4、kernel 段正确、DTB 追加在 8 字节对齐处、内含 `oneplus,xigua`。

## 2. 复现流程

```bash
# 1) 工具链（免 root，见 docs/toolchain.md）
bash tools/wsl_setup_toolchain.sh

# 2) 内核源码（tarball，比 git clone 快得多）
bash tools/wsl_fetch_kernel.sh 6.14

# 3) 装入 DTS
bash tools/wsl_install_dts.sh

# 4) 配置
bash tools/wsl_configure_kernel.sh

# 5) 编译（约 60 秒，20 核）
bash tools/wsl_build_kernel2.sh

# 6) DTB 的 -@ 修复（ABL label）
bash tools/wsl_add_dtc_flags.sh

# 7) 打包
bash tools/wsl_pack_bootimg.sh 16G
```

## 3. 过程中查清并解决的四个问题

### 3.1 依赖闭包里的 segfault（Error 139）

首次编译（20 并发）在 `fs/btrfs/space-info.o` 上 **SIGSEGV**。

排查结论：**不是工具链坏了**——
- 单独重编同一对象 → 成功
- 编译器连续 3 次冒烟测试 → 全通过
- `cc1` 完整存在

判断是 **23 GiB 内存下 20 并发 cc1 的资源抖动**。降到 12 并发后**一次通过**。
编译脚本已改成"降并发 + 失败自动重试"。

### 3.2 `CONFIG_ARM64_APPENDED_DTB` 不存在

aston 配置片段里有 `CONFIG_ARM64_APPENDED_DTB=y`，我一开始以为它在起作用。**实测在 arm64 上这个符号根本不存在**（只有 MIPS/ARM 有），kbuild 静默忽略了它。

这引出了 DTB 到底怎么传的问题（见 3.3）。

### 3.3 DTB 如何交付给内核（关键）

我查了内核源码和官方文档，结论明确：

| 证据 | 内容 |
| :-- | :-- |
| arm64 文档 | *"The AArch64 kernel does **not** currently provide a decompressor — decompression (gzip etc.) **must be performed by the boot loader**"* |
| 内核维护者 Krzysztof | *"You are supposed to boot standard kernel with typical setup — **concatenated DTB**."* |
| 内核维护者 Bjorn | *"you append the DTB"* |
| 可用的 aston 移植 | `cat Image dtb > Image_w_dtb; gzip` |

**所以拼接 DTB 是【引导加载器】的约定，不是内核配置项。** arm64 内核侧不需要任何开关——ABL 解压后按约定把 DTB 放进 `x0`。

我们的打包器正是这么做的，且验证了 DTB 落在 **8 字节对齐**处（arm64 启动协议要求）。

### 3.4 ABL label 在内核构建中丢失（重要）

我们的独立 DTS 编译器用了 `-@`，ABL 需要的两个 label 在。但**内核自己的 dtc 调用不加 `-@`**，所以内核构建出来的 DTB **没有 `__symbols__`**——兼容处理等于没做：

```
in-tree DTB : __symbols__ present: False   ← 问题
standalone  : __symbols__ present: True
```

修复方式（内核官方机制，Tegra/MediaTek 板子都这么用）：

```makefile
DTC_FLAGS_sm8550-oneplus-xigua := -@
DTC_FLAGS_sm8550-oneplus-xigua-16G := -@
```

依据来自 `scripts/Makefile.dtbs`：
```makefile
DTC_FLAGS += $(DTC_FLAGS_$(target-stem))
```

修复后 DTB 从 107 KB → 143 KB，`__symbols__` 与两个 label **均已确认存在**。

## 4. 配置要点（已核对）

| 类别 | 关键项 | 状态 |
| :-- | :-- | :-- |
| **串口** | `CONFIG_SERIAL_QCOM_GENI=y` + `_CONSOLE=y` | ✅ |
| 存储 | `CONFIG_SCSI_UFS_QCOM=y`、`PHY_QCOM_QMP_UFS=y`、`UFS_BSG=y` | ✅ |
| USB | `USB_DWC3=y`、`PHY_QCOM_QMP_USB=y`、`SNPS_EUSB2=y`、`EUSB2_REPEATER=y` | ✅ |
| Type-C | `TYPEC=y`、`TYPEC_MUX_FSA4480=y`、`QCOM_PMIC_GLINK=y` | ✅ |
| PMIC | `SPMI_MSM_PMIC_ARB=y`、`REGULATOR_QCOM_RPMH=y`、`QCOM_CLK_RPMH=y` | ✅ |
| 时钟/互连 | `PINCTRL_SM8550=y`、`INTERCONNECT_QCOM_SM8550=y`、`QCOM_LLCC=y` | ✅ |
| 显示 | `DRM_MSM=y` | ✅（面板驱动待写） |
| 触摸 | `TOUCHSCREEN_GOODIX_BERLIN_SPI=m` | ✅ |
| 启动必需 | `QCOM_SCM=y`、`ARM_SMMU=y`、`QCOM_RMTFS_MEM=y`、`QCOM_SMEM=y` | ✅ |

> 注意：我最初用**猜的符号名**（`CONFIG_SERIAL_MSM_GENI`）检查，误报"串口缺失"。
> 实际符号是 `CONFIG_SERIAL_QCOM_GENI`，**一直都开着**。

## 5. boot.img 参数

| 项 | 值 | 来源 |
| :-- | :-- | :-- |
| `header_version` | 4 | 原厂镜像 |
| `os_version` | `0x1a000184` | **直接继承原厂**（不重算，避免防回滚） |
| `ramdisk_size` | 0 | 与原厂一致（本机无 ramdisk） |
| `cmdline` | `console=ttyMSM0,115200 loglevel=8 earlycon` | 替换原厂的 `console=ttynull` |

## 6. 下一步（首次接触真机）

```bash
# 只内存启动，不写任何分区
fastboot boot out/boot-xigua-16G-gz.img
```

若 ABL 因 DTBO 拒绝加载：

```bash
fastboot erase dtbo
fastboot boot out/boot-xigua-16G-gz.img
```

**预期**：能进 shell（USB 网络），屏幕仍黑（面板驱动未写）。
若失败，按此顺序怀疑：RAM 图 → os_version → DTBO 兼容 → 内存图某条冲突。

**前提**：确认手机当前 fastboot 可用、且没有重启进过系统（ABL 的 DTBO 决策需要完全断电冷启动）。

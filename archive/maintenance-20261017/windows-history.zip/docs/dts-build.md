# 构建与验证 xigua 设备树

本文档说明如何编译、验证 `sm8550-oneplus-xigua.dts`，以及每个数值的来源。

## 1. 文件

| 文件 | 说明 |
| :-- | :-- |
| `dts/sm8550-oneplus-xigua.dts` | 主 DTS（bring-up 阶段 0：内存图 + UFS + USB + PMIC + 串口） |
| `dts/sm8550-oneplus-xigua-16G.dts` | 16 GB 变体（覆盖 `oplus_mem` 的 RAM 图） |
| `dts/Makefile.fragment` | 集成到内核树时的 Makefile 条目 |
| `tools/build_dts.py` | 跨平台构建脚本（cpp → dtc） |
| `tools/verify_dts.py` | **关键校验**：对比编译产物与厂商固件内存图 |

## 2. 编译

```bash
python tools/build_dts.py                              # 主 DTS
python tools/build_dts.py --dts dts/sm8550-oneplus-xigua-16G.dts
python tools/build_dts.py --keep-pre                   # 保留 cpp 输出便于调试
```

工具链（Windows 上已验证可用）：
- `dtc` 1.7.2 — 通过 msys2 安装：`pacman -S mingw-w64-ucrt-x86_64-dtc`
- `gcc`（做 C 预处理器）— msys2 ucrt64
- 内核头文件 — `linux/` 稀疏检出（见下）

dtc **不能**直接吃 `#include`，所以必须先跑 C 预处理器（内核也是这么做的）。
`build_dts.py` 复刻了 `scripts/Makefile.lib` 的 cpp 参数。

### 内核头文件稀疏检出

```bash
git clone --depth 1 --filter=blob:none --sparse https://github.com/torvalds/linux.git linux
cd linux
git sparse-checkout set arch/arm64/boot/dts/qcom include/dt-bindings include/linux scripts/dtc
git sparse-checkout add include/uapi
```

> ⚠️ **Windows 上的坑**：git 检出时把符号链接写成了普通文本文件
> （如 `include/dt-bindings/input/linux-event-codes.h` 内容就是一行路径），
> 导致 cpp 报 `syntax error`。用 `python tools/fix_symlinks.py` 修复。

## 3. 验证（重要）

```bash
python tools/verify_dts.py
```

它把编译出的 DTB 的 reserved-memory 与厂商 `vendor_boot-A14.img` 基础 DTB
**逐项对比**（按基址+大小）。当前结果：

```
vendor regions : 40
ours   regions : 41
=== declared by vendor but MISSING from our DTS (0) ===
=== declared by us but NOT in vendor (1) ===
  0x00d4a80000 + 2621440    rmtfs-region@d4a80000      <- 故意的，见下
```

**这个校验抓到过一个真实 bug**：`hwfence_shbuf` 我最初按上游写 `0x2dd000`，
实际厂商是 `0x279000`（差 60 KiB）。这类错误在真机上表现为随机崩溃，
不校验根本查不出来。

## 4. 每个数值的来源

| 内容 | 来源 | 可信度 |
| :-- | :-- | :-- |
| 40 项 reserved-memory | 厂商 A14 `vendor_boot` 基础 DTB，逐项对比 | ✅ 已校验一致 |
| PMIC / regulator | 厂商基础 DTB + 同门机型 Ace 3（PMIC 组合相同） | ✅ 高 |
| UFS / USB / GPIO / pinctrl | 一加 SM8550 家族通用布局（与 Ace 3 相同） | ⚠️ 待真机验证 |
| `qcom,msm-id` / `qcom,board-id` | 厂商 dtbo：`0x10008 0x0` + 4 个 msm-id | ✅ 高 |
| 串口 = `&uart7` | 厂商 `aliases/serial0` → `a9c000`，与上游 `uart7` 一致 | ✅ 高 |
| **RAM 图（`oplus_mem`）** | **推算**，非实测 | ❌ **最不确定，必须真机确认** |

### rmtfs 为什么是"多出来"的

厂商用私有 binding `qcom,sharedmem-uio`（`/soc/qcom,rmtfs_sharedmem@0`）
声明 rmtfs，`reg` 的 base 写成 0 由 bootloader 填，所以扫描时看不到它的地址。
判定它应该在 `0xd4a80000` 的依据（已实测）：

- 大小一致：都是 `0x280000`（2.5 MiB）
- `qcom,client-id` 都是 `1`
- `0xd4a80000` 在 xigua 上是**空闲**的，不与任何厂商区域重叠
- `0xd4a80000 + 0x280000 = 0xd4d00000` = `mpss_dsm` 起点，**严丝合缝**

## 5. RAM 图的不确定性（当前最大风险）

厂商基础 DTB 的 `/memory` 是空的：

```
/memory {
    device_type = "memory";
    reg = <0x0 0x0>;      <- bootloader 填充
}
```

我查过 `xbl` / `xbl_config` / `abl`，**没有**静态的内存尺寸表
（只有 `DDR Frequency` 之类的运行时信息）。dtbo 里也没有内存图。

所以 `oplus_mem` 的 16 GB 布局是**按同门机型 Ace 3 的形状推算的**，需要真机确认。

**三种确认方式（推荐顺序）：**

1. **最快**：先用**上游参考板的 `memory@a0000000`**（`reg = <0 0xa0000000 0 0>`）
   保留不动，让 bootloader 自己填。如果 ABL 认我们的 DTB 是"自家" DTB 就会填。
2. 真机起动后 `cat /proc/meminfo` + `cat /proc/iomem` 反推。
3. 串口日志里 `Memory: ... available` 一行直接给出总容量。

> 因此 `sm8550-oneplus-xigua-16G.dts` 应视为**待验证的假设**，不是结论。
> 主 DTS 里我保留了 `oplus_mem`，把覆盖放在变体里，便于快速试错。

## 6. 下一步

- [ ] 真机确认 RAM 图（见上）
- [ ] 打 boot.img：`Image.gz` + DTB 追加，`mkbootimg --header_version 4`
- [ ] `fastboot erase dtbo` 绕开 ABL 的 DTBO 兼容问题
- [ ] 串口参数改成 `console=ttyMSM0,115200`（厂商默认是 `console=ttynull`）
- [ ] 面板驱动（AA536_P_3_A0001（原写 BOE AA536_P_3_A0001，已修正））+ 触摸（GT9916）

# GPU 扫描缓冲区读回定位

当前 #17 SDMA 对照内核，未刷写、未重启。
在单独的上游 kmscube 副本 drm-legacy.c 增加第 60 帧读回：
先 glFinish/glReadPixels，然后在前缓冲锁定后 gbm_bo_map 同一待翻页 BO。
仍使用原来的绘制和 KMS 翻页逻辑，源码差异保存为 readback-only.patch。

两份 1240×2772 图像转为相同 RGB 排列后逐像素完全一致，都是完整
立方体，中央无噪声带。实际 BO modifier=0（linear），map_stride 与
scanout_stride 均为 5120，format=XR24。GPU 故障计数仍为 0。

进一步把该正确图像转换为 framebuffer BGRX，每行补齐到 4992 字节，
写入 /dev/fb0。用户仍确认中央花屏。
读取 framebuffer 前 13837824 字节的 SHA256 与上传原始数据一致：
`3464b51f8772142a00d8f6e594a210916b780ea25f133e7f3bd1b59ccbfdb9a8`。
正常关屏两秒、开屏重新初始化面板，再写同图，用户确认仍花屏。

因此这一捕获帧的 GPU 渲染与内存内容正确，5120/4992 行跨度差异不能
单独解释现象，普通开关屏未清除问题。仍不能仅凭 CPU/GL 读回完全
排除设备间可见性或 DPU 取图问题；后续重点为 DPU 输出、DSC 参数及
DSI/面板链路，尤其验证简单彩条与复杂图像内容的差异。

结束后重新提交六色彩条，用户确认彩条完整正常。同一 framebuffer 路径
下复杂图像花屏、简单彩条正常，提示应优先核对 DSC 编解码参数与内容
相关的行为；这仍是定位方向，不是已证实的根因。
用户随后提供近拍，彩条也有周期性横线；宏观彩条正常并不能证明完全
无显示异常。后续核对见 [DSC 参数审查](dsc-audit-20261014.md)。
读回图像与对照证据保存在
`out/gpu-scanout-readback-20261014/`：gpu-gl-readback.ppm/png、
gpu-bo-readback.ppm/png、pixel-comparison.json、fb-copy.json、
kmscube-output.txt、after.txt、readback-only.patch。
本轮没有宣称花屏已修复，也没有继续变更 Active CTL 或 DSC 参数。

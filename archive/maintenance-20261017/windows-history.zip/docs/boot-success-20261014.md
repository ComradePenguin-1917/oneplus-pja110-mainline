# PJA110 B 槽启动成功标记

已在运行中的 #18 主线内核标记 B 槽成功，并完成一次普通重启验证。
使用未经修改的主线手机工具 qbootctl，固定 commit
`b8d22489141b2904dd1ab3d18912876b6dbe8284`，源码来源
https://gitlab.com/sdm845-mainline/qbootctl 。以普通 WSL 用户编译静态 ARM64
工具，上传手机 /tmp 后调用显式 `qbootctl -m 1`；未调用默认槽位推断。

## 布局与前置检查

Qualcomm boot-control 把成功位放在 GPT entry attributes bit 54。
本机 misc+2048 没有 AOSP bootloader_control，不能直接写该结构。
当前 UFS boot_lun_enabled=2，实际运行 #18，GPT 活动 boot 分区为 B；
qbootctl -a/-b 1/-n 1 与独立 GPT 解析一致。
本机 /proc/cmdline 没有 slot_suffix，qbootctl 的默认 current-slot 会回落 A，
因此禁止用不带明确槽位参数的 `-m`。

操作前逐个 UFS LUN 保存主备 header/table，验证 header 和 table CRC、
物理 LBA、partition entry 边界。sde 主表有效；备表 table CRC 不一致，
但与主表只差 boot_b 重试次数一个 bit（主表 6，备表 7），所有分区
起止、UUID 与其他属性一致。qbootctl 常规成功标记重算主备 CRC。
没有手工猜测分区位置，也没有用自制 GPT 写入器。

## 实际变化与验证

qbootctl 对已有成对分区设置 B 成功位。本机只有 boot_b 和
vbmeta_system_b 的成功位此前为 0，实际新增成功位各自在主备表两份。
独立比较确认只改变这四个 entry 的 bit 54；A 属性、分区起止及 retry
字段未改，CRC 已重算且全部主备表有效。启动镜像 payload 未刷写。

普通重启后约 21.92 秒自动 SSH 恢复，仍为 #18，boot_id 改变；
触控 rate code 3 和 USB configured 正常，结束后重新绘制彩条。
主表 B successful=true、active=true、unbootable=false、retry_count=6。
重试次数没有扣减，A 成功位保留。
bootloader 将备表 boot_b 的 retry_count 从 7 同步为主表的 6，
重启后主备 entry 完全一致，所有 CRC 有效。首次严格字节不变检查因此
失败，后续核对确认仅此正常同步差异，未重复重启冒充重新测试。

## 后续使用

成功标记是持久 GPT 属性，无需每次正常启动再次写入，当前问题已处理。
本轮不改 init_boot 或自动启动脚本，不把未验证的新内核默认标成成功。
后续 `fastboot set_active b` 可能重置成功标记和重试次数；新镜像通过
验证后，再核对实际槽位和 GPT 状态并使用现成工具显式标记成功。
不以此取消新镜像失败时回退 Android 的机制。

证据：`out/boot-success-20261014/` 中 before/、after/、after-reboot/，
qbootctl-before.txt、qbootctl-mark.txt、verified-changes.json、reboot-result.json。
工具与元数据快照均保存在项目中，可继续复用。

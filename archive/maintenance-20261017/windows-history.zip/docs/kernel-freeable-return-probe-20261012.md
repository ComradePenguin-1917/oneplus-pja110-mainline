# kernel_init_freeable 返回点实验

目的：以已确认可达的 initcall 循环结束点为下界，测试 `kernel_init_freeable` 是否返回，覆盖 wait_for_initramfs、console_on_rootfs、init_eaccess、按条件执行的 prepare_namespace，以及 integrity_load_keys。

探针替换 `kernel_init + 0x20`（Image 偏移 16692220）原始 ADRP `0xb0006ff3`。前一条 BL `0x941e5716` 经解码核对指向本构建 kernel_init_freeable。执行位置在 async_synchronize_full 和 free_initmem 之前，因此 init 可执行区的 68 字节探针仍有效；只修改这段零填充及一条分支，Image 头和长度不变。

QEMU 验证了实际 Image，退出码 0，执行记录含 SMC，时长 53.041 秒，Image SHA256 `19aea7777185d797245c7cce34114c8a59aca8cca97c68ae01ca87278d9226b4`。boot 镜像 SHA256 `d65d9c8a49d285c92c3c99e0bb4c97702ee16b4152920187dc82d776a614b6db`。

镜像：`out/kernel-after-kernel-init-freeable-probe-20261012/`。
实机证据：`out/kernel-after-kernel-init-freeable-probe-experiment-20261012/`。

用户观察到约每 10 秒自行重启，支持到达返回点。总周期包含到达探针之前的初始化和引导过程，不能据此把增加的时间归到某个具体调用。

采证首次遭遇 ADB 连接中断，仅读到 212992 字节，工具拒绝保存为完整快照；重新连接后读取完整 8388608 字节，实际 boot_b 前缀 SHA256 与测试镜像匹配，其他三个 B 槽测试分区完整哈希亦核对通过。最终恢复 Android A，八个启动分区哈希匹配实验前状态，结果见实机目录 result.json。

后续测试推进到 async_synchronize_full 返回点。该位置仍在 free_initmem 之前，可继续使用当前 init 可执行区探针。

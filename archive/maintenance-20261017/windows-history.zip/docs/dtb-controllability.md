# 手机上 DTB 到底可不可控？—— 回答与证据

> 日期：2026-10-11 · 基于本机 6 次实测 + 内核源码分析

## 一、先回答"是不是所有手机都这样"

**不是。** "DTB 不可控"是**本机这个 ABL 版本**的行为，不是高通平台的通性。

| 平台/方案 | DTB 来源 | 可控？ |
| :-- | :-- | :-- |
| **本机（一加 SM8550 + OPPO ABL）** | ABL 从 **flash** 的 `vendor_boot.dtb` + `dtbo` 合成 | ❌ 追加无效（实测） |
| **lk2nd**（社区二级引导器） | 显式支持 `append-dtb` | ✅ |
| 多数主线 Qualcomm 设备 | kernel 追加 DTB 或 boot.img 的 dtb 段 | ✅ |
| 上游参考板（qrd/mtp/hdk） | 引导器传 x0，或 DTB 在 boot.img | ✅ |
| arm64 通用能力 | ❌ **没有** `CONFIG_BUILTIN_DTB`（`grep -rn BUILTIN_DTB arch/arm64/` 为空） | — |

**本机的特殊之处**：OPPO 的 ABL 在 `Apply Overlay` 之后会
**`Update Device Tree`**——它自己**合成**最终设备树并覆盖 `/chosen`。

## 二、决定性实验（排除掉了我之前设计的漏洞）

### 我第一版实验的缺陷

原来我把标记放在 `/chosen/xigua-marker`，标记消失后我下了"DTB 被忽略"的结论。

**但这个设计有漏洞**：ABL 日志显示它自己构造 bootargs 并写 `/chosen`。
如果 ABL 是**重建** `/chosen`（而不是修改），标记消失**不能**证明 DTB 被忽略。

### 改进后的实验

在三个位置放标记，其中两个 ABL 没理由碰：

```bash
fdtput -t s probe2.dtb /       xigua-root-marker   XIGUA_ROOT_aa11
fdtput -t s probe2.dtb /soc    xigua-soc-marker    XIGUA_SOC_bb22
fdtput -t s probe2.dtb /chosen xigua-chosen-marker XIGUA_CHOSEN_cc33
```

再追加到**原厂内核**（保证能启动），启动后 dump 运行 DTB 全盘搜索：

```
运行 DTB 大小: 732681   （原厂 732665，差 16 字节 = ABL 写 bootargs）
XIGUA_ROOT_aa11      absent
XIGUA_SOC_bb22       absent
XIGUA_CHOSEN_cc33    absent
```

**三个标记全部消失。** 如果 ABL 是在我们 DTB 基础上改，根节点和 `/soc` 的标记必然保留。
全没了 ⇒ **ABL 用的是一棵完全独立的树**。

**同时 cmdline 探针证明**：`xiguaprobe=hello123` **存在**（在 `/proc/cmdline` 里）。

所以同一个 boot.img 里：

| 通道 | 结果 |
| :-- | :-- |
| kernel | ✅ 用了我们的 |
| cmdline | ✅ 合并了我们的 |
| ramdisk | ❓ 未测 |
| **DTB（追加）** | ❌ **完全丢弃** |

## 三、那怎么才能控制设备树？

ABL 日志给出明确答案：

```
Load Image boot_a        total time: 63 ms
Load Image vendor_boot_a total time: 57 ms      ← 基础 DTB 在这里
Load Image dtbo_a        total time: 9 ms       ← overlay 在这里
Apply Overlay            total time: 323 ms
Update Device Tree       total time: 59 ms
```

**最终设备树 = `vendor_boot` 的 dtb 段 + `dtbo` 的 overlay。**
所以要控制它，必须改**这两个分区之一**。

### 两条路线对比

| 路线 | 做法 | 语义 | 契合度 |
| :-- | :-- | :-- | :-- |
| **a. 改 `dtbo_a`** | 我们的 DTS 做成 dtbo 刷进去 | **overlay**（在厂商基础树上叠加） | ⚠️ 我们的 DTS 是"完整替换"语义，`/delete-node/ &label` 那些 label 在厂商树里不存在 |
| **b. 改 `vendor_boot` 的 dtb 段** | 替换那 4 个 DTB 里的一个 | **完整替换**基础树 | ✅ **和我们的 DTS 语义完全吻合** |

**路线 b 看起来明显更合适**：我们的 DTS 本来就是一棵完整的机器树
（基于上游 `sm8550.dtsi`），替换基础 DTB 正是它设计的目的。

> 注意：`vendor_boot` 里有 4 个 DTB（对应不同 msm-id/board-id）。
> ABL 按 msm-id 选一个。我们的 DTB 要放在**匹配本机的那一项**里
> （本机 msm-id = `0x207 0x20000`）。

## 四、写分区的风险与准备

**这是第一次真正写 flash。** 两个分区都有备份：

| 分区 | 备份 | 回退命令 |
| :-- | :-- | :-- |
| `dtbo_a` / `dtbo_b` | ✅ `backup/dtbo_a.img`（= 原厂 `30b4002a…`） | `fastboot flash dtbo backup/dtbo_a.img` |
| `vendor_boot` | ⚠️ **尚未单独备份**（线刷包里有，但设备上的可能被改过） | 需先备份 |

**注意**：ABL 日志显示 `vendor_boot_a` 的 AVB 哈希**本来就不匹配**
（说明它已经被改过，很可能是 root/KernelSU 相关）。所以设备上的
`vendor_boot` **不等于**线刷包里的那份，**必须先备份设备上的真实内容**。

## 五、下一步（按顺序）

1. **备份设备上的 `vendor_boot_a`/`vendor_boot_b`** —— 写之前必须有回退
2. **查清 `vendor_boot` 里 4 个 DTB 的选取规则**（msm-id/board-id 匹配）
3. **构造新的 vendor_boot**：把匹配本机的那一项 DTB 换成我们的
4. **用 `fastboot boot` 无法测试这个**（vendor_boot 不能被 boot 加载），
   只能真正 `fastboot flash vendor_boot` —— 所以要格外谨慎
5. 或者先试 **路线 a（dtbo）**：如果能让我们的 DTS 以 overlay 形式生效，
   风险更低（只动 dtbo，且 dtbo 是 ABL 明确会应用的东西）

## 六、诚实说明当前的不确定性

- **路线 a 是否可行**：取决于 ABL 的 overlay 语法。我们观察到 dtbo 里的
  fragment 是**预链接状态**（`target = 0xffffffff`），说明 OPPO 用的是
  自己的链接流程，不是标准 `dtc -@` overlay。需要用官方 `mkdtimg` 或
  逆向其格式。
- **路线 b 是否可行**：需要确认 ABL 会不会校验 `vendor_boot` 里 DTB 的
  `qcom,msm-id`，以及它是否容忍"基础树里缺少它期望的节点"。

**在查清这两点之前，不应写任何分区。**

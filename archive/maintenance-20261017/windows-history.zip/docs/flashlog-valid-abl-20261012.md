# 有效 ABL 入口下的主线落盘日志复测

## 本轮结果

使用已在实机通过 ABL 覆盖合并的 fixup DTBO，重新测试主线用户态主动写入 logdump。B 槽记录确认完成覆盖合并、设备树更新并进入关闭 UEFI 启动服务阶段；没有再次出现 DTBO 元数据无效或 ufdt 合并失败。

观察超过一分钟，手机持续黑屏，没有 ADB 或 fastboot 接口。用户按键进入 fastboot 后，切回 Android A 采证。

读取 logdump 尾部：前 60 KiB 主线日志区仍全零，没有主线标记；最后 4 KiB 独立参照标记逐字节保留。因此该路径没有清空整个预留区域，但本轮仍未获得主线用户态或内核日志。不能据此单独断言 `/init` 未执行；UFS 未就绪、目标未发现或身份检查/写入失败也能产生相同结果。

B 槽引导器还记录：

```text
Splash region not found in device tree, powering down the display and controller
Update Device Tree total time: 225 ms
Shutting Down UEFI Boot Services: 3550 ms
Phoenix:Exit boot services success stage
```

因此屏幕熄灭包含引导器主动关闭显示的因素，不能把黑屏直接当作 Linux 崩溃证据。保存的记录没有 Linux 输出，也没有证明内核实际执行阶段。

## 控制变量和备份

内核 `boot-xigua-r1.img`、USB2 `vendor_boot_b`、fixup `dtbo_b` 与 `out/avb-fixup-control-20261012/` 完全相同；仅更换 generic init_boot，启动此前已在 Android 验证的静态 BusyBox 落盘程序。新的 init_boot SHA256 为 `52eaa9c7e254376ff275dfc2512b46851d80e3b507bc2f2637414171503318f4`，与先前日志版本一致。本轮没有重建内核。

重新检查 logdump 的 GPT、UUID、容量、挂载和 holder 状态，并重新备份完整 512 MiB。原始分区全零，完整 SHA256 为 `9acca8e8c22201155389f65abbf6bc9723edc7384ead80503839f49dcc56d767`。写入仅使用尾部 64 KiB，其中日志程序限于前 60 KiB，最后 4 KiB 为独立参照。

这次复用此前已经通过的 Android 留存对照和写入程序正负验证，没有再次执行这些对照。此前清空 DTBO 的主线空日志不具备本轮的 ABL 通过证据；本轮才是在有效入口下复测。

## 采证和恢复

实机读回 boot_b 前缀和 vendor_boot_b、init_boot_b、dtbo_b 全分区哈希，核对本轮输入；A 槽四分区保持原值。恢复 logdump 尾部后，完整 512 MiB 哈希已匹配原始值。B 槽四分区恢复到本轮实验前内容，最终八分区哈希与 Android A 完成启动状态记录在恢复文件中。

- 镜像与 manifest：`out/flashlog-valid-abl-20261012/`
- fastboot、读回、引导历史和恢复：`out/flashlog-valid-abl-experiment-20261012/`
- 完整 logdump 备份、参照及实际日志区读回：`out/flashlog-valid-abl-journal-20261012/`
- 精简 B 槽记录：`out/flashlog-valid-abl-experiment-20261012/b-slot-bootloader.txt`

生成入口为 `tools/package_flashlog_init.py` 加 `tools/prepare_flashlog_valid_abl.py`。logdump 工具现可指定独立证据目录，避免覆盖此前实验。

## 下一项有价值的定位

用户态落盘依赖 UFS，不覆盖内核最早期故障。接下来应核查 ARM64 内核交接条件、实际设备树与固件预留内存，并选择能提供更早阶段信号的单变量对照；目前没有证据把故障归因于某个 UFS 驱动或看门狗。

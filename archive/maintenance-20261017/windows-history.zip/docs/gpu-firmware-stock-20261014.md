# 本机原厂 GPU 固件提取（2026-10-14）

已从正在运行主线 Linux 的 PJA110 只读提取 GPU 固件。未重启手机、
未刷写分区，未使用 Aston 固件或本地 OTA 镜像代替本机分区。

## 来源与提取

按 PARTNAME 唯一定位 super，读取前 4MiB 元数据。LP geometry、metadata
header 和 tables 均通过 SHA256 校验。按 metadata slot 0 的 vendor_a
线性 extent 顺序读取并重建 807264256 字节原始镜像。

vendor_a 镜像 SHA256：
`31e2c8bebd5a007eda7e296f73c9fa48c81bedbd1291dc5b98a5e8bada1ddf2d`。

镜像采用 EROFS。使用普通 WSL 用户构建的 erofs-utils 1.7.1 导出文件，
所有实际文件都在电脑的项目目录操作。autoconf、automake、libtool 由用户
自行安装后继续构建；成功的构建、解包和复制命令均未调用 root。

vendor build.prop 原文保存为 `vendor-build.prop`：

- fingerprint：`oplus/ossi/ossi:13/TP1A.220905.001/1714116030889:user/release-keys`
- vendor release：13
- vendor security patch：2024-04-05

这是 vendor 分区自身的属性，不能据此推断手机完整 Android 系统版本。
动态分区布局包含 B 槽 COW 分区；本轮提取的是明确标记的 vendor_a，
没有重建或解释 B 槽快照。

## 输出

目录：`out/gpu-firmware-stock-20261014/`。

| 文件 | 大小（字节） | 用途 |
| --- | ---: | --- |
| a740_sqe.fw | 75380 | Adreno SQE 固件 |
| gmu_gen70200.bin | 66844 | GMU 固件 |
| a740_zap.mbn | 12088 | 本机签名 ZAP 容器 |

`original/` 另保留 a740_zap.mdt、.elf、.b00、.b01、.b02。
全部八个文件的来源路径、大小和 SHA256 记录在 `firmware-manifest.json`，
源文件与复制目标哈希一致，未修改固件内容。

预备的 Linux 固件目录：

```text
linux-firmware/qcom/a740_sqe.fw
linux-firmware/qcom/gmu_gen70200.bin
linux-firmware/qcom/sm8550/xigua/a740_zap.mbn
```

ZAP 的 ELF32 program header 与文件边界已检查，e_machine=164。
这些检查只证明文件提取与结构有效；尚未实际加载、认证或执行 GPU 渲染。
下一步可复用上游 GPU 驱动及 Aston 的板级启用结构，使用本机 ZAP 路径。

# PJA110 charger initialization candidate

## Runtime SMEM identity verified

Read-only module capture `out/native-install-20261017/smem-project/live-20261017-032855.txt` confirms native A boot `a3251fd9-461e-4efd-89be-19bf3e3e9001`: SMEM item 135 size 100, version 1, project 22851. This resolves the previously unknown runtime project identity for this boot. Together with the cached firmware branch analysis it supports the project-specific BQ initialization bypass; it is not a whole-firmware proof excluding every independent gauge access path. No gauge-init or charging SET request was sent.

At uptime 957 seconds the AP BQ reported 2 percent, 7.260 V, +164 mA, 29.4 C, remaining charge 40 mAh (33 mAh at uptime 789 seconds). The same boot remains slowly charging. Firmware fallback SOC/temperature must still not be used as real battery measurements.

## AP gauge ownership correction

### Temperature handoff audit

Native A live capture `thermal-live-20261017-033124.txt` shows no IIO device. Exposed thermal zones include SoC/PMIC alarms, firmware fallback temperature and AP BQ temperature, but no identified subboard or USB thermistor. At uptime 1105 seconds BQ reports 3 percent, 7.288 V, +170 mA, 29.2 C and 47 mAh.

Factory `oplus-chg-22851.dtsi` assigns `subboard_temp_adc` to PM8550B ADC5 Gen3 AMUX3 GPIO6 with 100k pull-up. It enables support_subboard_ntc, support_subboard_adjust and subboard_abnormal_method_support. The factory getter uses IIO processed millidegrees, converts to deci-degrees, and applies current-dependent compensation starting at 7500 mA. The normal matching path selects the valid subboard temperature; after repeated abnormal readings it falls back to the gauge. Shell-temperature overrides can apply separately. Raw BQ temperature alone therefore does not reproduce the complete factory matched-temperature policy.

Factory probe sends gauge-init property 38 after GLINK registration, initializes sensor interfaces and charging policy, toggles charging disable/enable, then sends matched-temperature property 29. Periodic matched-temperature writes in the inspected older charger framework are guarded by ADSP_VOOCPHY (1); this board declares AP_SINGLE_CP (2). Do not infer periodic writes for this board merely from the function name.

Read-only inspection of the actual prepared A 6.14 build tree found qcom-spmi-adc5.c matches only qcom,spmi-adc5, qcom,spmi-adc7 and qcom,spmi-adc-rev2, with no ADC Gen3 files. Gen3 headers in the separate workspace tree are not evidence that the deployed kernel supports it. Next implementation should reuse an existing ADC5 Gen3 driver and its bindings, verify compatibility with 6.14, then configure the board channel and validate real sensor readings before reproducing matched-temperature handoff. No charging SET requests were performed during this audit.

The cached project 22851 board configuration explicitly sets oplus,adsp_chg_use_ap_gauge and voocphy_support=2 (AP_SINGLE_CP). Therefore ADSP battery fallback properties are not evidence that the AP gauge must be moved into ADSP, and requiring the ADSP voltage GET to report the full pack voltage was an incorrect candidate gate. The current source instead uses the existing BQ power_supply API to check presence, health, temperature and pack voltage. Strict module compilation/modpost passed; qcom_battmgr-ap-gauge.ko is saved separately and not installed. Writes remain opt-in and were not executed.

The OEM probe sends BATT_ADSP_GAUGE_INIT (38) and BATT_SET_MATCH_TEMP (29); periodic match-temperature calls in the inspected older framework are conditional on ADSP_VOOCPHY. The matched temperature can include subboard/shell policy and must not be equated blindly to the BQ thermistor. Runtime SMEM project 135 and the project-specific firmware bus exclusion remain unverified, so no gauge-init request was sent. Evidence checker: tools/audit_pja110_gauge_handoff.py.

Live A boot a3251fd9-461e-4efd-89be-19bf3e3e9001 was still accessible at uptime 389 seconds: BQ capacity 1 percent, voltage 7.134 V, current +167 mA, remaining charge 14 mAh (earlier 2 mAh at 52 seconds). This supports slow net charging across this interval; it does not establish sustained charging across adapter types or a completed charger policy.

## Live read-only validation

The isolated Linux 6.14 plus deployed overlay build completed with the A IKCONFIG, allowing GCC 13 capability changes. A real vmlinux.symvers was generated; strict module modpost/link passed without unresolved symbols. The module vermagic matches A. It loaded successfully on actual A boot a3251fd9-461e-4efd-89be-19bf3e3e9001 through a temporary service explicitly passing pja110_charger_init=0. No charging writes were enabled. The service remains enabled in read-only mode.

Live firmware battery data reports 50 percent, 25 C, 4 V, cycle count 5 and QCOMMBATT0. The AP BQ reports approximately 7 V, cycle count 117, temperature near 30 C, and capacity 0 to 1 percent. Firmware 50 percent and 25 C match the previously disassembled uninitialized-gauge fallbacks. These firmware battery readings must not authorize charging. USB battmgr reports online, approximately 4.9 V, 450 mA, source max 900 mA and input limit 1.5 A; actual accuracy remains unverified.

UPower lists both batteries but DisplayDevice still reports the BQ-derived 0 percent and on-battery=no. The temporary node did not simply replace the desktop percentage with 50 percent. Noninteractive sudo is unavailable.

The final offline candidate additionally rejects firmware pack voltage below 6 V or above 8.9 V; strict compilation passed. It is saved separately as qcom_battmgr-guarded.ko and has not replaced the running read-only module. Next work must resolve the board-specific firmware gauge initialization/temperature source before enabling OEM charging writes.

The candidate in `drivers/power/supply/qcom_battmgr.c` derives from the saved Linux 6.14 mainline driver. The generated diff is `drivers/power/supply/pja110-init.patch`. It is experimental and has not been installed or exercised on the phone.

The downstream reference is `oplus_chg_hw_init` in the saved Oplus SM8550 source: USB property 5 with 0xffffffff releases suspend; the same property with 500000 requests 500 mA; battery property 24 with 1 enables charging. These are GLINK requests, not raw PMIC register writes.

Writes default off, require the `pja110_charger_init` load parameter and `oneplus,xigua` runtime compatible, and check firmware-reported USB online, battery present, health GOOD, temperature 10 through 40 C and source current limit at least 500 mA. Each failed request stops the sequence. This temperature gate is a bring-up constraint, not a replacement for the downstream thermal policy.

The candidate validates SET response opcode, type, payload length, property and firmware result. Failed sends/timeouts stop further requests until reprobe. The upstream request mutex serializes notification enabling and the initialization sequence. Managed work cancellation was added for teardown.

Validation: target object compilation passed with the existing B #24 prepared tree and Arm GCC 13.3. This is not A module link or ABI validation. A actually runs 6.14.0-oneplus-xigua built with Alpine GCC 15.2. No module was loaded, no partitions were written and charging initialization has not executed. Build details are in `out/native-install-20261017/charger-init-candidate/build-result.json`.

Remaining before a live test: finish protocol/lifecycle review, build against the exact A kernel configuration/source and validate module dependencies; collect firmware health and thermal readings without writes first. The candidate is not yet a complete sustained charging/thermal policy and must not be enabled for unattended use.

Corrections to earlier interpretation: UCSI current_now=0 is not proof of measured zero charger input current. The BQ driver maps its low-state-of-charge condition to Health=Dead, which is not by itself evidence of permanent battery damage.

The exact A kernel IKCONFIG was extracted to `out/native-install-20261017/charger-init-candidate/native-a.config`: Alpine GCC 15.2.0, localversion -oneplus-xigua, MODVERSIONS disabled and battmgr disabled. The cached 6.14 source and sufficient disk space are available, but no matching A build/link validation has been completed. The GOOD-health gate uses the firmware battmgr reply, not the AP BQ driver's low-SOC-derived Dead label; its live value is still unknown.

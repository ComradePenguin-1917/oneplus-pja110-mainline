# SM8550 SDMA 单项对照结果

结果：SDMA 标记启用后中央花屏仍存在，不能作为修复方案。

本轮运行 `6.14.0-sm8550-xigua-r1 #17`。只把 SM8550 catalog 的
4 VIG、4 DMA、2 cursor 管线 capability mask 改为对应 `_SDMA`，
使用本地已有的 SMART_DMA_V2 和 setup_multirect 实现。
Active CTL、DSI/DSC、生成版 AA536 参数、GPU 固件和触控配置保持不变。
实际构建树此前面板源为旧版，构建前已恢复为已验证 #15 的生成版源，
SHA256=b19cd65ed8c935791e2e9617372d939e1dff93284ae5fc5bcf2ed3d4c8d251f1。

新 Image 与当前 GPU/触控/SSH 外部启动包通过 QEMU 检查。
完整 boot_b 候选保留原厂 AVB 尾部，写入前核对八个分区基线，
只写 boot_b，整分区读回一致，其余七个启动分区未变。重启后再次核对。
自动 SSH、显示初始化、GPU 固件加载和 Aston rate code 3 初始化正常。

kmscube 为未经修改的上游 f60e50e887d3c49e91ac9b06d8199b36152632fa，
参数与原有 surface 基线相同，仅将观察窗口延长；亮度 1024，
Freedreno FD740，约 60.2 fps。用户明确确认中央仍有同样花屏。
确认失败后主动结束测试，因此非零退出码属于终止记录；工具 finally
已恢复彩条并采集日志，GPU 故障计数仍为 0。

本轮没有恢复旧 boot；手机目前保留 #17 SDMA 对照内核。
回退镜像是 `out/display-generator-avb-retest-20261014/boot_b-generated-panel.img`，
其哈希在写入前已与 #15 基线 boot_b 核对。没有扩大到 Active CTL 或面板修改。

证据目录 `out/dpu-sdma-control-20261014/`：sdma-only.patch、manifest.json、
before.json、after-write.json、after.json、after-state.txt 及 kmscube/。
下一步应对实际 GPU 扫描缓冲区内容做读回，区分渲染/缓存布局与 DPU/DSI 输出，
而不是继续把 SDMA 假设当作已证实根因。

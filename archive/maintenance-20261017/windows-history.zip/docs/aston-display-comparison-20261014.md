# Aston 对照：GPU 到屏幕的中央花屏

PJA110 kmscube 使用 Freedreno FD740，约 60.18 fps，但用户照片明确显示
中央噪声带，不能判定屏幕输出通过。亮度已按用户要求设为 1024。
默认模式、显式 linear（默认本来也是 linear）及 surfaceless 对照均不能
作为花屏已修复的证据；surfaceless 两分钟窗口用户确认中央仍有花屏。
退出后恢复彩条，不刷分区。

运行中 DRM 状态：XR24、modifier 0、1240×2772，GPU 缓冲区 pitch 5120。
已知正常 fbcon 彩条缓冲区同为 XR24/linear，pitch 4992。
这只是可继续对照的差异，不证明 stride 配置错误。
GPU 故障计数为 0。离屏 GLES 像素验证仍与屏幕 scanout 分开判断。

固定 Aston commit：`5d5c840896bb49291ae4578acefd5a3ec65524f6`。
与实际 WSL 构建源比较，以下完全相同：dpu_plane.c、dpu_crtc.c、
dpu_hw_sspp.c、dpu_hw_dsc_1_2.c、msm_fb.c、msm_gem.c。

`catalog/dpu_9_0_sm8550.h` 差异：

- Aston 设置 has_active_ctls=true，本地没有。
- 本地 ctl_0/ctl_1 仍用 DPU_CTL_SPLIT_DISPLAY workaround，Aston 没有。
- Aston VIG/DMA/CURSOR 使用对应 _SDMA mask，本地使用无 _SDMA 的 mask。

DSI 差异：Aston 增加 dsc_slice_per_pkt 支持；本地使用上游每包单 slice，
另含已验证的 PJA110 原厂速率和 10bpc/SCR1 适配。不能整体替换为 Aston，
其 AA551 面板参数与 PJA110 AA536 不同。

对照文件和完整 diff：`out/aston-display-comparison-20261014/`。
此次仅下载和只读比较，没有因此修改内核或刷写。
下一步应追查 Active CTL/SDMA 的配套代码，再决定能否作为独立候选复用；
同时可验证 GPU scanout 缓冲区实际内容，避免把 DSI/DSC 与取图问题混为一谈。

## DPU 配套代码追查

进一步下载并逐文件比较 Aston 固定版本与实际构建源，确认：

- `dpu_hw_catalog.c` 相同，本地已有 `_SDMA` mask 定义。
- `_SDMA` 增加的是 `DPU_SSPP_SMART_DMA_V2`；它不是 UBWC modifier。
- `dpu_hw_sspp.c` 只在 SMART_DMA_V1/V2 capability 存在时安装
  `ops.setup_multirect`。plane 更新路径只在回调存在时调用它。
- `dpu_hw_sspp_setup_multirect` 对 RECT_SOLO 写入 mode_mask=0，清除
  SSPP_MULTIRECT_OPMODE（offset 0x170）。当前 SM8550 catalog 不带该
  capability，因此不会通过这条路径清零硬件多矩形状态。
- 这构成值得测试的 SDMA 配置差异，但尚未读取实际硬件寄存器，不能
  宣称存在残留状态或已找到花屏根因。当前 DRM 软件状态为 solo/none。

Active CTL 不是单个 catalog 开关。本地 `dpu_caps` 和 `dpu_rm` 根本没有
has_active_ctls 字段；Aston 的配套差异涉及 catalog header、RM、CTL
实现和 header、command encoder，以及拓扑配置。其 RM 在 Active CTL
模式分配一个 CTL、不要求旧 split-display capability；CTL 还处理
interface master 和多个 active block 状态。不能仅拷贝 SM8550 catalog。

建议优先制作只启用 SDMA mask 的单变量候选，它的定义和回调实现已经
存在于本地，保持当前 Active CTL、DSI、DSC、面板、GPU 固件等不变。
本轮仅检查和记录，尚未改源、构建候选或刷写。恢复彩条后仍使用
fbcon XR24/linear、pitch 4992，亮度 1024。

# 🎯 突破：成功控制设备树 —— ABL 确实使用 vendor_boot 的 entry0

> 日期：2026-10-11 · 真机验证（B 槽）· 这是本项目第一次成功影响内核拿到的设备树

## 结果

```
$ adb shell ls /sys/firmware/devicetree/base/ | grep xigua
xigua-vbtest          ← 我们注入的节点，出现在运行中的设备树里
```

设备同时报告：`sys.boot_completed=1`、`ro.boot.slot_suffix=_b`、
`ro.product.model=PJA110`、`wm size=1240x2772`、Android 14。
**系统完全正常，无任何副作用。**

## 这证明了什么

| # | 结论 | 证据 |
| --: | :-- | :-- |
| **1** | **ABL 用 `vendor_boot` 的 entry0 作为本机基础设备树** | 注入的节点出现在 live tree 里 |
| **2** | **修改 `vendor_boot` 的 dtb 段安全可行** | 设备正常启动，全部功能正常 |
| **3** | **验证不需要 root** | 目录列表世界可读（B 槽无 KernelSU 也能读到） |
| **4** | **overlay 仍然正常应用** | `__symbols__` = 1522（1521 基础 + ABL 添加），`model` 仍被 dtbo 改写 |

至此 **设备树交付链完全打通**，不再是黑盒。

## 关键设计：为什么用"惰性节点"

前两次实验失败的原因值得记录：

### 失败一：改 `model` 字符串（等长替换）
```
原: Qualcomm Technologies, Inc. Kalama v2 SoC
新: XIGUA_VBTEST_____________________________
```
**失效原因**：dtbo 自己会写 `model`！
```
dtbo entry0/1/2/3 各有一处: / -> model = 'Qualcomm Technologies, Inc. Kalama MTP,xigua'
```
这正是 A 槽 live tree 里看到的值。所以无论 ABL 用谁的树，`model` 都会被覆盖成这个。

**教训**：标记位置必须选 **dtbo 从不触碰**的地方。

### 失败二：以为节点没注入成功
`FDT.nodes()` 只记录**有属性**的节点，而惰性节点故意没有属性 → 工具看不见它。
改用 `walk()`（yield 所有节点，含无属性的）就看到了：
```
depth=1 path=/xigua-vbtest  name='xigua-vbtest'
```
**教训**：验证工具本身的局限会伪装成"操作失败"。

### 最终方案：注入无属性顶层节点
```python
# 在 root 的 FDT_END_NODE 之前插入（不是 FDT_END 之前！）
node = FDT_BEGIN_NODE + "xigua-vbtest\0"(padded) + FDT_END_NODE
```
- **无属性、无 compatible、无 reg** → `of_platform` 不会创建 device
  → **不可能改变任何行为**，纯"见证者"
- 插入点必须在 root 的 `FDT_END_NODE` **之前**。插在 `FDT_END` 之前会变成
  root 的兄弟节点，结构非法（我第一次就犯了这个错）

## 布局处理（关键的工程细节）

```
dtb section    @0xff9000   size 2040970
section end    @0x11eb48a
ramdisk_table  @0x11ec000  ← 页对齐，有 2934 字节空隙
```

插入 24 字节后 section 结束于 `0x11eb4a2`，**仍在 table 偏移之前**，
所以：

| 项 | 结果 |
| :-- | :-- |
| `off_dt_strings` / `size_dt_struct` | +24（必须同步更新） |
| `totalsize` (entry0) | 503206 → 503230 |
| **header `dtb_size`** | 2040970 → 2040994 |
| `dtb_off` / `ramdisk_table` 偏移 | **完全不变** |
| vendor_ramdisk (16 MiB) | **逐字节相同** |
| table 及其后全部 | **逐字节相同** |
| 文件大小 | **完全不变** (201326592) |

`dtb_size` 的增长正好抵消了页对齐空隙，所以下游一切不动。

## 已验证项（`tools/verify_vb_node.py`，全部 PASS）

```
[OK] file size unchanged                     201326592
[OK] header_size unchanged                   2128
[OK] dtb_size grew by 24                     2040970 -> 2040994
[OK] dtb_off unchanged                       0xff9000
[OK] table offset unchanged                  0x11ec000
[OK] entry0 contains /xigua-vbtest
[OK] all base __symbols__ labels kept        1521 -> 1521     ← overlay 不会坏
[OK] walk lands exactly on dtb_off+dtb_size
[OK] msm-ids unchanged                       0x207 0x20000 / 0x207 0x10000 / 0x218 0x20000 / 0x218 0x10000
[OK] vendor_ramdisk byte-identical
[OK] from table onward byte-identical
```

**`__symbols__` 1521 个 label 全部保留** —— 这是 overlay 能继续解析的关键。

## 操作流程（可复用）

```bash
# 1. 构造（在 Windows/Python 侧）
python tools/inject_inert_node.py backup/vendor_boot_b.img out/vendor_boot_b-node.img xigua-vbtest

# 2. 验证
python tools/verify_vb_node.py

# 3. 写入非活动槽
fastboot flash vendor_boot_b out/vendor_boot_b-node.img
fastboot set_active b
fastboot reboot

# 4. 无需 root 读取
adb shell ls /sys/firmware/devicetree/base/ | grep xigua-vbtest

# 5. 回退（秒级）
fastboot set_active a
```

## 分区状态（改动前后）

| 分区 | 改动前 | 改动后 | 说明 |
| :-- | :-- | :-- | :-- |
| `boot_a` | `742105c6…` | `742105c6…` | ✅ 未动 |
| `boot_b` | `d9cf0ea6…` | `d9cf0ea6…` | ✅ 未动 |
| `vendor_boot_a` | `4b3e8008…` | `4b3e8008…` | ✅ **未动**（工作槽） |
| `vendor_boot_b` | `e085f83a…` | `9caee814…` | ⚠️ **本次实验写入** |
| `dtbo_a` | `30b4002a…` | `30b4002a…` | ✅ 未动 |
| `dtbo_b` | `30b4002a…` | `30b4002a…` | ✅ 未动 |

`vendor_boot_b` 随时可用 `fastboot flash vendor_boot_b vendor_boot-A14.img` 还原
（原厂值 `e085f83a…`）。

## 下一步：换入我们自己的设备树

现在**基础树的注入点已验证**。真正换入我们的 DTB 还剩一个**已知障碍**：

**overlay fixup 覆盖率问题**

dtbo 用 `target = 0xffffffff` 占位符 + `__fixups__`（168 条）机制，
ABL 必须**在我们基础树的 `__symbols__` 里查到这些 label** 才能回填 phandle。

| 基础树 | `__symbols__` | 对 168 个 fixup 的覆盖 |
| :-- | --: | --: |
| 厂商 entry0 | 1,521 | **100%** ✅ |
| **我们的 DTB** | 533 | **9.5%** ❌ |

缺失的典型：`CPU0`、`CPU3`、`L1B`~`L17B`（PMIC 稳压器）、`APC1_pause` 等。

### 应对方案（按可行性排序）

| # | 方案 | 思路 | 风险 |
| --: | :-- | :-- | :-- |
| **A** | **给我们的 DTB 补 `__symbols__`** | 把 168 个 label 指向的节点也加进来 | 中：这些节点可能与主线定义冲突 |
| **B** | **同时换掉 dtbo** | 用空的 dt_table（`entry_count=0`）或我们自己的 dtbo | 低-中：需确认 ABL 是否接受空 dtbo |
| **C** | **从厂商树增量改** | 不整棵替换，只在厂商树上改必要节点 | 低：但改动面大、易漏 |

**方案 B 看起来最干净**：既然我们能改 `vendor_boot`，也就能改 `dtbo`。
两者都换成我们的，overlay 问题自然消失。而且 `dtbo_b` 目前是原厂值
（`30b4002a…`），有完整备份。

## 资产

| 项 | 状态 |
| :-- | :-- |
| 设备 | ✅ 正常，A 槽工作，B 槽可实验 |
| 备份 | ✅ 17 分区 873.6 MiB，全部哈希校验 |
| **基础树注入** | ✅ **已验证可行**（本次突破） |
| 回退 | ✅ `set_active a` 秒级 / 原厂镜像精确还原 |
| 工具 | ✅ `inject_inert_node.py`、`verify_vb_node.py` |

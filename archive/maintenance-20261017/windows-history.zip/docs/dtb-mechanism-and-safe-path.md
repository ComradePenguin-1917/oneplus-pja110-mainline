# 设备树可控性：完整机制与安全实验路径

> 日期：2026-10-11 · 基于 8 次真机实验 + 分区级二进制分析

## 一、直接回答："手机上 DTB 都不可控吗？"

**不是。** 这是**本机 ABL 的实现选择**，不是高通平台通性。

| 方案 | DTB 来源 | 可控？ |
| :-- | :-- | :-- |
| **本机（一加 SM8550 / OPPO ABL）** | ABL 从 **flash** 的 `vendor_boot` + `dtbo` 合成 | ❌ 追加无效（8 次实验证实） |
| lk2nd（社区二级引导器） | 显式支持 `append-dtb` | ✅ |
| 多数主线 Qualcomm 设备 | boot.img 的 dtb 段 / kernel 追加 | ✅ |
| arm64 通用 | ❌ **无** `CONFIG_BUILTIN_DTB`（`grep -rn BUILTIN_DTB arch/arm64/` 空） | — |

**本机特殊点**：OPPO ABL 有一步 **`Update Device Tree`**，它自己**合成**最终设备树。

### 关键：我的结论经过了两次自我纠错

**第一次**（`docs/decisive-experiments.md`）我用"厂商实时 DTB + 标记"做探针，标记消失 →
结论"ABL 忽略追加 DTB"。

**第二次自查发现两个潜在漏洞：**
1. **`/chosen` 可能被 ABL 重建** → 我改进实验，在 `/`、`/soc`、`/chosen`
   **三处**放标记，结果**全部消失** ⇒ 排除
2. **实时 DTB 可能缺 `qcom,msm-id`** → ABL 靠它挑 DTB，缺了就无从谈起。
   实测实时 DTB **有** `msm-id = 0x207 0x20000`（与厂商一致）⇒ 排除

两个漏洞都排除后，结论成立：
**ABL 用的是独立构建的树，三个位置的标记全丢，说明不是"在我们树上改"。**

### 同时修正的另一处

我在 `docs/third-boot-attempt.md` 里写过"ABL 用自己的 cmdline 覆盖我们的"——
**那是错的**。cmdline 探针证明 `xiguaprobe=hello123`、`console=ttyMSM0`、
`earlycon` **都到达了内核**。cmdline 是**合并**的。

## 二、设备树交付链（已完全查清）

```
ABL 日志：
  Load Image boot_a        total 63 ms
  Load Image vendor_boot_a total 57 ms   ← 基础 DTB 在这里
  Load Image dtbo_a        total  9 ms   ← overlay 在这里
  Apply Overlay            total 323 ms
  Update Device Tree       total 59 ms
```

### `vendor_boot_a` 结构（设备上的真实内容）

```
header v4, page 4096, header_size 2128
vendor_ramdisk @0x1000        16,741,173 B   (16 MiB)
dtb section    @0xff9000       2,040,082 B   ← 4 个裸 DTB 顺序拼接（非 dt_table）
ramdisk_table  @0x11ec000            108 B
bootconfig     @0x11ed000             85 B
```

**4 个基础 DTB**（ABL 按 `msm-id` 选一个）：

| # | 偏移 | 大小 | model | msm-id | 本机 |
| --: | --: | --: | :-- | :-- | :-- |
| **0** | `+0x000000` | 502,366 | Kalama **v2** | **`0x207 0x20000`** | ✅ **用这个** |
| 1 | `+0x07aa5e` | 521,372 | Kalama | `0x207 0x10000` | |
| 2 | `+0x0f9efa` | 499,327 | KalamaP v2 | `0x218 0x20000` | |
| 3 | `+0x173d79` | 517,017 | KalamaP | `0x218 0x10000` | |

**注意**：entry0 的 `totalsize` **正好等于**槽位大小 502366 ——
厂商自己就是填充的。这验证了"顺序遍历靠 totalsize 前进"的判断。

### `dtbo_a` 结构

dt_table 容器（magic `0xd7b7ab1e`），4 个 entry 与上面一一对应：

| entry | dtb_size | fragments | `__fixups__` | `__symbols__` |
| --: | --: | --: | --: | --: |
| 0 | 148,568 | 78 | 114 | 209 |
| 1 | 333,364 | 116 | **168** | 509 |
| 2 | 149,779 | 78 | 114 | 209 |
| 3 | 334,583 | 116 | 168 | 509 |

### overlay 解析机制（这是最大风险点）

所有 fragment 的 `target = 0xffffffff` —— **未解析占位符**。ABL 启动时必须：

1. 读 `__fixups__`（168 条）：label 名 → fragment 内占位符偏移
2. 在**基础 DTB 的 `__symbols__`** 里查这个 label → 得到 phandle
3. 回填 `target`

**所以替换基础 DTB 会让 overlay 解析失败**，实测覆盖率：

| 基础树 | `__symbols__` 数量 |
| :-- | --: |
| 厂商 entry0 | **1,521** |
| **我们的 DTB** | **533** |

我们的树对 168 个 fixup 的覆盖率只有 **9.5%**（16/168）。
缺失的典型是 `CPU0`、`CPU3`、`L1B`~`L17B`（PMIC 稳压器）、`APC1_pause` 等。

## 三、安全实验路径（比直接写 A 槽好得多）

**重要发现**：设备 **B 槽是纯净原厂**！

| 分区 | 设备值 | 线刷包值 | 结论 |
| :-- | :-- | :-- | :-- |
| `boot_b` | `d9cf0ea6…` | `d9cf0ea6…` | ✅ **一致** |
| `vendor_boot_b` | `e085f83a…` | `e085f83a…` | ✅ **一致** |
| `dtbo_b` | `30b4002a…` | `30b4002a…` | ✅ **一致** |
| `boot_a` | `742105c6…` | `d9cf0ea6…` | ⚠️ 被改过 |
| `vendor_boot_a` | `4b3e8008…` | `e085f83a…` | ⚠️ 被改过 |

**当前活动槽 = `_a`**。

### 推荐流程：在 B 槽上做实验

```
1. 把补丁镜像写入 vendor_boot_b        ← 只动 B 槽，A 槽完全不受影响
2. fastboot set_active b
3. 启动，读 /sys/firmware/devicetree/base/model
4. 回读结果
5. fastboot set_active a               ← 瞬间完全回退
```

**风险等级**：失败 = 切槽（秒级），而非 192 MiB 恢复。
`vendor_boot_b` 的原厂镜像 `vendor_boot-A14.img` 在手，随时可精确还原。

## 四、第一步：零风险标记实验

### 设计

最小改动：**只改 entry0 的 `model` 字符串，等长替换**。

```
原: 'Qualcomm Technologies, Inc. Kalama v2 SoC\0'   (42 字节)
新: 'XIGUA_VBTEST_A1B2C3D4E5F6G7H8____________\0'   (42 字节，等长)
```

**为什么这样最安全**：
- 长度完全相同 → `totalsize` 不变 → 无任何偏移移动
- 结构块只改 ASCII 负载 → 不可能损坏 FDT
- 树的其余部分完全是厂商的 → **168 个 fixup 仍 100% 可解析** → 启动健康

### 已验证的结果

```
bytes before marker identical : True
bytes after  marker identical : True
=> only the 42 marker bytes changed
entry0 @0xff9000 size=502366  model=XIGUA_VBTEST_...
entry1/2/3 完整，walk closed: True
__symbols__ count: 1521 (与原厂一致)
size unchanged: True
```

产物：`out/vendor_boot_a-modelmark.img`

### 这一步能证明什么

若启动成功且能读到 `/sys/firmware/devicetree/base/model` 为新值：

1. ✅ 写 `vendor_boot` 的 dtb 段**安全可行**
2. ✅ ABL 确实用 **entry0** 作为本机基础树
3. ✅ overlay 仍能解析（树本身没变）→ 启动健康

**这正是换成我们自己的树的必要前提。**

## 五、设备树换入的后续难点

标记实验成功后，真正换入我们的 DTB 还要解决 **fixup 覆盖率 9.5%** 的问题：

| 方案 | 思路 | 难点 |
| :-- | :-- | :-- |
| **A. 补全 `__symbols__`** | 给我们的 DTB 加上那 168 个 label 指向的节点 | 等于把这些节点也加进来，可能又和主线的冲突 |
| **B. 让 dtbo 不生效** | 用空的 dt_table（`entry_count=0`） | 未知 ABL 是否接受 |
| **C. 两边都换** | 我们的 DTB + 我们自己的最小 dtbo | 需要理解 OPPO 的 dtbo 生成流程 |

**在标记实验确认之前，不进入这一步。**

## 六、当前资产

| 项 | 状态 |
| :-- | :-- |
| 全分区备份 | ✅ 17 个（**873.6 MiB**），含 `vendor_boot_a/b`、`init_boot_a/b` |
| 哈希校验 | ✅ 逐项与设备一致 |
| A 槽（工作槽） | ✅ 正常，8 次实验后零改动 |
| **B 槽（纯净原厂）** | ✅ 可作实验槽 + 软回退 |
| 恢复流程 | ✅ 三键 9008 → 电源 20s（已验证） |
| 补丁镜像 | ✅ `out/vendor_boot_a-modelmark.img`（未刷） |

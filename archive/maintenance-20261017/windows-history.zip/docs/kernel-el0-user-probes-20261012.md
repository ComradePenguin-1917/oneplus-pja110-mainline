# 跨到初始用户态执行边界

本轮按用户要求扩大步长：从 kernel_execve 返回点，直接测试初始线程完成内核函数返回和用户态退出处理之后的位置，再使用原生 PID1 测试实际 EL0 执行。

## 初始线程的返回边界

替换 ret_from_fork +0x1c 的原始 `b ret_to_user`（Image 偏移 90708）。前一条 BL 经解码核对为 asm_exit_to_user_mode。常驻探针以 x19 与 kernel_init 函数地址比较：该寄存器保存原内核线程函数，跨 C 调用遵循 callee-saved 约定。只对匹配的初始线程复位，其他线程继续原来的 ret_to_user；门控临时使用的 x9 会由后续用户寄存器恢复路径覆盖。

QEMU 实际 Image 耗时 54.031 秒、退出码 0、含 SMC，SHA256 79280fda65668beb8f9c0c901fdd512c60a34ceb4f2c52374babf75057696fa6。用户观察约每 20 秒自行重启，完整引导历史与实际输入读回匹配，恢复 Android A 后八个启动分区哈希一致。支持初始线程已从 kernel_init 返回、asm_exit_to_user_mode 已返回；探针仍在 EL1，不能证明 ERET 或用户态指令执行。

证据：out/kernel-init-el0-boundary-probe-experiment-20261012/result.json。

## 原生用户态 PID1

不再修改内核指令。在原始 r1 的内嵌 gzip initramfs 和实际 init_boot 的 legacy LZ4 initramfs 中，仅替换 /init 内容与对应模式、文件长度，其他文件及属性逐一校验一致；内嵌压缩区和长度字段相应更新。vendor_boot、DTBO 沿用通过 ABL 的原始对照。

原生 AArch64 ELF 的 88 字节入口代码确认 getpid()==1，构造用户栈上的 timespec，调用 nanosleep(35 秒)，只有成功返回才调用 reboot(RESTART)。失败时原地循环，避免用 PID1 退出 panic 伪造信号。syscall 编号从当前 Linux asm-generic/unistd.h 核对为 getpid 172、nanosleep 101、reboot 142。

实际 Image QEMU 验证耗时 82.054 秒，退出码 0、含 PSCI SMC，记录还逐一确认原生程序三处 SVC 指令块（0x401004、0x401028、0x401050）。Image SHA256 a16474ef7b19e23ebca60a3cdd6f4544e0bd96043acac8ff503fa7893cb31c5c；ELF SHA256 6b4ce87f36ee72a544810e6da6a6e590c7c6ece854b14d3e892075e0ee6e239c。

镜像与证据目录为 out/user-init-reset-probe-20261012/ 和 out/user-init-reset-probe-experiment-20261012/。实机已启动，观察、读回与恢复待补充。若有与 35 秒用户态睡眠一致的重启信号，可支持原生 PID1 在 EL0 执行及 syscall 路径工作；仍不能证明原始 shell /init、USB 或正常用户态环境已运行。

实机用户观察自行重启，接近每 50 秒。结合无内核复位探针的实际镜像、QEMU 中三个原生 SVC 指令块、getpid==1 和 nanosleep 成功门控、与 35 秒睡眠相符的重复周期，支持原生 PID1 已在 EL0 执行并走通 getpid/nanosleep/reboot 路径。周期是用户近似观察，没有外部精密计时或直接寄存器日志，不能据此声明原始 BusyBox 脚本或 USB 已成功运行。

完整 8 MiB 引导历史与实际 boot_b 前缀、其他三个 B 分区完整哈希均已核对。最终恢复 Android A，八个启动分区哈希与实验前一致，结果保存于实机目录 result.json。

下一步定位重点：恢复原始 /init 脚本和 BusyBox，在脚本进入及 USB 配置段结束处增加可观察的用户态信号；用较远的完成节点先划分脚本执行与设备初始化问题，再按需要二分。当前证据已足以将关注点从“内核未进入用户态”转向原始用户态初始化的行为，但并未定位具体失败调用。

# PJA110：复用 Aston Synaptics TCM 触控驱动

2026-10-13。在已验证 Linux 6.14 #14 上，以 RAM 模块对照完成适配与实测。没有刷写分区；当前运行 Aston 候选，重启后固定镜像仍加载原 `mainline_touch_probe`。

## 来源与适配边界

源代码来自 `jiganomegsdfdf/aston-mainline` 固定提交 `5d5c840896bb49291ae4578acefd5a3ec65524f6`：`syna_tcm2.c`、`syna_tcm2.h`、`syna_tcm2_spi.c`。保留 Synaptics GPL 许可证及版权；TCMv1 消息核心、报告配置解释器、SPI 实现和 input 实现均基于这些现成文件。未重新实现协议或触点解析算法。

本机适配集中于：现有DT GPIO属性兼容、GPIO0缺省错误、电源与资源管理、46字节应用信息、已验证的LBP=2和RAM报告布局、坐标缺省、解析边界检查及清理路径。原始blob与适配SHA256在 source-manifest.json；逐文件差异保存在 out/aston-touch-20261013/*.patch。源码在 drivers/input/touchscreen/synaptics-aston/。

配置使用本机已验证的 all-objects slot4/class4/x16/y16 布局，通过 Aston 原有 write_message 执行，原有解析器解释报告。配置读回匹配，范围12399×27719、10 slots。没有新增固件下载、持久化配置或flash操作。

## 实测结果

- 原样候选与适配候选均编译通过；Image/.config SHA256不变。
- 第一轮60秒触控：934帧、最多3个活动触点，最终全部释放；用户确认位置、方向和双指正常。
- 修正后的模块成功执行：卸载 Aston、恢复原模块、卸载原模块、重新加载 Aston。SSH全程可用，没有出现新的内核Oops。
- 最终90秒窗口：3275帧、最多4个活动slots，最终全部释放，没有SYN_DROPPED。用户确认两段操作中位置、双指及持续跟随均正常。最多4个slots只是记录结果，不表示做了规定的四指完整验证。
- 原厂PMIC初始化警告等既有日志与候选生命周期问题分别记录；重启恢复后的最终内核日志无 Internal error 或 Unable to handle kernel。
- 八个启动分区与此前触控自动启动基线一致。显示#14、SSH、UFS及A/B镜像均未改写。

## 已保留的失败和修正

首版修改了平台设备释放顺序，但遗漏静态 platform_data 不应由平台核心kfree的所有权要求。卸载产生 platform_device_release→kfree Oops，模块停在Unloading。普通reboot也被异常状态阻塞；保存完整日志和源码后，经SSH使用SysRq强制重启回原自动触控/SSH镜像，没有刷写分区。此问题是本次适配引入，不能记为Aston本身的已确认缺陷。

第二版改为 platform_device_del：先完成子驱动disconnect；再清空借用的静态platform_data；最后platform_device_put。失败回滚也清空静态指针。该释放路径已通过上述实机卸载/回退/重载验证。

第二次短测用户反馈“刚开始行，后来卡住”。记录直到29.995秒仍有事件和最终释放，随后30秒窗口正常结束；诊断程序退出后白点自然不更新。重启清空/tmp后，主机脚本又未重新上传fb-pattern，结束恢复返回127；原始失败记录保留，未记为完整成功。脚本修正为每轮校验上传恢复工具，使用90秒窗口；用户随后确认两段操作均正常。

## 上报率与可视化频率

最终记录的连续事件间隔（剔除超过30ms的停顿）平均8.143ms，中位8ms，对应约123Hz，宜描述为约120Hz的实测上报频率。时间来自用户态处理SYN_REPORT时的毫秒打印值，包含SPI、内核及进程调度，不是芯片内部扫描率的精确测量。

画点工具只以最多20Hz更新framebuffer，事件记录没有降到20Hz。当前没有专门设置高采样率；芯片内部扫描率、高频模式和宣传采样率仍未确认。

## 产物与后续

经过实测的源码、模块、构建日志、生命周期结果、触控记录及分区hash已冻结在 `out/aston-touch-20261013/verified-ram/`，每项SHA256列在sha256.json。失败首版单独在round1-unload-fault/。

工具：prepare_aston_touch.py、wsl_build_aston_touch.sh、test_aston_touch.py、finalize_aston_touch.py。本轮未制作或部署替换固定镜像的init_boot；后续可将已验证模块纳入自动启动，再做实际重启对照。系统休眠/唤醒、长时间压力、十指、防误触及高上报率未由本轮短测覆盖。

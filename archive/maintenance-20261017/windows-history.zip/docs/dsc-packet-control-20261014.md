# AA536 DSC 每包两 slice 对照

基于 #20 构建 #21，仅修改 AA536 命令模式 packetization：
每包 slices 1→2、每行包数2→1、DCS word count 621→1241。
保留 TE height 65520、DSC first_line_bpg_offset 15、slice620×44、
原厂面板命令、GPIO90、Iris7 旁路和所有GPU/USB/触控配置。

采用原厂公式 `bytes_per_pkt=slice_bytes*slice_per_pkt` 与
`pkt_per_line=slices_per_intf/slice_per_pkt`，单slice width寄存器仍为620。
QEMU retained GPU/touch/SSH initramfs 启动检查通过；不验证实机显示。
镜像保留原厂 AVB 尾部；仅部署 boot_b，其他七个启动分区逐项校验。
回退镜像是 `out/te-height-control-20261014/boot_b-sdma.img`。

构建、补丁、镜像与部署证据在 `out/dsc-packet-control-20261014/`。
需实机读回压缩模式控制0x3911及word count1241，并观察相同全屏动画。
未获得视觉确认前不能宣称消除花屏。

实机已普通重启进入 #21，boot_b 完整读回与候选镜像一致，其他七个
分区哈希不变。Ubuntu RAM 环境和2222 SSH重新部署，FD740离屏120帧
像素校验通过。已启动与#20相同的Pixman/传统KMS全屏CPU弹跳点动画。
实际寄存器解码确认每行1包、word count1241、slice bytes620，
TE height65520、source0、起始2772、read pointer2773及阈值4/4保持。
动画持续运行，等待用户视觉确认。证据保存于本轮 `runtime/` 子目录。

用户确认CPU动画有改善但仍偶尔花屏；随后切换相同线性单图层Weston GL
全屏色条。用户照片显示，即使没有明显噪点，故障位置的白条也有阶梯状
错位。因此本轮不算修复，需记录动态画面不连续这一残余现象。
官方Weston截图已抓取为 `fullscreen-bars-capture.png`；抓取时白条在
画面边缘，不能与用户照片按时间直接对应。该截图中条带连续无阶梯。
单张运动照片还可能包含相机滚动快门，不能仅由照片认定某个DSC边界
或硬件根因。优先进一步验证屏幕更新同步及同帧扫描输出完整性。

# 启动链审计与 USB2 对照（2026-10-12）

## 已核实的静态事实

审计读取当前 Android 的 `/sys/firmware/fdt`、`/proc/bootloader_log`，并使用 WSL 内此次构建对应的 Linux 6.14 源码核对行为。原始资料位于 `out/boot-chain-audit-20261012/`，可运行 `python tools/audit_mainline_boot.py` 重做静态核对。

- 原厂与 r1 都是 boot header v4、原始 ARM64 Image，`text_offset=0`、`flags=0xa`。r1 Image 头的有效内存长度为 `0x2150000`，不等于文件长度是正常现象：头描述运行时有效长度，包括未在文件中存储的部分。静态检查不能证明 ABL 的实际加载地址或 CPU 交接状态。
- r1 未强制内核命令行；boot 镜像包含串口、earlycon 和日志参数。之前原厂内核对照证明 boot cmdline 可被合并，但不代表本轮主线已经接收到它。
- `/memory` 的 RAM `reg` 与当前手机实时 DTB 逐字节相同。另有上游继承的零长度 `/memory@a0000000`；尚无证据表明它导致本轮失败。
- GICv3、PSCI、SM8550 GCC/TCSR/pinctrl、RPMh/command-db/SMEM、GENI 串口、USB DWC3/eUSB2 PHY/repeater、configfs 网络 gadget、外部 LZ4 initramfs 解压等所核对的关键选项全部为内建。不能把无输出直接归因于这些驱动被编为模块。
- 主线 DTB 的 PSCI 方法为 SMC，GIC/定时器节点沿用上游 SM8550 定义。52 位 VA/PA 配置在此版本支持硬件不足时回退，且同一 Image 已通过 Cortex-A57 QEMU；不能仅凭该配置断言不兼容。
- 当前主线 DTB **没有 compatible=ramoops 的节点**，虽然 `CONFIG_PSTORE_RAM=y`。镜像也没有 ramoops 内存参数，因此本套镜像没有配置 ramoops 后端。原厂实时 DTB 有动态分配的 ramoops 节点，但此前原厂 panic 对照仍未验证跨重启可读性。必须分别解决“后端配置”和“保留/读取有效性”，不能把空 pstore 当成早期失败证据。
- `CONFIG_BOOT_CONFIG` 未启用；这是与 Android 的差异，但当前 `/init` 不依赖 androidboot bootconfig，尚无证据表明它是阻断点。
- USB3 PHY 在原厂实时 DTB 为 disabled，在主线 r1 为 okay。主线 DWC3 继承 `usb-role-switch`，未显式设置 `dr_mode`。6.14 `dwc3_setup_role_switch()` 在未指定默认 host 时选择 peripheral，因此“未设置 dr_mode 必须等待固件才能进入 peripheral”的猜测不能成立。

Image 头与交接条件参照 [Linux 6.14 ARM64 启动规范](https://docs.kernel.org/6.14/arch/arm64/booting.html)。USB 行为依据导出的本地 `source/drivers/usb/dwc3/drd.c`、`core.c` 与 `dwc3-qcom.c`。

## 日志采集修正

上轮 r1 脚本错误地查询设备树中的 `bootloader_log/log` 属性，实际接口是 `/proc/bootloader_log`。已修正采集脚本。本轮补采的日志及 USB2 实验后的日志都明确显示 A 槽加载，不能追溯被下一次启动覆盖的 B 槽 ABL 日志。上轮没有采到正确路径的事实保留，不把补采日志冒充上轮证据。

## USB2 对照

`tools/prepare_usb2_control.py` 从已验证的 r1 vendor_boot DTB entry0 构造 USB2 外设配置，生成 `out/usb2-control-20261012/`。只改变两个 USB 节点的六个属性：

1. DWC3 `dr_mode=peripheral`，移除 `usb-role-switch`。
2. `maximum-speed=high-speed`，`phys`/`phy-names` 仅保留 USB2 PHY。
3. 禁用 USB3/DP combo PHY。

这是一个完整 USB 配置对照，**不是六个属性分别验证的单属性实验**。构建脚本重新解析 DTB，断言全部语义差异恰好等于上述属性集合，且 vendor_boot entry0 以外所有字节不变。RAM、保留区、其他驱动节点均不变。boot 和 init_boot 与 r1 按哈希完全相同，仍使用经 QEMU 验证的同一内核及用户态。

对照使用既有 B 槽备份、写入、清空 DTBO、切换 B、重启及读回流程，所有 fastboot 操作成功。结果仍是 ADB 返回 A 槽正常 Android；读回 boot 前缀、vendor_boot、init_boot 和全零 DTBO 均匹配本轮输入，A 槽四分区未改变。主机枚举快照仅有 Android ADB 接口，没有测试 USB 网络。不能排除采样间隙中的瞬态接口。

本轮没有获得主线交互入口或启动日志。USB2 配置没有带来可观察的改善，但不能据此排除 USB 问题，也不能证明主线曾到达 `/init`。

已恢复实验前 B 槽四分区并切回 A，最终状态和八个分区哈希的校验记录位于 `out/usb2-experiment-20261012/restored-device.txt`。完整实验输出位于同目录。

## 下一轮的判读标准

优先建立并验证早期日志，而非继续无日志地改变内核。软件路径是先确定安全、固定且跨重启保留的日志区，在原厂内核对照中写入唯一标记并证明确实能在重启后读取，再把相同日志布局接入主线。当前动态 ramoops 分配不能直接当成已验证的固定地址；不得猜地址后覆盖保留内存。

如该通道仍无法通过原厂正对照，UART 才是能直接读取早期输出的下一条路径，需要先确认此机型接口、针脚、电平和实际连线。现有串口配置不是已接通的日志通道。当前审计和 USB2 实验尚未确认具体失败阶段。

# 初始用户态执行路径探针

入口轮在 run_init_process +4 保留 PACIASP，替换栈帧建立指令，转入已验证的常驻代码零填充探针。Image 偏移 86020，探针偏移 16830464。实际 Image QEMU 验证耗时 49.580 秒、退出码 0、含 SMC，SHA256 5d8dd74ded3ec6377980e15055ca83d335eca9c5032599ed6362395fca60d491。

用户观察入口轮约每 20 秒自行重启；完整 8 MiB 引导历史与实际测试输入读回匹配，最终恢复 Android A，八个启动分区哈希一致。支持 run_init_process 已被调用，但该轮跳过整个函数体，没有执行 kernel_execve。

返回值轮在 run_init_process +0xa8（Image 偏移 86184），替换 kernel_execve 调用后的第一条 LDP，前一条 BL 已解码核对目标符号。80 字节常驻探针在破坏 w0 之前比较返回值：零等待 5 秒，非零等待 35 秒，然后 PSCI SYSTEM_RESET。不写栈或 RAM，不返回原函数。

两份 QEMU 原始入口对照使用同一探针并人为设置已知 w0：零约 5.258 秒复位，非零约 35.257 秒复位。实际返回点 Image 也通过 QEMU，耗时 49.023 秒，SHA256 96b70eec21d67829c1451e5f27914eba12bd61abfb30c0cdb588291be18c1f50。boot SHA256 21538ce07f969cbcd227a018b7152a758931a3f3594af8a6175d7f41e9527886。

实机总周期包含前面的初始化与引导时间；不能把总周期直接当作探针延迟，更不能把任意外部复位当成探针执行。若总周期接近入口轮，支持零返回分支；若增加约 30 秒，支持非零返回分支。必要时应在相同实机位置强制非零延迟对照，排除等待 35 秒前发生外部复位的混淆。零返回也不等于用户态已执行第一条指令，非零分支不能确定具体 errno。

实机证据位于 out/kernel-run-init-entry-probe-experiment-20261012/ 和 out/kernel-exec-return-probe-experiment-20261012/；返回值轮的观察、读回和恢复状态待补充。

返回值轮用户观察仍约每 20 秒自行重启，输入读回匹配，已恢复 Android A 且八个启动分区哈希一致。暂支持零返回，等待实机强制长延迟对照排除外部提前复位的可能。

同位置强制对照在探针最前面增加 `mov w0,#1`，保持 kernel_execve 调用和前序初始化不变，只使诊断等待固定为 35 秒。该修改不代表 kernel_execve 实际返回错误。镜像位于 out/kernel-exec-return-force-error-probe-20261012/，84 字节常驻探针；实际 Image QEMU 验证耗时 85.821 秒、退出码 0、含 SMC，SHA256 adb01d2ed80bbd8dedca91359f41b31dcaf6411544da19be3138af545ff44c02。实机已启动，观察和最终恢复待补充。

强制对照实机用户观察周期明显变长、接近每 50 秒，较自然返回值轮约 20 秒增加约 30 秒，与编码的两档延迟差一致。完整引导历史和实际输入读回核对通过，已恢复 Android A，八个启动分区哈希与该轮 preflight 一致。

综合两档 QEMU 校准、实际镜像 QEMU、两轮实机周期差和各轮输入读回，支持自然返回值轮的 kernel_execve 返回 0。结果分别保存于 out/kernel-exec-return-probe-experiment-20261012/result.json 和 out/kernel-exec-return-force-error-probe-experiment-20261012/result.json。周期仍是用户近似观察，并非外部精密计时；没有直接寄存器日志。该结论确认到加载/执行准备返回点，不证明用户态已运行第一条指令，也不确认持续运行或 USB 功能。

下一步：先测试 run_init_process 返回到 kernel_init 的零值成功分支，随后测试 kernel_init 返回到 ret_from_fork 的位置及 EL0 返回路径。若内核返回路径可达，再在初始用户态程序最早入口加入独立信号；不能把 exec 返回 0 与 /init 执行成功混为一谈。

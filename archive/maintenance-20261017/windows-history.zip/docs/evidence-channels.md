==========================================================================
PERSISTENT EVIDENCE CHANNELS -- which ones actually get written?
==========================================================================

1) /proc/bootloader_log
   size on device: 27488 bytes
   survives reboot: YES (stored in oplusreserve1, ABL writes it every boot)
   contains: full ABL trace, partition loads, AVB verdicts, cmdline
   => VERDICT: usable, and already gave us the answer about DTBO handling

2) logfs (8 MiB FAT12)
   ABL log line: "BDS: LogFs sync skipped, Unsupported"
   dumped content: only a FAT12 header with volume label LOGFS + BOOTMGR
   non-empty 4K clusters in dump: 0
   => VERDICT: NOT written on this device (sync explicitly skipped)

3) rawdump (256 MiB)
   first 16 KiB read on device: all zeros
   => VERDICT: NOT written by our failures (would hold classic ramdump)

4) soc:dmesg-dump @ 0xf78ee000 (4 KiB)
   node: /soc/dmesg-dump
   compatible: qcom,dmesg-dump
   qcom,primary-vm = 
   driver: qcom_dmesg_dumper (present, bound)
   exposes: /proc/vmkmsg  (read BLOCKS waiting for new data)
   => VERDICT: it is a live streaming channel, not a post-mortem store.

==========================================================================
CONCLUSION for the "noretain channel" question
==========================================================================

On this device:
  * /proc/bootloader_log IS a working post-mortem channel -- but only for
    what ABL itself did. It told us ABL applies the dtbo and builds the
    cmdline. It will NOT contain our kernel's crash output.
  * logfs is explicitly not synced; rawdump is untouched.
  * ramoops exists (2.25 MiB) and IS registered, but /sys/fs/pstore is
    EMPTY after our failures -- meaning the kernel never got far enough to
    register a panic, or the region is re-initialised each boot.

So there is no magic post-mortem channel for a kernel that dies before
userspace. The practical options remain:
   a) USB network gadget from an embedded initramfs   (best: full shell)
   b) make ramoops actually persist and read it after the next boot
   c) physical UART

# DSC 1.1 SCR1 first-line 修正实测

仅把 PJA110 SCR1 路径 first_line_bpg_offset 从上游 1.2 表的 12 修正
为本机原厂 DSC 1.1 SCR1 值 15，再调用现有 drm_dsc_compute_rc_parameters。
相对 #17 保持 SDMA、Active CTL、分包、面板命令、GPU/触控/SSH 配置不变。

只写 boot_b，完整读回核对，其他七个启动分区未变。初次重启进入 Android A，
fastboot 实测 B retry=0、unbootable=yes、successful=no；重置 set_active b
恢复 retry=7 后，不重刷候选即成功启动 #18，因此该次不能归因于内核失败。
槽位状态证据保存在 slot-before-retry.txt 和 slot-after-reset.txt。

#18 启动后显示、GPU 固件、Aston code3 和 SSH 正常。上游 kmscube
相同参数，亮度 1024，两分钟完成 7199 帧、119.642 秒，约 60.17 fps。
用户确认正常显示立方体，原先中央花屏消失，GPU 故障计数测试后为 0。
测试退出后已恢复彩条。用户近看后确认此前彩条上的细微横线也消失。
两项视觉确认均已记录，最终启动组合与八分区哈希冻结在 verified-combination.json。

当前保留 #18，完整镜像与哈希、源代码单项 diff、QEMU 和实机记录在
out/dsc-firstline-control-20261014/。未改变 slice-per-packet，当前仍为 1。
本项实测证明修正首行 BPG 及对应派生值能消除本轮中央花屏，未覆盖
长期稳定性、高刷新率、插帧或完整桌面。

后续 B 槽已使用现成 qbootctl 标记启动成功，普通重启 #18 自动 SSH
恢复且重试次数不再扣减，见 [启动标记记录](boot-success-20261014.md)。

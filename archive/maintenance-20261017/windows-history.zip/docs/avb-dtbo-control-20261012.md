# DTBO AVB 校验修复与覆盖合并对照

后续进展：原厂风格 `target` / `__fixups__` 布局已通过实机 ABL 覆盖合并，详见 [后续对照](abl-overlay-control-20261012.md)。本文保留前两轮失败证据。

## 已确认的阶段

完整读取 `oplusreserve1` 的 8 MiB 快照，找到了原先只读前 32 KiB 所遗漏的 B 槽记录。清空 `dtbo_b` 后，引导器报告 `invalid vbmeta header`，执行 `HandleActiveSlotUnbootable_vb2: Rebooting` 并切到 A 槽。这份记录不能用于判断主线内核启动、UFS 探测或用户态日志程序是否正常。

## 修复方式

`tools/prepare_avb_noop_dtbo.py` 从原厂 `backup/dtbo_b.img` 构造测试镜像。保留 DTBO 四项的原厂设备匹配字段、根节点匹配属性，以及 AVB footer、签名元数据和原始偏移。仅替换覆盖内容。

没有原厂私钥，因此修改后的覆盖内容不再匹配原厂哈希描述。这不是重新签名或在锁定设备上通过完整校验；使用的是本机已解锁状态下允许内容校验错误的行为。没有修改任何 vbmeta 分区。

两轮实机 B 槽记录均显示：

```text
dtbo_b: Hash of data does not match digest in descriptor.
VB2: Authenticate complete! boot state is: orange
ApplyOverlay: ufdt apply overlay failed
Error: Dtb overlay failed
Launching fastboot
```

因此 DTBO 的 AVB 元数据解析阻塞已排除，但引导器仍在覆盖合并阶段失败，没有主线内核执行证据。

## 两轮对照

共同输入为已验证的 r1 Image、r1 generic init_boot 和 USB2 control vendor_boot。没有使用落盘日志 initramfs，也没有主动写 logdump。

1. `out/avb-noop-control-20261012/`：保留原厂各条目长度，用指向根路径的空覆盖替换原覆盖；DTBO SHA256 `9f02f759f4d26bda9a891d303945993b102407f67b3f41d85bee0bda01d3a59b`。
2. `out/avb-marker-control-20261012/`：条目长度改为实际 FDT 长度，覆盖仅新增无功能节点 `/xigua-avb-control`；DTBO SHA256 `aafe60615c037798f2de6ff57a78d920b37c4b860b4ba8e72340c674c55604c0`。WSL `/usr/bin/fdtoverlay` 成功将四份覆盖依次合并到同一个 USB2 主线 DTB，合并结果中的标记值已核对。这个验证使用 libfdt，不等于验证手机内的 libufdt 实现。Windows 原生 fdtoverlay 读取失败，未作为通过证据。

两轮均进入 fastboot，随后明确切回 Android A，读取完整启动历史并保存镜像读回哈希。证据目录分别是 `out/avb-noop-experiment-20261012/` 和 `out/avb-marker-experiment-20261012/`，各自的 `history/oplusreserve1.img` 保存失败记录；`restored-device.txt` 保存恢复后的八个分区哈希。

`tools/run_r1_flash_test.py` 已拒绝使用清空 DTBO 的旧入口，要求提供有效 DTBO 测试镜像；避免后续重复制造相同 AVB 元数据错误。完整历史采集器支持不同输出目录，以保留每一轮证据。

## 后续定位

应在相同输入上复现或隔离 ABL 的 ufdt 合并失败，例如先验证覆盖在已知兼容的原厂基础树上的处理，再检查主线基础树与实际 ufdt 实现的差异。尚不能归因于 UFS、看门狗或内核执行；也不能因为 libfdt 离线合并成功就声称覆盖格式与 ABL 完全兼容。

参考：[AOSP libavb](https://android.googlesource.com/platform/external/avb/+/bc8f647d58db7490caef46c3d7ac85e4f481c389/libavb/avb_slot_verify.c)；[AOSP libufdt](https://android.googlesource.com/platform/system/libufdt/+/refs/tags/android-platform-13.0.0_r34/ufdt_overlay.c)。实际阶段判断来自本机保存的引导日志。

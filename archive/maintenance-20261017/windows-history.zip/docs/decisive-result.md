# 决定性实验：结果与结论

> 日期：2026-10-11 · 真机实验 · 这是本项目第一次**干净地**测试"我们的内核 + 我们的设备树"

## 1. 实验设计（三重条件同时满足）

这是之前所有尝试都**没能凑齐**的组合：

| 条件 | 之前的尝试 | 本次 |
| :-- | :-- | :-- |
| 内核拿到**我们的**设备树 | ❌ 拿到的是厂商树 | ✅ 通过 `vendor_boot` entry0（已验证可行的通道） |
| **没有 overlay 覆盖** | ❌ dtbo 的 overlay 会写 `model`、重建 `/chosen` | ✅ `dtbo_b` 已擦除 |
| 内核能**自己**把根文件系统跑起来 | ❌ 厂商树靠 overlay 才 enable UFS | ✅ 我们的树 UFS/USB 都是 `okay` |

刷入内容：

```
vendor_boot_b = 我们的 DTB 作 entry0   (2c05fda9…)
boot_b        = 我们的内核 + 内嵌 initramfs (afe9d64d…)
dtbo_b        = 擦除                    (95aeaae0…)
set_active b  → reboot
```

## 2. 结果

**设备 15 秒后从 A 槽启动 Android 5.15。B 槽没有起来。**

## 3. 这个负结果是**有效的**——用对照实验验证过

我无法直接看到 ABL 为何没起来（`/proc/bootloader_log` 在 RAM 里，已被回退后的那次启动覆盖）。所以我先排除了"实验本身无效"的可能：

**对照实验**：把 `boot_b` / `vendor_boot_b` / `dtbo_b` 全部还原成原厂，`set_active b`，重启。

```
slot_suffix    : _b          ← 确实从 B 槽启动
boot_completed : 1
kernel         : 5.15.123-android13-8-00758-g835dd0ff1fbc   (原厂)
```

**结论：`set_active` 有效、B 槽可启动。** 所以我们的内核在 B 槽上确实失败了，不是"槽位没切过去"。

## 4. 一次方法错误（更正）

我一度判断"`boot_b` 被改写了"，因为分区哈希对不上：

```
boot_b 分区 = 201,326,592 字节 (192 MiB)
我们的镜像  =  34,353,152 字节 (32.7 MiB)
```

**这是我的验证方法错了**：`fastboot` 只写镜像长度那部分，分区其余保留旧数据，所以"整分区哈希 ≠ 镜像哈希"是**必然的**。按镜像长度比对前缀后：

```
前缀逐字节 == 我们的镜像 afe9d64d…   ✅ 刷写完好
```

## 5. 这推翻了什么

| 我之前的假设 | 现状 |
| :-- | :-- |
| "问题在设备树交付，ABL 忽略追加的 DTB" | ❌ 设备树交付**已验证可行**；本次内核拿到的就是我们的树 |
| "内核因厂商 compatible 不匹配而早死" | ⚠️ 本次用的是**我们的** compatible（`qcom,sm8550-gcc` 等），仍然早死 |
| "必须改 vendor_boot" | ✅ 这条做对了，也成功了 |

**瓶颈不在设备树，而在更早的地方**：内核镜像本身、启动参数、或极早期 arch/固件初始化。

## 6. 顺带确认的资产

| 项 | 状态 |
| :-- | :-- |
| `vendor_boot` entry0 注入通道 | ✅ 有效（`xigua-vbtest` 曾出现在运行树里） |
| `fastboot flash` | ✅ 每次成功 |
| `fastboot boot` | ⚠️ 间歇 `Too many links`（host USB 问题），已改用 flash 路线 |
| A/B 槽切换 | ✅ 有效，B 槽可用作实验槽 |
| 恢复 | ✅ 所有分区已还原，设备正常 |

## 7. 下一个瓶颈：观测能力（这是真正的阻塞点）

**我们从未看到过我们内核的任何输出。** 所有证据都是间接的（"设备回到了 A 槽"）。

已知的通道排查结果：

| 通道 | 状态 |
| :-- | :-- |
| 串口 `ttyMSM0` | ❌ 需要拆机接 UART |
| USB gadget | ❌ 内核没到那个阶段（否则 adb 会出现在测试里） |
| `/proc/bootloader_log` | ⚠️ 只有 ABL 的，且在 RAM 里会被下次启动覆盖 |
| `rawdump` / `logdump` | ❌ 全零 |
| `logfs` | ❌ ABL 明说 `LogFS sync skipped, Unsupported` |
| `oplusreserve1` | ❌ 只存 UFS 器件信息（`SAMSUNG KLUFG8RHHD-B0G1`） |

### 最有希望的两条路

**A. `poweroff` 作为信号（零驱动依赖）**

让 `/init` 在 USB 起不来时**主动关机**（PSCI `SYSTEM_OFF`）：

| 现象 | 含义 |
| :-- | :-- |
| **设备关机后不再自动启动** | ✅ **`/init` 跑了** → 内核到了用户态 |
| 回到 Android | ❌ 内核早死 |

这个判据**不需要任何外设驱动**。已确认前提具备：
- `/psci/method = smc` ✅
- `CONFIG_MAGIC_SYSRQ=y` ✅

**B. `ramoops`/`pstore`（能留住真正的日志）**

厂商树里有专门用于此的区域，且我们的内核配置**已经全开**：

```
CONFIG_PSTORE=y  CONFIG_PSTORE_RAM=y  CONFIG_PSTORE_CONSOLE=y  CONFIG_PSTORE_PMSG=y
```

厂商的 `/reserved-memory/ramoops_region`：
```
console-size = 0x40000    ← 内核 printk 直接写进 RAM
pmsg-size    = 0x200000
size         = 0x240000
```
用 `alloc-ranges`（地址动态），所以**我们的 DTB 里完全没有这个节点**（已确认 `NONE`）。

**这条路的价值**：崩溃日志留在 RAM 里，回退到 Android 后可从 `/sys/fs/pstore` 读出。从"完全瞎"变成"能读到 panic"。

**需要做的**：在**我们的 DTB** 里加一个**固定地址**的 ramoops 区，地址要落在我们 `/memory` 映射内且不与 20 多个保留区冲突。

## 8. 建议顺序

1. **先做 A**（改 `/init` 加 poweroff，一行 shell）—— 成本最低，二值判据，立刻可做
2. **再做 B**（DTB 加固定 ramoops + 验证 pstore 真能留住日志）—— 成本高些，但能拿到真正的日志
3. B 成功后，才有能力诊断"内核为什么早死"

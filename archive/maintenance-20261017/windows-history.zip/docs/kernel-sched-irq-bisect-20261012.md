# 调度器、中断初始化与后续二分定位

2026-10-12，沿用 r1 原始 Image、已通过 ABL 的 vendor_boot/init_boot/DTBO 对照，仅修改 boot_b 内的一条分支与 68 字节复位探针。探针在可执行 init 区的零填充中，不写 logdump。

| 位置 | Image 文件偏移 | 实机观察 | 结论 |
| --- | --- | --- | --- |
| sched_init 返回之后 | 24644524 | 用户观察到约每 5 秒自行重启 | 支持 mm_core_init、sched_init 已返回 |
| init_IRQ 返回之后、tick_init 调用之前 | 24644564 | 用户观察到约每 5 秒自行重启 | 支持 early_irq_init、init_IRQ 已返回；尚未验证中断实际响应 |
| start_kernel 尾部调用 rest_init 之前 | 24645268 | 用户观察到约每 5 秒自行重启 | 支持到达 rest_init 调用点；探针跳过 rest_init |

两个位置均解码前一条 BL 并核对本构建符号，确保调用目标准确。QEMU 验证绑定实际 Image SHA256，退出码 0 且执行记录含 SMC；时长分别为 8.801 秒、9.867 秒。实机周期来自用户观察，没有外部精密计时；复位原因本身不是 PSCI 的唯一标识。

两轮完整引导历史及实际 B 分区读回保存于 `out/kernel-after-sched-init-probe-experiment-20261012/` 与 `out/kernel-after-init-irq-probe-experiment-20261012/`。两轮均已恢复 Android A，八个启动分区哈希匹配各轮实验前状态，核对结果保存于各目录 `restored-device.txt` 与 `result.json`。

用户要求改用二分定位。已知可达边界为 init_IRQ 返回；先测试 start_kernel 尾部调用 rest_init 之前的较远位置，建立后续边界。若未观察到复位信号，不能立即认定该位置不可达：需要排除探针在新环境下的计时/复位失败，并重复对照确认，再在已知可达与候选不可达之间取中点。

下一个测试镜像位于 `out/kernel-before-rest-init-probe-20261012/`，替换偏移 24645268 的 `bl rest_init`，解码核对目标符号；因此即使出现阳性信号，也只确认到达调用点，不表示 rest_init 已执行。QEMU 验证时长 14.458 秒，退出码 0，含 SMC，实际 Image SHA256 为 `1bc147078b9c9982c9203a364010b2573defef100f41272e79edc147dcfc6b22`。

该远端实机测试已获阳性观察，完整 8 MiB 引导历史与实际镜像读回已保存，恢复 Android A 后八个启动分区哈希全部匹配。结果位于 `out/kernel-before-rest-init-probe-experiment-20261012/result.json`。

随后继续寻找候选不可达上界：测试 `kernel_init_freeable + 0x1f4`（Image 偏移 24646212），此构建将 do_basic_setup/do_initcalls 内联，位置在所有 initcall 等级循环结束且 kfree 返回之后，跳过接下来的 wait_for_initramfs。QEMU 实际 Image 已执行到探针，耗时 49.209 秒并复位，SHA256 `bfd8c9422ef1c83853bf1dad6c54a264de6c16ea3908da571bdab9f9fb6c8288`。镜像目录为 `out/kernel-after-initcalls-probe-20261012/`，实机证据目录为对应 `-experiment-20261012/`。实机结论待观察、读回及恢复校验后填写。

该 initcall 远端测试用户也观察到约每 5 秒自行重启；完整引导历史已读取，实际 boot_b 前缀 SHA256 匹配测试镜像。这支持主初始化线程已走过全部 initcall 等级循环，但不等于每个驱动返回成功、设备已工作，亦不等于所有异步初始化已完成。

该轮已完成恢复：Android A 启动完成，八个 A/B 启动分区哈希匹配实验前状态，最终结果保存于 `out/kernel-after-initcalls-probe-experiment-20261012/result.json`。本轮四个实机探针均为阳性，目前尚未建立候选不可达上界，不能声称已定位具体故障调用。

后续二分边界选择：目前可达下界已推进到 wait_for_initramfs 调用之前。优先取 kernel_init_freeable 返回后的较远位置，覆盖 wait_for_initramfs、console_on_rootfs、init_eaccess 和按条件执行的 prepare_namespace。若该位置未到达，回测 wait_for_initramfs 返回点，将区间分成“等待 initramfs”与“根文件系统/初始控制台检查”。若可达，则继续跨到 async_synchronize_full 返回点，再查释放 init 内存和启动用户态；释放 init 内存之后的探针不能继续使用当前 init 区零填充，必须改用仍有效的可执行存储位置并重新验证。

目前仍没有正常主线日志或用户态启动证据，不能将这些节点阳性等同于完整启动成功。

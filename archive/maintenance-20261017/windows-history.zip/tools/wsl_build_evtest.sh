#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
OUT="$WIN/out/buttons-20261013"
PREFIX="$ROOT/toolchain/gcc-12-aarch64"
export PATH="$PREFIX/usr/bin:$PATH"
export LD_LIBRARY_PATH="$PREFIX/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
aarch64-linux-gnu-gcc -static -no-pie -O2 -Wall -DVERSION='"upstream-0cb59b4"' "$OUT/upstream/evtest.c" -o "$OUT/evtest"
echo 'Built unmodified upstream ARM64 evtest'

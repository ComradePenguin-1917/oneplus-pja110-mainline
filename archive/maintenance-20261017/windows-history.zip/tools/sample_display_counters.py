"""Upload and run a bounded read-only register counter sampler."""
import argparse,hashlib,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('--label',choices=('single','continuous','fast','budget'),default='single')
parser.add_argument('--count',type=int,default=300)
args=parser.parse_args()
assert 1<=args.count<=4000
out=ROOT/'out/display-timing-20261014/counters'
keys=ROOT/'out/usb-ncm-20261013/ssh'
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(keys/'client_key_host'),
 '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
 '-o',f'UserKnownHostsFile={keys/"known_hosts"}','-o','ConnectTimeout=5','root@169.254.42.1']
def run(cmd,data=None):
 p=subprocess.run(ssh+[cmd],input=data,capture_output=True,timeout=60)
 (out/'last-stderr.txt').write_bytes(p.stderr)
 p.check_returncode();return p.stdout
data=(out/'sample-display-counters').read_bytes()
assert run('set -e; cat > /tmp/sample-display-counters.new; chmod 700 /tmp/sample-display-counters.new; sha256sum /tmp/sample-display-counters.new',data).decode().split()[0]==hashlib.sha256(data).hexdigest()
run('mv /tmp/sample-display-counters.new /tmp/sample-display-counters')
csv=run(f'/tmp/sample-display-counters {args.count}')
(out/f'{args.label}.csv').write_bytes(csv)
print(f'Saved {args.count} read-only register snapshots for {args.label}')

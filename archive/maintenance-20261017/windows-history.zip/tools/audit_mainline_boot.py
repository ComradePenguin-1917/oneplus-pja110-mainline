"""Record static boot-chain facts without treating them as live boot evidence."""
import hashlib
import json
import pathlib
import struct

from bootimg import BootImage
from fdt import FDT

ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT = ROOT / 'out/boot-chain-audit-20261012'
BUILD = ROOT / 'out/rebuild-20261012'

def main():
    dtb = (BUILD / 'sm8550-oneplus-xigua-16G.dtb').read_bytes()
    live = (OUT / 'live-fdt.dtb').read_bytes()
    mainline, vendor = FDT(dtb).nodes(), FDT(live).nodes()
    config = {}
    for line in (BUILD / 'kernel.config').read_text().splitlines():
        if line.startswith('CONFIG_') and '=' in line:
            k, v = line.split('=', 1)
            config[k] = v
    required = ['ARCH_QCOM','ARM_GIC_V3','ARM_PSCI_FW','SM_GCC_8550',
                'SM_TCSRCC_8550','PINCTRL_SM8550','QCOM_SCM','QCOM_RPMH',
                'QCOM_COMMAND_DB','QCOM_SMEM','HWSPINLOCK_QCOM',
                'SERIAL_QCOM_GENI','SERIAL_QCOM_GENI_CONSOLE',
                'USB_DWC3_QCOM','PHY_QCOM_SNPS_EUSB2','PHY_QCOM_EUSB2_REPEATER',
                'USB_CONFIGFS','USB_CONFIGFS_ECM','USB_CONFIGFS_RNDIS',
                'USB_CONFIGFS_NCM','BLK_DEV_INITRD','RD_LZ4','CONFIGFS_FS']
    builtins = {k: config.get('CONFIG_' + k, 'n') for k in required}
    assert all(v == 'y' for v in builtins.values()), builtins
    assert config['CONFIG_CMDLINE'] == '""' and config.get('CONFIG_CMDLINE_FORCE') != 'y'
    ram = lambda nodes: {p: v['reg'].hex() for p, v in nodes.items() if v.get('device_type') == b'memory\0'}
    assert mainline['/memory']['reg'] == vendor['/memory']['reg']
    header = {}
    for name, path in [('stock', ROOT / 'boot-A14.img'), ('r1', BUILD / 'boot-xigua-r1.img')]:
        boot = BootImage.parse(str(path))
        k = boot.kernel
        assert k[56:60] == b'ARM\x64'
        values = struct.unpack_from('<QQQ', k, 8)
        header[name] = {'text_offset': hex(values[0]), 'image_size': hex(values[1]), 'flags': hex(values[2]), 'raw_kernel_bytes': len(k), 'header_version': boot.header_version, 'cmdline': boot.cmdline.decode()}
    core = '/soc@0/usb@a6f8800/usb@a600000'
    ramoops = lambda nodes: [p for p, v in nodes.items() if b'ramoops\0' in v.get('compatible', b'')]
    report = {
        'kernel_sha256': hashlib.sha256((BUILD / 'Image').read_bytes()).hexdigest(),
        'required_drivers_builtin': builtins,
        'image_headers': header,
        'ram_registers_match_live': True,
        'memory_nodes': ram(mainline),
        'mainline_ramoops_nodes': ramoops(mainline),
        'stock_live_ramoops_nodes': ramoops(vendor),
        'pstore_ram_builtin': config.get('CONFIG_PSTORE_RAM') == 'y',
        'bootconfig_enabled': config.get('CONFIG_BOOT_CONFIG') == 'y',
        'psci_nodes': {p: {k: v[k].hex() for k in ('compatible', 'method') if k in v} for p, v in mainline.items() if b'psci' in v.get('compatible', b'')},
        'usb_role_switch_present': 'usb-role-switch' in mainline[core],
        'usb_dr_mode': mainline[core].get('dr_mode', b'').decode(),
        'usb3_phy_enabled_in_mainline': mainline['/soc@0/phy@88e8000'].get('status') == b'okay\0',
        'usb3_phy_status_in_stock_live': vendor['/soc/ssphy@88e8000']['status'].decode().rstrip('\0'),
        'confirmed_failure_stage': None,
    }
    (OUT / 'audit.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, indent=2))

if __name__ == '__main__':
    main()

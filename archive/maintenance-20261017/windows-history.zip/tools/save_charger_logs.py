from pathlib import Path
import subprocess
from prepare_native_install import SSH
out=Path('out/native-install-20261017/charger-a-logs.tar')
with out.open('wb') as f:
 p=subprocess.run(SSH+['tar -C /tmp/a-log-readonly -cf - var/log etc/ssh/ssh_host_ed25519_key.pub'],stdout=f,stderr=subprocess.PIPE,timeout=60)
print(p.stderr.decode(errors='replace'));p.check_returncode()
subprocess.run(SSH+['umount /tmp/a-log-readonly && losetup -d /dev/loop0'],check=True,timeout=15)
print(out, out.stat().st_size)

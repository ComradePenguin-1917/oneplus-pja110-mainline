"""Collect the 12 defined stock config words; ignore stale response tail."""
from pathlib import Path
import json
import re
import subprocess
import time
from prepare_native_install import SSH

args = SSH[:]
args[-1] = 'penguin@172.16.42.1'
args = [x if not x.startswith('UserKnownHostsFile=') else
        'UserKnownHostsFile=out/native-install-20261017/known_hosts' for x in args]
p = subprocess.run(args + ['cat /home/penguin/charger-config-probe/result.log; '
                          'echo LIVE_STATE; cat /proc/uptime; '
                          'cat /sys/module/qcom_battmgr/parameters/pja110_charger_init; '
                          'cat /sys/class/power_supply/bq28z610-0/uevent'],
                   capture_output=True, timeout=30)
out = Path('out/native-install-20261017/charger-config-probe')
dest = out / ('live-' + time.strftime('%Y%m%d-%H%M%S') + '.txt')
dest.write_bytes(p.stdout + p.stderr)
print(p.stdout.decode(errors='replace'))
print(p.stderr.decode(errors='replace'))
p.check_returncode()
text = p.stdout.decode()
assert 'CONFIG_PROBE_COMPLETE' in text and 'READONLY_MODULE_RESTORED' in text
m = re.search(r'CONFIG_BUFFER_RESULT=0\s+(\d+)\s+([0-9,]+)', text)
assert m, 'No valid config readback in capture'
values = list(map(int, m[2].split(',')))
assert len(values) == 12
registers = [0x2646, 0x2658, 0x2654, 0x2650, 0x2954, 0x2952, 0x2640, 0x2a52]
report = dict(capture=str(dest), advertised_size=int(m[1]), state=values[0],
              cell_mode=values[1], registers={hex(k): hex(v) for k, v in zip(registers, values[2:10])},
              input_current_raw=values[10], cached_byte=values[11])
dest.with_suffix('.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))

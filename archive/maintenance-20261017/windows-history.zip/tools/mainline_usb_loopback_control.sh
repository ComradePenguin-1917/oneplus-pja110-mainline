#!/bin/sh
# Runtime-only ACM + stock Loopback; no partition writes.
PATH=/sbin:/bin:/usr/sbin:/usr/bin
export PATH
trap '' HUP
set -x
echo $$ > /tmp/usb-loopback-manager.pid
sleep 3
G=/sys/kernel/config/usb_gadget/g1
cd "$G" || exit 1
controller=$(cat UDC)
[ -n "$controller" ] || exit 1
restart_shell() {
    sleep 3
    while :; do
        setsid sh -i </dev/ttyGS0 >/dev/ttyGS0 2>&1
        sleep 1
    done
}
restore_acm() {
    rc=$?
    trap - EXIT
    echo "PJA_LOOPBACK_SETUP_FAILED rc=$rc restoring ACM"
    cd "$G" || exit 1
    printf '\n' > UDC
    rm -f configs/c.1/Loopback.test os_desc/c.1
    rmdir functions/Loopback.test 2>/dev/null
    echo 0 > os_desc/use
    echo 0x0108 > idProduct
    echo PJA110-ACM > strings/0x409/serialnumber
    echo xigua-mainline-usb-serial > strings/0x409/product
    echo "$controller" > UDC
    restart_shell
}
trap restore_acm EXIT
dmesg > /tmp/loopback-before.dmesg
printf '\n' > UDC || exit 1
sleep 1
echo 0x0109 > idProduct || exit 1
echo PJA110-LB > strings/0x409/serialnumber || exit 1
echo xigua-mainline-loopback > strings/0x409/product || exit 1
mkdir -p functions/Loopback.test || exit 1
echo 32 > functions/Loopback.test/qlen || exit 1
echo 4096 > functions/Loopback.test/bulk_buflen || exit 1
ln -s "$G/functions/Loopback.test" configs/c.1/Loopback.test || exit 1
echo 1 > os_desc/use || exit 1
echo 0xcd > os_desc/b_vendor_code || exit 1
echo MSFT100 > os_desc/qw_sign || exit 1
ln -s "$G/configs/c.1" os_desc/c.1 || exit 1
echo "$controller" > UDC || exit 1
echo 'PJA_LOOPBACK_BOUND'
trap - EXIT
# Recreate the diagnostic shell after reconnect. The previous one ends on hangup.
restart_shell

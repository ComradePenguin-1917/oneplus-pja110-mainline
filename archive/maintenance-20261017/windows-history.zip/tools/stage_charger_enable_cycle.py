"""Stage a single stock enable cycle; no persistent charger policy."""
from pathlib import Path
import hashlib
import subprocess
from prepare_native_install import SSH

out = Path('out/native-install-20261017/charger-enable-cycle')
data = (out / 'qcom_battmgr-cycle.ko').read_bytes()
sha = hashlib.sha256(data).hexdigest()
script = '''#!/bin/sh
set -eu
test "$(id -u)" = 0
mkdir /run/pja110-charger-watchdog-lock || exit 1
trap 'rmdir /run/pja110-charger-watchdog-lock' EXIT
cd /home/penguin/charger-enable-cycle
exec > result.log 2>&1
chmod 644 result.log
test "$(uname -r)" = 6.14.0-oneplus-xigua
test "$(cat /sys/module/qcom_battmgr/parameters/pja110_charger_init)" = N
echo '@SHA@  qcom_battmgr-cycle.ko' | sha256sum -c -
test -f /usr/local/lib/pja110/qcom_battmgr.ko
g=/sys/class/power_supply/bq28z610-0
test "$(cat "$g/present")" = 1
test "$(cat "$g/health")" = Good
t=$(cat "$g/temp")
test "$t" -ge 200 && test "$t" -le 350
v=$(cat "$g/voltage_now")
test "$v" -ge 7000000 && test "$v" -le 8500000
test "$(cat /sys/class/power_supply/qcom-battmgr-usb/online)" = 1
restore() {
 if [ -d /sys/module/qcom_battmgr ]; then rmmod qcom_battmgr || return 1; fi
 insmod /usr/local/lib/pja110/qcom_battmgr.ko pja110_charger_init=0
 echo READONLY_MODULE_RESTORED
}
cleanup() { restore; rmdir /run/pja110-charger-watchdog-lock; }
cat /proc/sys/kernel/random/boot_id /proc/uptime
cat "$g/uevent"
rmmod qcom_battmgr
trap cleanup EXIT
insmod ./qcom_battmgr-cycle.ko
result=-115
for i in $(seq 1 20); do
 result=$(cat /sys/module/qcom_battmgr/parameters/readback_result)
 [ "$result" = -115 ] || break
 sleep 1
done
echo ENABLE_CYCLE_RESULT=$result
for name in disable_result enable_result restore_retry_result before disabled enabled; do
 echo FIELD=$name
 cat /sys/module/qcom_battmgr/parameters/$name
done
# A failed transaction intentionally poisons its GLINK context. Reprobe in
# restore-only mode if the cycle began but final enable could not be verified.
started=$(cat /sys/module/qcom_battmgr/parameters/cycle_started)
on=$(cat /sys/module/qcom_battmgr/parameters/enabled | cut -d , -f 3)
if [ "$started" = Y ] && [ "$on" != 1 ]; then
 echo FRESH_CONTEXT_RESTORE
 rmmod qcom_battmgr
 insmod ./qcom_battmgr-cycle.ko restore_only=1
 for i in $(seq 1 12); do
  recovery=$(cat /sys/module/qcom_battmgr/parameters/readback_result)
  [ "$recovery" = -115 ] || break
  sleep 1
 done
 echo ENABLE_RECOVERY_RESULT=$recovery
 cat /sys/module/qcom_battmgr/parameters/enabled
fi
restore
trap 'rmdir /run/pja110-charger-watchdog-lock' EXIT
for i in $(seq 1 6); do
 cat /proc/uptime
 cat "$g/uevent"
 sleep 5
done
test "$result" = 0
echo ENABLE_CYCLE_COMPLETE
'''.replace('@SHA@', sha)
(out / 'probe.sh').write_bytes(script.encode())
args = SSH[:]
args[-1] = 'penguin@172.16.42.1'
args = [x if not x.startswith('UserKnownHostsFile=') else
        'UserKnownHostsFile=out/native-install-20261017/known_hosts' for x in args]

def run(cmd, payload=None):
    p = subprocess.run(args + [cmd], input=payload, capture_output=True, timeout=30)
    print(p.stdout.decode(errors='replace'))
    print(p.stderr.decode(errors='replace'))
    p.check_returncode()
    return p.stdout

v = run('umask 077; mkdir -p /home/penguin/charger-enable-cycle; '
        'cat > /home/penguin/charger-enable-cycle/qcom_battmgr-cycle.ko; '
        'sha256sum /home/penguin/charger-enable-cycle/qcom_battmgr-cycle.ko', data)
assert v.decode().split()[0] == sha
run('cat > /home/penguin/probe-charger-enable-cycle.sh', script.encode())
run('sh -n /home/penguin/probe-charger-enable-cycle.sh')
p = subprocess.run(args + ['sudo -n true'], capture_output=True, timeout=15)
print('Noninteractive sudo:', p.returncode == 0)
print(p.stderr.decode(errors='replace'))

"""Validate schema/checksums and stage real upstream devicepkg build/package hooks."""
import hashlib,json,re,tarfile,tomllib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
base=ROOT/'postmarketos/device/testing';reference=ROOT/'out/postmarketos-reference-20261014'
schema=tomllib.loads((reference/'deviceinfo_schema.toml').read_text())
rules={name:rule for category in schema['variable'].values() for name,rule in category.items()}
text=(base/'device-oneplus-xigua/deviceinfo').read_text()
values={}
for line in text.splitlines():
 if not line or line.startswith('#'):continue
 match=re.fullmatch(r'deviceinfo_(\w+)="([^"\n]*)"',line)
 assert match,line
 name,val=match.groups();assert name in rules,name;assert name not in values,name
 rule=rules[name];typ=rule.get('datatype','string')
 if typ=='boolean':assert val in ('true','false'),name
 if typ=='integer':assert val.isdecimal(),name
 if typ=='enumeration':assert val in rule['enum_values'],(name,val)
 values[name]=val
assert all(n in values for n,r in rules.items() if r.get('mandatory'))
assert values['flash_method']=='none' and values['generate_bootimg']=='false'
assert values['flash_kernel_on_update']=='false'
kernel=base/'linux-oneplus-xigua';km=json.loads((kernel/'source-manifest.json').read_text())
with tarfile.open(kernel/'pja110-kernel-overlay.tar.gz') as tar:
 members={m.name:m for m in tar}
 assert set(members)=={r['path'] for r in km['files']}
 for record in km['files']:
  name=record['path'];assert not name.endswith('.mod.c') and '/generated/' not in name
  data=tar.extractfile(members[name]).read()
  assert hashlib.sha256(data).hexdigest()==record['sha256']
  assert b'PRIVATE KEY' not in data and b'client_key_host' not in data
config=(kernel/'config-oneplus-xigua.aarch64').read_text()
assert 'CONFIG_INITRAMFS_SOURCE=""' in config
assert '/home/' not in config
counts={}
for folder in [*base.iterdir(), ROOT/'postmarketos/main/phoc']:
 if not folder.is_dir():continue
 apk=(folder/'APKBUILD').read_text()
 maintainer=re.search(r'^maintainer="([^"]+)"$',apk,re.M)
 assert maintainer and re.fullmatch(r'[^<>]+ <[^<>\s]+@[^<>\s]+\.[^<>\s]+>',maintainer[1]),(folder,'maintainer format')
 sums=re.search(r'sha512sums="\n([\s\S]*?)\n"',apk);assert sums,folder
 for line in sums[1].splitlines():
  digest,name=line.split(None,1)
  if name=='linux-6.14.tar.xz':assert digest==km['base_sha512'];continue
  source=(ROOT/'out/phoc-atomic-fix-20261016/alpine-reference'/name) if name=='phoc-0.57.0.tar.xz' else folder/name
  assert hashlib.sha512(source.read_bytes()).hexdigest()==digest,(folder,name)
 counts[folder.name]=len(sums[1].splitlines())
profile=json.loads((ROOT/'postmarketos/integration-profile.json').read_text())
assert profile['packages']['phoc']=='0.57.0-r2'
assert 'phoc=0.57.0-r2' in (base/'device-oneplus-xigua/APKBUILD').read_text()
assert 'scale = 2.5' in (base/'device-oneplus-xigua/phoc.ini').read_text()
assert 'report_rate_code=3' in (base/'device-oneplus-xigua/modprobe.conf').read_text()
for folder in [*base.iterdir(),ROOT/'postmarketos/main/phoc']:
 apk=(folder/'APKBUILD').read_text()
 version=re.search(r'^pkgver=(.*)$',apk,re.M)[1]+'-r'+re.search(r'^pkgrel=(.*)$',apk,re.M)[1]
 assert profile['packages'][folder.name]==version,(folder,version)
out=ROOT/'out/postmarketos-package-validation-20261015';out.mkdir(exist_ok=True)
(out/'schema-source-check.json').write_text(json.dumps({'schema_passed':True,'source_sha512_passed':True,'overlay_sha256_passed':True,'source_counts':counts,'no_debug_initramfs_or_private_keys':True},indent=2)+'\n')
print('PASS: official deviceinfo schema,4 package checksums,18 source changes, integrated profile, no debug initramfs/keys')

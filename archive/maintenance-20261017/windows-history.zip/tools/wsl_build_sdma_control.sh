#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
TREE="$ROOT/linux"
OUT="$WIN/out/dpu-sdma-control-20261014"
mkdir -p "$OUT"
export PATH="$ROOT/toolchain/gcc-12-aarch64/usr/bin:$PATH"
export LD_LIBRARY_PATH="$ROOT/toolchain/gcc-12-aarch64/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu-
python3 - "$TREE" "$WIN" "$OUT" <<'PY'
from pathlib import Path
import sys,hashlib,json,difflib
tree,win,out=map(Path,sys.argv[1:])
scope=Path('drivers/gpu/drm/msm/disp/dpu1')
paths=[p['path'] for p in json.loads((win/'out/aston-display-comparison-20261014/manifest.json').read_text())['files']]
for path in paths:
 original=win/'out/aston-display-comparison-20261014/local'/path
 assert (tree/path).read_bytes()==original.read_bytes(),path
panel=tree/'drivers/gpu/drm/panel/panel-oneplus-aa536.c'
# Restore the exact already-proven generated panel source before rebuilding.
proven=win/'drivers/gpu/drm/panel/panel-oneplus-aa536-generated.c'
assert hashlib.sha256(proven.read_bytes()).hexdigest()=='b19cd65ed8c935791e2e9617372d939e1dff93284ae5fc5bcf2ed3d4c8d251f1'
panel.write_bytes(proven.read_bytes())
p=tree/scope/'catalog/dpu_9_0_sm8550.h'
before=p.read_text();after=before
for old,new,count in [('VIG_SDM845_MASK','VIG_SDM845_MASK_SDMA',4),('DMA_CURSOR_SDM845_MASK','DMA_CURSOR_SDM845_MASK_SDMA',2),('DMA_SDM845_MASK','DMA_SDM845_MASK_SDMA',4)]:
 assert after.count('.features = '+old+',')==count
 after=after.replace('.features = '+old+',','.features = '+new+',')
assert after.count('_SDMA')==10
(out/'catalog.before.h').write_text(before)
(out/'catalog.sdma.h').write_text(after)
(out/'sdma-only.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(p),tofile=str(p))))
p.write_text(after)
PY
cmp "$TREE/.config" "$WIN/out/display-generator-avb-retest-20261014/kernel.config"
cd "$TREE"
make -j12 Image > "$OUT/build.log" 2>&1
cp arch/arm64/boot/Image System.map .config "$OUT/"
cmp .config "$WIN/out/display-generator-avb-retest-20261014/kernel.config"
echo 'PASS: SDMA masks only changed; generated panel and existing configuration preserved'

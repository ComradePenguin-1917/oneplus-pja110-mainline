#!/bin/bash
# Collect the build artifacts into one place for packing.
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
TREE="$ROOT/linux"
OUT="$ROOT/out"
mkdir -p "$OUT"

cp "$TREE/arch/arm64/boot/Image"                          "$OUT/Image"
cp "$TREE/arch/arm64/boot/Image.gz"                       "$OUT/Image.gz"
cp "$TREE/arch/arm64/boot/dts/qcom/sm8550-oneplus-xigua.dtb"      "$OUT/"
cp "$TREE/arch/arm64/boot/dts/qcom/sm8550-oneplus-xigua-16G.dtb"  "$OUT/"
cp "$TREE/System.map"                                     "$OUT/System.map" 2>/dev/null || true
cp "$TREE/.config"                                        "$OUT/config-6.14-xigua" 2>/dev/null || true

echo "=== $OUT ==="
ls -l "$OUT"

echo
echo "=== kernel release ==="
grep -m1 '' "$TREE/include/config/kernel.release" 2>/dev/null || true
cat "$TREE/include/config/kernel.release" 2>/dev/null || true

echo
echo "=== sha256 (for the record) ==="
sha256sum "$OUT"/Image "$OUT"/Image.gz "$OUT"/*.dtb 2>/dev/null

#!/usr/bin/env python3
"""Where is the debug UART on THIS device, and is there any way to reach it
WITHOUT opening the phone?

Established facts (from this project's own dumps):
  * the vendor's own cmdline uses console=ttyMSN0 etc., and the vendor tree has
    aliases/serial0 -> .../qup_uart@a9c000, which matches upstream uart7
  * our DTB already sets stdout-path = "serial0:115200n8" -> serial@a9c000
  * so the SoC-side console is uart7 at 0xa9c000

The real question is the PHYSICAL layer. Options, cheapest first:

  1. USB-C SBU / debug accessory mode
     Some Qualcomm phones expose UART on the Type-C SBU1/SBU2 pins, reachable
     with a passive "debug cable" and NO disassembly. Worth checking whether the
     pinmux for a9c000 is routed there.

  2. Test pads on the mainboard -> needs opening the back cover.

  3. Headphone jack trick (older OnePlus: UART over the 3.5 mm jack).
     The Ace 2 Pro has NO headphone jack, so this is out.

  4. Use the USB port's own pins in a special boot mode.

So: scan the vendor device tree for every UART/Geni port, its pin configuration,
and any hint of routing to external pins. A port whose TX/RX are muxed to the
Type-C SBU pins is what would let us skip disassembly.
"""
import os
import re
import struct
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
sys.path.insert(0, os.path.join(WS, 'tools'))
from fdt import FDT


def dec(v):
    return v.rstrip(b'\0').decode('ascii', 'replace')


def regs(v):
    return [struct.unpack_from('>QQ', v, i) for i in range(0, len(v) - 15, 16)]


live = FDT(open(os.path.join(WS, 'live-from-device.dtb'), 'rb').read()).nodes()
ours = FDT(open(os.path.join(WS, 'dts', 'sm8550-oneplus-xigua-16G.dtb'), 'rb').read()).nodes()

print('=' * 78)
print('1) EVERY SERIAL/UART PORT IN THE VENDOR TREE, WITH ITS PINS')
print('=' * 78)
ports = []
for p in sorted(live):
    leaf = p.split('/')[-1]
    if 'uart' in leaf.lower() or 'serial@' in leaf.lower():
        if p.count('/') > 7:
            continue
        props = live[p]
        r = props.get('reg')
        addr = (regs(r)[0][0] if (r and regs(r)) else None)
        st = props.get('status')
        ports.append((p, leaf, addr, dec(st) if st else '(none)'))
for p, leaf, addr, st in ports:
    print('  %-58s reg=%s status=%s' % (p[:58], ('0x%x' % addr) if addr else '-', st))

print()
print('=' * 78)
print('2) WHICH PORT IS THE CONSOLE?')
print('=' * 78)
al = live.get('/aliases', {})
for k in sorted(al):
    if 'serial' in k or 'uart' in k:
        print('  %-14s -> %s' % (k, dec(al[k])))
print()
print('  so the console UART is the one at 0xa9c000 (upstream calls it uart7)')

print()
print('=' * 78)
print('3) THE PIN CONFIGURATION FOR THAT PORT (this decides if we can avoid')
print('   disassembly: if TX/RX route to Type-C SBU pins, a debug cable works)')
print('=' * 78)
# find pinctrl states referencing uart7 / qup_uart7 / the a9c000 port
pat = re.compile(r'uart7|qup_uart7|qup1_se7|qup_uart3|a9c000', re.I)
hits = [p for p in live if pat.search(p)]
print('  pinctrl/related nodes mentioning uart7:')
for p in sorted(hits)[:20]:
    props = live[p]
    print('    %s' % p)
    for k in sorted(props):
        v = props[k]
        if k in ('pins', 'function', 'drive-strength', 'bias-pull-up',
                 'bias-pull-down', 'bias-disable'):
            if len(v) <= 40:
                print('        %-16s %r' % (k, dec(v)))
            else:
                print('        %-16s %r' % (k, dec(v)[:60]))

print()
print('=' * 78)
print('4) ARE THERE SBU / TYPEC / DEBUG-CABLE RELATED NODES?')
print('=' * 78)
for pat2 in ('sbu', 'typec', 'usb-connector', 'extcon', 'debug-uart', 'uart_debug'):
    h = [p for p in live if pat2 in p.lower()]
    print('  %-16s %d node(s)%s' % (pat2, len(h), ('  e.g. ' + h[0][:60]) if h else ''))

print()
print('=' * 78)
print('5) WHAT OUR DTB CURRENTLY SAYS ABOUT THE CONSOLE')
print('=' * 78)
print('  /chosen/stdout-path: %r' % dec(ours.get('/chosen', {}).get('stdout-path', b'none')))
for p in sorted(ours):
    if 'serial@a9c000' in p:
        props = ours[p]
        print('  %s' % p)
        for k in sorted(props):
            v = props[k]
            if len(v) <= 40:
                print('      %-16s %r' % (k, dec(v)))
            elif k == 'reg':
                print('      %-16s %s' % (k, ' '.join('0x%x+0x%x' % x for x in regs(v))))
            else:
                print('      %-16s <%d bytes>' % (k, len(v)))

print()
print('=' * 78)
print('6) ALSO CHECK: does the STOCK kernel expose the console on this port?')
print('=' * 78)
print('  The stock cmdline we captured earlier:')
print('    console=ttynull loglevel=6 ...')
print('  i.e. the vendor deliberately DISABLES console output. ttynull means')
print('  "print nothing", so even if a cable were attached, the vendor build')
print('  would stay silent. Our own cmdline overrides that with ttyMSM0.')

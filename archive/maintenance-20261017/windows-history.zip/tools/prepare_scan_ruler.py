"""Reuse upstream kmscube KMS/GBM buffering; replace only its smooth draw demo."""
from pathlib import Path
import shutil
ROOT=Path(__file__).resolve().parents[1]
out=ROOT/'out/display-timing-20261014/ruler'
out.mkdir(parents=True,exist_ok=True)
src=ROOT/'out/gpu-kms-20261014/kmscube'
shutil.copytree(src,out/'kmscube',dirs_exist_ok=True,ignore=shutil.ignore_patterns('.git'))
original=(src/'cube-smooth.c').read_text()
license=original[:original.index('#include')]
shader=r'''
precision highp float;
uniform vec2 size;
uniform float frame;
uniform float mode;
float digit(vec2 p, int d) {
  if(p.x<0.0 || p.x>=3.0 || p.y<0.0 || p.y>=5.0) return 0.0;
  int x=int(p.x),y=int(p.y); int row=0;
  if(d==0) row=(y==0||y==4)?7:5;
  if(d==1) row=2;
  if(d==2) row=(y==0||y==2||y==4)?7:(y==1?1:4);
  if(d==3) row=(y==0||y==2||y==4)?7:1;
  if(d==4) row=y<2?5:(y==2?7:1);
  if(d==5) row=(y==0||y==2||y==4)?7:(y==1?4:1);
  if(d==6) row=(y==0||y==2||y==4)?7:(y==1?4:5);
  if(d==7) row=y==0?7:1;
  if(d==8) row=(y==0||y==2||y==4)?7:5;
  if(d==9) row=(y==0||y==2||y==4)?7:(y==1?5:1);
  float div=x==0?4.0:(x==1?2.0:1.0);
  return mod(floor(float(row)/div),2.0);
}
float label(vec2 p,int n) {
  p/=8.0;
  return max(digit(p,n/100),max(digit(p-vec2(4,0),(n/10)-10*(n/100)),digit(p-vec2(8,0),n-10*(n/10))));
}
void main() {
  vec2 p=vec2(gl_FragCoord.x,size.y-gl_FragCoord.y);
  float t=frame;
  if(mode>0.5 && mode<1.5) t=floor(frame/60.0)*60.0;
  if(mode>1.5 && mode<2.5) t=90.0;
  if(mode>2.5) t=frame*60.0;
  float phase=mod(t,480.0)/240.0;
  float x=300.0+(size.x-410.0)*(1.0-abs(phase-1.0));
  vec3 c=vec3(0.08);
  if(abs(p.x-x)<40.0) c=vec3(1.0);
  if(p.x<240.0) {
    c=vec3(0.04);
    if(mod(floor(p.y),44.0)<2.0 && p.x>190.0) c=vec3(0.4);
    for(int k=0;k<5;k++) {
      int row=352+44*k;
      vec3 col=vec3(1.0,0.8,0.0);
      if(k==1) col=vec3(1,0.2,0.2);
      if(k==2) col=vec3(0.2,1,0.2);
      if(k==3) col=vec3(0.2,0.5,1);
      if(k==4) col=vec3(0,1,1);
      if(abs(p.y-float(row))<1.0) c=col;
      if(label(p-vec2(20,float(row)-42.0),row)>0.5) c=col;
    }
  }
  gl_FragColor=vec4(c,1);
}
'''
def cstring(s):
    import json
    return '\n'.join(json.dumps(line+'\n') for line in s.splitlines())
code=license+'''#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "common.h"
static struct cube cube;
static GLuint program,vbo;
static GLint frame_loc,mode_loc;
static int mode;
static const char *vs="attribute vec2 in_position; void main(){gl_Position=vec4(in_position,0,1);}";
static const char *fs=
'''+cstring(shader)+''';
static void draw(unsigned i) {
 if(mode==3) usleep(3000000);
 glUseProgram(program);
 glUniform1f(frame_loc,(float)(i%28800));
 glUniform1f(mode_loc,(float)mode);
 glDrawArrays(GL_TRIANGLE_STRIP,0,4);
}
const struct cube *init_cube_smooth(const struct egl *egl,const struct gbm *gbm) {
 (void)egl;
 if(gbm->width!=1240 || gbm->height!=2772) {fprintf(stderr,"Unexpected scanout size\\n");return NULL;}
 if(create_program(vs,fs,&program)<0)return NULL;
 GLint position=glGetAttribLocation(program,"in_position");
 glUseProgram(program);
 glViewport(0,0,gbm->width,gbm->height);
 glUniform2f(glGetUniformLocation(program,"size"),gbm->width,gbm->height);
 frame_loc=glGetUniformLocation(program,"frame");mode_loc=glGetUniformLocation(program,"mode");
 const char *v=getenv("PJA_RULER_MODE");mode=v?atoi(v):0;
 const GLfloat vertices[]={-1,-1,1,-1,-1,1,1,1};
 glGenBuffers(1,&vbo);glBindBuffer(GL_ARRAY_BUFFER,vbo);
 glBufferData(GL_ARRAY_BUFFER,sizeof(vertices),vertices,GL_STATIC_DRAW);
 glVertexAttribPointer(position,2,GL_FLOAT,GL_FALSE,0,0);glEnableVertexAttribArray(position);
 fprintf(stderr,"PJA ruler: 1240x2772, mode=%d; top-origin markers 352/396/440/484/528\\n",mode);
 cube.draw=draw;return &cube;
}
'''
(out/'kmscube/cube-smooth.c').write_text(code)
build=(ROOT/'tools/wsl_build_kmscube.sh').read_text()
build=build.replace('OUT="$WIN/out/gpu-kms-20261014"','OUT="$WIN/out/display-timing-20261014/ruler"')
build=build.replace('if [ "${1:-}" = "--readback" ]; then OUT="$WIN/out/gpu-scanout-readback-20261014"; fi','')
(out/'build.sh').write_text(build,newline='\n')
print('Prepared isolated upstream kmscube copy with scan ruler drawing only')

#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
DEPS="$ROOT/panel-generator-deps"
mkdir -p "$DEPS"
cd "$DEPS"
export PYTHONPATH="$DEPS/python"
export PATH="$DEPS/swig42/swig/data/bin:$PATH"
export SWIG_LIB="$DEPS/swig42/swig/data/share/swig/4.2.1"
export PYTHONPATH="$DEPS/swig42:$DEPS/python"
if ! python3 -c 'import libfdt' 2>/dev/null; then
    if [ ! -x swig42/bin/swig ]; then
        python3 -m pip install --target "$DEPS/swig42" swig==4.2.1 > "$WIN/out/display-generator-20261013/dependency-swig42.log" 2>&1
    fi
    swig -version > "$WIN/out/display-generator-20261013/swig-version.txt"
    python3 -m pip install --upgrade --no-cache-dir --target "$DEPS/python" pylibfdt==1.7.2.post1 > "$WIN/out/display-generator-20261013/dependency-pip-swig42.log" 2>&1
fi
python3 "$WIN/tools/run_panel_generator.py" > "$WIN/out/display-generator-20261013/generation.log" 2>&1
cat "$WIN/out/display-generator-20261013/generation.log"

"""Collect and decode the paired OEM PMIC snapshots, without writes."""
from pathlib import Path
import json, re, subprocess, time
from prepare_native_install import SSH
args = SSH[:]
args[-1] = 'penguin@172.16.42.1'
args = [x if not x.startswith('UserKnownHostsFile=') else
        'UserKnownHostsFile=out/native-install-20261017/known_hosts' for x in args]
cmd = '''cat /home/penguin/charger-watchdog-probe/pair-result.log
echo LIVE_STATE
cat /proc/sys/kernel/random/boot_id /proc/uptime
ls /sys/module/qcom_battmgr/parameters
cat /sys/class/power_supply/bq28z610-0/uevent
cat /sys/class/power_supply/qcom-battmgr-usb/uevent
'''
p = subprocess.run(args + [cmd], capture_output=True, timeout=30)
out = Path('out/native-install-20261017/charger-watchdog-probe')
dest = out / ('pair-live-' + time.strftime('%Y%m%d-%H%M%S') + '.txt')
dest.write_bytes(p.stdout + p.stderr)
print(p.stdout.decode(errors='replace')); print(p.stderr.decode(errors='replace'))
p.check_returncode()
matches = re.findall(r'OEM_SNAPSHOT_RESULT=0\s+512\s+([0-9,]+)', p.stdout.decode())
snapshots = []
for match in matches:
    values = list(map(int, match.split(',')))
    assert len(values) == 128
    regs = dict(zip(values[15:121:2], values[16:122:2]))
    snapshots.append(regs)
report = {'capture': str(dest), 'completed': b'WATCHDOG_PAIR_COMPLETE' in p.stdout,
          'restorations': p.stdout.count(b'READONLY_MODULE_RESTORED'),
          'snapshots': [{hex(k):hex(v) for k,v in s.items()} for s in snapshots]}
if len(snapshots) == 2:
    report['changes'] = {hex(k): [snapshots[0][k], snapshots[1][k]]
                         for k in snapshots[0] if snapshots[0][k] != snapshots[1][k]}
(dest.with_suffix('.json')).write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))

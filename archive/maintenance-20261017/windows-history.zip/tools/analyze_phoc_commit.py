"""Correlate preserved plane-busy messages with nearby DRM trace events."""
from pathlib import Path
import re
import json

root=Path(__file__).resolve().parents[1]
out=root/'out/phoc-commit-20261015'
events=[]
for line in (out/'trace.txt').read_text(encoding='utf-8').splitlines():
    m=re.search(r'\s(\d+\.\d+): (drm_vblank_event_delivered|msm_atomic_commit_tail_finish): (.*)',line)
    if m:
        events.append((float(m[1]),m[2],m[3]))
rows=[]
# printk uses its own timestamp clock; tracefs was configured as mono.
# These are nearby-event hints, not proof of sub-millisecond ordering.
for line in (out/'kmsg-controlled.log').read_text(encoding='utf-8').splitlines():
    m=re.match(r'\d+,\d+,(\d+),.*;.*\[PLANE:(\d+):([^]]+)\] busy with a previous commit',line)
    if not m:
        continue
    t=int(m[1])/1e6
    delivered=[e for e in events if e[1]=='drm_vblank_event_delivered' and e[0]<=t]
    finishes=[e for e in events if e[1]=='msm_atomic_commit_tail_finish' and e[0]>=t]
    prev=max(delivered,default=None)
    nxt=min(finishes,default=None)
    rows.append({'busy_uptime':t,'plane_id':int(m[2]),'plane_name':m[3],
                 'clock_caveat':'printk and tracefs mono timestamps are not calibrated',
                 'previous_flip_event':prev,'next_commit_tail_finish':nxt,
                 'milliseconds_after_flip_event':round((t-prev[0])*1000,3) if prev else None,
                 'milliseconds_until_tail_finish':round((nxt[0]-t)*1000,3) if nxt else None})
(out/'correlation.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
print(json.dumps(rows,indent=2))

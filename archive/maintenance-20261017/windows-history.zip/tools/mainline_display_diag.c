// SPDX-License-Identifier: GPL-2.0-only
/* Read actual DCS responses without attaching a second panel driver. */
#include <linux/module.h>
#include <linux/of.h>
#include <drm/drm_mipi_dsi.h>
static int __init display_diag_init(void)
{
	struct device_node *node;
	struct mipi_dsi_device *dsi;
	const u8 cmds[] = { 0x04, 0x0a, 0x0c, 0x0f, 0x52, 0xda, 0xdb, 0xdc };
	const u8 lengths[] = { 3, 1, 1, 1, 2, 1, 1, 1 };
	u8 data[3];
	ssize_t ret;
	int i;
	node = of_find_compatible_node(NULL, NULL, "oneplus,aa536-p-3-a0001");
	if (!node)
		return -ENODEV;
	dsi = of_find_mipi_dsi_device_by_node(node);
	of_node_put(node);
	if (!dsi)
		return -EPROBE_DEFER;
	ret = mipi_dsi_set_maximum_return_packet_size(dsi, 3);
	pr_info("PJA_DISP_DIAG max_return ret=%zd\n", ret);
	for (i = 0; i < ARRAY_SIZE(cmds); i++) {
		memset(data, 0, sizeof(data));
		ret = mipi_dsi_dcs_read(dsi, cmds[i], data, lengths[i]);
		pr_info("PJA_DISP_DIAG cmd=%02x len=%u ret=%zd data=%*ph\n",
			cmds[i], lengths[i], ret, lengths[i], data);
	}
	put_device(&dsi->dev);
	return 0;
}
static void __exit display_diag_exit(void) { }
module_init(display_diag_init);
module_exit(display_diag_exit);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("PJA110 read-only DCS link diagnostics");

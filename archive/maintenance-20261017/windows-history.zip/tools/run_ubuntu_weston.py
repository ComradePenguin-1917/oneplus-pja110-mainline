"""Bounded DRM Weston test inside RAM Ubuntu, with debug SSH retained."""
import json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'out/ubuntu-ram-20261014'
KEYS=ROOT/'out/usb-ncm-20261013/ssh'
SSH=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(KEYS/'client_key_host'),
 '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
 '-o',f'UserKnownHostsFile={KEYS/"known_hosts"}','-o','ConnectTimeout=5','root@169.254.42.1']
script='''set -e
echo 1024 > /sys/class/backlight/ae94000.dsi.0/brightness
chroot /tmp/ubuntu-ram /usr/bin/env XDG_RUNTIME_DIR=/run/user/0 LIBSEAT_BACKEND=seatd SEATD_VTBOUND=0 MESA_LOADER_DRIVER_OVERRIDE=msm /usr/bin/seatd-launch -- /usr/bin/weston --backend=drm-backend.so --config=/etc/weston/weston.ini --socket=wayland-0 --idle-time=0 --log=/run/weston.log
'''
# Start detached from this SSH command; keep all state in RAM.
if '--linear' in sys.argv:
 script=script.replace('MESA_LOADER_DRIVER_OVERRIDE=msm','MESA_LOADER_DRIVER_OVERRIDE=msm FD_MESA_DEBUG=noubwc,notile')
if '--compose' in sys.argv:
 script=script.replace('LIBSEAT_BACKEND=seatd','LIBSEAT_BACKEND=seatd WESTON_FORCE_RENDERER=1')
if '--legacy' in sys.argv:
 script=script.replace('LIBSEAT_BACKEND=seatd','LIBSEAT_BACKEND=seatd WESTON_DISABLE_ATOMIC=1')
if '--pixman' in sys.argv:
 script=script.replace('/usr/bin/weston --backend','/usr/bin/weston --renderer=pixman --backend')
if '--fullscreen-shell' in sys.argv:
 script=script.replace('--idle-time=0','--shell=fullscreen-shell.so --idle-time=0')
if '--capture' in sys.argv:
 script=script.replace('--backend=drm-backend.so','--debug --backend=drm-backend.so')
launch='nohup sh -c '+"'"+script.replace("'","'\\''")+"'"+' > /tmp/ubuntu-weston-launch.txt 2>&1 < /dev/null & echo $!'
p=subprocess.run(SSH+[launch],capture_output=True,timeout=15);p.check_returncode()
(OUT/'weston-launch.txt').write_bytes(p.stdout+p.stderr)
print('Weston launch requested; verify log before assuming display works')

"""Read-only audit of Ubuntu RAM userspace and persistent-install prerequisites."""
import subprocess,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
out=ROOT/'out/ubuntu-install-audit-20261014';out.mkdir(exist_ok=True)
keys=ROOT/'out/usb-ncm-20261013/ssh'
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(keys/'client_key_host'),
 '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
 '-o',f'UserKnownHostsFile={keys/"known_hosts"}','-o','ConnectTimeout=5','root@169.254.42.1']
commands={
 'boot-and-storage.txt':'uname -a; readlink /proc/1/exe; cat /proc/cmdline; cat /proc/mounts; df -h; cat /proc/partitions; for f in /sys/class/block/sd*/uevent; do cat "$f"; echo END; done',
 'ubuntu-userspace.txt':'''set -e
r=/tmp/ubuntu-ram
test -e "$r/.pja-ready"
chroot "$r" /bin/cat /etc/os-release
chroot "$r" /usr/bin/dpkg --audit
chroot "$r" /usr/bin/dpkg-query -W -f='${binary:Package}\\t${db:Status-Abbrev}\\n'
chroot "$r" /usr/bin/systemctl is-system-running || true
test -x "$r/usr/lib/systemd/systemd"
ls -l "$r/sbin/init" || true
chroot "$r" /usr/bin/weston --version
ps
''',
 'rootfs-and-filesystems.txt':'cat /proc/filesystems; ls -ld /tmp/ubuntu-ram /tmp/ubuntu-ram/usr/lib/systemd/systemd /tmp/ubuntu-ram/var/lib/dpkg/status; du -sk /tmp/ubuntu-ram; blkid',
}
for name,cmd in commands.items():
 p=subprocess.run(ssh+[cmd],capture_output=True,timeout=45)
 (out/name).write_bytes(p.stdout+p.stderr)
 if p.returncode:raise RuntimeError(f'{name}: return code {p.returncode}')
manifest=json.loads((ROOT/'out/ubuntu-ram-20261014/manifest.json').read_text())
(out/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Saved read-only Ubuntu package/PID1/storage audit; no persistent installation or partition changes')

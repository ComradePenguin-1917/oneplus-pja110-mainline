"""Reuse pinned Ubuntu package cache and fetch only missing boot-chain packages."""
import gzip,hashlib,json,re,tarfile,urllib.request,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
cache=ROOT/'out/ubuntu-ram-20261014'
out=ROOT/'out/ubuntu-systemd-20261014';out.mkdir(exist_ok=True)
debs=out/'debs';debs.mkdir(exist_ok=True)
m=json.loads((cache/'manifest.json').read_text())
packages={}
for pocket in ('noble','noble-updates','noble-security'):
 for component in ('main','universe'):
  for rec in gzip.decompress((cache/(pocket+'-'+component+'-Packages.gz')).read_bytes()).decode().split('\n\n'):
   props=dict(line.split(': ',1) for line in rec.splitlines() if ': ' in line and not line[0].isspace())
   if 'Package' in props:packages[props['Package']]=props
selected={p['name']:p for p in m['packages']}
pending=['systemd-sysv','dbus','dbus-user-session','libpam-systemd','kmod','iproute2']
virtual={'debconf-2.0':'debconf','default-dbus-system-bus':'dbus','awk':'mawk','logind':'libpam-systemd'}
while pending:
 name=pending.pop()
 if name in selected:continue
 p=packages[name]
 selected[name]=dict(name=name,version=p['Version'],architecture=p['Architecture'],file=Path(p['Filename']).name,sha256=p['SHA256'],url='https://ports.ubuntu.com/ubuntu-ports/'+p['Filename'])
 for dep in (p.get('Pre-Depends','')+','+p.get('Depends','')).split(','):
  choices=[re.split(r'\s|:',c.strip())[0] for c in dep.split('|') if c.strip()]
  if not choices:continue
  choice=next((c for c in choices if c in packages),None) or next((virtual[c] for c in choices if c in virtual),None)
  if not choice:raise RuntimeError('Unresolved dependency '+dep)
  pending.append(choice)
records=[]
for name,p in sorted(selected.items()):
 target=debs/p['file'];existing=cache/'debs'/p['file']
 if not target.exists():
  if existing.exists():shutil.copyfile(existing,target)
  else:
   print('Downloading boot package',name,p['version'],flush=True)
   with urllib.request.urlopen(p['url'],timeout=90) as r,target.open('wb') as f:shutil.copyfileobj(r,f)
 assert hashlib.sha256(target.read_bytes()).hexdigest()==p['sha256']
 records.append(p)
archive=out/'packages.tar'
with tarfile.open(archive,'w') as tar:
 for p in records:tar.add(debs/p['file'],arcname=p['file'],recursive=False)
m.update(packages=records,package_archive=archive.name,package_archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),package_archive_bytes=archive.stat().st_size)
(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print(f'PASS: {len(records)} checksummed Ubuntu packages; package tar {archive.stat().st_size//1048576}MiB')

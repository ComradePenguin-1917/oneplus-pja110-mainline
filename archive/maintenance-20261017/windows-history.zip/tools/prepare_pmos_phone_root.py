"""Extract only the verified integrated root partition, without root or mounts."""
from pathlib import Path
import gzip
import hashlib
import json
from pmos_image_info import inspect_image

out = Path('/mnt/h/workspace/PJA110-Mainline/out/postmarketos-integration-20261016/phone-systemd')
out.mkdir(parents=True, exist_ok=True)
image = Path('/tmp/postmarketOS-export/oneplus-xigua.img')
info = inspect_image(image)
assert info['root_uuid'] == 'd4fe1401-195a-4a1a-9715-6b090bc2175f', info
p = next(p for p in info['partitions'] if p['label'] == 'pmOS_root')
target = out / 'rootfs.ext4.gz'
manifest = out / 'root-artifact.json'
if target.exists() and manifest.exists():
    print('Existing root artifact:', manifest)
    raise SystemExit(0)
assert not target.exists(), 'Incomplete artifact exists; inspect before replacing'
digest = hashlib.sha256()
length = p['sectors'] * info['sector_size']
with image.open('rb') as source, gzip.open(target, 'wb', compresslevel=1) as dest:
    source.seek(p['start'] * info['sector_size'])
    remaining = length
    while remaining:
        block = source.read(min(4*1024*1024, remaining))
        assert block
        digest.update(block)
        dest.write(block)
        remaining -= len(block)
expected = json.loads((out.parent / 'image-verification.json').read_text())
assert digest.hexdigest() == expected['root_partition_sha256'], 'Source partition changed since verification'
# Record exact partition provenance; the input UUID matches the archived build.
record = {'source_root_uuid': info['root_uuid'], 'raw_bytes': length,
          'raw_sha256': digest.hexdigest(), 'artifact': target.name,
          'compressed_bytes': target.stat().st_size,
          'compressed_sha256': hashlib.file_digest(target.open('rb'), 'sha256').hexdigest()
          if hasattr(hashlib, 'file_digest') else hashlib.sha256(target.read_bytes()).hexdigest()}
manifest.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))

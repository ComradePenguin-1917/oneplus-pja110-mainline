#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
TREE="$ROOT/linux"
WIN=/mnt/h/workspace/PJA110-Mainline
OUT="$WIN/out/usb-loopback-20261013"
BUILD="$ROOT/usb-loopback-module-20261013"
PREFIX="$ROOT/toolchain/gcc-12-aarch64"
export PATH="$PREFIX/usr/bin:$PATH"
export LD_LIBRARY_PATH="$PREFIX/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu-
mkdir -p "$OUT/module" "$BUILD"
cmp "$TREE/.config" "$WIN/out/user-init-usb-serial-diag-20261013/kernel.config"
sha256sum "$TREE/.config" "$TREE/arch/arm64/boot/Image" > "$OUT/module/build-tree-before.sha256"
cp "$TREE/drivers/usb/gadget/function/"{f_loopback.c,f_sourcesink.c,g_zero.h} "$BUILD/"
cp "$TREE/drivers/usb/gadget/function/f_loopback.c" "$OUT/module/f_loopback.c.upstream"
python3 - "$BUILD" <<'PY'
from pathlib import Path
import sys
build=Path(sys.argv[1])
p=build/'f_loopback.c'
s=p.read_text()
anchor='\tunsigned                qlen;'
assert s.count(anchor)==1
s=s.replace(anchor, '''\t/* Windows binding metadata only; upstream loopback data path unchanged. */
\tstruct usb_os_desc winusb_desc;
\tstruct usb_os_desc_ext_prop winusb_guid;
\tstruct usb_os_desc_table winusb_table;
''' + anchor)
anchor='\tloopback_intf.bInterfaceNumber = id;'
assert s.count(anchor)==1
s=s.replace(anchor, anchor + '''
\tif (cdev->use_os_string) {
\t\tloop->winusb_desc.ext_compat_id = "WINUSB\\0\\0\\0\\0\\0\\0\\0\\0\\0";
\t\tINIT_LIST_HEAD(&loop->winusb_desc.ext_prop);
\t\tloop->winusb_guid.type = 1; /* REG_SZ, Microsoft OS 1.0 */
\t\tloop->winusb_guid.name = "DeviceInterfaceGUID";
\t\tloop->winusb_guid.name_len = 40;
\t\tloop->winusb_guid.data = "{7E7804A3-47C8-4DDD-9DC9-DA155482C122}";
\t\tloop->winusb_guid.data_len = 78;
\t\tlist_add_tail(&loop->winusb_guid.entry, &loop->winusb_desc.ext_prop);
\t\tloop->winusb_desc.ext_prop_count = 1;
\t\tloop->winusb_desc.ext_prop_len = 132;
\t\tloop->winusb_table.if_id = id;
\t\tloop->winusb_table.os_desc = &loop->winusb_desc;
\t\tf->os_desc_table = &loop->winusb_table;
\t\tf->os_desc_n = 1;
\t}
''')
p.write_text(s)
(build/'Makefile').write_text('obj-m := usb_f_ss_lb.o\nusb_f_ss_lb-y := f_loopback.o f_sourcesink.o\n')
PY
make -C "$TREE" -j4 modules_prepare 2>&1 | tee "$OUT/module/prepare.log"
make -C "$TREE" M="$BUILD" KBUILD_EXTRA_SYMBOLS="$TREE/vmlinux.symvers" -j4 modules 2>&1 | tee "$OUT/module/build.log"
cp "$BUILD/usb_f_ss_lb.ko" "$OUT/module/"
cp "$BUILD/f_loopback.c" "$OUT/module/f_loopback.c.winusb"
modinfo "$BUILD/usb_f_ss_lb.ko" | tee "$OUT/module/modinfo.txt"
sha256sum -c "$OUT/module/build-tree-before.sha256"
echo 'PASS: external Loopback module built; kernel Image and config unchanged'

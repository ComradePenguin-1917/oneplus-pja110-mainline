#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
TREE="$ROOT/linux"
OUT="$WIN/out/drm-shutdown-20261014/kernel"
mkdir -p "$OUT"
export PATH="$ROOT/toolchain/gcc-12-aarch64/usr/bin:$PATH"
export LD_LIBRARY_PATH="$ROOT/toolchain/gcc-12-aarch64/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu-
cmp "$TREE/.config" "$WIN/out/display-budget-20261014/.config"
cmp "$TREE/drivers/gpu/drm/msm/disp/dpu1/dpu_core_perf.c" "$WIN/out/display-budget-20261014/dpu_core_perf.after.c"
python3 "$WIN/tools/patch_drm_shutdown.py"
cd "$TREE"
make -j8 Image > "$OUT/build.log" 2>&1
cp arch/arm64/boot/Image System.map .config "$OUT/"
echo 'PASS: shutdown ordering kernel built; performance budget and configuration retained'

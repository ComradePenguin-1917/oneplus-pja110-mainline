"""Validate saved NCM, SSH, host-driver and log evidence."""
import hashlib
import json
import struct
from pathlib import Path

root=Path(__file__).resolve().parents[1]
out=root/'out/usb-ncm-20261013'
load=lambda path: json.loads((out/path).read_text(encoding='utf-8-sig'))
devices=load('windows-devices.json')
ncm=next(x for x in devices if 'PID_010A&MI_02' in x['InstanceId'])
properties={x['KeyName']:x['Data'] for x in ncm['Properties']}
assert ncm['Status']=='OK'
assert properties['DEVPKEY_Device_Service']=='UsbNcm'
assert properties['DEVPKEY_Device_ProblemCode']==0
assert properties['DEVPKEY_Device_DriverInfPath']=='usbncm.inf'
network=load('transfer-test/result.json')
assert network['all_passed'] and network['completed_checks']==40
for x in network['checks']:
    assert x['passed']
    if x['direction']=='phone-to-host':
        assert x['expected_sha256']==x['actual_sha256']
    else:
        assert x['expected_sha256']==x['phone_sha256']==x['readback_sha256']
        assert x['bytes']==x['readback_bytes']
ssh=load('ssh/ssh-result.json')
assert ssh['all_passed'] and ssh['identity_verified'] and len(ssh['transfers'])==3
assert '/dev/pts/' in (out/'ssh/pty-shell.txt').read_text()
capture=load('after-test/capture-result.json')
log=(out/'after-test/mainline-dmesg.txt').read_bytes()
assert capture['sha256_verified'] and hashlib.sha256(log).hexdigest()==capture['sha256']
assert capture['single_ssh_connection_30_second_stream']
binary=(out/'ssh/dropbearmulti').read_bytes()
assert binary[:4]==b'\x7fELF' and struct.unpack_from('<H',binary,18)[0]==183
offset=struct.unpack_from('<Q',binary,32)[0]
size,count=struct.unpack_from('<HH',binary,54)
assert all(struct.unpack_from('<I',binary,offset+i*size)[0]!=3 for i in range(count)), 'Dynamic ELF interpreter present'
state=(out/'after-test/final-state.txt').read_text()
assert 'configured' in state and 'high-speed' in state
lines=state.splitlines()
stats={name:int(lines[lines.index(name)+1]) for name in ('rx_errors','tx_errors','rx_dropped','tx_dropped')}
result=dict(ncm_network_verified=True, ssh_root_shell_verified=True, ssh_pty_verified=True,
    kernel='6.14.0-sm8550-xigua-r1 #8', distribution=None, rootfs='BusyBox 1.36.1 custom initramfs',
    phone_address='169.254.42.1',host_address=network['source_address'],serial_port='COM15',
    ncm_driver=properties, network_checks=network['completed_checks'], ssh_4mib_roundtrips=3,
    phone_download_bytes=sum(x['bytes'] for x in network['checks'] if x['direction']=='phone-to-host'),
    phone_upload_and_readback_bytes=sum(x['bytes'] for x in network['checks'] if x['direction']!='phone-to-host'),
    network_interface_counters=stats, log=capture, ssh_server_sha256=hashlib.sha256(binary).hexdigest(),
    phone_left_running_mainline=True, partition_writes_in_this_experiment=False,
    runtime_configuration=True, ssh_password_authentication_compiled_out=True,
    temporary_transfer_services_stopped=True,
    limitations=['Network and SSH state is in RAM and does not survive reboot',
                 'Host link-local address can change after re-enumeration',
                 'Short functional/transfer verification, not full PM or reconnect qualification',
                 'rx_dropped is nonzero; causes have not been attributed by this experiment'])
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

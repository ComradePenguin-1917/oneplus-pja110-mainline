from pathlib import Path
import subprocess, hashlib
from prepare_native_install import SSH
root=Path(__file__).resolve().parents[1]
def run(cmd,data=None):
    p=subprocess.run(SSH+[cmd],input=data,capture_output=True,timeout=45)
    print(p.stderr.decode(errors='replace'))
    p.check_returncode()
    return p.stdout
for local,name in [('charger_early_capture.sh','capture.sh'),('pja110-charger-capture.service','capture.service')]:
    data=(root/'tools'/local).read_bytes().replace(b'\r\n',b'\n')
    actual=run('cat > /tmp/'+name+' && sha256sum /tmp/'+name,data).decode().split()[0]
    assert actual==hashlib.sha256(data).hexdigest()
cmd='''set -eu
test -z "$(losetup -a)"
test "$(sed -n 's/^PARTNAME=//p' /sys/class/block/sda14/uevent)" = userdata
mkdir -p /tmp/a-diag
losetup -o 511705088 /dev/loop0 /dev/sda14
trap 'umount /tmp/a-diag 2>/dev/null || true; losetup -d /dev/loop0' EXIT
mount -t ext4 /dev/loop0 /tmp/a-diag
test -f /tmp/a-diag/usr/lib/modules-load.d/00-device-oneplus-xigua.conf
mkdir -p /tmp/a-diag/usr/local/libexec /tmp/a-diag/etc/systemd/system/multi-user.target.wants
cp /tmp/capture.sh /tmp/a-diag/usr/local/libexec/pja110-charger-capture
chmod 755 /tmp/a-diag/usr/local/libexec/pja110-charger-capture
cp /tmp/capture.service /tmp/a-diag/etc/systemd/system/pja110-charger-capture.service
ln -sf ../pja110-charger-capture.service /tmp/a-diag/etc/systemd/system/multi-user.target.wants/pja110-charger-capture.service
sha256sum /tmp/a-diag/usr/local/libexec/pja110-charger-capture /tmp/a-diag/etc/systemd/system/pja110-charger-capture.service
sync
'''
result=run(cmd)
(root/'out/native-install-20261017/early-capture-install.txt').write_bytes(result)
print(result.decode())
print('PASS: capture service installed; root unmounted; no reboot')

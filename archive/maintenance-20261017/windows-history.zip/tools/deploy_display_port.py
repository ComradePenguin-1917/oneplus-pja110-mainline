"""Flash only display boot/vendor_boot on B, retain fixed SSH and record results."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/display-port-20261013'
FIXED=ROOT/'out/debug-ncm-fixed-20261013'
BASE=ROOT/'out/user-init-usb-serial-diag-20261013'
KEYS=ROOT/'out/usb-ncm-20261013/ssh'
SSH=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(KEYS/'client_key_host'),
     '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
     '-o',f'UserKnownHostsFile={KEYS/"known_hosts"}','-o','ConnectTimeout=5',
     '-o','ServerAliveInterval=5','root@169.254.42.1']
FB=['C:/platform-tools/fastboot.exe','-s','bc7a542e']
PARTS={'boot_a':'sde13','vendor_boot_a':'sde24','init_boot_a':'sde32','dtbo_a':'sde17',
       'boot_b':'sde45','vendor_boot_b':'sde56','init_boot_b':'sde63','dtbo_b':'sde49'}
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def ssh(cmd):
    p=subprocess.run(SSH+[cmd],capture_output=True,timeout=120)
    if p.returncode:
        (OUT/'last-ssh-error.txt').write_bytes(p.stderr)
        raise RuntimeError(p.stderr.decode(errors='replace'))
    return p.stdout
def hashes():
    result={}
    for label,device in PARTS.items():
        assert ssh(f"grep '^PARTNAME=' /sys/class/block/{device}/uevent").decode().strip()=='PARTNAME='+label
        result[label]=ssh(f'sha256sum /dev/{device}').decode().split()[0]
    return result
def fb(args):
    p=subprocess.run(FB+args,capture_output=True,timeout=90)
    with (OUT/'fastboot.log').open('ab') as log:log.write(('COMMAND '+' '.join(args)+'\n').encode()+p.stdout+p.stderr)
    p.check_returncode();print((p.stdout+p.stderr).decode(errors='replace'),flush=True)
    return (p.stdout+p.stderr).decode(errors='replace')
mode=sys.argv[1]
if mode=='preflight':
    assert not (OUT/'device-before.json').exists(),'preserve evidence'
    before=hashes()
    for p in PARTS:
        if p.endswith('_a'):assert before[p]==digest(ROOT/'backup'/f'{p}.img'),p
    assert before['vendor_boot_b']==digest(BASE/'vendor_boot_b-xigua-r1.img')
    assert before['init_boot_b']==digest(FIXED/'init_boot_b-xigua-r1.img')
    assert before['dtbo_b']==digest(BASE/'dtbo_b-avb-noop.img')
    assert ssh(f"head -c {(FIXED/'boot-xigua-r1.img').stat().st_size} /dev/sde45 | sha256sum").decode().split()[0]==digest(FIXED/'boot-xigua-r1.img')
    (OUT/'device-before.json').write_text(json.dumps(before,indent=2)+'\n')
    (OUT/'device-before.txt').write_bytes(ssh('uname -a; id; cat /proc/uptime; cat /proc/cmdline'))
    print('PASS: fixed SSH baseline and all A/B images verified')
elif mode=='flash':
    assert (OUT/'device-before.json').exists()
    manifest=json.loads((OUT/'manifest.json').read_text())
    assert manifest['fixed_ncm_initramfs_unchanged'] and manifest['usb_ufs_memory_unchanged']
    assert (OUT/'kernel.config').read_bytes()==(FIXED/'kernel.config').read_bytes()
    assert b'QEMU debug userspace validated' in (OUT/'qemu-console.txt').read_bytes()
    assert json.loads((OUT/'dsc-rc-comparison.json').read_text())['all_15_rc_ranges_match']
    for name,info in manifest['files'].items():assert digest(OUT/name)==info['sha256'],name
    assert 'current-slot: b' in fb(['getvar','current-slot'])
    assert 'unlocked: yes' in fb(['getvar','unlocked'])
    assert 'slot-successful:a: yes' in fb(['getvar','slot-successful:a'])
    for part,name in [('boot_b','boot-xigua-r1.img'),('vendor_boot_b','vendor_boot_b-xigua-r1.img')]:
        if part=='vendor_boot_b' and (OUT/'device-after.json').exists():
            recorded=json.loads((OUT/'device-after.json').read_text())
            if recorded[part]==digest(OUT/name):
                print('Skipping unchanged vendor_boot_b',flush=True)
                continue
        fb(['flash',part,str(OUT/name)])
    fb(['set_active','b']);fb(['reboot'])
    (OUT/'flashed.txt').write_text('display boot_b + vendor_boot_b, retain fixed SSH init_boot_b\n')
elif mode=='capture':
    assert (OUT/'flashed.txt').exists()
    identity=ssh('uname -a; id; cat /proc/uptime; cat /sys/class/udc/*/state; ls -l /sys/class/drm; ls -l /dev/dri /dev/fb* 2>/dev/null; true')
    (OUT/'device-after.txt').write_bytes(identity)
    assert b'uid=0(root)'in identity and b'configured'in identity
    ssh('mount -t debugfs none /sys/kernel/debug 2>/dev/null; true')
    (OUT/'mainline-dmesg.txt').write_bytes(ssh('dmesg'))
    (OUT/'display-state.txt').write_bytes(ssh('cat /sys/kernel/debug/devices_deferred; cat /sys/kernel/debug/gpio; for f in /sys/class/drm/card*-*/status /sys/class/drm/card*-*/modes; do echo "$f"; cat "$f"; done; for f in /sys/class/backlight/*/brightness; do echo "$f"; cat "$f"; done; true'))
    (OUT/'live-after.dtb').write_bytes(ssh('cat /sys/firmware/fdt'))
    after=hashes();before=json.loads((OUT/'device-before.json').read_text())
    assert all(after[n]==before[n] for n in PARTS if n not in ('boot_b','vendor_boot_b'))
    assert after['vendor_boot_b']==digest(OUT/'vendor_boot_b-xigua-r1.img')
    assert ssh(f"head -c {(OUT/'boot-xigua-r1.img').stat().st_size} /dev/sde45 | sha256sum").decode().split()[0]==digest(OUT/'boot-xigua-r1.img')
    (OUT/'device-after.json').write_text(json.dumps(after,indent=2)+'\n')
    manifest=json.loads((OUT/'manifest.json').read_text());manifest['phone_execution_confirmed']=True
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(identity.decode(),flush=True)
    print('PASS: display kernel SSH reachable; flashed images readback verified; other six partitions unchanged')
else:raise SystemExit('use preflight | flash | capture')

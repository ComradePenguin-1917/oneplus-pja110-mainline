"""Validate host serial shell and exact mainline log capture without rebooting."""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / 'out/user-init-usb-serial-shell-20261013'
OUT = ROOT / 'out/user-init-usb-serial-shell-experiment-20261013'
manifest = json.loads((BUILD / 'manifest.json').read_text())
qemu = json.loads((BUILD / 'qemu-result.json').read_text())
assert qemu['exit_code'] == 0 and qemu['persistent_init_script_reached_test_only_poweroff']
assert qemu['image_sha256'] == hashlib.sha256((BUILD / 'Image-probe').read_bytes()).hexdigest()
for name, entry in manifest['files'].items():
    assert hashlib.sha256((BUILD / name).read_bytes()).hexdigest() == entry['sha256']
assert (OUT / 'flashed-at.txt').exists()
windows = json.loads((OUT / 'windows-acm-initial.json').read_text(encoding='utf-8-sig'))
assert any(d['Class'] == 'Ports' and d['Problem'] == 0 and 'PID_0108&MI_00' in d['InstanceId'] for d in windows['Devices'])
identity = (OUT / 'serial-identity.txt').read_text()
assert '6.14.0-sm8550-xigua-r1' in identity and 'uid=0 gid=0' in identity
assert 'ACM_IDENTITY_DONE' in identity
state = (OUT / 'serial-usb-state.txt').read_text()
assert re.search(r'(?m)^configured$', state) and re.search(r'(?m)^high-speed$', state)
uptime = re.search(r'(?m)^(\d+\.\d+) \d+\.\d+$', state)
assert uptime
log = (OUT / 'mainline-dmesg.txt').read_bytes()
phone_hash = re.search(r'(?m)^([0-9a-f]{64})\s+/tmp/acm-dmesg.txt', (OUT / 'serial-dmesg-hash.txt').read_text())
assert phone_hash and phone_hash[1] == hashlib.sha256(log).hexdigest()
assert b'Linux version 6.14.0-sm8550-xigua-r1' in log and b'[initramfs] USB ACM bound' in log
result = {
    'host_usb_enumeration_confirmed': True,
    'windows_serial_device_started': True,
    'mainline_shell_connected': True,
    'shell_uid': 0,
    'mainline_kernel_release': '6.14.0-sm8550-xigua-r1',
    'mainline_dmesg_lines': len(log.splitlines()),
    'mainline_dmesg_sha256': phone_hash[1],
    'mainline_dmesg_phone_host_hash_match': True,
    'mainline_observed_uptime_seconds': float(uptime[1]),
    'usb_state': 'configured', 'usb_speed': 'high-speed',
    'qemu_verified_exact_image': True,
    'b_test_partitions_retained_at_user_request': True,
    'all_eight_boot_partition_hashes_restored': False,
    'post_flash_partition_readback_pending': True,
    'phone_left_running_mainline': True,
    'serial_transport_missing_output_observed': True,
    'serial_log_integrity_verified_after_chunk_retries': True,
    'rndis_network_not_yet_working': True,
}
if (OUT/'after-test-device.txt').exists():
    device=(OUT/'after-test-device.txt').read_text()
    assert device.splitlines()[:2]==['_a','1']
    actual={}
    for line in device.splitlines():
        if '/dev/block/by-name/' in line:
            digest,name=line.split()
            actual[name.rsplit('/',1)[1]]=digest
    assert len(actual)==8
    before=json.loads((OUT/'preflight.json').read_text())['partition_hashes_before']
    assert all(actual[p]==before[p] for p in before if p.endswith('_a'))
    for part,name in [('vendor_boot_b','vendor_boot_b-xigua-r1.img'),('init_boot_b','init_boot_b-xigua-r1.img'),('dtbo_b','dtbo_b-avb-noop.img')]:
        assert actual[part]==manifest['files'][name]['sha256']
    assert (OUT/'boot-b-prefix.txt').read_text().split()[0]==manifest['files']['boot-xigua-r1.img']['sha256']
    result.update(post_flash_partition_readback_pending=False,input_readback_verified=True,
                  android_a_boot_completed=True,a_partition_hashes_match_preflight=True,
                  phone_left_running_mainline=False)
(OUT / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
manifest['phone_execution_confirmed'] = True
manifest['user_observation_evidence'] = (OUT / 'result.json').relative_to(ROOT).as_posix()
(BUILD / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print('PASS: real mainline root shell; complete dmesg SHA256 verified; B test images retained')

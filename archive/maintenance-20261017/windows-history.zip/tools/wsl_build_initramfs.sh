#!/bin/bash
# Build the bring-up initramfs: busybox + our /init, as a gzipped cpio.
#
# Design notes
#   * Use the HOST's busybox. It is dynamically linked against glibc, so we must
#     also copy the shared-library closure, or /init cannot run at all and the
#     whole exercise is pointless. Verified with ldd + readelf INTERP.
#   * Keep it minimal: no udev, no external modules; everything the kernel needs
#     is built in, devices come from devtmpfs.
set -uo pipefail

ROOT="$HOME/workspace/PJA110-Mainline"
WORK="$ROOT/initramfs"
TREE="$WORK/tree"
WIN="/mnt/h/WorkSpace/PJA110-Mainline"

rm -rf "$TREE"
mkdir -p "$TREE"/bin "$TREE"/sbin "$TREE"/proc "$TREE"/sys "$TREE"/dev "$TREE"/tmp "$TREE"/newroot "$TREE"/lib "$TREE"/lib64 "$TREE"/usr/lib

BB=$(command -v busybox)
echo "=== busybox: $BB ==="
"$BB" 2>&1 | head -1

cp "$BB" "$TREE/bin/busybox"
chmod 755 "$TREE/bin/busybox"

echo
echo "=== applet symlinks (only those this busybox really has) ==="
for app in sh mount umount mkdir rmdir ls cat echo sleep ip ifconfig telnetd \
           udhcpd dd dmesg grep sed awk uname setsid pwd ps free df \
           mknod chmod ln sync hostname more vi cut tr head tail wc \
           printf test true false kill env printenv; do
    if "$BB" --list 2>/dev/null | grep -qx "$app"; then
        ln -sf busybox "$TREE/bin/$app"
    fi
done
ls "$TREE/bin" | tr '\n' ' '
echo

echo
echo "=== shared library closure ==="
ldd "$BB" 2>/dev/null | awk '/=>/ {print $3} /^\// {print $1}' | sort -u | while read -r lib; do
    [ -f "$lib" ] || continue
    dest="$TREE$lib"
    mkdir -p "$(dirname "$dest")"
    cp -L "$lib" "$dest"
    echo "  $lib"
done

INTERP=$(readelf -l "$BB" 2>/dev/null | awk '/interpreter/ {gsub(/[\[\]]/,"",$NF); print $NF}')
echo "  interpreter: ${INTERP:-none}"
if [ -n "${INTERP:-}" ] && [ -e "$INTERP" ]; then
    mkdir -p "$TREE$(dirname "$INTERP")"
    cp -L "$INTERP" "$TREE$INTERP"
    echo "  copied $INTERP"
fi

echo
echo "=== /init ==="
cp "$WIN/initramfs/init" "$TREE/init"
chmod 755 "$TREE/init"
head -3 "$TREE/init"

echo
echo "=== build cpio.gz ==="
cd "$TREE"
find . -print0 | cpio --null -ov --format=newc 2>/dev/null | gzip -9 > "$WORK/initramfs.cpio.gz"
ls -l "$WORK/initramfs.cpio.gz"

echo
echo "=== verify archive ==="
zcat "$WORK/initramfs.cpio.gz" > "$WORK/.list.cpio"
echo "  entries      : $(cpio -t < "$WORK/.list.cpio" 2>/dev/null | wc -l)"
echo "  has ./init   : $(cpio -t < "$WORK/.list.cpio" 2>/dev/null | grep -cx './init')"
echo "  has busybox  : $(cpio -t < "$WORK/.list.cpio" 2>/dev/null | grep -cx './bin/busybox')"
echo "  has ld.so    : $(cpio -t < "$WORK/.list.cpio" 2>/dev/null | grep -c 'ld-linux')"
echo "  size         : $(stat -c%s "$WORK/initramfs.cpio.gz") bytes"
echo
echo "  first entries:"
cpio -t < "$WORK/.list.cpio" 2>/dev/null | head -12
rm -f "$WORK/.list.cpio"

mkdir -p "$WIN/initramfs"
cp "$WORK/initramfs.cpio.gz" "$WIN/initramfs/"
echo
echo "copied to $WIN/initramfs/"

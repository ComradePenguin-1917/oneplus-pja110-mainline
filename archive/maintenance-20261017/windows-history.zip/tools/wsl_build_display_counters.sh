#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
OUT="$WIN/out/display-timing-20261014/counters"
mkdir -p "$OUT"
export PATH="$ROOT/toolchain/gcc-12-aarch64/usr/bin:$PATH"
export LD_LIBRARY_PATH="$ROOT/toolchain/gcc-12-aarch64/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
aarch64-linux-gnu-gcc -static -no-pie -O2 -Wall -Wextra "$WIN/tools/sample_display_counters.c" -o "$OUT/sample-display-counters" > "$OUT/build.log" 2>&1
echo 'PASS: read-only counter sampler built using existing compiler'

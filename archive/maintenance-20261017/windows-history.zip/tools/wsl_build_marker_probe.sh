#!/bin/bash
# UNAMBIGUOUS test: does ABL use the DTB appended to the kernel Image?
#
# Design (chosen so the device boots either way, and the answer is binary):
#   1. take the LIVE vendor DTB (dumped from the phone: it is exactly what the
#      running kernel uses) and add ONE unique marker property to /chosen
#   2. append it to the STOCK kernel and pack a boot image
#   3. memory-boot it, then dump /sys/firmware/fdt and look for the marker
#
#   marker present -> ABL used our appended DTB   (so DTB delivery was never the
#                     problem, and our own DTB has been in effect all along)
#   marker absent  -> ABL ignored it              (so we must patch the dtbo
#                     partition instead)
#
# Because the base tree is the vendor's own, the stock kernel still boots, so we
# can always read the answer.
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
OUT="$ROOT/out"
WIN="/mnt/h/WorkSpace/PJA110-Mainline"
LIVE="$WIN/live-from-device.dtb"
MARK="XIGUA_MARKER_7f3a9c"

command -v fdtput >/dev/null || { echo "fdtput missing (install dtc)"; exit 1; }

echo "=== 1) copy the live vendor DTB and add a marker ==="
cp "$LIVE" "$OUT/probe-marker.dtb"
cp "$OUT/probe-marker.dtb" "$OUT/probe-marker.dtb.bak"

# add a string property under /chosen
fdtput -t s "$OUT/probe-marker.dtb" /chosen xigua-marker "$MARK"
echo "  set /chosen/xigua-marker = $MARK"

echo
echo "=== 2) confirm the marker is in the DTB ==="
fdtget -t s "$OUT/probe-marker.dtb" /chosen xigua-marker
echo "  raw search:"
if grep -qa "$MARK" "$OUT/probe-marker.dtb"; then echo "    FOUND"; else echo "    NOT FOUND"; fi
ls -l "$OUT/probe-marker.dtb"

echo
echo "=== 3) append to the STOCK kernel and pack ==="
cat "$OUT/stock-kernel.bin" "$OUT/probe-marker.dtb" > "$OUT/probe-marker-kernel.bin"
cd "$WIN"
python3 tools/bootimg.py pack \
    --kernel "$OUT/probe-marker-kernel.bin" \
    --stock boot-A14.img \
    --cmdline "xiguaprobe=markertest" \
    -o "$OUT/probe-marker.img"

echo
echo "=== 4) verify the boot image ==="
python3 - "$OUT/probe-marker.img" "$OUT/probe-marker.dtb" <<'PY'
import struct, sys
img = open(sys.argv[1],'rb').read()
dtb = open(sys.argv[2],'rb').read()
ksize = struct.unpack_from('<I', img, 8)[0]
k = img[4096:4096+ksize]
i = k.find(b'\xd0\x0d\xfe\xed', len(k)-2000000)
print('  kernel field : %d bytes' % ksize)
print('  DTB at       : %s' % ('0x%x (%d bytes, byte-identical)' % (i, len(dtb)) if i>=0 and k[i:i+len(dtb)]==dtb else ('0x%x' % i if i>=0 else 'NONE')))
print('  marker in DTB: %s' % (b'XIGUA_MARKER_7f3a9c' in dtb))
PY

echo
echo "built: $OUT/probe-marker.img"

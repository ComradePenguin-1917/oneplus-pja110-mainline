#!/usr/bin/env python3
"""Parse the reserved-memory block of a DTS file into structured regions.

Handles the two shapes used in qcom DTS files:

    foo_mem: foo@12340000 { reg = <0x0 0x12340000 0x0 0x100000>; ... };

and the label-only form where `reg` is filled in by the bootloader:

    foo_mem: foo { size = <0x100000>; ... };   (no reg)

Usage:
    python resmem.py <file.dts> [--json out.json]
"""
import argparse
import json
import re
import sys


def strip_comments(src):
    src = re.sub(r'/\*.*?\*/', lambda m: '\n' * m.group(0).count('\n'), src, flags=re.S)
    src = re.sub(r'//[^\n]*', '', src)
    return src


def find_block(src, pattern):
    """Return (start_line, end_line, text) of a brace-matched block."""
    m = re.search(pattern, src)
    if not m:
        return None
    # find the opening brace after the match
    i = src.find('{', m.start())
    if i < 0:
        return None
    depth = 0
    j = i
    while j < len(src):
        if src[j] == '{':
            depth += 1
        elif src[j] == '}':
            depth -= 1
            if depth == 0:
                break
        j += 1
    return src[m.start():j + 1]


def iter_nodes(block):
    """Yield (label, name, body) for depth-1 child nodes inside a block."""
    # strip the outer "{ ... }"
    body = block[block.find('{') + 1: block.rfind('}')]
    pos = 0
    decl = re.compile(
        r'(?:([A-Za-z0-9_\-]+)\s*:\s*)?'      # optional label
        r'([A-Za-z0-9_][A-Za-z0-9_@,\-\.\+]*)'  # node name
        r'\s*\{')
    while True:
        m = decl.search(body, pos)
        if not m:
            return
        depth = 0
        j = m.end() - 1
        while j < len(body):
            if body[j] == '{':
                depth += 1
            elif body[j] == '}':
                depth -= 1
                if depth == 0:
                    break
            j += 1
        inner = body[m.end(): j]
        yield m.group(1), m.group(2), inner
        pos = j + 1


def parse_reg(inner):
    """Extract (base, size) from a reg = <...> property, if present."""
    m = re.search(r'\breg\s*=\s*<([^>]*)>', inner, re.S)
    if not m:
        return None, None
    nums = re.findall(r'0x[0-9a-fA-F]+|\d+', m.group(1))
    vals = [int(n, 16) if n.lower().startswith('0x') else int(n) for n in nums]
    if len(vals) == 4:              # <hi lo sizehi sizelo>  (64-bit addr + 64-bit size)
        base = (vals[0] << 32) | vals[1]
        size = (vals[2] << 32) | vals[3]
        return base, size
    if len(vals) == 2:              # <addr size>
        return vals[0], vals[1]
    return None, None


def parse_size(inner):
    m = re.search(r'\bsize\s*=\s*<([^>]*)>', inner, re.S)
    if not m:
        return None
    nums = re.findall(r'0x[0-9a-fA-F]+|\d+', m.group(1))
    if not nums:
        return None
    v = nums[0]
    return int(v, 16) if v.lower().startswith('0x') else int(v)


def parse(path):
    src = strip_comments(open(path, encoding='utf-8').read())
    block = find_block(src, r'reserved-memory\s*\{')
    if not block:
        return None, []
    regions = []
    for label, name, inner in iter_nodes(block):
        # skip nested garbage like "#address-cells"
        if name.startswith('#'):
            continue
        base, size = parse_reg(inner)
        if size is None:
            size = parse_size(inner)
        regions.append({
            'label': label,
            'name': name,
            'base': base,
            'size': size,
            'has_reg': base is not None,
            'no_map': 'no-map' in inner,
            'reusable': 'reusable' in inner,
            'compatible': (re.search(r'compatible\s*=\s*"([^"]+)"', inner) or [None, None])[1],
        })
    return block, regions


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('file')
    ap.add_argument('--json')
    ap.add_argument('--quiet', action='store_true')
    args = ap.parse_args()

    block, regions = parse(args.file)
    if block is None:
        sys.exit('no reserved-memory block found in %s' % args.file)

    if args.json:
        json.dump(regions, open(args.json, 'w', encoding='utf-8'), indent=1)

    if not args.quiet:
        print('%s: %d regions' % (args.file, len(regions)))
        tot = 0
        for r in regions:
            if r['size']:
                tot += r['size']
            base = ('0x%x' % r['base']) if r['base'] is not None else '(dynamic)'
            print('  %-34s %-14s %10s  %s%s' % (
                r['label'] or r['name'], base,
                ('%.1f MiB' % (r['size'] / 2**20)) if r['size'] else '?',
                'no-map ' if r['no_map'] else '',
                'reusable' if r['reusable'] else ''))
        print('  total: %.1f MiB' % (tot / 2**20))


if __name__ == '__main__':
    main()

"""Run raw Win32 capture in a separate process, then validate payloads offline."""
from pathlib import Path
import base64
import hashlib
import json
import re
import subprocess

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/usb-serial-reliability-new-cable-20261013/native'
OUT.mkdir(exist_ok=True)
command="stty -ixon; dmesg | grep -c gs_write_complete; for r in 1 2 3 4 5 6 7 8 9 10; do for n in 1048576 4194304; do head -c $n /dev/urandom > /tmp/usb-native.bin; printf '\\nNATIVE_%s_%s_HASH\\n' $r $n; sha256sum /tmp/usb-native.bin; printf '\\nNATIVE_%s_%s_BEGIN\\n' $r $n; base64 /tmp/usb-native.bin; printf '\\nNATIVE_%s_%s_END\\n' $r $n; done; done; dmesg | grep -c gs_write_complete; cat /proc/uptime; cat /sys/class/udc/*/current_speed; echo NATIVE_USB_DONE"
(OUT/'command.txt').write_text(command)
run=subprocess.run([str(ROOT/'out/usb_serial_native_capture.exe'),'COM12',str(OUT/'command.txt'),str(OUT/'transcript.txt'),'\nNATIVE_USB_DONE\n'],capture_output=True,timeout=130)
(OUT/'host-status.txt').write_bytes(run.stdout+run.stderr)
run.check_returncode()
text=(OUT/'transcript.txt').read_text().replace('\r','')
results=[]
for match in re.finditer(r'(?s)\nNATIVE_(\d+)_(\d+)_HASH\n([0-9a-f]{64})\s+/tmp/usb-native.bin\s*\nNATIVE_\1_\2_BEGIN\n(.*?)\nNATIVE_\1_\2_END\n',text):
    round_,size,expected,payload=match.groups()
    try:
        data=base64.b64decode(re.sub(r'\s','',payload),validate=True)
        actual=hashlib.sha256(data).hexdigest()
    except ValueError:
        data=b'';actual=''
    passed=len(data)==int(size) and actual==expected
    results.append(dict(round=int(round_),bytes=int(size),captured=len(data),expected_sha256=expected,actual_sha256=actual,passed=passed))
    print(f'native round={round_} bytes={size} passed={passed}')
result=dict(all_passed=len(results)==20 and all(r['passed'] for r in results),transfers=results,native_capture_exit=run.returncode)
(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print('All passed:',result['all_passed'])

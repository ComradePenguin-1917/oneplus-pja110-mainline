"""Record an enumerated shell attempt after live A/B readback, without restoring B."""
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
build, out = [(ROOT/a).resolve() for a in sys.argv[1:3]]
for p in (build,out):
    p.relative_to(ROOT)
manifest = json.loads((build/'manifest.json').read_text())
qemu = json.loads((build/'qemu-result.json').read_text())
assert qemu['exit_code'] == 0 and qemu['persistent_init_script_reached_test_only_poweroff']
assert qemu['image_sha256'] == hashlib.sha256((build/'Image-probe').read_bytes()).hexdigest()
def hashes(path):
    result = {}
    for line in path.read_text().splitlines():
        if '/dev/block/by-name/' in line:
            digest,name = line.split()
            result[name.rsplit('/',1)[1]] = digest
    assert len(result) == 8
    return result
actual = hashes(out/'after-test-device.txt')
assert (out/'after-test-device.txt').read_text().splitlines()[:2] == ['_a','1']
before = json.loads((out/'preflight.json').read_text())['partition_hashes_before']
assert all(actual[p] == before[p] for p in before if p.endswith('_a'))
for part,name in [('vendor_boot_b','vendor_boot_b-xigua-r1.img'),('init_boot_b','init_boot_b-xigua-r1.img'),('dtbo_b','dtbo_b-avb-noop.img')]:
    assert actual[part] == manifest['files'][name]['sha256']
assert (out/'boot-b-prefix.txt').read_text().split()[0] == manifest['files']['boot-xigua-r1.img']['sha256']
windows = json.loads((out/'windows-rndis-initial.json').read_text(encoding='utf-8-sig'))
assert any(d['Class'] == 'USB' and d['Status'] == 'OK' and d['Problem'] == 0 for d in windows['Devices'])
interfaces = [d for d in windows['Devices'] if '&MI_' in d['InstanceId']]
assert interfaces and any('RNDIS' in d['FriendlyName'] or 'NDIS' in d['FriendlyName'] for d in interfaces)
result = {'host_usb_enumeration_confirmed':True,'mainline_shell_connected':False,
          'host_network_driver_bound':bool(windows['Adapters']),
          'windows_interface_problems':[d['Problem'] for d in interfaces],
          'host_network_device_started':any(d['Class']=='Net' and d['Problem']==0 for d in interfaces),
          'input_readback_verified':True,'qemu_verified_exact_image':True,
          'android_a_boot_completed':True,'a_partition_hashes_match_preflight':True,
          'b_test_partitions_retained_at_user_request':True,'all_eight_boot_partition_hashes_restored':False}
(out/'result.json').write_text(json.dumps(result,indent=2))
manifest['phone_execution_confirmed'] = True
manifest['user_observation_evidence'] = (out/'result.json').relative_to(ROOT).as_posix()
(build/'manifest.json').write_text(json.dumps(manifest,indent=2))
print('PASS: RNDIS gadget enumeration, input readback and A state verified; B retained')

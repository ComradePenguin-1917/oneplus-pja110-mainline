"""Save current Wi-Fi failure evidence, then request an ordinary clean reboot."""
from pathlib import Path
import subprocess
import time
from prepare_native_install import SSH

out = Path('out/wifi-bringup-20261017')
args = SSH[:]
args[-1] = 'penguin@172.16.42.1'
args = [x if not x.startswith('UserKnownHostsFile=') else
        'UserKnownHostsFile=out/native-install-20261017/known_hosts' for x in args]
cmd = '''cat /proc/sys/kernel/random/boot_id
sha256sum /usr/lib/firmware/ath12k/WCN7850/hw2.0/*
cat /home/penguin/wifi-bringup/stock-board/result.txt
journalctl -b -k --no-pager | tail -n 300
if [ -r /proc/config.gz ]; then zcat /proc/config.gz | grep ATH12K; fi
'''
p = subprocess.run(args + [cmd], capture_output=True, timeout=30)
(out / ('before-clean-boot-' + time.strftime('%Y%m%d-%H%M%S') + '.txt')).write_bytes(p.stdout+p.stderr)
p.check_returncode()
print('Evidence saved; requesting ordinary reboot without an authentication prompt', flush=True)
p = subprocess.run(args + ['systemctl reboot --no-ask-password'], capture_output=True, timeout=20)
print(p.stdout.decode(errors='replace'))
print(p.stderr.decode(errors='replace'))
print('Reboot request exit:', p.returncode)

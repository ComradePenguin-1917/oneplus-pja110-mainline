"""Read A persistent logs through B rescue without replaying ext4 journal."""
from pathlib import Path
import subprocess, time
from prepare_native_install import SSH
out = Path('out/native-install-20261017') / ('shutdown-' + time.strftime('%Y%m%d-%H%M%S'))
out.mkdir()
cmd = '''set -eu
test -z "$(losetup -a)"
test "$(sed -n 's/^PARTNAME=//p' /sys/class/block/sda14/uevent)" = userdata
mkdir -p /tmp/a-shutdown-ro
losetup -r -o 511705088 /dev/loop0 /dev/sda14
trap 'umount /tmp/a-shutdown-ro 2>/dev/null || true; losetup -d /dev/loop0' EXIT
mount -t ext4 -o ro,noload /dev/loop0 /tmp/a-shutdown-ro
tar -C /tmp/a-shutdown-ro -cf - var/log/pja110-charger var/log/journal
'''
with (out / 'logs.tar').open('wb') as f:
    p = subprocess.run(SSH + [cmd], stdout=f, stderr=subprocess.PIPE, timeout=60)
(out / 'stderr.txt').write_bytes(p.stderr)
p.check_returncode()
print(out)
print('PASS: read-only logs saved; A root unmounted; no reboot')

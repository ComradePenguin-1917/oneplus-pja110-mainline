#!/usr/bin/env python3
"""Patch only CONFIG_CMDLINE's literal for a reversible boot experiment."""
import hashlib
import os

WS = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(WS, "out", "Image-poweroff")
OUT = os.path.join(WS, "out", "Image-poweroff-norootcmdline")
OLD = (b"console=tty0 root=PARTLABEL=win rootwait keep_bootcon quiet splash "
       b"allow_mismatched_32bit_el0 ignore_loglevel")
NEW = b"console=ttyMSM0,115200 loglevel=8 earlycon ignore_loglevel"

data = open(SRC, "rb").read()
count = data.count(OLD)
if count == 0:
    raise SystemExit("forced cmdline literal not found")
if len(NEW) > len(OLD):
    raise SystemExit("replacement is longer than source literal")
patched = data.replace(OLD, NEW + b"\0" * (len(OLD) - len(NEW)))
open(OUT, "wb").write(patched)
print("replaced %d occurrences (%d -> %d bytes)" % (count, len(OLD), len(NEW)))
print("output: %s (%d bytes)" % (OUT, len(patched)))
print("sha256: %s" % hashlib.sha256(patched).hexdigest())

#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
OUT="$WIN/out/display-touch-reuse-20261013"
TREE="$ROOT/linux"
BUILD="$ROOT/aston-touch-audit-20261013"
export PATH="$ROOT/toolchain/gcc-12-aarch64/usr/bin:$PATH"
export LD_LIBRARY_PATH="$ROOT/toolchain/gcc-12-aarch64/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu-
mkdir -p "$BUILD"
sha256sum "$TREE/.config" "$TREE/arch/arm64/boot/Image" > "$OUT/aston-build-before.sha256"
cp "$OUT/aston/drivers/input/touchscreen/"syna_tcm2* "$BUILD/"
printf 'obj-m := synaptics-aston-audit.o\nsynaptics-aston-audit-y := syna_tcm2.o syna_tcm2_spi.o\n' > "$BUILD/Makefile"
set +e
make -C "$TREE" M="$BUILD" KBUILD_EXTRA_SYMBOLS="$TREE/vmlinux.symvers" -j4 modules > "$OUT/aston-touch-unmodified-build.log" 2>&1
build_result=$?
set -e
sha256sum -c "$OUT/aston-build-before.sha256"
echo "Unmodified Aston candidate build exit=$build_result; Image/config unchanged"
if [ "$build_result" = 0 ]; then cp "$BUILD/synaptics-aston-audit.ko" "$OUT/"; fi
exit "$build_result"

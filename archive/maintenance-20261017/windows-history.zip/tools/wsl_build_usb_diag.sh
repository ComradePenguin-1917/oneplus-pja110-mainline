#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
TREE="$ROOT/linux"
OUT="$WIN/out/user-init-usb-serial-diag-20261013"
PREFIX="$ROOT/toolchain/gcc-12-aarch64"
export PATH="$PREFIX/usr/bin:$PATH"
export LD_LIBRARY_PATH="$PREFIX/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu-
cd "$TREE"
python3 - "$OUT" <<'PY'
from pathlib import Path
import sys
out=Path(sys.argv[1])
ep=Path('drivers/usb/dwc3/ep0.c')
serial=Path('drivers/usb/gadget/function/u_serial.c')
for p in (ep,serial):
    backup=out/(p.name+'.before')
    if not backup.exists(): backup.write_bytes(p.read_bytes())
text=ep.read_text()
anchor='\ttrace_dwc3_ctrl_req(ctrl);\n'
addition='''
\tdev_warn(dwc->dev, "PJA_USB_SETUP type=%02x req=%02x value=%04x index=%04x len=%u\\n",
\t\tctrl->bRequestType, ctrl->bRequest, le16_to_cpu(ctrl->wValue),
\t\tle16_to_cpu(ctrl->wIndex), le16_to_cpu(ctrl->wLength));
'''
if 'PJA_USB_SETUP' not in text:
    assert text.count(anchor)==1
    ep.write_text(text.replace(anchor,anchor+addition))
text=serial.read_text()
begin=text.index('static void gs_write_complete(')
end=text.index('static void gs_free_requests(',begin)
section=text[begin:end]
old='"%s: unexpected %s status %d\\n"'
new='"%s: unexpected %s status %d actual=%u length=%u zero=%u\\n"'
if 'actual=%u length=%u zero=%u' not in text:
    assert section.count(old)==1
    args='__func__, ep->name, req->status);'
    assert section.count(args)==1
    section=section.replace(old,new).replace(args,'__func__, ep->name, req->status, req->actual, req->length, req->zero);')
    serial.write_text(text[:begin]+section+text[end:])
init=Path('initramfs-xigua.cpio.gz')
backup=out/'initramfs.before.cpio.gz'
if not backup.exists(): backup.write_bytes(init.read_bytes())
init.write_bytes((out/'initramfs.cpio.gz').read_bytes())
(out/'config.before').write_bytes(Path('.config').read_bytes())
PY
make -j12 Image 2>&1 | tee "$OUT/build.log"
cp arch/arm64/boot/Image "$OUT/Image-probe"
cp System.map "$OUT/System.map"
cp .config "$OUT/kernel.config"
cp drivers/usb/dwc3/ep0.c "$OUT/ep0.c.diag"
cp drivers/usb/gadget/function/u_serial.c "$OUT/u_serial.c.diag"
cmp .config "$OUT/config.before"
echo 'PASS: diagnostic kernel built with unchanged config and proven ACM initramfs'

#!/usr/bin/env python3
"""Establish exactly how far our kernel got, from the ABL log plus timings.

Established facts:
  * ABL loaded boot_a (ours), AVB said "hash mismatch" which is EXPECTED and
    harmless because the device is unlocked (boot state: orange)
  * ABL applied the overlay, updated the device tree, and handed off
  * nothing appeared on USB afterwards

So ABL's job succeeded. The question is whether the kernel started at all.

This script extracts the timing evidence that tells us where the handoff ended
and whether the device was reset by watchdog vs by a clean power-off.
"""
import io
import os
import re

WS = r'H:\WorkSpace\PJA110-Mainline'
new = io.open(os.path.join(WS, 'bootloader-log-after-initrd.txt'),
              encoding='utf-8', errors='replace').read().splitlines()

print('=' * 74)
print('1) Did ABL load and hand off OUR kernel?')
print('=' * 74)
for l in new:
    if re.search(r'Load Image (boot_a|vendor_boot_a|dtbo_a|init_boot_a|recovery_a)', l):
        print('   %s' % l.strip())
print()
for l in new:
    if re.search(r'Apply Overlay|Update Device Tree', l):
        print('   %s' % l.strip())

print()
print('=' * 74)
print('2) AVB verdict for boot_a (expected mismatch: we replaced it)')
print('=' * 74)
for l in new:
    if 'avb_slot_verify' in l or 'boot state' in l:
        print('   %s' % l.strip())

print()
print('=' * 74)
print('3) the handoff sequence, in order')
print('=' * 74)
started = False
for l in new:
    if re.search(r'Apply Overlay', l):
        started = True
    if started:
        s = l.strip()
        if s:
            print('   %s' % s[:150])

print()
print('=' * 74)
print('4) reset / watchdog evidence AFTER the handoff')
print('=' * 74)
print('   (the device came back only after we forced it via EDL+power, or by')
print('    itself -- either way the trace ends at the handoff)')
tail = [l for l in new if re.search(r'(?i)reset|watchdog|wdt|panic|abort|warm|cold', l)]
for l in tail[-15:]:
    print('   %s' % l.strip()[:150])

print()
print('=' * 74)
print('5) the very last lines of ABL activity')
print('=' * 74)
for l in new[-12:]:
    print('   %s' % l.rstrip()[:150])

print()
print('=' * 74)
print('CONCLUSION')
print('=' * 74)
print('   ABL did everything right:')
print('     - loaded our boot_a')
print('     - AVB mismatch is expected and non-fatal on an unlocked device')
print('     - applied the dtbo overlay and updated the device tree')
print('     - shut down boot services and jumped to the kernel')
print('   Then nothing was observable.')
print()
print('   Because the kernel now HAS an initramfs whose /init would bring up a')
print('   USB gadget, "nothing observable" means the kernel did not reach')
print('   userspace. The failure is therefore in early kernel bring-up:')
print('   memory map, the (vendor) device tree we are handed, or CPU/SMMU init.')

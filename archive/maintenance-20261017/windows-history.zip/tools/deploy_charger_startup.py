"""Write prepared A startup images from B RAM rescue, retaining B unchanged."""
from pathlib import Path
import hashlib,json,subprocess
from prepare_native_install import SSH,read,inventory
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/"out/native-install-20261017"
SRC=BASE/"charger-startup"
OUT=BASE/"charger-startup-deployment"
OUT.mkdir(exist_ok=True)
m=json.loads((SRC/"manifest.json").read_text())
r=json.loads((BASE/"charger-rootfs-deployment/result.json").read_text())
assert r["prefix_readback_verified"] and r["backup_gpt_readback_verified"]
assert not (OUT/"write-started.json").exists(),"Inspect earlier write before retry"
state=read("uname -a; cat /proc/sys/kernel/random/boot_id; cat /proc/mounts")
assert b"#24 SMP" in state and b"/dev/loop" not in state
parts=inventory()
backup=json.loads((ROOT/"out/native-install-20261016/backup-verification.json").read_text())
def run(cmd,data=None):
    p=subprocess.run(SSH+[cmd],input=data,capture_output=True,timeout=180)
    with (OUT/"operations.log").open("ab") as f:f.write((cmd+"\n").encode()+p.stdout+p.stderr)
    p.check_returncode();return p.stdout
def guard(n):
    d=parts[n]["device"]
    return "test \"$(sed -n 's/^PARTNAME=//p' /sys/class/block/"+d+"/uevent)\" = "+n
rescue=["boot_b","init_boot_b","vendor_boot_b","dtbo_b"]
for n in rescue:
    assert run(guard(n)+" && sha256sum /dev/"+parts[n]["device"]).decode().split()[0]==backup[n]["sha256"]
before={}
for n in ["boot_a","vendor_boot_a","init_boot_a","dtbo_a"]:
    raw=read("cat /dev/"+parts[n]["device"])
    assert len(raw)==parts[n]["bytes"]
    (OUT/(n+"-before.img")).write_bytes(raw)
    before[n]=hashlib.sha256(raw).hexdigest()
(OUT/"write-started.json").write_text(json.dumps({"before":before,"boot_id":state.splitlines()[1].decode()},indent=2))
result={"writes":{},"b_unchanged":False}
for n in ["vendor_boot_a","init_boot_a","dtbo_a","boot_a"]:
    data=(SRC/(n+".img")).read_bytes();info=m["files"][n+".img"]
    assert len(data)==parts[n]["bytes"]==info["bytes"]
    assert hashlib.sha256(data).hexdigest()==info["sha256"]
    remote="/tmp/charger-"+n+".img"
    assert run("cat > "+remote+" && sha256sum "+remote,data).decode().split()[0]==info["sha256"]
    run(guard(n)+" && dd if="+remote+" of=/dev/"+parts[n]["device"]+" bs=1048576 conv=fsync && sync")
    assert run("sha256sum /dev/"+parts[n]["device"]).decode().split()[0]==info["sha256"]
    result["writes"][n]={**info,"readback_verified":True}
    (OUT/"result.json").write_text(json.dumps(result,indent=2))
    run("rm "+remote)
    print(n+": written and readback verified",flush=True)
for n in rescue:
    assert run("sha256sum /dev/"+parts[n]["device"]).decode().split()[0]==backup[n]["sha256"]
result["b_unchanged"]=True
(OUT/"result.json").write_text(json.dumps(result,indent=2))
print("PASS: A startup written and verified; B rescue unchanged; not rebooted")

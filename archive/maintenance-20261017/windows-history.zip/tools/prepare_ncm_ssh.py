"""Create a local client key; never print private key material."""
import subprocess
import argparse
from pathlib import Path

root = Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('--host-account', action='store_true')
args=parser.parse_args()
key = root / 'out/usb-ncm-20261013/ssh' / ('client_key_host' if args.host_account else 'client_key')
key.parent.mkdir(parents=True, exist_ok=True)
if not key.exists():
    subprocess.run(['C:/Windows/System32/OpenSSH/ssh-keygen.exe', '-q', '-t', 'ed25519',
                    '-N', '', '-C', 'pja110-ncm-bringup', '-f', str(key)], check=True)
print('Client public key ready:', key.with_suffix('.pub'))

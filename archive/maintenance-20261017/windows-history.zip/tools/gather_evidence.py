#!/usr/bin/env python3
"""Gather the evidence needed to tell these apart:

  H1  ABL tried slot B, our kernel failed fast, ABL fell back to A
  H2  ABL never tried B (set_active ineffective), so it booted A directly

Why it matters: under H1 the experiment DID exercise our kernel and the result is
a real negative. Under H2 nothing was tested at all.

Evidence available without a console:
  * reset reason / boot reason recorded by ABL for THIS boot
  * /sys/fs/pstore -- ramoops content, which would hold a panic from the B attempt
    if the kernel got far enough to write it
  * whether our own DTB even defines a ramoops region (prerequisite for that
    channel to work at all)
  * oplusreserve1, which the ABL log shows it writes on every boot (boot history)
"""
import os
import re
import shutil
import subprocess

ADB = shutil.which('adb') or r'C:\platform-tools\adb.exe'
WS = r'H:\WorkSpace\PJA110-Mainline'
SERIAL = 'bc7a542e'


def sh(cmd, timeout=600):
    r = subprocess.run([ADB, '-s', SERIAL, 'shell', cmd], capture_output=True, timeout=timeout)
    return ((r.stdout or b'') + (r.stderr or b'')).decode('utf-8', 'replace')


def root(cmd, timeout=600):
    return sh("su -c '%s'" % cmd, timeout)


print('=' * 78)
print('1) RESET / BOOT REASON IN THE CURRENT ABL LOG')
print('=' * 78)
log = os.path.join(WS, 'bootloader-log-bfail.txt')
txt = open(log, encoding='utf-8', errors='replace').read()
for pat in (r'Reset', r'Boot Reason', r'boot reason', r'PON', r'PON_REASON',
            r'watchdog', r'WDG', r'RunTime', r'powerup', r'PowerOn'):
    hits = [l.strip() for l in txt.splitlines() if re.search(pat, l, re.I)]
    if hits:
        print('--- %s' % pat)
        for h in hits[:6]:
            print('    %s' % h[:120])

print()
print('=' * 78)
print('2) PSTORE / RAMOOPS  (would hold a panic written by our kernel)')
print('=' * 78)
print('  /sys/fs/pstore listing:')
print('   ', root('ls -la /sys/fs/pstore/ 2>&1').strip()[:500])
print()
print('  ramoops node present in the running tree?')
print('   ', root('ls /sys/firmware/devicetree/base/reserved-memory/ 2>&1 | grep -i ramoops').strip()[:200])
print()
print('  pstore console/ramoops params:')
print('   ', root('cat /proc/cmdline 2>/dev/null | tr " " "\\n" | grep -i -E "ramoops|pstore"').strip()[:300])

print()
print('=' * 78)
print('3) DOES OUR OWN DTB DEFINE RAMOOPS?  (prerequisite for that channel)')
print('=' * 78)
import sys
sys.path.insert(0, os.path.join(WS, 'tools'))
from fdt import FDT
ours = FDT(open(os.path.join(WS, 'dts', 'sm8550-oneplus-xigua-16G.dtb'), 'rb').read()).nodes()
hits = [p for p in ours if 'ramoops' in p.lower() or 'pstore' in p.lower()]
print('  nodes mentioning ramoops/pstore in OUR DTB: %s' % (hits or 'NONE'))
vend = FDT(open(os.path.join(WS, 'live-from-device.dtb'), 'rb').read()).nodes()
vh = [p for p in vend if 'ramoops' in p.lower()]
print('  in the VENDOR live tree: %s' % (vh or 'NONE'))
if vh:
    for p in vh[:2]:
        print('    %s:' % p)
        for k in sorted(vend[p]):
            v = vend[p][k]
            val = v.hex() if len(v) <= 32 else '%d bytes' % len(v)
            print('      %-22s %s' % (k, val))

print()
print('=' * 78)
print('4) BOOT HISTORY: oplusreserve1')
print('=' * 78)
print('  the ABL log writes oplusreserve1 every boot; check size and content')
print('   ', root('ls -l /dev/block/by-name/oplusreserve1 2>&1').strip()[:200])

print()
print('=' * 78)
print('5) DECISIVE: does ABL actually honour set_active on this device?')
print('=' * 78)
print('  Evidence FOR (B really was booted earlier):')
print('    the xigua-vbtest marker test ran with set_active b and the marker')
print('    appeared in the running tree, AND ro.boot.slot_suffix reported _b.')
print('    That marker exists only in slot B_s vendor_boot, so slot B genuinely')
print('    booted at that time.')
print()
print('  => set_active works, and slot B is bootable.')
print('  => therefore in the decisive test, B was attempted and did NOT come up,')
print('     so ABL fell back to A. That is a real (negative) result for our')
print('     kernel+tree combination, not an untested case.')

print()
print('=' * 78)
print('6) WHAT THAT IMPLIES')
print('=' * 78)
print('  Our kernel fails to reach userspace BOTH when handed:')
print('    * the vendor device tree (earlier attempts)')
print('    * our own device tree, with the dtbo erased (this attempt)')
print('  The second case is the clean one, and it still failed. So the blocker is')
print('  upstream of the device tree: the kernel image itself, its boot arguments,')
print('  or very early arch/firmware init.')
print()
print('  Without a console we cannot see where. The next genuinely useful step is')
print('  to obtain a log channel, not to refine the DTB.')

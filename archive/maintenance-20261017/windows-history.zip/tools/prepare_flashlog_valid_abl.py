"""Combine the verified flash logger with the DTBO that passed real ABL."""
from pathlib import Path
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'out/flashlog-valid-abl-20261012'
ABL = ROOT / 'out/avb-fixup-control-20261012'
manifest = json.loads((OUT / 'manifest.json').read_text())
known = json.loads((ABL / 'manifest.json').read_text())
result = json.loads((ROOT / 'out/avb-fixup-experiment-20261012/result.json').read_text())
assert result['abl_overlay_merge_succeeded'] and result['all_eight_boot_partition_hashes_restored']
for name in ('boot-xigua-r1.img', 'vendor_boot_b-xigua-r1.img'):
    assert hashlib.sha256((OUT / name).read_bytes()).hexdigest() == known['files'][name]['sha256']
name = 'dtbo_b-avb-noop.img'
assert hashlib.sha256((ABL / name).read_bytes()).hexdigest() == known['files'][name]['sha256']
shutil.copyfile(ABL / name, OUT / name)
manifest['files'][name] = known['files'][name]
manifest['baseline'] = 'Real ABL merge passed; only generic init_boot changed to flash logger'
manifest['abl_success_evidence'] = 'out/avb-fixup-experiment-20261012/result.json'
manifest['device_boot_tested'] = False
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
print('PASS: kernel, vendor_boot and DTBO match ABL-success experiment; flashlog init differs.')

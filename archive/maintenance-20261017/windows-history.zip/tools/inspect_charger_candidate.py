﻿from pathlib import Path
import gzip
from fdt import FDT
p=Path('out/native-install-20261017/rootfs-integrated/vmlinuz')
b=p.read_bytes();s=b.index(b'IKCFG_ST')+8;e=b.index(b'IKCFG_ED',s);c=gzip.decompress(b[s:e]).decode()
for line in c.splitlines():
 if any(k in line for k in ['CONFIG_BATTERY_QCOM_BATTMGR','CONFIG_QCOM_PD_MAPPER','CONFIG_QCOM_PMIC_GLINK']):print(line)
n=FDT(Path('out/native-install-20261017/charger-startup/adsp-enabled.dtb').read_bytes()).nodes()
print('ROOT_COMPATIBLE', n['/']['compatible'].decode().split('\0')[:-1])
for p,v in n.items():
 if 'pmic-glink' in p and p.count('/')==1:print(p,v)

"""Apply a scoped AA536 command-transfer budget to the existing DPU perf vote."""
from pathlib import Path
import difflib
root=Path.home()/'workspace/PJA110-Mainline/linux'
out=Path('/mnt/h/workspace/PJA110-Mainline/out/display-budget-20261014')
out.mkdir(parents=True,exist_ok=True)
path=root/'drivers/gpu/drm/msm/disp/dpu1/dpu_core_perf.c'
text=path.read_text()
if 'dpu_core_perf_aa536_transfer_us' in text:
 assert text==(out/'dpu_core_perf.after.c').read_text()
else:
 before=text
 text=text.replace('#include <linux/bitmap.h>','#include <linux/bitmap.h>\n#include <linux/of.h>')
 text=text.replace('#include "dpu_core_perf.h"','#include "dpu_core_perf.h"\n#include "dpu_encoder.h"')
 helper='''/*
 * Local AA536 60Hz command-mode quirk. Vendor timing specifies a 6000us
 * MDP transfer window, not the entire 60Hz frame period. Keep the existing
 * DPU vote/OPP policy; account for the burst window before applying its cap.
 * A generic upstream solution needs per-connector transfer-time plumbing.
 */
static u32 dpu_core_perf_aa536_transfer_us(struct drm_crtc *crtc,
                                        struct drm_crtc_state *state)
{
 struct drm_display_mode *mode = &state->adjusted_mode;
 struct drm_encoder *encoder;
 struct device_node *panel;
 bool command = false;

 if (mode->hdisplay != 1240 || mode->vdisplay != 2772 ||
     drm_mode_vrefresh(mode) != 60)
  return 0;

 drm_for_each_encoder_mask(encoder, crtc->dev, state->encoder_mask) {
  if (dpu_encoder_get_intf_mode(encoder) == INTF_MODE_CMD)
   command = true;
 }
 if (!command)
  return 0;

 panel = of_find_compatible_node(NULL, NULL, "oneplus,aa536-p-3-a0001");
 if (!panel)
  return 0;
 of_node_put(panel);
 return 6000;
}

'''
 anchor='static void _dpu_core_perf_calc_crtc('
 assert text.count(anchor)==1
 text=text.replace(anchor,helper+anchor)
 needle='''		perf->core_clk_rate = _dpu_core_perf_calc_clk(perf_cfg, crtc, state);
'''
 assert text.count(needle)==1
 addition='''		/* Scale the normal frame-average vote for the command burst. */
		{
			u32 transfer_us = dpu_core_perf_aa536_transfer_us(crtc, state);
			struct dpu_kms *kms = _dpu_crtc_get_kms(crtc);

			if (transfer_us) {
				u32 denominator = transfer_us *
					drm_mode_vrefresh(&state->adjusted_mode);

				perf->core_clk_rate = DIV_ROUND_UP_ULL(
					perf->core_clk_rate * USEC_PER_SEC, denominator);
				perf->bw_ctl = DIV_ROUND_UP_ULL(
					perf->bw_ctl * USEC_PER_SEC, denominator);
				if (kms->num_paths)
					perf->max_per_pipe_ib = max_t(u64,
						perf->max_per_pipe_ib,
						DIV_ROUND_UP_ULL(perf->bw_ctl,
							kms->num_paths * 1000ULL));
			}
		}
'''
 text=text.replace(needle,needle+addition)
 (out/'dpu_core_perf.before.c').write_text(before)
 (out/'dpu_core_perf.after.c').write_text(text)
 (out/'budget.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),text.splitlines(True),fromfile='a/drivers/gpu/drm/msm/disp/dpu1/dpu_core_perf.c',tofile='b/drivers/gpu/drm/msm/disp/dpu1/dpu_core_perf.c')))
 path.write_text(text)
print('Applied scoped 6000us command-mode budget; existing OPP limit retained')

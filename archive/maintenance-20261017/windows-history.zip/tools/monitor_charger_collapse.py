"""Read-only 30-second correlation of USB collapse, input and AP gauge."""
from pathlib import Path
import subprocess, time
from prepare_native_install import SSH

args = SSH[:]
args[-1] = 'penguin@172.16.42.1'
args = [x if not x.startswith('UserKnownHostsFile=') else
        'UserKnownHostsFile=out/native-install-20261017/known_hosts' for x in args]
cmd = '''set -u
for i in $(seq 1 15); do
  date +%s
  for p in qcom-battmgr-usb bq28z610-0; do
    echo "$p"
    for n in online voltage_now current_now input_current_limit usb_type capacity charge_now status; do
      f=/sys/class/power_supply/$p/$n
      [ -r "$f" ] && printf '%s=' "$n" && cat "$f"
    done
  done
  sleep 2
done
echo JOURNAL
journalctl -b -k --no-pager -n 120 | grep -Ei 'collapse|aicl|charger|battmgr|usb' | tail -n 80 || true
'''
p = subprocess.run(args + [cmd], capture_output=True, timeout=50)
out = Path('out/native-install-20261017/charger-policy-audit')
out.mkdir(exist_ok=True)
dest = out / ('collapse-monitor-' + time.strftime('%Y%m%d-%H%M%S') + '.txt')
dest.write_bytes(p.stdout + p.stderr)
print(p.stdout.decode(errors='replace'))
print(p.stderr.decode(errors='replace'))
print('Saved:', dest)
p.check_returncode()

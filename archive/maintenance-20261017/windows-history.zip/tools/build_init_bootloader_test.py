#!/usr/bin/env python3
"""Build an init_boot image whose ramdisk reboots to bootloader from /init."""
import gzip
import hashlib
import os
import struct
import subprocess

WS = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC_BOOT = os.path.join(WS, "backup", "init_boot_b.img")
SRC_CPIO = os.path.join(WS, "initramfs", "initramfs.cpio.gz")
SRC_INIT = os.path.join(WS, "initramfs", "init-bootloader")
OUT_CPIO = os.path.join(WS, "out", "initramfs-bootloader.cpio.gz")
OUT_BOOT = os.path.join(WS, "out", "init_boot_b-rebootbootloader.img")
LZ4 = r"D:\msys64\ucrt64\bin\lz4.exe"
PAGE = 4096


def align(value):
    return (value + 3) & ~3


def parse_cpio(blob):
    entries = []
    pos = 0
    while pos + 110 <= len(blob):
        if blob[pos:pos + 6] not in (b"070701", b"070702"):
            raise ValueError("invalid newc archive at 0x%x" % pos)
        namesize = int(blob[pos + 94:pos + 102], 16)
        filesize = int(blob[pos + 54:pos + 62], 16)
        header = blob[pos:pos + 110]
        name_start = pos + 110
        name = blob[name_start:name_start + namesize - 1].decode()
        data_start = pos + align(110 + namesize)
        data = blob[data_start:data_start + filesize]
        entries.append((header, name, data))
        pos = data_start + align(filesize)
        if name == "TRAILER!!!":
            break
    return entries


def make_cpio(entries, replacement):
    out = bytearray()
    for header, name, data in entries:
        if name in ("init", "./init"):
            data = replacement
            h = bytearray(header)
            h[54:62] = ("%08x" % len(data)).encode()
            header = bytes(h)
        out += header
        encoded_name = name.encode() + b"\0"
        out += encoded_name
        out += b"\0" * ((-len(out)) & 3)
        out += data
        out += b"\0" * ((-len(out)) & 3)
    return bytes(out)


def lz4_compress(data):
    result = subprocess.run([LZ4, "-z", "-l", "-c"], input=data,
                            stdout=subprocess.PIPE, check=True)
    return result.stdout


def main():
    source = gzip.decompress(open(SRC_CPIO, "rb").read())
    replacement = open(SRC_INIT, "rb").read()
    archive = make_cpio(parse_cpio(source), replacement)
    open(OUT_CPIO, "wb").write(gzip.compress(archive, compresslevel=9, mtime=0))

    original = bytearray(open(SRC_BOOT, "rb").read())
    old_size = struct.unpack_from("<I", original, 12)[0]
    old_end = PAGE + ((old_size + PAGE - 1) // PAGE * PAGE)
    compressed = lz4_compress(archive)
    if len(compressed) >= old_size:
        raise SystemExit("new ramdisk does not fit in init_boot slot")
    struct.pack_into("<I", original, 12, len(compressed))
    original[PAGE:PAGE + len(compressed)] = compressed
    original[PAGE + len(compressed):old_end] = b"\0" * (old_end - PAGE - len(compressed))
    open(OUT_BOOT, "wb").write(original)
    print("cpio: %d bytes -> %s" % (len(archive), OUT_CPIO))
    print("ramdisk: %d bytes (slot %d)" % (len(compressed), old_size))
    print("image: %d bytes -> %s" % (len(original), OUT_BOOT))
    print("sha256: %s" % hashlib.sha256(original).hexdigest())


if __name__ == "__main__":
    main()

#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
OUT="$WIN/out/display-port-20261013"
TREE="$ROOT/linux"
export PATH="$ROOT/toolchain/gcc-12-aarch64/usr/bin:$PATH"
export LD_LIBRARY_PATH="$ROOT/toolchain/gcc-12-aarch64/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu-
cd "$TREE"
cmp .config "$WIN/out/debug-ncm-fixed-20261013/kernel.config"
cp .config "$OUT/config.before"
cp "$WIN/drivers/gpu/drm/panel/"panel-oneplus-aa536* drivers/gpu/drm/panel/
python3 - "$OUT" <<'PY'
from pathlib import Path
import sys
out=Path(sys.argv[1])
p=Path('drivers/gpu/drm/panel/Makefile')
if not (out/'panel-Makefile.before').exists(): (out/'panel-Makefile.before').write_bytes(p.read_bytes())
line='obj-$(CONFIG_DRM_MIPI_DSI) += panel-oneplus-aa536.o\n'
if line not in p.read_text(): p.write_text(p.read_text()+line)
p=Path('drivers/gpu/drm/msm/dsi/dsi_host.c')
if not (out/'dsi_host.c.before').exists(): (out/'dsi_host.c.before').write_bytes(p.read_bytes())
s=p.read_text()
if 'PJA110 SCR1' not in s:
    old='if (dsc->bits_per_component != 8) {'
    new='''/* PJA110 SCR1: opt-in board experiment, legacy panels unchanged. */
\tif (dsc->bits_per_component != 8 &&
\t    !(dsc->bits_per_component == 10 &&
\t      of_property_read_bool(msm_host->pdev->dev.of_node, "oneplus,dsc-scr1"))) {'''
    assert s.count(old)==1
    s=s.replace(old,new)
    old='ret = drm_dsc_setup_rc_params(dsc, DRM_DSC_1_1_PRE_SCR);'
    new='''ret = drm_dsc_setup_rc_params(dsc,
\t\tof_property_read_bool(msm_host->pdev->dev.of_node, "oneplus,dsc-scr1") ?
\t\tDRM_DSC_1_2_444 : DRM_DSC_1_1_PRE_SCR);'''
    assert s.count(old)==1
    s=s.replace(old,new)
    p.write_text(s)
s=p.read_text()
if 'PJA110 fixed command-mode lane rate' not in s:
    anchor='''\tunsigned long pclk_rate = dsi_get_pclk_rate(mode, msm_host->dsc, is_bonded_dsi);
\tunsigned long pclk_bpp;'''
    replacement=anchor+'''
\tu64 fixed_rate;

\t/* PJA110 fixed command-mode lane rate, from the vendor 60 Hz timing. */
\tif (!msm_host->cphy_mode && !(msm_host->mode_flags & MIPI_DSI_MODE_VIDEO) &&
\t    !of_property_read_u64(msm_host->pdev->dev.of_node,
\t\t\t\t  "oneplus,command-mode-lane-rate", &fixed_rate) &&
\t    fixed_rate == 1094400000ULL)
\t\treturn fixed_rate / 8;
'''
    assert s.count(anchor)==1
    s=s.replace(anchor,replacement)
    anchor='''\tmsm_host->byte_clk_rate = dsi_byte_clk_get_rate(&msm_host->base, is_bonded_dsi,
\t\t\t\t\t\t\tmsm_host->mode);'''
    replacement=anchor+'''
\tif (!msm_host->cphy_mode && !(msm_host->mode_flags & MIPI_DSI_MODE_VIDEO) &&
\t    of_property_read_bool(msm_host->pdev->dev.of_node, "oneplus,command-mode-lane-rate"))
\t\tmsm_host->pixel_clk_rate = mult_frac(msm_host->byte_clk_rate,
\t\t\t8 * msm_host->lanes, mipi_dsi_pixel_format_to_bpp(msm_host->format));
'''
    assert s.count(anchor)==1
    s=s.replace(anchor,replacement)
    p.write_text(s)
(out/'dsi_host.c.scr1').write_bytes(p.read_bytes())
(out/'drm_dsc_helper.c').write_bytes(Path('drivers/gpu/drm/display/drm_dsc_helper.c').read_bytes())
PY
make -j12 Image 2>&1 | tee "$OUT/build.log"
cmp .config "$OUT/config.before"
cp arch/arm64/boot/Image "$OUT/Image-probe"
cp System.map "$OUT/System.map"
cp .config "$OUT/kernel.config"
echo 'PASS: AA536 driver and opt-in DSC10/SCR1 built; kernel config unchanged'

"""Stage Wi-Fi DT, upstream boot firmware, and one explicit root installer."""
from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile
from prepare_native_install import SSH

out = Path('out/wifi-bringup-20261017')
manifest = json.loads((out / 'vendor-manifest.json').read_text())
args = SSH[:]
args[-1] = 'penguin@172.16.42.1'
args = [x if not x.startswith('UserKnownHostsFile=') else
        'UserKnownHostsFile=out/native-install-20261017/known_hosts' for x in args]
remote = '/home/penguin/wifi-bringup'

def run(command, data=None, timeout=90):
    p = subprocess.run(args + [command], input=data, capture_output=True, timeout=timeout)
    if p.returncode:
        print(p.stderr.decode(errors='replace'))
    p.check_returncode()
    return p.stdout

collector = '''#!/bin/sh
set -u
dest=/home/penguin/wifi-bringup
exec > "$dest/boot-probe.txt" 2>&1
chmod 644 "$dest/boot-probe.txt"
echo WIFI_BOOT_PROBE_BEGIN
date; uname -a; cat /proc/sys/kernel/random/boot_id
for module in pwrseq_qcom_wcn pci_pwrctrl_pwrseq ath12k; do
 modprobe "$module" || true
done
sleep 35
ip -brief link
nmcli -t -f DEVICE,TYPE,STATE device
for d in /sys/bus/pci/devices/*; do
 [ -d "$d" ] || continue
 echo PCI="$d"
 cat "$d/vendor" "$d/device" "$d/subsystem_vendor" "$d/subsystem_device"
 readlink "$d/driver" || true
done
lsmod | grep -E 'ath|mhi|pci|pwrseq|cfg80211|mac80211' || true
cat /sys/kernel/debug/devices_deferred 2>/dev/null || true
journalctl -b -k --no-pager | grep -Ei 'ath12|wcn|wlan|pcie|pci |mhi|firmware|pwrseq|regulator' | tail -n 240
echo WIFI_BOOT_PROBE_COMPLETE
'''
service = '''[Unit]
Description=Capture PJA110 WCN7850 first boot diagnostics
After=systemd-modules-load.service NetworkManager.service
ConditionPathExists=!/home/penguin/wifi-bringup/boot-probe-complete

[Service]
Type=oneshot
ExecStart=/usr/local/libexec/pja110-wifi-probe
ExecStartPost=/usr/bin/touch /home/penguin/wifi-bringup/boot-probe-complete
TimeoutStartSec=110

[Install]
WantedBy=multi-user.target
'''
install = '''#!/bin/sh
set -eu
test "$(id -u)" = 0
test "$(uname -r)" = 6.14.0-oneplus-xigua
test "$(cat /proc/1/comm)" = systemd
cd /home/penguin/wifi-bringup
sha256sum -c staged.sha256
for m in pwrseq_qcom_wcn pci_pwrctrl_pwrseq ath12k; do modinfo "$m" >/dev/null; done
target=/dev/disk/by-partlabel/vendor_boot_a
test "$(blockdev --getsize64 "$target")" = 201326592
current=$(sha256sum "$target" | cut -d ' ' -f 1)
case "$current" in
 SOURCE_SHA|CANDIDATE_SHA) ;;
 *) echo 'A vendor_boot changed since preparation; nothing written'; exit 1;;
esac
if [ "$current" = SOURCE_SHA ]; then
 if [ ! -e vendor_boot_a-before.img ]; then
  dd if="$target" of=vendor_boot_a-before.img bs=4194304 status=none
 fi
 test "$(sha256sum vendor_boot_a-before.img | cut -d ' ' -f 1)" = SOURCE_SHA
fi
# No board.bin fallback: select the factory board data after QMI identifies this device.
for f in amss.bin m3.bin; do
 dest=/usr/lib/firmware/ath12k/WCN7850/hw2.0/$f
 if [ -e "$dest" ] && ! cmp -s "firmware/ath12k/WCN7850/hw2.0/$f" "$dest"; then
  echo "Existing different firmware at $dest; nothing flashed"; exit 1
 fi
done
for f in amss.bin m3.bin; do
 install -D -m 644 "firmware/ath12k/WCN7850/hw2.0/$f" "/usr/lib/firmware/ath12k/WCN7850/hw2.0/$f"
done
install -D -m 755 boot-probe.sh /usr/local/libexec/pja110-wifi-probe
install -D -m 644 pja110-wifi-probe.service /etc/systemd/system/pja110-wifi-probe.service
systemctl daemon-reload
systemctl enable pja110-wifi-probe.service
if [ "$current" = SOURCE_SHA ]; then
 dd if=vendor_boot_a-wifi.img of="$target" bs=4194304 conv=fsync status=none
fi
test "$(sha256sum "$target" | cut -d ' ' -f 1)" = CANDIDATE_SHA
echo 'PASS: A vendor_boot readback matches Wi-Fi candidate; rebooting for PCIe/QMI identification'
sync
systemctl reboot
'''.replace('SOURCE_SHA', manifest['source_sha256']).replace('CANDIDATE_SHA', manifest['candidate_sha256'])
files = {
    'vendor_boot_a-wifi.img': (out / 'vendor_boot_a-wifi.img').read_bytes(),
    'boot-probe.sh': collector.encode(),
    'pja110-wifi-probe.service': service.encode(),
    'install.sh': install.encode(),
    'vendor-manifest.json': (out / 'vendor-manifest.json').read_bytes(),
}
assert hashlib.sha256(files['vendor_boot_a-wifi.img']).hexdigest() == manifest['candidate_sha256']
for name in ['amss.bin', 'm3.bin', 'board-2.bin']:
    key = 'firmware/ath12k/WCN7850/hw2.0/' + name
    files[key] = (out / key).read_bytes()
checksums = ''.join(hashlib.sha256(b).hexdigest() + '  ' + n + '\n' for n, b in files.items())
files['staged.sha256'] = checksums.encode()
for name in ['boot-probe.sh', 'pja110-wifi-probe.service', 'install.sh', 'staged.sha256']:
    (out / name).write_bytes(files[name])
payload = io.BytesIO()
with tarfile.open(fileobj=payload, mode='w') as tf:
    for name, data in files.items():
        entry = tarfile.TarInfo(name)
        entry.size = len(data)
        entry.mode = 0o644
        tf.addfile(entry, io.BytesIO(data))
print(run(f'mkdir -p {remote}; tar -xf - -C {remote}', payload.getvalue(), timeout=180).decode())
print(run(f'cd {remote}; sha256sum -c staged.sha256; sh -n install.sh; sh -n boot-probe.sh').decode())
manifest['phone_candidate_staged'] = True
manifest['phone_written'] = False
(out / 'vendor-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print('Staged. Root command: sudo sh /home/penguin/wifi-bringup/install.sh')
p = subprocess.run(args + ['sudo -n true'], capture_output=True, timeout=15)
print('Noninteractive sudo available:', p.returncode == 0)
print(p.stderr.decode(errors='replace'))

#!/usr/bin/env python3
"""Pre-flight for the validation test: does the plan actually test what I think?

The test is: `fastboot boot <image>` where image = STOCK kernel + OUR initramfs,
while the active slot is B.

Open questions that decide whether the result means anything:

1. Does ABL use the ramdisk from the boot.img I hand it, or from vendor_boot in
   flash? Android header v4 keeps the GENERIC ramdisk in vendor_boot, and the
   boot.img ramdisk field is legacy. If ABL ignores my ramdisk field, /init never
   comes from me and the test proves nothing about our initramfs.

   Evidence: I already ran this exact pattern earlier in the project
   (`boot-xigua-initrd-rd.img`, which carried our initramfs in the ramdisk field),
   and the outcome was indistinguishable from the no-ramdisk variant. That is a
   warning sign, not a proof.

2. Alternatively the KERNEL can embed the initramfs (CONFIG_INITRAMFS_SOURCE).
   Our mainline kernel does. The STOCK kernel cannot be rebuilt, so for the stock
   kernel the only route is the ramdisk field -- which brings back question 1.

3. `rdinit=/init` is only honoured if an initramfs/initrd was actually unpacked.

So: verify by checking what the STOCK kernel's own config says about ramdisk
handling, and reason about which piece ABL actually supplies.

A cleaner, decisive option exists and should be considered instead:
   use OUR kernel (which has the initramfs EMBEDDED, so no ramdisk handoff is
   needed at all) and give it the VENDOR's device tree by leaving vendor_boot
   untouched. That removes question 1 entirely. But our kernel already failed
   that way earlier, so what it really tests is "does our kernel boot at all".

Let me lay out the matrix honestly so the next run is chosen deliberately.
"""
import gzip
import io
import os
import struct
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
PAGE = 4096

print('=' * 78)
print('WHAT FASTBOOT BOOT ACTUALLY FEEDS THE KERNEL')
print('=' * 78)
img = os.path.join(WS, 'out', 'validate-stockkernel-ourinitrd.img')
b = open(img, 'rb').read()
ksize, rsize, osver = struct.unpack_from('<3I', b, 8)
hver = struct.unpack_from('<I', b, 40)[0]
cmd = b[44:44 + 1536].rstrip(b'\0').decode()
print('  boot.img header v%d' % hver)
print('  kernel  : %d bytes' % ksize)
print('  ramdisk : %d bytes   <== ours, in the legacy ramdisk field' % rsize)
print('  cmdline : %r' % cmd)

print()
print('  Android boot header v4 semantics:')
print('    - the GENERIC ramdisk lives in the vendor_boot partition')
print('    - boot.img "ramdisk" is the legacy slot, still loaded by most ABLs')
print('    - bootconfig comes from vendor_boot too')
print()
print('  => whether our ramdisk is used depends on ABL behaviour we have NOT')
print('     verified. Earlier, handing our initramfs in this same field produced')
print('     no observable difference, so this path is UNPROVEN.')

print()
print('=' * 78)
print('THE OPTION THAT REMOVES THE UNCERTAINTY')
print('=' * 78)
k = os.path.join(WS, 'out', 'Image-poweroff')
ki = open(k, 'rb').read()
raw = open(os.path.join(WS, 'initramfs', 'initramfs.cpio.gz'), 'rb').read()
i = ki.find(raw[:32])
print('  our mainline kernel has the initramfs EMBEDDED:')
print('    Image-poweroff: %d bytes' % len(ki))
print('    embedded archive found: %s' % ('YES @0x%x' % i if i >= 0 else 'NO'))
print()
print('  With an embedded initramfs the kernel does not need any ramdisk handoff,')
print('  so ABL behaviour stops mattering. That is the reliable way to run OUR')
print('  /init as rootfs on the phone.')

print()
print('=' * 78)
print('OPTION MATRIX')
print('=' * 78)
rows = [
    ('stock kernel + our initramfs in ramdisk',
     'tests our initramfs end-to-end',
     'HINGES on ABL honouring the legacy ramdisk field (unverified)'),
    ('our kernel (embedded initramfs) + vendor tree',
     'no ramdisk handoff needed at all',
     'already failed; tests "can our kernel boot", not the initramfs'),
    ('our kernel (embedded initramfs) + our tree',
     'the real goal',
     'already failed'),
]
for i, (what, good, risk) in enumerate(rows, 1):
    print('  %d) %s' % (i, what))
    print('       pro : %s' % good)
    print('       risk: %s' % risk)

print()
print('=' * 78)
print('RECOMMENDATION')
print('=' * 78)
print('  Run option 1 anyway -- it is a memory boot and costs nothing -- but read')
print('  the result against the right question:')
print()
print('    /init runs (phone goes dark) -> our initramfs + busybox + /init all')
print('                                    work on this hardware, AND ABL does')
print('                                    honour the ramdisk field. Two unknowns')
print('                                    resolved at once.')
print('    Android returns              -> EITHER our initramfs was never used,')
print('                                    OR the stock kernel refused it. This')
print('                                    does NOT prove our initramfs is broken.')
print()
print('  So a positive result is very informative; a negative one is not.')
print('  That asymmetry is worth stating up front rather than discovered later.')

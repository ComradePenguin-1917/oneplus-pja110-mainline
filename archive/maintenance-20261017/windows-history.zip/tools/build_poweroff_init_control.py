"""Use identical native POWER_OFF PID1 for the stock/mainline comparison."""
import hashlib
import json
import pathlib
import struct

from capstone import Cs, CS_ARCH_ARM64, CS_MODE_ARM
from build_init_marker_test import parse_cpio, make_entry, lz4
from build_native_init_probe import movz, movk

ROOT=pathlib.Path(__file__).resolve().parents[1]
OUT=ROOT/'out/mainline-init-experiment-20261012'

def main():
    OUT.mkdir(exist_ok=True)
    words=[movz(0,0xDEAD),movk(0,0xFEE1),movz(1,0x1969),movk(1,0x2812),
           movz(2,0xFEDC),movk(2,0x4321),movz(3,0,wide=True),
           movz(8,142,wide=True),0xD4000001,0x4B0003E0,
           movz(8,93,wide=True),0xD4000001,0x14000000]
    code=b''.join(struct.pack('<I',w) for w in words)
    ins=list(Cs(CS_ARCH_ARM64,CS_MODE_ARM).disasm(code,0x401000))
    assert len(ins)==len(words)
    listing='\n'.join('%x: %s %s'%(i.address,i.mnemonic,i.op_str) for i in ins)
    (OUT/'poweroff-disassembly.txt').write_text(listing+'\n')
    size=4096+len(code)
    header=struct.pack('<16sHHIQQQIHHHHHH',b'\x7fELF\x02\x01\x01'+b'\0'*9,
                       2,183,1,0x401000,64,0,0,64,56,1,0,0,0)
    ph=struct.pack('<IIQQQQQQ',1,5,0,0x400000,0x400000,size,size,4096)
    elf=(header+ph).ljust(4096,b'\0')+code
    (OUT/'poweroff-init').write_bytes(elf)
    stock=(ROOT/'backup/init_boot_b.img').read_bytes()
    oldsize=struct.unpack_from('<I',stock,12)[0]
    entries=parse_cpio(lz4(['-d','-l','-c'],stock[4096:4096+oldsize]))
    rebuilt=bytearray()
    count=0
    for fields,name,data in entries:
        if name=='init':
            fields=list(fields)
            fields[1]=0o100755
            data=elf
            count+=1
        rebuilt+=make_entry(fields,name,data)
    assert count==1
    verified=parse_cpio(bytes(rebuilt))
    assert len(verified)==len(entries) and verified[-1][1]=='TRAILER!!!'
    assert all(n==on and d==(elf if n=='init' else od)
               for (_,on,od),(_,n,d) in zip(entries,verified))
    compressed=lz4(['-z','-l','-12','-c'],bytes(rebuilt))
    assert lz4(['-d','-l','-c'],compressed)==rebuilt
    end=4096+((oldsize+4095)//4096)*4096
    assert len(compressed)<=end-4096
    image=bytearray(stock)
    struct.pack_into('<I',image,12,len(compressed))
    image[4096:end]=compressed+b'\0'*(end-4096-len(compressed))
    assert image[end:]==stock[end:] and len(image)==len(stock)
    (OUT/'init_boot_b-poweroff.img').write_bytes(image)
    info={'elf_sha256':hashlib.sha256(elf).hexdigest(),
          'init_boot_sha256':hashlib.sha256(image).hexdigest(),
          'command':'LINUX_REBOOT_CMD_POWER_OFF=0x4321fedc',
          'syscall':142,'dependencies':'none'}
    (OUT/'probe.json').write_text(json.dumps(info,indent=2))
    print(listing)
    print(json.dumps(info,indent=2))

if __name__=='__main__':
    main()

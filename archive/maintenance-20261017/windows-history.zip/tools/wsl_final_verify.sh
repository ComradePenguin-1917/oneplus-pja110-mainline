#!/bin/bash
# Final end-to-end verification of the packed boot images.
# Parses each image back independently (not trusting the packer's own report)
# and confirms the kernel payload and the embedded DTB.
set -uo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
OUT="$ROOT/out"
WIN="/mnt/h/WorkSpace/PJA110-Mainline"

echo "############ FINAL ARTIFACT VERIFICATION ############"
echo
for img in "$OUT"/boot-xigua-16G-gz.img "$OUT"/boot-xigua-16G-raw.img; do
    echo "=============================================================="
    echo "  $(basename "$img")  ($(stat -c%s "$img") bytes)"
    echo "=============================================================="
    python3 - "$img" <<'PY'
import gzip, struct, sys

p = sys.argv[1]
b = open(p, 'rb').read()

assert b[:8] == b'ANDROID!', 'bad boot magic'
ksize, rsize, osver, hsize = struct.unpack_from('<4I', b, 8)
hver = struct.unpack_from('<I', b, 40)[0]
cmdline = b[44:44+1536].rstrip(b'\0').decode('utf-8', 'replace')
print('  header_version : %d' % hver)
print('  os_version     : 0x%08x' % osver)
print('  kernel_size    : %d' % ksize)
print('  cmdline        : %r' % cmdline)

k = b[4096:4096+ksize]
print('  payload magic  : %r' % k[:2])
if k[:2] == b'\x1f\x8b':
    d = gzip.decompress(k)
    print('  -> gzip; decompressed %d bytes' % len(d))
else:
    d = k
    print('  -> raw (%d bytes)' % len(d))

# arm64 Image header
isz = struct.unpack_from('<Q', d, 16)[0]
print('  arm64 image_size : %d' % isz)
print('  ARMd magic @56   : %r' % d[56:60])

# DTB appended?
off = d.find(b'\xd0\x0d\xfe\xed', max(0, len(d) - 400000))
if off < 0:
    print('  APPENDED DTB     : NOT FOUND')
else:
    dsz = struct.unpack_from('>I', d, off+4)[0]
    print('  APPENDED DTB     : offset=%d (0x%x), totalsize=%d' % (off, off, dsz))
    print('  DTB 8-byte aligned: %s' % (off % 8 == 0))
    dtb = d[off:off+dsz]
    for probe in (b'OnePlus Ace 2 Pro', b'oneplus,xigua'):
        print('  DTB has %-18s: %s' % (probe.decode(), probe in dtb))
    # __symbols__ / ABL labels
    print('  DTB has __symbols__: %s' % (b'__symbols__' in dtb))
    print('  DTB has qcom_tzlog : %s' % (b'qcom_tzlog' in dtb))
print()
PY
done

echo "############ COMPARISON WITH STOCK ############"
python3 - "$WIN/boot-A14.img" "$OUT/boot-xigua-16G-gz.img" <<'PY'
import struct, sys
for p in sys.argv[1:]:
    b = open(p, 'rb').read()
    k = struct.unpack_from('<I', b, 8)[0]
    r = struct.unpack_from('<I', b, 12)[0]
    h = struct.unpack_from('<I', b, 20)[0]
    hv = struct.unpack_from('<I', b, 40)[0]
    print('  %-34s partition=%-11d hdr=v%d hdr_size=%-5d kernel=%-9d ramdisk=%d'
          % (p.split('/')[-1], len(b), hv, h, k, r))
PY

echo
echo "############ FLASHING COMMANDS (NOT executed) ############"
echo "  # 1) boot in memory only -- writes nothing:"
echo "  fastboot boot out/boot-xigua-16G-gz.img"
echo
echo "  # 2) if the ABL applies a dtbo, erase it first:"
echo "  fastboot erase dtbo"
echo
echo "  # (the raw variant is an alternative if the gzipped one is refused)"

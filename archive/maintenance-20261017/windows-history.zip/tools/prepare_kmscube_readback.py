"""Add bounded readback witnesses to a separate copy of upstream kmscube."""
import difflib,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/gpu-scanout-readback-20261014'
OUT.mkdir(exist_ok=True)
src=ROOT/'out/gpu-kms-20261014/kmscube'
dest=OUT/'kmscube'
shutil.copytree(src,dest,ignore=shutil.ignore_patterns('.git'),dirs_exist_ok=True)
p=dest/'drm-legacy.c';before=p.read_text()
helper=r'''
static void write_ppm(const char *path, const unsigned char *ptr,
                     unsigned w, unsigned h, unsigned stride, int flip, int bgr)
{
    FILE *f=fopen(path,"wb");
    if(!f){perror(path);exit(20);}
    fprintf(f,"P6\n%u %u\n255\n",w,h);
    for(unsigned y=0;y<h;y++)for(unsigned x=0;x<w;x++){
        const unsigned char *v=ptr+(flip?h-1-y:y)*stride+x*4;
        unsigned char rgb[3]={v[bgr?2:0],v[1],v[bgr?0:2]};
        if(fwrite(rgb,1,3,f)!=3)exit(21);
    }
    fclose(f);
}
'''.replace(r'\"','"')
s=before.replace('#include <errno.h>','#include <errno.h>\n#include <stdlib.h>\n#include <stdint.h>')
s=s.replace('static struct drm drm;',helper+'\nstatic struct drm drm;')
s=s.replace('\t\tcube->draw(i++);','''\t\tcube->draw(i++);
        unsigned char *witness=NULL;
        if(frame==60){
            witness=malloc(gbm->width*gbm->height*4);
            if(!witness)return -1;
            glFinish();
            glReadPixels(0,0,gbm->width,gbm->height,GL_RGBA,GL_UNSIGNED_BYTE,witness);
            if(glGetError()!=GL_NO_ERROR)return -1;
            write_ppm("/tmp/gpu-gl-readback.ppm",witness,gbm->width,gbm->height,gbm->width*4,1,0);
        }''')
needle='\t\tfb = drm_fb_get_from_bo(next_bo);'
assert s.count(needle)==1
s=s.replace(needle,'''        if(witness){
            uint32_t stride=0;void *map_data=NULL;
            const unsigned char *mapped=gbm_bo_map(next_bo,0,0,gbm->width,gbm->height,GBM_BO_TRANSFER_READ,&stride,&map_data);
            if(!mapped){perror("gbm_bo_map");return -1;}
            write_ppm("/tmp/gpu-bo-readback.ppm",mapped,gbm->width,gbm->height,stride,0,1);
            printf("READBACK width=%u height=%u map_stride=%u scanout_stride=%u format=0x%x modifier=0x%llx\\n",
                   gbm->width,gbm->height,stride,gbm_bo_get_stride(next_bo),gbm_bo_get_format(next_bo),
                   (unsigned long long)gbm_bo_get_modifier(next_bo));
            fflush(stdout);
            gbm_bo_unmap(next_bo,map_data);free(witness);
        }
'''+needle)
p.write_text(s)
(OUT/'readback-only.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='upstream/drm-legacy.c',tofile='readback/drm-legacy.c')))
print('PASS: separate upstream copy adds frame 60 GL and actual GBM BO readback; render and KMS algorithms preserved')

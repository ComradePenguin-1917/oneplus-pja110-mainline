#!/usr/bin/env python3
"""CRITICAL: does the dtbo overlay overwrite the root `model` property?

Discovery: 
  vendor_boot entry0 (base tree)  model = "Qualcomm Technologies, Inc. Kalama v2 SoC"
  live tree on the running phone   model = "Qualcomm Technologies, Inc. Kalama MTP,xigua"

Something rewrote `model` during boot. If it was the dtbo overlay, then my
vendor_boot marker (an equal-length replacement of `model`) would be ERASED by
that overlay no matter whether ABL used my base tree -- making the experiment
useless.

Check every fragment in every dtbo entry for a root-level write, especially to
`model`.
"""
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fdt import FDT, load_entries

WS = r'H:\WorkSpace\PJA110-Mainline'


def depth(p):
    return len([s for s in p.split('/') if s])


def dec(v):
    return v.rstrip(b'\0').decode('ascii', 'replace')


entries, _ = load_entries(os.path.join(WS, 'dtbo-A14.img'))

print('=' * 76)
print('1) FRAGMENTS THAT WRITE THE ROOT NODE')
print('=' * 76)
for label, sub in entries:
    f = FDT(sub)
    n = f.nodes()
    root_writes = []
    for p in n:
        # a fragment whose __overlay__ is the root: /fragment@N/__overlay__
        if depth(p) == 2 and p.endswith('/__overlay__'):
            props = sorted(n[p])
            if props:
                root_writes.append((p, props))
    print('--- %s : %d fragments write the ROOT node' % (label, len(root_writes)))
    for p, props in root_writes:
        print('      %s -> %s' % (p, props))
        for k in props:
            if k == 'model':
                print('         *** model = %r' % dec(n[p][k]))

print()
print('=' * 76)
print('2) ANY fragment anywhere setting `model`?')
print('=' * 76)
for label, sub in entries:
    f = FDT(sub)
    n = f.nodes()
    hits = [(p, dec(n[p]['model'])) for p in n if 'model' in n[p]]
    print('  %-8s fragments setting model: %d' % (label, len(hits)))
    for p, v in hits[:6]:
        print('      %-46s %r' % (p[:46], v))

print()
print('=' * 76)
print('3) what the LIVE tree says vs the base tree (A slot, current)')
print('=' * 76)
live = FDT(open(os.path.join(WS, 'live-from-device.dtb'), 'rb').read()).nodes()['/']
print('  live tree model      : %r' % dec(live.get('model', b'')))
print('  live tree compatible : %r' % dec(live.get('compatible', b'')).replace('\0', ' | '))
print('  live tree msm-id     : %s' % ' '.join(
    '0x%x' % x for x in struct.unpack('>%dI' % (len(live['qcom,msm-id'])//4), live['qcom,msm-id'])))

v = open(os.path.join(WS, 'backup', 'vendor_boot_a.img'), 'rb').read()
hsize, dtbsize = struct.unpack_from('<2I', v, 28+2048+4+16)
vrsize = struct.unpack_from('<I', v, 24)[0]
dtb_off = (((hsize+4095)//4096)*4096 + vrsize + 4095)//4096*4096
e0 = struct.unpack_from('>I', v, dtb_off+4)[0]
base = FDT(v[dtb_off:dtb_off+e0]).nodes()['/']
print('  base tree model      : %r' % dec(base.get('model', b'')))
print('  base tree compatible : %r' % dec(base.get('compatible', b'')).replace('\0', ' | '))

print()
print('=' * 76)
print('VERDICT')
print('=' * 76)
any_model = False
for label, sub in entries:
    n = FDT(sub).nodes()
    if any('model' in n[p] for p in n):
        any_model = True
if any_model:
    print('  The dtbo DOES set `model` -> my equal-length model marker would be')
    print('  overwritten by the overlay, so it cannot prove anything.')
    print('  => pick a marker property the overlays never touch.')
else:
    print('  The dtbo does NOT set `model`. Something else changed it (ABL itself).')
    print('  => my marker is still meaningful, but I should verify with a second')
    print('     property anyway.')
print()
print('  Note: live model is %r which carries "xigua" -- that is the OPPO')
print('  project name, so the change most likely happens in ABL, not in Linux.' % dec(live.get('model', b'')))

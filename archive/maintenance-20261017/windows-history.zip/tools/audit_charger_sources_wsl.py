from pathlib import Path
import subprocess
r=Path.home()/'workspace/PJA110-Mainline'; out=Path('/mnt/h/workspace/PJA110-Mainline/out/battery-bringup-20261016/charger-source'); out.mkdir(exist_ok=True)
for name in ['drivers/power/supply/qcom_battmgr.c','drivers/soc/qcom/pmic_glink.c','drivers/remoteproc/qcom_q6v5_pas.c','drivers/power/supply/Kconfig']:
 p=r/'linux'/name; (out/Path(name).name).write_bytes(p.read_bytes())
for base in [r/'erofs-extraction-tools/vendor-a-extracted',r/'out']:
 print('ROOT',base)
 if base.exists():
  for p in base.rglob('*'):
   if p.is_file() and any(k in p.name.lower() for k in ['adsp','battmgr','charger']) and p.suffix in ['.mbn','.mdt','.elf','.img','.b00','.b01','.b02']: print(p,p.stat().st_size)

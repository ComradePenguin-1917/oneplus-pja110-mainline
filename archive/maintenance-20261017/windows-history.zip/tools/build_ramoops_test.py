#!/usr/bin/env python3
"""Build the ramoops-equipped test image set.

Goal: finally SEE why our kernel dies, using pstore as the transport.

The chain that makes this work
    1. our DTB gets a ramoops node pinned at 0xBF800000 -- the exact address the
       running Android kernel uses (read from /sys/module/ramoops/parameters)
    2. our kernel boots, and whatever happens (panic, oops, or even clean early
       console output) is written into that RAM window
    3. our kernel does not come up, so ABL falls back to slot A
    4. Android's kernel maps the same window as its ramoops and exposes it at
       /sys/fs/pstore
    5. we read our kernel's messages out of pstore

Because RAM survives a warm reset, this is the one channel that does not need a
UART cable, a working USB peripheral, or a bootable rootfs.

Also enable PSTORE_CONSOLE capture of ordinary printk (already CONFIG_PSTORE_CONSOLE=y)
and make sure the kernel's own console goes to ramoops as well.
"""
import hashlib
import os
import struct
import subprocess
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
WSL_WS = '/mnt/h/WorkSpace/PJA110-Mainline'
PAGE = 4096


def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''):
            h.update(c)
    return h.hexdigest()


DTB = os.path.join(WS, 'out', 'xigua-with-ramoops.dtb')
KERN = os.path.join(WS, 'out', 'Image-poweroff')

print('=== inputs ===')
print('  DTB   : %s (%d bytes)' % (os.path.basename(DTB), os.path.getsize(DTB)))
print('  kernel: %s (%d bytes)' % (os.path.basename(KERN), os.path.getsize(KERN)))

# ---- 1) vendor_boot_b: our tree (with ramoops) as entry0 ----
print()
print('=' * 78)
print('1) vendor_boot_b  <- our DTB (with pinned ramoops) as entry0')
print('=' * 78)
src = os.path.join(WS, 'backup', 'vendor_boot_b.img')
v = bytearray(open(src, 'rb').read())
hsize, dtbsize = struct.unpack_from('<2I', v, 28 + 2048 + 4 + 16)
vrsize = struct.unpack_from('<I', v, 24)[0]
dtb_off = (((hsize + PAGE - 1)//PAGE)*PAGE + vrsize + PAGE - 1)//PAGE*PAGE
slot = struct.unpack_from('>I', v, dtb_off + 4)[0]
dtb = open(DTB, 'rb').read()
print('  dtb section @0x%x  entry0 slot = %d' % (dtb_off, slot))
print('  our DTB %d bytes, fits: %s' % (len(dtb), len(dtb) <= slot))
if len(dtb) > slot:
    sys.exit('DTB does not fit')

padded = bytearray(dtb) + b'\0' * (slot - len(dtb))
struct.pack_into('>I', padded, 4, slot)
orig = bytes(v)
v[dtb_off:dtb_off + slot] = bytes(padded)
out_vb = os.path.join(WS, 'out', 'vb-ourdtb-ramoops.img')
open(out_vb, 'wb').write(bytes(v))
w = open(out_vb, 'rb').read()
print('  head/ramdisk untouched : %s' % (w[:dtb_off] == orig[:dtb_off]))
print('  entries 1..3 untouched : %s' % (w[dtb_off + slot:] == orig[dtb_off + slot:]))
print('  sha256: %s' % sha(out_vb)[:32])

# ---- 2) boot_b: our kernel, and ALSO the dtb appended (belt and braces) ----
print()
print('=' * 78)
print('2) boot_b  <- our kernel (embedded initramfs) + appended DTB')
print('=' * 78)
combined = os.path.join(WS, 'out', 'Image-poweroff-w-dtb')
open(combined, 'wb').write(open(KERN, 'rb').read() + dtb)
print('  combined: %d + %d = %d bytes'
      % (os.path.getsize(KERN), len(dtb), os.path.getsize(combined)))

out_boot = os.path.join(WS, 'out', 'boot_b-ramoops.img')
cmd = ('cd %s && python3 tools/bootimg.py pack --kernel out/Image-poweroff-w-dtb '
       '--stock boot-A14.img '
       '--cmdline "console=ttyMSM0,115200 loglevel=8 earlycon ignore_loglevel rdinit=/init" '
       '-o out/boot_b-ramoops.img' % WSL_WS)
r = subprocess.run(['wsl.exe', '-d', 'Ubuntu-22.04', '--', 'bash', '-lc', cmd],
                   capture_output=True)
for line in (r.stdout or b'').decode('utf-8', 'replace').splitlines():
    if line.strip() and 'localh' not in line and 'N/e' not in line:
        print('  %s' % line.strip()[:100])

if os.path.exists(out_boot):
    b = open(out_boot, 'rb').read()
    ksize = struct.unpack_from('<I', b, 8)[0]
    k = b[4096:4096 + ksize]
    import gzip
    import io
    raw = open(os.path.join(WS, 'initramfs', 'initramfs.cpio.gz'), 'rb').read()
    i = k.find(raw[:32])
    print()
    print('  size          : %d' % len(b))
    print('  embedded initrd: %s' % ('yes @0x%x' % i if i >= 0 else 'NO'))
    print('  ramoops dtb appended: %s' % (k.find(dtb) >= 0))
    print('  sha256        : %s' % sha(out_boot)[:32])

print()
print('=' * 78)
print('3) RUN')
print('=' * 78)
for line in (
    'fastboot flash vendor_boot_b out/vb-ourdtb-ramoops.img',
    'fastboot flash boot_b        out/boot_b-ramoops.img',
    'fastboot erase dtbo_b',
    'fastboot set_active b',
    'fastboot reboot',
):
    print('  %s' % line)
print()
print('  then, after it falls back to Android:')
print('    adb shell su -c "ls -la /sys/fs/pstore/"')
print('    adb shell su -c "cat /sys/fs/pstore/console-ramoops*"')
print()
print('  that output is our kernel'"'"'s own view of why it died.')

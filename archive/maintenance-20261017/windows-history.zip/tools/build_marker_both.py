#!/usr/bin/env python3
"""Build the marker image for an arbitrary slot.

Slot choice matters:
  * slot A is the CURRENT working slot, and its vendor_boot has been modified
    (4b3e8008..., not the OTA value). Breaking it costs a 192 MiB restore.
  * slot B is PRISTINE stock (e085f83a... == OTA). Breaking it costs a slot
    switch back to A.

So we patch slot B's vendor_boot, set_active b, boot, read the marker, then
set_active a. Rollback is instant and cannot fail.

The edit itself is the safest possible: replace the base tree's `model` string
with an equal-length marker, so no size, offset, or structure changes anywhere.
"""
import hashlib
import os
import struct
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
PAGE = 4096
MARKER_TEXT = 'XIGUA_VBTEST_'

sys.path.insert(0, os.path.join(WS, 'tools'))
from fdt import FDT


def build(src, out, marker_text):
    v = bytearray(open(src, 'rb').read())
    hsize, dtbsize = struct.unpack_from('<2I', v, 28+2048+4+16)
    vrsize = struct.unpack_from('<I', v, 24)[0]
    dtb_off = (((hsize+PAGE-1)//PAGE)*PAGE + vrsize + PAGE-1)//PAGE*PAGE
    e0_size = struct.unpack_from('>I', v, dtb_off+4)[0]
    e0 = bytes(v[dtb_off:dtb_off+e0_size])

    root = FDT(e0).nodes()['/']
    model = root.get('model', b'')
    mid = root.get('qcom,msm-id')
    ms = ' '.join('0x%x' % x for x in struct.unpack('>%dI' % (len(mid)//4), mid)) if mid else '-'

    print('=== %s ===' % os.path.basename(src))
    print('  dtb section @0x%x  entry0 slot=%d' % (dtb_off, e0_size))
    print('  base tree model : %r' % model)
    print('  base tree msm-id: %s   (device is 0x207 0x20000)' % ms)
    print('  base tree symbols: %d' % len(FDT(e0).nodes().get('/__symbols__', {})))

    body = marker_text[:len(model)-1].ljust(len(model)-1, '_')
    marker = body.encode('ascii') + b'\0'
    assert len(marker) == len(model)
    assert b'\0' not in marker[:-1]

    occ = []
    start = 0
    while True:
        i = e0.find(model, start)
        if i < 0:
            break
        occ.append(i)
        start = i + 1
    if len(occ) != 1:
        sys.exit('model string not unique (%d occurrences)' % len(occ))

    pos = dtb_off + occ[0]
    plen, noff = struct.unpack('>2I', e0[occ[0]-8:occ[0]])
    print('  patch at 0x%x (FDT_PROP len=%d matches %s)' % (pos, plen, plen == len(model)))
    print('  marker : %r' % marker)

    orig = bytes(v)
    v[pos:pos+len(marker)] = marker
    w = bytes(v)

    same_before = w[:pos] == orig[:pos]
    same_after = w[pos+len(marker):] == orig[pos+len(marker):]
    print('  only marker bytes changed: %s' % (same_before and same_after))
    if not (same_before and same_after):
        sys.exit('patch leaked outside the marker!')

    open(out, 'wb').write(w)

    # verify
    ww = open(out, 'rb').read()
    off = dtb_off
    print('  --- walk ---')
    for i in range(4):
        total = struct.unpack_from('>I', ww, off+4)[0]
        fj = FDT(ww[off:off+total])
        rr = fj.nodes()['/']
        flag = ''
        if i == 0:
            flag = '  <== %r' % rr.get('model', b'')
        print('    entry%d @0x%06x size=%-7d symbols=%-5d%s'
              % (i, off, total, len(fj.nodes().get('/__symbols__', {})), flag))
        off += total
    print('    walk closed: %s' % (off == dtb_off + dtbsize))
    print('    size unchanged: %s' % (len(ww) == len(orig)))
    print('    sha256: %s -> %s' % (hashlib.sha256(orig).hexdigest()[:16],
                                    hashlib.sha256(ww).hexdigest()[:16]))
    print('  wrote %s' % out)
    print()
    return ww


print('=' * 74)
print('SLOT B (pristine stock) -- the safe experiment slot')
print('=' * 74)
build(os.path.join(WS, 'backup', 'vendor_boot_b.img'),
      os.path.join(WS, 'out', 'vendor_boot_b-modelmark.img'),
      MARKER_TEXT)

print('=' * 74)
print('SLOT A (for reference, not recommended first)')
print('=' * 74)
build(os.path.join(WS, 'backup', 'vendor_boot_a.img'),
      os.path.join(WS, 'out', 'vendor_boot_a-modelmark.img'),
      MARKER_TEXT)

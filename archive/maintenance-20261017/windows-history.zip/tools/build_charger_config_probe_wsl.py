"""Build a bounded one-shot reader for the stock firmware config buffer."""
from pathlib import Path
import hashlib
import json
import subprocess

win = Path('/mnt/h/workspace/PJA110-Mainline')
root = Path.home() / 'workspace/PJA110-Mainline/charger-native-a'
build = root / 'charger-config-probe'
out = win / 'out/native-install-20261017/charger-config-probe'
build.mkdir(exist_ok=True)
out.mkdir(exist_ok=True)
s = (win / 'out/native-install-20261017/temperature-readback/qcom_battmgr-readback.c').read_text()
s = s.replace('static int matched_temp = -10000;\nmodule_param(matched_temp, int, 0444);',
'''static unsigned int snapshot[12], snapshot_size;
module_param_array(snapshot, uint, NULL, 0444);
module_param(snapshot_size, uint, 0444);''')
s = s.replace('0x10003', '0x10002')
s = s.replace('le32_to_cpu(bcc->data_size) >= 32', 'le32_to_cpu(bcc->data_size) >= 48')
s = s.replace('matched_temp = (s32)le32_to_cpu(bcc->data[7]);',
'''unsigned int i;
            snapshot_size = le32_to_cpu(bcc->data_size);
            /* Only these 12 words are produced by this firmware handler. */
            for (i = 0; i < ARRAY_SIZE(snapshot); i++)
                snapshot[i] = le32_to_cpu(bcc->data[i]);''')
s = s.replace('PJA110 BCC response:', 'PJA110 config buffer response:')
s = s.replace('PJA110 BCC matched-temp readback: dC=%d result=%d',
              'PJA110 stock config readback: bytes=%u result=%d')
s = s.replace('matched_temp, ret', 'snapshot_size, ret')
s = s.replace('/* Factory bcc_read_buffer request. No property SET is issued. */',
              '/* Stock firmware config buffer handler; no charger property SET or watchdog pet. */')
(build / 'qcom_battmgr.c').write_text(s)
(build / 'Makefile').write_text('obj-m += qcom_battmgr.o\n')
p = subprocess.run(['make', '-C', str(root / 'linux-6.14'), 'ARCH=arm64',
                    'CROSS_COMPILE=/opt/aarch64-linux-gnu-toolchain-13.3/bin/aarch64-none-linux-gnu-',
                    'M=' + str(build), 'modules'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(out / 'build.log').write_bytes(p.stdout)
print(p.stdout.decode(errors='replace'))
p.check_returncode()
data = (build / 'qcom_battmgr.ko').read_bytes()
(out / 'qcom_battmgr-config.ko').write_bytes(data)
(out / 'source.c').write_text(s)
manifest = dict(sha256=hashlib.sha256(data).hexdigest(), opcode='0x10002',
                watchdog_pet=False, property_set=False, one_shot=True,
                defined_words=12, phone_tested=False)
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest, indent=2))

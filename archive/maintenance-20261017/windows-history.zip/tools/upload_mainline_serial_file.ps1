param(
    [Parameter(Mandatory)][string]$File,
    [Parameter(Mandatory)][string]$RemotePath,
    [string]$PortName='COM12',
    [string]$OutputDirectory='out/usb-loopback-20261013/upload'
)
$ErrorActionPreference='Stop'
if($RemotePath -notmatch '^/tmp/[a-zA-Z0-9_.-]+$'){throw 'Upload destination must be a simple /tmp filename'}
$workspace=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$target=[IO.Path]::GetFullPath((Join-Path $workspace $OutputDirectory))
if(-not $target.StartsWith($workspace+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Output must stay in workspace'}
[IO.Directory]::CreateDirectory($target)|Out-Null
. (Join-Path $PSScriptRoot 'UsbSerialReader.ps1')
Initialize-UsbSerialReaderType
$data=[IO.File]::ReadAllBytes((Resolve-Path $File))
$encoded=[Convert]::ToBase64String($data)
$expected=(Get-FileHash -Algorithm SHA256 $File).Hash.ToLowerInvariant()
$port=[IO.Ports.SerialPort]::new($PortName,115200)
$port.DtrEnable=$true;$port.RtsEnable=$true;$port.WriteTimeout=15000
$reader=$null;$transcript=[Text.StringBuilder]::new()
function Wait-Marker([string]$Marker){
    $reply=[Text.StringBuilder]::new();$timer=[Diagnostics.Stopwatch]::StartNew();$tail=''
    while($timer.Elapsed.TotalSeconds -lt 30){
        $chunk=[Text.Encoding]::ASCII.GetString($reader.Drain()).Replace("`r",'')
        [void]$reply.Append($chunk)
        $scan=$tail+$chunk
        if($scan -match ('(?m)^'+[regex]::Escape($Marker)+'$')){[void]$transcript.Append($reply);return $reply.ToString()}
        $tail=$scan.Substring([Math]::Max(0,$scan.Length-$Marker.Length-4))
        Start-Sleep -Milliseconds 5
    }
    [void]$transcript.Append($reply);throw "Missing marker $Marker"
}
try{
    $port.Open();$reader=[UsbSerialContinuousReader]::new($port,$true)
    $port.Write("stty -echo -ixon -ixoff; echo PJA_FILE_READY; head -c $($encoded.Length) | base64 -d > $RemotePath; sha256sum $RemotePath; echo PJA_FILE_DONE`n")
    [void](Wait-Marker 'PJA_FILE_READY')
    $port.Write($encoded)
    $reply=Wait-Marker 'PJA_FILE_DONE'
    $match=[regex]::Match($reply,'(?m)^([0-9a-f]{64})\s+'+[regex]::Escape($RemotePath)+'$')
    $passed=$match.Success -and $match.Groups[1].Value -eq $expected
    [ordered]@{File=$File;RemotePath=$RemotePath;Bytes=$data.Length;ExpectedSHA256=$expected;ActualSHA256=$match.Groups[1].Value;Passed=$passed} |
        ConvertTo-Json | Set-Content -Encoding utf8 (Join-Path $target 'result.json')
    if(-not $passed){throw 'File upload checksum mismatch'}
    Write-Output "PASS uploaded $RemotePath bytes=$($data.Length) sha256=$expected"
}finally{
    if($reader){$reader.Stop()}else{$port.Dispose()}
    [IO.File]::WriteAllText((Join-Path $target 'transcript.txt'),$transcript.ToString())
}

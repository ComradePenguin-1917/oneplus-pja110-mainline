#!/bin/bash
# Verify the freshly built kernel artifacts.
set -uo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
TREE="$ROOT/linux"
cd "$TREE"

IMG=arch/arm64/boot/Image
DTB=arch/arm64/boot/dts/qcom/sm8550-oneplus-xigua-16G.dtb

echo "=== Image header (arm64 boot protocol) ==="
python3 - "$IMG" <<'PY'
import struct, sys
d = open(sys.argv[1], 'rb').read(64)
code0, code1 = struct.unpack_from('<2I', d, 0)
text_off, image_size, flags = struct.unpack_from('<3Q', d, 8)
print('  code0        = 0x%08x' % code0)
print('  text_offset  = 0x%x' % text_off)
print('  image_size   = %d (%.2f MiB)' % (image_size, image_size / 2**20))
print('  flags        = 0x%x' % flags)
print('  magic @56    = %r' % d[56:60])
PY
echo "  file size    = $(stat -c%s "$IMG") bytes"

echo
echo "=== kernel release + config sanity ==="
make -s ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu- kernelrelease
grep -E '^CONFIG_LOCALVERSION' .config || true

echo
echo "=== does the Image contain an embedded DTB? ==="
python3 - "$IMG" <<'PY'
import sys
d = open(sys.argv[1], 'rb').read()
hits = []
i = 0
while True:
    i = d.find(b'\xd0\x0d\xfe\xed', i)
    if i < 0:
        break
    hits.append(i)
    i += 4
    if len(hits) > 8:
        break
print('  FDT magic occurrences in Image: %d %s' % (len(hits), hits[:5]))
print('  -> as expected: arm64 does NOT append a DTB to Image; the DTB is')
print('     supplied separately (ABL/bootloader), so we must pass it explicitly.')
PY

echo
echo "=== DTB content checks ==="
for d in arch/arm64/boot/dts/qcom/sm8550-oneplus-xigua.dtb \
         arch/arm64/boot/dts/qcom/sm8550-oneplus-xigua-16G.dtb; do
    echo "--- $(basename $d)  ($(stat -c%s $d) bytes)"
    python3 - "$d" <<'PY'
import struct, sys
b = open(sys.argv[1], 'rb').read()
assert b[:4] == b'\xd0\x0d\xfe\xed', 'bad FDT magic'
size = struct.unpack_from('>I', b, 4)[0]
print('    FDT totalsize = %d' % size)
for probe in (b'OnePlus Ace 2 Pro', b'oneplus,xigua', b'qcom,sm8550'):
    print('    contains %-18s %s' % (probe.decode(), probe in b))
for lbl in (b'qcom_tzlog', b'arch_timer'):
    print('    ABL label %-14s %s' % (lbl.decode(), lbl in b))
PY
done

echo
echo "=== Image size vs the partition / stock image ==="
echo "  our Image      : $(stat -c%s "$IMG") bytes"
echo "  stock kernel   : 53238272 bytes (from boot-A14.img)"
echo "  boot partition : 201326592 bytes (192 MiB)"

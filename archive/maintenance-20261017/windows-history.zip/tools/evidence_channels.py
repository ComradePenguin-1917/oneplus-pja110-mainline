#!/usr/bin/env python3
"""Check whether logfs/rawdump would actually capture our failed boot.

Rationale: the user asked about a "noretain channel" -- a way to get evidence
out of a device that never reaches userspace. On this platform the candidates are:

  logfs     (8 MiB, FAT12)          -- ABL's own log filesystem
  rawdump   (256 MiB, blank)        -- classic Qualcomm ramdump target
  logdump   (512 MiB)               -- larger log target
  xbl_sc_logs (128 KiB, IMTL magic) -- XBL log
  /proc/bootloader_log              -- ABL log exposed to a RUNNING kernel
  soc:dmesg-dump (0x1000)           -- 4 KiB region at f78ee000

Key question: does the ABL/kernel WRITE anything to a persistent place when our
kernel fails? If yes, we can read it after recovering. If no, we still need the
USB-gadget approach.

Evidence for the answer:
  * ABL log says "BDS: LogFs sync skipped, Unsupported"  <-- logfs NOT synced
  * bootloader_log IS populated and survives            <-- best channel we have
  * rawdump is all zeros despite two failed boots        <-- not written
"""
import io
import os
import re
import struct

WS = r'H:\WorkSpace\PJA110-Mainline'
out = []
def p(s=''):
    out.append(str(s))

p('=' * 74)
p('PERSISTENT EVIDENCE CHANNELS -- which ones actually get written?')
p('=' * 74)

# --- 1. bootloader_log: known populated ---
log = io.open(os.path.join(WS, 'bootloader-log.txt'), encoding='utf-8',
              errors='replace').read()
p()
p('1) /proc/bootloader_log')
p('   size on device: %d bytes' % len(log))
p('   survives reboot: YES (stored in oplusreserve1, ABL writes it every boot)')
p('   contains: full ABL trace, partition loads, AVB verdicts, cmdline')
p('   => VERDICT: usable, and already gave us the answer about DTBO handling')

# --- 2. logfs: synced? ---
p()
p('2) logfs (8 MiB FAT12)')
p('   ABL log line: "BDS: LogFs sync skipped, Unsupported"')
p('   dumped content: only a FAT12 header with volume label LOGFS + BOOTMGR')
nz = 0
b = open(os.path.join(WS, 'logfs.img'), 'rb').read()
for i in range(512, len(b), 4096):
    if b[i:i+64].strip(b'\0\xff'):
        nz += 1
p('   non-empty 4K clusters in dump: %d' % nz)
p('   => VERDICT: NOT written on this device (sync explicitly skipped)')

# --- 3. rawdump: written? ---
p()
p('3) rawdump (256 MiB)')
p('   first 16 KiB read on device: all zeros')
p('   => VERDICT: NOT written by our failures (would hold classic ramdump)')

# --- 4. dmesg-dump region ---
p()
p('4) soc:dmesg-dump @ 0xf78ee000 (4 KiB)')
live = FDT = None
import sys
sys.path.insert(0, os.path.join(WS, 'tools'))
from fdt import FDT
f = FDT(open(os.path.join(WS, 'live-from-device.dtb'), 'rb').read())
got = False
for path, props in f.nodes().items():
    if 'dmesg-dump' in path:
        got = True
        comp = props.get('compatible', b'').rstrip(b'\0').decode('ascii', 'replace')
        p('   node: %s' % path)
        p('   compatible: %s' % comp)
        for k, v in sorted(props.items()):
            if k in ('reg',) and len(v) == 16:
                base, size = struct.unpack('>QQ', v)
                p('   reg: 0x%x + 0x%x' % (base, size))
            elif k.startswith('qcom,') or k in ('memory-region',):
                p('   %s = %s' % (k, v.hex()[:40]))
if not got:
    p('   (no node found)')
p('   driver: qcom_dmesg_dumper (present, bound)')
p('   exposes: /proc/vmkmsg  (read BLOCKS waiting for new data)')
p('   => VERDICT: it is a live streaming channel, not a post-mortem store.')

p()
p('=' * 74)
p('CONCLUSION for the "noretain channel" question')
p('=' * 74)
p()
p('On this device:')
p('  * /proc/bootloader_log IS a working post-mortem channel -- but only for')
p('    what ABL itself did. It told us ABL applies the dtbo and builds the')
p('    cmdline. It will NOT contain our kernel\'s crash output.')
p('  * logfs is explicitly not synced; rawdump is untouched.')
p('  * ramoops exists (2.25 MiB) and IS registered, but /sys/fs/pstore is')
p('    EMPTY after our failures -- meaning the kernel never got far enough to')
p('    register a panic, or the region is re-initialised each boot.')
p()
p('So there is no magic post-mortem channel for a kernel that dies before')
p('userspace. The practical options remain:')
p('   a) USB network gadget from an embedded initramfs   (best: full shell)')
p('   b) make ramoops actually persist and read it after the next boot')
p('   c) physical UART')

io.open(os.path.join(WS, 'docs', 'evidence-channels.md'), 'w',
        encoding='utf-8').write('\n'.join(out) + '\n')
print('\n'.join(out))

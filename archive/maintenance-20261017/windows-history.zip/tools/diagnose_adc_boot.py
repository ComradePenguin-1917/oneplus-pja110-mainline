"""Read-only dual-endpoint capture after ADC reboot."""
from pathlib import Path
import concurrent.futures
import subprocess
import time
from prepare_native_install import SSH
out = Path('out/native-install-20261017/adc-gen3') / ('boot-diagnosis-' + time.strftime('%Y%m%d-%H%M%S'))
out.mkdir()
def probe(slot):
    args = SSH[:]
    if slot == 'a':
        args[-1] = 'penguin@172.16.42.1'
        args = [x if not x.startswith('UserKnownHostsFile=') else 'UserKnownHostsFile=out/native-install-20261017/known_hosts' for x in args]
    cmd = '''uname -a
cat /proc/sys/kernel/random/boot_id /proc/uptime /proc/cmdline
cat /proc/mounts
ls -l /sys/fs/pstore
for f in /sys/fs/pstore/*; do
    [ -f "$f" ] || continue
    echo PSTORE=$f
    cat "$f"
done
dmesg | tail -n 100
'''
    if slot == 'b':
        cmd += 'sha256sum /dev/sde24; cat /sys/class/block/sde24/uevent; losetup -a'
    p = subprocess.run(args + [cmd], capture_output=True, timeout=35)
    (out / (slot + '.txt')).write_bytes(p.stdout + p.stderr)
    return slot, p.returncode, (p.stdout + p.stderr).decode(errors='replace')
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    for slot, code, result in pool.map(probe, ['a', 'b']):
        print('ENDPOINT', slot, 'EXIT', code)
        print(result[-16000:])
print('Capture:', out)

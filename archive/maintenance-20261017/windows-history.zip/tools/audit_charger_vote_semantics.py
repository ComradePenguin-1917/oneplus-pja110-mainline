"""Preserve firmware vote/config distinctions without touching the phone."""
from pathlib import Path
import json
import re
import runpy
import struct
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
scope = runpy.run_path(str(ROOT / 'tools/inspect_adsp_disassembly.py'))
CACHE = scope['OUT']
OUT = ROOT / 'out/native-install-20261017/charger-policy-audit'
instructions = {}
for line in (CACHE / 'adsp-charger-analysis-only.dis').read_text().splitlines():
    m = re.match(r'^([0-9a-f]+):', line)
    if m:
        instructions[int(m[1], 16)] = line

def bytes_at(address, count):
    for base, data in scope['segments']:
        offset = address - base
        if 0 <= offset and offset + count <= len(data):
            return data[offset:offset + count]
    raise ValueError(hex(address))

descriptors = []
for index in range(4):
    raw = bytes_at(0x60204458 + 20 * index, 20)
    descriptors.append(dict(index=index, name=raw[:12].split(b'\0')[0].decode(),
                            operation=raw[13], default=struct.unpack_from('<I', raw, 16)[0]))
assert [x['name'] for x in descriptors] == ['iusb0_tot', 'iwls_tot', 'fcc_tot', 'fv_tot']
checks = {
    0x60082bf8: 'memw(r2+#0x11c)',
    0x600819e0: 'memw(r2+#0x11c) = r3',
    0x600828a4: 'r1 = memw(r3+#0x11c)',
    0x60057994: 'r0 = #0x2',
    0x6005799c: 'call 0x60082b00',
    0x600579a8: 'mpyi(r2,##0x3e8)',
    0x60056ba0: '##0x60056f80',
    0x60056ba4: 'r0 = #0x2',
    0x60056ba8: 'call 0x60082c20',
    0x60056f90: 'r0 = #0x0',
    0x60056f94: 'dealloc_return',
    0x601b3f1c: '##0x1964',
    0x6004fba0: 'call 0x601b3ee0',
    0x6004fc78: 'r3 = memuh(r30+#-0x1c)',
    0x6004fc7c: 'r0 = #0x2',
    0x6004fc90: 'call 0x60080ee0',
    0x6002a724: '##0x44aa20',
    0x6002a728: 'memw(r2+#0x6cc) = r4',
    0x6004fe88: 'memw(r2+#0x6cc) = r3',
    0x60059420: 'call 0x600a9840',
    0x600a98e4: '##0x6021a279',
    0x600a9944: 'r2 = memw(r2+#0x58)',
    0x600a996c: 'callr r2',
}
for address, text in checks.items():
    assert text in instructions[address], hex(address)
ranges = [
    '60082b00:60082c18', '600819c8:60081a00', '60082884:600828d4',
    '60057980:600579bc', '60056b80:60056bc4', '60056f80:60056fa0',
    '601b3ee0:601b3f34', '6004fb90:6004fbb0', '6004fc70:6004fc94',
    '6002a714:6002a72c', '6004fe70:6004fea0',
    '60059404:60059460', '600a9840:600a9988',
    '600583e4:60058414', '600584b4:600584d0',
]
p = subprocess.run([sys.executable, str(ROOT / 'tools/inspect_adsp_disassembly.py'),
                    *ranges], capture_output=True, check=True)
(OUT / 'vote-semantics-annotated.dis').write_bytes(p.stdout)
report = {
    'platform': 'cached scpqchg2s_extfg_r1; exact runtime callback selection not independently captured',
    'aggregator_descriptors': descriptors,
    'fcc_get': 'battery property 10 -> aggregator index 2 result field +0x11c -> mA * 1000',
    'fcc_6500_origin': 'fixed getter 0x601b3ee0 returns 6500; charger_config submits it as aggregator index 2 vote',
    'fcc_callback': 'registered 0x60056f80 returns success without hardware action',
    'callback_caution': 'no-op callback does not prove no hardware FCC control exists elsewhere',
    'fcc_max_4500': 'property 11 backing slot +0x6cc initialized to 4500000; charger_config can overwrite from platform config +0x4a8',
    'fcc_max_caution': 'not demonstrated as a clamp applied to the FCC GET result',
    'usb_icl_get': 'USB property 5 -> PmSchgUsb_GetUsbICLCfg -> registered getter +0x58 -> mA * 1000',
    'usb_icl_caution': 'configured ICL is not necessarily the settled/effective limit or measured input',
    'sdp_branch': 'factory USB-ICL setter has specific SDP + 900mA branch and i_sdp voter; current host request history unknown',
    'runtime_consistency': '6.5A vote and 4.5A config metadata are separate data paths; neither establishes actual pack charge current',
    'remaining': ['runtime winning client and settled input limit',
                  'source negotiation versus PMIC input regulation',
                  'wall-adapter charging and disconnect behavior'],
    'checked_instructions': {hex(a): instructions[a] for a in checks},
    'phone_modified': False,
}
(OUT / 'vote-semantics.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: report[k] for k in (
    'fcc_6500_origin', 'fcc_max_4500', 'usb_icl_get', 'phone_modified')}, indent=2))

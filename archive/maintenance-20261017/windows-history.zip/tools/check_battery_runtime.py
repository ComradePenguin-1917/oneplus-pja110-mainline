"""Read-only battery/UPower capture over native USB SSH."""
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'out/battery-bringup-20261016'
SSH = ['C:/Windows/System32/OpenSSH/ssh.exe', '-F', 'none', '-T', '-i',
       str(ROOT/'out/usb-ncm-20261013/ssh/client_key_host'), '-o', 'BatchMode=yes',
       '-o', 'IdentitiesOnly=yes', '-o', 'StrictHostKeyChecking=yes', '-o',
       f'UserKnownHostsFile={ROOT/"out/native-install-20261016/first-native-boot/known_hosts"}',
       '-o', 'ConnectTimeout=6', 'penguin@172.16.42.1']

def run(cmd):
    p = subprocess.run(SSH+[cmd], capture_output=True, timeout=20)
    p.check_returncode()
    return p.stdout

state = run('cat /proc/sys/kernel/random/boot_id; uname -r; systemctl is-system-running; systemctl --failed --no-pager; cat /home/penguin/battery-candidate/install-result.txt; cat /sys/class/power_supply/bq28z610-0/uevent; upower -d; readlink -f /sys/class/power_supply/bq28z610-0/device/driver; journalctl -b -k --no-pager | grep -Ei "bq27|bq28|880000|i2c|battery"')
assert b'6.14.0-oneplus-xigua' in state and b'\nrunning\n' in state
assert b'POWER_SUPPLY_NAME=bq28z610-0' in state
assert b'PASS: vendor_boot_a readback verified; all four B startup partitions unchanged' in state
(OUT/'runtime-initial.txt').write_bytes(state)
samples = []
for n in range(5):
    if n:
        time.sleep(12)
    data = run('cat /proc/uptime; cat /sys/class/power_supply/bq28z610-0/uevent')
    (OUT/f'sample-{n}.txt').write_bytes(data)
    props = dict(line.split('=', 1) for line in data.decode().splitlines() if '=' in line)
    samples.append({'host_time': time.time(), **props})
    print({k.removeprefix('POWER_SUPPLY_'): v for k,v in props.items() if k in ['POWER_SUPPLY_CAPACITY', 'POWER_SUPPLY_VOLTAGE_NOW', 'POWER_SUPPLY_CURRENT_NOW', 'POWER_SUPPLY_CHARGE_NOW', 'POWER_SUPPLY_HEALTH', 'POWER_SUPPLY_STATUS']}, flush=True)
(OUT/'samples.json').write_text(json.dumps(samples, indent=2)+'\n')
manifest_path = OUT/'candidate.json'
manifest = json.loads(manifest_path.read_text())
manifest.update(phone_written=True, install_readback_user_script_passed=True,
                native_reboot_verified=True, gauge_bound=True, upower_detected=True,
                capacity_accuracy_verified=False, usb_online_reporting_verified=False,
                charging_control_verified=False)
manifest_path.write_text(json.dumps(manifest, indent=2)+'\n')
print('PASS: existing gauge driver bound and UPower detected; accuracy/charging validation remains open')

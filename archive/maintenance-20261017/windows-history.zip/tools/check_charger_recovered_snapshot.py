"""Compare the post-recovery stock snapshot with the saved stopped baseline."""
from pathlib import Path
import json
import re
import subprocess
import time
from prepare_native_install import SSH

args = SSH[:]
args[-1] = 'penguin@172.16.42.1'
args = [x if not x.startswith('UserKnownHostsFile=') else
        'UserKnownHostsFile=out/native-install-20261017/known_hosts' for x in args]
p = subprocess.run(args + ['cat /home/penguin/charger-watchdog-probe/recovered-result.log; '
                          'echo LIVE_STATE; cat /proc/uptime; '
                          'cat /sys/class/power_supply/bq28z610-0/uevent'],
                   capture_output=True, timeout=30)
out = Path('out/native-install-20261017/charger-watchdog-probe')
dest = out / ('recovered-live-' + time.strftime('%Y%m%d-%H%M%S') + '.txt')
dest.write_bytes(p.stdout + p.stderr)
text = p.stdout.decode(errors='replace')
print(text)
print(p.stderr.decode(errors='replace'))
p.check_returncode()
assert 'RECOVERED_SNAPSHOT_COMPLETE' in text and 'READONLY_MODULE_RESTORED' in text
m = re.search(r'OEM_SNAPSHOT_RESULT=0\s+512\s+([0-9,]+)', text)
assert m, 'No valid snapshot response'
values = list(map(int, m[1].split(',')))
assert len(values) == 128
regs = dict(zip(values[15:121:2], values[16:122:2]))
baseline = json.loads((out / 'pair-live-20261017-140037.json').read_text())['snapshots'][1]
report = dict(capture=str(dest), state=regs[0x2606] & 7,
              registers={hex(a): hex(v) for a, v in regs.items()},
              changes={hex(a): [baseline[hex(a)], hex(v)] for a, v in regs.items()
                       if int(baseline[hex(a)], 16) != v},
              note='Snapshot precedes one watchdog pet; no watchdog configuration changed.')
dest.with_suffix('.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))

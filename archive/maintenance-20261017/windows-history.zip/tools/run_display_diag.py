"""Upload checksummed diagnostic module, read DCS status, then remove it."""
import hashlib
import subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/display-port-20261013'
KEYS=ROOT/'out/usb-ncm-20261013/ssh'
SSH=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(KEYS/'client_key_host'),
     '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
     '-o',f'UserKnownHostsFile={KEYS/"known_hosts"}','-o','ConnectTimeout=5',
     '-o','ServerAliveInterval=5','root@169.254.42.1']
def run(cmd,data=None):
    p=subprocess.run(SSH+[cmd],input=data,capture_output=True,timeout=60)
    (OUT/'diag-last-stderr.txt').write_bytes(p.stderr)
    p.check_returncode();return p.stdout
data=(OUT/'mainline_display_diag.ko').read_bytes()
actual=run('cat > /tmp/mainline_display_diag.ko; sha256sum /tmp/mainline_display_diag.ko',data).decode().split()[0]
assert actual==hashlib.sha256(data).hexdigest()
response=run('insmod /tmp/mainline_display_diag.ko; rc=$?; dmesg | grep PJA_DISP_DIAG; if [ "$rc" = 0 ]; then rmmod mainline_display_diag; fi; exit "$rc"')
(OUT/'dcs-readback.txt').write_bytes(response)
(OUT/'dmesg-after-dcs-readback.txt').write_bytes(run('dmesg'))
(OUT/'scan-state.txt').write_bytes(run('cat /sys/kernel/debug/dri/0/state; cat /sys/kernel/debug/gpio; cat /sys/class/backlight/ae94000.dsi.0/brightness; cat /proc/interrupts'))
print(response.decode())

"""Verify boot-success changes are limited to upstream B-slot success bits."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'out/boot-success-20261014'
before=json.loads((OUT/'before/gpt.json').read_text())
after=json.loads((OUT/'after/gpt.json').read_text())
changes=[]
for a,b in zip(before,after):
 assert a['device']==b['device'] and a['block_size']==b['block_size'] and a['bytes']==b['bytes']
 for ca,cb in zip(a['copies'],b['copies']):
  assert cb['header_crc_valid'] and cb['table_crc_valid']
  assert ca['table_lba']==cb['table_lba'] and ca['table_count']==cb['table_count'] and ca['entry_size']==cb['entry_size']
  for ea,eb in zip(ca['entries'],cb['entries']):
   if ea!=eb:
    assert ea['name'].endswith('_b') and ea['name']==eb['name']
    assert int(ea['attributes'],16)^int(eb['attributes'],16)==1<<54
    assert {k:v for k,v in ea.items() if k not in ('attributes','ab_byte','successful')}=={k:v for k,v in eb.items() if k not in ('attributes','ab_byte','successful')}
    changes.append(dict(device=a['device'],copy=ca['side'],partition=ea['name']))
assert changes
(OUT/'verified-changes.json').write_text(json.dumps(changes,indent=2)+'\n')
print('PASS:',len(changes),'GPT entry updates: only B-slot success bit; layouts, A-slot attributes and retry fields unchanged')

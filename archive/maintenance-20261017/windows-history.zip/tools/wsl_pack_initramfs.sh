#!/bin/bash
# Build the bring-up initramfs using the AARCH64 static busybox we compiled.
#
# The earlier attempt silently shipped the host's x86-64 busybox, which would
# have failed on the phone with "exec format error" and looked like a kernel
# problem. Now we assert the architecture before packing.
set -uo pipefail

ROOT="$HOME/workspace/PJA110-Mainline"
WORK="$ROOT/initramfs"
TREE="$WORK/tree"
WIN="/mnt/h/WorkSpace/PJA110-Mainline"
BB="$WORK/dl/busybox-aarch64-static"

echo "=== verify busybox architecture BEFORE packing ==="
if [ ! -f "$BB" ]; then echo "missing $BB"; exit 1; fi
file "$BB"
MACHINE=$(readelf -h "$BB" 2>/dev/null | awk '/Machine:/ {print $2}')
echo "  Machine: $MACHINE"
if [ "$MACHINE" != "AArch64" ]; then
    echo "  REFUSING: busybox is not aarch64"
    exit 1
fi
echo -n "  static (NEEDED count, expect 0): "
readelf -d "$BB" 2>/dev/null | grep -c NEEDED

rm -rf "$TREE"
mkdir -p "$TREE"/{bin,sbin,proc,sys,dev,tmp,newroot}
mkdir -p "$TREE"/lib "$TREE"/lib64 "$TREE"/usr/lib

echo
echo "=== install busybox + applet links ==="
cp "$BB" "$TREE/bin/busybox"
chmod 755 "$TREE/bin/busybox"
n=0
for app in sh mount umount mkdir rmdir ls cat echo sleep ip ifconfig telnetd \
           udhcpd dd dmesg grep sed awk uname setsid pwd ps free df \
           mknod chmod ln sync hostname more vi cut tr head tail wc \
           printf test true false kill env printenv; do
    if "$BB" --list 2>/dev/null | grep -qx "$app"; then
        ln -sf busybox "$TREE/bin/$app"
        n=$((n+1))
    fi
done
echo "  linked $n applets"

echo
echo "=== /init ==="
cp "$WIN/initramfs/init" "$TREE/init"
chmod 755 "$TREE/init"
sh -n "$TREE/init" && echo "  syntax OK"

echo
echo "=== pack ==="
cd "$TREE"
find . -print0 | cpio --null -o --format=newc 2>/dev/null | gzip -9 > "$WORK/initramfs.cpio.gz"
ls -l "$WORK/initramfs.cpio.gz"

echo
echo "=== verify archive contents ==="
zcat "$WORK/initramfs.cpio.gz" > /tmp/z.cpio
LIST=$(cpio -t < /tmp/z.cpio 2>/dev/null)
echo "  entries          : $(echo "$LIST" | wc -l)"
echo "  ./init present   : $(echo "$LIST" | grep -cx 'init')"
echo "  ./bin/busybox    : $(echo "$LIST" | grep -cx 'bin/busybox')"
echo "  size             : $(stat -c%s "$WORK/initramfs.cpio.gz") bytes"
echo
echo "  root entries:"
echo "$LIST" | grep -v / | sed 's/^/    /'
rm -f /tmp/z.cpio

mkdir -p "$WIN/initramfs"
cp "$WORK/initramfs.cpio.gz" "$WIN/initramfs/"
echo
echo "copied -> $WIN/initramfs/initramfs.cpio.gz"

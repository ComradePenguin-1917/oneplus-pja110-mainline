#!/bin/bash
# DECISIVE CONTROL EXPERIMENT
#
# Question: does ABL use the DTB concatenated to the kernel Image, or does it
# always substitute the device tree built from vendor_boot + dtbo?
#
# Method: take the STOCK kernel (which we know boots) and append OUR DTB.
#   * our DTB describes sm8550 with MAINLINE compatibles
#   * the stock 5.15 kernel knows only the vendor compatibles
#   so if ABL feeds the kernel our appended DTB, the stock kernel should fail to
#   probe the essentials and misbehave; if ABL ignores the appended bytes, the
#   stock kernel boots normally.
#
# This is safe: memory boot only, nothing written.
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
OUT="$ROOT/out"
WIN="/mnt/h/WorkSpace/PJA110-Mainline"

# 1) extract the stock kernel payload
python3 - <<'PY'
import struct
b = open('/mnt/h/WorkSpace/PJA110-Mainline/boot-A14.img','rb').read()
ksize = struct.unpack_from('<I', b, 8)[0]
open('/home/comrade_penguin_desktop/workspace/PJA110-Mainline/out/stock-kernel.bin','wb').write(b[4096:4096+ksize])
print('stock kernel payload: %d bytes' % ksize)
PY

DTB="$OUT/sm8550-oneplus-xigua-16G.dtb"
echo
echo "=== build variant C: STOCK kernel + OUR dtb ==="
cat "$OUT/stock-kernel.bin" "$DTB" > "$OUT/control-stockkernel-ourdtb.bin"
ls -l "$OUT/control-stockkernel-ourdtb.bin"

echo
echo "=== build variant D: STOCK kernel + NO dtb (pure control) ==="
cp "$OUT/stock-kernel.bin" "$OUT/control-stockkernel-nodtb.bin"
ls -l "$OUT/control-stockkernel-nodtb.bin"

echo
echo "=== pack both as boot images ==="
cd "$WIN"
for v in ourdtb nodtb; do
    python3 tools/bootimg.py pack \
        --kernel "$OUT/control-stockkernel-$v.bin" \
        --stock boot-A14.img \
        -o "$OUT/control-$v.img"
    echo
done

echo "=== results ==="
ls -l "$OUT"/control-*.img
echo
sha256sum "$OUT"/control-*.img

echo
echo "=== verify the dtb really is appended in the ourdtb variant ==="
python3 - <<'PY'
import struct
p='/home/comrade_penguin_desktop/workspace/PJA110-Mainline/out/control-ourdtb.img'
b=open(p,'rb').read()
ksize=struct.unpack_from('<I',b,8)[0]
k=b[4096:4096+ksize]
i=k.find(b'\xd0\x0d\xfe\xed', len(k)-400000)
print('  kernel field: %d bytes' % ksize)
print('  DTB at offset %s' % ('0x%x size=%d' % (i, struct.unpack_from('>I',k,i+4)[0]) if i>=0 else 'NONE'))
PY

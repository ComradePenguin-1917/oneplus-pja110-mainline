"""Capture already-loaded read-only SMEM identity and AP gauge state."""
from pathlib import Path
import subprocess
import time
from prepare_native_install import SSH
args = SSH[:]
args[-1] = 'penguin@172.16.42.1'
args = [x if not x.startswith('UserKnownHostsFile=') else
        'UserKnownHostsFile=out/native-install-20261017/known_hosts' for x in args]
cmd = '''set -eu
uname -r
cat /proc/sys/kernel/random/boot_id /proc/uptime
for key in item_size version project; do
    printf '%s=' "$key"
    cat /sys/module/pja110_smem_project/parameters/"$key"
done
cat /sys/class/power_supply/bq28z610-0/uevent
'''
p = subprocess.run(args + [cmd], capture_output=True, timeout=25)
out = Path('out/native-install-20261017/smem-project')
dest = out / ('live-' + time.strftime('%Y%m%d-%H%M%S') + '.txt')
dest.write_bytes(p.stdout + p.stderr)
print(p.stdout.decode(errors='replace'))
print(p.stderr.decode(errors='replace'))
print('Saved:', dest, 'SSH exit:', p.returncode)
p.check_returncode()

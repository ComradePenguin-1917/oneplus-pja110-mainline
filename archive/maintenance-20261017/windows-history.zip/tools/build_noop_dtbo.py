#!/usr/bin/env python3
"""Build a NO-OP dtbo, so the base tree we install in vendor_boot is used AS-IS.

Why this is needed
------------------
The vendor dtbo is a set of OVERLAYS. Every fragment carries
`target = 0xffffffff` plus an entry in /__fixups__ naming a LABEL. At boot ABL
resolves each label against the BASE tree's /__symbols__ and patches the phandle
in.

  vendor base tree : 1521 labels  -> all 168 fixups resolve
  our DTB          :  533 labels  -> only 9.5% resolve

So if we swap the base tree and leave the vendor dtbo in place, ABL faces ~152
unresolvable fixups and its behaviour is unknown. Replacing the dtbo with a
no-op removes the problem entirely: the base tree becomes the final tree.

Design
------
Keep the container shape identical (same magic, header_size, entry_size,
entry_count, entries_offset, page_size, version, and the SAME id/rev/custom
fields per entry) so nothing ABL might match on changes. Only the DTB payloads
become a minimal valid FDT with no fragments -- a valid overlay that does
nothing.

The partition is 24 MiB and mostly padding; the image is padded with zeros to
the full partition size, exactly like the stock one.
"""
import hashlib
import os
import struct
import subprocess
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
WSL_WS = '/mnt/h/WorkSpace/PJA110-Mainline'
PART_SIZE = 25165824

NOOP_DTS = """/dts-v1/;
/ {
\tcompatible = "xigua,noop";
};
"""


def compile_noop():
    """Build a minimal valid DTB via WSL's dtc."""
    dts = os.path.join(WS, 'out', 'noop.dts')
    dtb = os.path.join(WS, 'out', 'noop.dtb')
    with open(dts, 'w', encoding='ascii') as f:
        f.write(NOOP_DTS)
    cmd = 'dtc -I dts -O dtb -o %s/out/noop.dtb %s/out/noop.dts' % (WSL_WS, WSL_WS)
    r = subprocess.run(['wsl.exe', '-d', 'Ubuntu-22.04', '--', 'bash', '-lc', cmd],
                       capture_output=True)
    out = (r.stdout or b'').decode('utf-8', 'replace')
    err = (r.stderr or b'').decode('utf-8', 'replace')
    for line in (out + err).splitlines():
        if 'N/e' in line or 'localh' in line or not line.strip():
            continue
        print('    dtc: %s' % line.strip())
    if not os.path.exists(dtb):
        sys.exit('dtc failed to produce noop.dtb')
    blob = open(dtb, 'rb').read()
    if blob[:4] != b'\xd0\x0d\xfe\xed':
        sys.exit('noop.dtb is not a valid FDT')
    print('  noop.dtb: %d bytes, totalsize=%d' % (len(blob), struct.unpack_from('>I', blob, 4)[0]))
    return blob


def build(src, out):
    orig = open(src, 'rb').read()
    magic, total_size, header_size, entry_size, entry_count, entries_offset, page_size, version = \
        struct.unpack_from('>8I', orig, 0)

    print('=== original dtbo ===')
    print('  file size     : %d' % len(orig))
    print('  magic         : 0x%08x' % magic)
    print('  total_size    : %d' % total_size)
    print('  header_size   : %d' % header_size)
    print('  entry_size    : %d' % entry_size)
    print('  entry_count   : %d' % entry_count)
    print('  entries_offset: %d' % entries_offset)
    print('  page_size     : %d' % page_size)
    print('  version       : %d' % version)

    # preserve id/rev/custom so nothing ABL matches on changes
    meta = []
    print()
    print('  entries (id/rev/custom preserved):')
    for i in range(entry_count):
        o = entries_offset + i * entry_size
        dt_size, dt_offset, ident, rev = struct.unpack_from('>4I', orig, o)
        custom = orig[o + 16:o + 32]
        meta.append((ident, rev, custom))
        print('    [%d] size=%-8d off=%-8d id=0x%08x rev=0x%08x custom=%s'
              % (i, dt_size, dt_offset, ident, rev, custom.hex()))

    noop = compile_noop()
    pad = (-len(noop)) % 4
    payload = noop + b'\0' * pad
    print()
    print('=== rebuild with no-op payloads ===')
    print('  payload per entry: %d bytes (padded from %d)' % (len(payload), len(noop)))

    body_off = entries_offset + entry_count * entry_size
    offs = []
    cur = body_off
    for _ in range(entry_count):
        offs.append(cur)
        cur += len(payload)
    new_total = cur
    print('  body offset      : %d' % body_off)
    print('  new total_size   : %d' % new_total)

    outb = bytearray()
    outb += struct.pack('>8I', magic, new_total, header_size, entry_size,
                        entry_count, entries_offset, page_size, version)
    for i, (ident, rev, custom) in enumerate(meta):
        outb += struct.pack('>4I', len(noop), offs[i], ident, rev) + custom
    for _ in range(entry_count):
        outb += payload

    print('  image so far     : %d bytes' % len(outb))
    if len(outb) > PART_SIZE:
        sys.exit('image exceeds the partition')
    outb += b'\0' * (PART_SIZE - len(outb))
    print('  padded to        : %d bytes (partition size)' % len(outb))

    open(out, 'wb').write(bytes(outb))

    # verify
    print()
    print('=== verify the no-op dtbo ===')
    w = open(out, 'rb').read()
    m2 = struct.unpack_from('>8I', w, 0)
    print('  magic/entry_count/entries_offset: 0x%08x / %d / %d'
          % (m2[0], m2[4], m2[5]))
    sys.path.insert(0, os.path.join(WS, 'tools'))
    from fdt import FDT
    for i in range(entry_count):
        o = entries_offset + i * entry_size
        dt_size, dt_offset, ident, rev = struct.unpack_from('>4I', w, o)
        blob = w[dt_offset:dt_offset + dt_size]
        f = FDT(blob)
        nn = f.nodes()
        frags = [p for p in nn if p.lstrip('/').startswith('fragment@')]
        print('  entry%d: size=%-4d fragments=%d  (no-op: %s)'
              % (i, dt_size, len(frags), len(frags) == 0))
    print()
    print('  sha256 original: %s' % hashlib.sha256(orig).hexdigest())
    print('  sha256 noop    : %s' % hashlib.sha256(w).hexdigest())
    print('  size unchanged : %s' % (len(w) == len(orig)))
    print()
    print('wrote %s' % out)


if __name__ == '__main__':
    src = sys.argv[1] if len(sys.argv) > 1 else os.path.join(WS, 'backup', 'dtbo_b.img')
    out = sys.argv[2] if len(sys.argv) > 2 else os.path.join(WS, 'out', 'dtbo_b-noop.img')
    build(src, out)

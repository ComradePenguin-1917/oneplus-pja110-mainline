"""Launch standard Weston clients in the temporary Ubuntu session."""
import subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'out/ubuntu-ram-20261014'
KEYS=ROOT/'out/usb-ncm-20261013/ssh'
SSH=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(KEYS/'client_key_host'),
 '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
 '-o',f'UserKnownHostsFile={KEYS/"known_hosts"}','-o','ConnectTimeout=5','root@169.254.42.1']
names=('weston-simple-egl',) if '--fullscreen-bars' in sys.argv else ('weston-terminal','weston-simple-touch','weston-simple-egl')
if '--cpu-damage' in sys.argv:
 names=('weston-simple-damage',)
for name in names:
 debug=' FD_MESA_DEBUG=noubwc,notile' if '--linear' in sys.argv else ''
 args=' -f -o -v' if '--fullscreen-bars' in sys.argv else ''
 if '--cpu-damage' in sys.argv:
  args=' --width=1240 --height=2772'
 command=f'nohup chroot /tmp/ubuntu-ram /usr/bin/env XDG_RUNTIME_DIR=/run/user/0 WAYLAND_DISPLAY=wayland-0{debug} /usr/bin/{name}{args} > /tmp/{name}.log 2>&1 < /dev/null & echo $!'
 p=subprocess.run(SSH+[command],capture_output=True,timeout=15);p.check_returncode()
 (OUT/(name+'-launch.txt')).write_bytes(p.stdout+p.stderr)
 print(name,p.stdout.decode().strip())

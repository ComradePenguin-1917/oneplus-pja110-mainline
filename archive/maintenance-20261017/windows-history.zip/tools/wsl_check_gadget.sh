#!/bin/bash
# Verify everything needed for a USB-network initramfs, BEFORE writing it.
#
# For the kernel to present a USB network interface with no userspace help
# beyond a configfs write, we need:
#   1. a UDC driver that binds on this SoC  (dwc3 + qcom glue)
#   2. configfs gadget support + the RNDIS/ECM function
#   3. the kernel to actually find the DWC3 controller (needs the right DTB --
#      which is the *vendor's*, so usb may or may not come up; we will see)
#   4. in the initramfs: busybox, and a /init that configures it
set -uo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
TREE="$ROOT/linux"
cd "$TREE"

echo "############ UDC / gadget driver availability ############"
for s in CONFIG_USB_DWC3 CONFIG_USB_DWC3_DUAL_ROLE CONFIG_USB_DWC3_GADGET \
         CONFIG_USB_DWC3_HOST CONFIG_USB_DWC3_QCOM CONFIG_USB_DWC3_MSM \
         CONFIG_USB_GADGET CONFIG_USB_GADGET_STORAGE_NUM_BUFFERS \
         CONFIG_USB_CONFIGFS CONFIG_USB_CONFIGFS_RNDIS CONFIG_USB_CONFIGFS_ECM \
         CONFIG_USB_CONFIGFS_ECM_SUBSET CONFIG_USB_CONFIGFS_NCM \
         CONFIG_USB_CONFIGFS_F_FS CONFIG_USB_CONFIGFS_SERIAL \
         CONFIG_USB_LIBCOMPOSITE CONFIG_USB_F_RNDIS CONFIG_USB_U_ETHER \
         CONFIG_USB_F_ECM CONFIG_USB_F_NCM CONFIG_USB_F_SERIAL \
         CONFIG_USB_ROLE_SWITCH CONFIG_TYPEC CONFIG_EXTCON ; do
    if grep -qE "^$s=" .config; then grep -E "^$s=" .config | sed 's/^/  /'
    elif grep -qE "^# $s is not set" .config; then echo "  # $s is not set"
    else echo "  $s: ABSENT(symbol)"
    fi
done

echo
echo "############ initramfs machinery ############"
for s in CONFIG_BLK_DEV_INITRD CONFIG_INITRAMFS_SOURCE CONFIG_RD_GZIP \
         CONFIG_DEVTMPFS CONFIG_DEVTMPFS_MOUNT CONFIG_TMPFS \
         CONFIG_PROC_FS CONFIG_SYSFS CONFIG_CONFIGFS_FS; do
    if grep -qE "^$s=" .config; then grep -E "^$s=" .config | sed 's/^/  /'
    elif grep -qE "^# $s is not set" .config; then echo "  # $s is not set"
    else echo "  $s: ABSENT(symbol)"
    fi
done

echo
echo "############ is busybox available on the host to build one? ############"
for t in busybox cpio gzip; do
    p=$(command -v "$t" 2>/dev/null)
    printf '  %-10s %s\n' "$t" "${p:-MISSING}"
done

echo
echo "############ does the kernel have a built-in initramfs already? ############"
ls -l usr/initramfs_data.cpio* 2>/dev/null || echo "  none"

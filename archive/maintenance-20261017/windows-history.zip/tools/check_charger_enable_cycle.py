"""Collect stock enable-cycle ACKs, hardware readback and net pack current."""
from pathlib import Path
import json
import re
import subprocess
import time
from prepare_native_install import SSH

args = SSH[:]
args[-1] = 'penguin@172.16.42.1'
args = [x if not x.startswith('UserKnownHostsFile=') else
        'UserKnownHostsFile=out/native-install-20261017/known_hosts' for x in args]
p = subprocess.run(args + ['cat /home/penguin/charger-enable-cycle/result.log; '
                          'echo LIVE_STATE; cat /proc/sys/kernel/random/boot_id /proc/uptime; '
                          'cat /sys/class/power_supply/bq28z610-0/uevent; '
                          'cat /sys/class/power_supply/qcom-battmgr-usb/uevent'],
                   capture_output=True, timeout=30)
out = Path('out/native-install-20261017/charger-enable-cycle')
dest = out / ('live-' + time.strftime('%Y%m%d-%H%M%S') + '.txt')
dest.write_bytes(p.stdout + p.stderr)
text = p.stdout.decode(errors='replace')
print(text)
print(p.stderr.decode(errors='replace'))
p.check_returncode()
report = dict(capture=str(dest), completed='ENABLE_CYCLE_COMPLETE' in text,
              restored='READONLY_MODULE_RESTORED' in text,
              currents_uA=[int(v) for v in re.findall(r'POWER_SUPPLY_CURRENT_NOW=(-?\d+)',
                                                   text.split('LIVE_STATE')[0])])
for name, values in re.findall(r'FIELD=(\w+)\s+([0-9,-]+)', text):
    report[name] = list(map(int, values.split(',')))
m = re.search(r'ENABLE_CYCLE_RESULT=(-?\d+)', text)
report['result'] = int(m[1]) if m else None
dest.with_suffix('.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
assert report['restored'], 'Original module restoration not confirmed'
assert report['completed'], 'Inspect captured error/recovery result before continuing'

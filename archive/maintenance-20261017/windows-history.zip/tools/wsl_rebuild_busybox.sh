#!/bin/bash
# Rebuild busybox for aarch64 now that the libc startup objects are present.
set -uo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
TC="$ROOT/toolchain/gcc-12-aarch64"
SRC="$ROOT/initramfs/dl/busybox-1.36.1"

export PATH="$TC/usr/bin:$PATH"
export LD_LIBRARY_PATH="$TC/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"

cd "$SRC" || { echo "no source dir"; exit 1; }

# make sure static linking stayed enabled
grep -q '^CONFIG_STATIC=y' .config || echo 'CONFIG_STATIC=y' >> .config

echo "=== building busybox for aarch64 (static) ==="
make ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu- -j"$(nproc)" > /tmp/bb2.log 2>&1
rc=$?
echo "make rc=$rc"
if [ $rc -ne 0 ]; then
    echo "--- tail of log ---"
    tail -25 /tmp/bb2.log
    echo "--- looking for the real error ---"
    grep -iE 'error|cannot find|undefined' /tmp/bb2.log | head -15
    exit 1
fi

echo
echo "=== result ==="
ls -l busybox
file busybox
echo -n "  NEEDED entries (0 = fully static): "
readelf -d busybox 2>/dev/null | grep -c NEEDED
echo -n "  ARCH check: "
readelf -h busybox 2>/dev/null | awk '/Machine/ {print $0}' | sed 's/^ *//'

cp busybox "$ROOT/initramfs/dl/busybox-aarch64-static"
echo
echo "installed: $ROOT/initramfs/dl/busybox-aarch64-static"

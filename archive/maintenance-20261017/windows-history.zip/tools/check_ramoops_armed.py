#!/usr/bin/env python3
"""`dump_oops = -1` is suspicious. Check what Android's ramoops is actually
configured to capture before concluding anything about our kernel.

In the mainline ramoops driver, `dump_oops` defaults to 1 and is a bool. A value
of -1 suggests either a vendor patch or a different parameter semantic. If
dump_oops is effectively DISABLED, then a panic by our kernel would NOT be
recorded even though the zone exists -- which would fully explain an empty
/sys/fs/pstore without implying our kernel never ran.

Check the remaining parameters and, crucially, whether the ZONE ITSELF is
registered and armed.
"""
import shutil
import subprocess

ADB = shutil.which('adb') or r'C:\platform-tools\adb.exe'
SERIAL = 'bc7a542e'


def root(cmd, timeout=300):
    r = subprocess.run([ADB, '-s', SERIAL, 'shell', "su -c '%s'" % cmd],
                       capture_output=True, timeout=timeout)
    return ((r.stdout or b'') + (r.stderr or b'')).decode('utf-8', 'replace')


print('=' * 78)
print('1) ALL ramoops module parameters')
print('=' * 78)
params = root('for f in /sys/module/ramoops/parameters/*; do '
              'printf "%-18s " "$(basename $f)"; cat "$f" 2>/dev/null; done')
for line in params.splitlines():
    if line.strip():
        print('  %s' % line.strip()[:100])

print()
print('=' * 78)
print('2) is the platform device bound to the driver?')
print('=' * 78)
print('  driver dir:')
print(root('ls /sys/bus/platform/drivers/ramoops/ 2>&1').strip()[:400])
print()
print('  device dir:')
print(root('ls -la /sys/devices/platform/reserved-memory:ramoops_region/ 2>&1').strip()[:600])

print()
print('=' * 78)
print('3) driver bind state + any probe messages')
print('=' * 78)
print('  driver present   : %s' % ('yes' if 'ramoops' in root('cat /proc/devices 2>/dev/null') or
                                    'ramoops' in root('ls /sys/bus/platform/drivers/ 2>/dev/null')
                                    else 'unknown'))
print('  modules loaded   :')
print(root('lsmod 2>/dev/null | grep -i -E "ramoops|pstore" || echo "  (none listed)"').strip()[:300])
print()
print('  dmesg ramoops lines:')
print(root('dmesg 2>/dev/null | grep -i -E "ramoops|pstore" | head -15').strip()[:900] or '  (none)')

print()
print('=' * 78)
print('4) the vendor ramoops node in the LIVE tree, as Android sees it')
print('=' * 78)
print(root('for f in compatible reg console-size pmsg-size mem-type ecc-size '
           'max-reason dump-oops; do '
           'p=/sys/firmware/devicetree/base/reserved-memory/ramoops_region/$f; '
           'if [ -f "$p" ]; then printf "%-14s " "$f"; '
           'od -An -tx1 "$p" 2>/dev/null | tr -s " " | tr -d "\\n"; echo; fi; done').strip()[:800])

print()
print('=' * 78)
print('5) INTERPRETATION')
print('=' * 78)
print('  If dump_oops is effectively off, an empty pstore proves nothing about our')
print('  kernel: a panic simply would not be recorded.')
print('  If the zone is bound and armed, then an empty pstore after our attempt')
print('  means either our kernel wrote nothing (died before ramoops init) or')
print('  Android reinitialised the zone and discarded stale data.')
print()
print('  Either way, the ramoops channel needs to be validated with a CONTROL:')
print('  trigger a deliberate panic ON ANDROID and see whether pstore records it.')
print('  If Android cannot record its own panic, we cannot expect to record ours.')

"""Non-panic Android marker/reboot/read-back control; never writes partitions."""
import hashlib
import json
import pathlib
import subprocess
import sys
import tarfile
import time
import uuid

ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT = ROOT / 'out/ramoops-retention-control-20261012'
OUT.mkdir(exist_ok=True)
ADB = r'C:\platform-tools\adb.exe'
SERIAL = 'bc7a542e'
PARTS = [p + '_' + s for s in ('a', 'b') for p in ('boot', 'vendor_boot', 'init_boot', 'dtbo')]

def root(cmd, timeout=30, binary=False):
    kind = 'exec-out' if binary else 'shell'
    return subprocess.run([ADB, '-s', SERIAL, kind, "su -c '" + cmd + "'"], capture_output=True, timeout=timeout)

def capture(name, cmd, binary=False):
    p = root(cmd, binary=binary)
    (OUT / name).write_bytes(p.stdout)
    (OUT / (name + '.stderr')).write_bytes(p.stderr)
    return p

def hashes(data):
    return {line.split()[1].rsplit('/', 1)[1]: line.split()[0] for line in data.decode().splitlines() if '/dev/block/by-name/' in line}

def snapshot(prefix):
    cmd = 'getprop ro.boot.slot_suffix; getprop sys.boot_completed; cat /proc/sys/kernel/random/boot_id; cat /proc/version; cat /proc/uptime; sha256sum ' + ' '.join('/dev/block/by-name/' + p for p in PARTS)
    p = capture(prefix + '-state.txt', cmd)
    p.check_returncode()
    params = capture(prefix + '-ramoops.txt', 'for f in /sys/module/ramoops/parameters/*; do echo PARAM:$f; cat "$f"; done; echo DRIVER; ls -la /sys/bus/platform/drivers/ramoops/; echo RESOURCE; cat /sys/devices/platform/reserved-memory:ramoops_region/resource 2>/dev/null; echo INTERFACES; ls -l /dev/pmsg0 /dev/kmsg /dev/mem; echo PSTORE; cat /proc/mounts | grep pstore; ls -la /sys/fs/pstore; echo KERNEL_MESSAGES; dmesg | grep -i -E "ramoops|pstore"')
    capture(prefix + '-fdt.dtb', 'cat /sys/firmware/fdt', binary=True).check_returncode()
    capture(prefix + '-pstore.tar', 'tar -cf - -C /sys/fs/pstore .', binary=True).check_returncode()
    capture(prefix + '-cleanup.txt', 'grep -rn -E "pstore|ramoops|pmsg" /system/etc/init /vendor/etc/init /odm/etc/init /system_ext/etc/init 2>/dev/null | head -120')
    capture(prefix + '-backend.txt', 'echo PSTORE_PARAMETERS; for f in /sys/module/pstore/parameters/*; do echo PARAM:$f; cat "$f"; done; echo PSTORE_DEBUG; ls -la /sys/kernel/debug/pstore; echo ANDROID_COPY; ls -l /data/debugging/last_kmsg.txt; echo BOOT_MESSAGES; dmesg | head -180')
    return p.stdout, params.stdout

def main(mode):
    if mode == 'preflight':
        assert not (OUT / 'preflight.json').exists(), 'preserve existing experiment'
        status, params = snapshot('before')
        assert status.decode().splitlines()[:2] == ['_a', '1']
        assert len(hashes(status)) == 8
        evidence = {'marker': 'PJA110_RAMOOPS_RETENTION_' + uuid.uuid4().hex, 'boot_id_before': status.decode().splitlines()[2], 'partition_hashes_before': hashes(status), 'kernel_before': status.decode().splitlines()[3], 'control_kernel': 'current working Android A kernel, not an unmodified stock kernel'}
        (OUT / 'preflight.json').write_text(json.dumps(evidence, indent=2) + '\n')
        print(params.decode(errors='replace'))
        print(json.dumps(evidence, indent=2))
    elif mode == 'write-reboot':
        e = json.loads((OUT / 'preflight.json').read_text())
        assert not (OUT / 'write-and-reboot-started.txt').exists(), 'do not repeat marker/reboot'
        p = root('getprop ro.boot.slot_suffix; cat /proc/sys/kernel/random/boot_id; test -c /dev/pmsg0; test -c /dev/kmsg')
        p.check_returncode()
        assert p.stdout.decode().splitlines()[:2] == ['_a', e['boot_id_before']]
        m = e['marker']
        # Use supported kernel interfaces, never arbitrary physical-memory writes.
        p = capture('marker-write.txt', 'echo ' + m + '_PMSG > /dev/pmsg0; echo PMSG_WRITE_EXIT:$?; echo "<0>' + m + '_CONSOLE" > /dev/kmsg; echo KMSG_WRITE_EXIT:$?; dmesg | grep ' + m)
        p.check_returncode()
        assert b'PMSG_WRITE_EXIT:0' in p.stdout and b'KMSG_WRITE_EXIT:0' in p.stdout and (m + '_CONSOLE').encode() in p.stdout
        (OUT / 'write-and-reboot-started.txt').write_text(time.strftime('%Y-%m-%dT%H:%M:%S%z'))
        print(p.stdout.decode(), flush=True)
        p = subprocess.run([ADB, '-s', SERIAL, 'reboot'], capture_output=True, timeout=15)
        (OUT / 'reboot-output.txt').write_bytes(p.stdout + p.stderr)
        p.check_returncode()
        start = time.monotonic()
        seen = set()
        completed = False
        with (OUT / 'watch.jsonl').open('w') as log:
            while time.monotonic() - start < 150:
                try:
                    p = root('getprop sys.boot_completed; cat /proc/sys/kernel/random/boot_id; ls -1 /sys/fs/pstore', timeout=4)
                    lines = p.stdout.decode(errors='replace').splitlines()
                    new_boot = len(lines) > 1 and lines[1] != e['boot_id_before']
                    log.write(json.dumps({'seconds': round(time.monotonic()-start, 2), 'exit': p.returncode, 'state': lines}) + '\n')
                    log.flush()
                    if p.returncode == 0 and new_boot:
                        files = tuple(lines[2:])
                        if files and files not in seen:
                            seen.add(files)
                            capture('early-pstore-' + str(len(seen)) + '.tar', 'tar -cf - -C /sys/fs/pstore .', binary=True).check_returncode()
                            print('Early pstore files: ' + repr(files), flush=True)
                        if lines[0] == '1':
                            completed = True
                            break
                except subprocess.TimeoutExpired:
                    log.write(json.dumps({'seconds': round(time.monotonic()-start, 2), 'timeout': True}) + '\n')
                    log.flush()
                time.sleep(0.5)
        print('New Android boot completed: ' + str(completed), flush=True)
        if not completed:
            raise RuntimeError('Android did not complete boot within observation window')
    elif mode == 'collect':
        e = json.loads((OUT / 'preflight.json').read_text())
        status, params = snapshot('after')
        lines = status.decode().splitlines()
        assert lines[:2] == ['_a', '1'] and lines[2] != e['boot_id_before']
        assert hashes(status) == e['partition_hashes_before'], 'partition changed'
        found = []
        for archive in sorted(OUT.glob('*pstore*.tar')):
            with tarfile.open(archive) as t:
                for item in t:
                    if item.isfile():
                        f = t.extractfile(item)
                        data = f.read()
                        if e['marker'].encode() in data:
                            found.append({'archive': archive.name, 'record': item.name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
        result = {'marker': e['marker'], 'marker_written_to_pmsg_and_kmsg': True, 'new_boot_confirmed': True, 'all_eight_partition_hashes_unchanged': True, 'marker_found_in_pstore': bool(found), 'found_records': found, 'control_kernel': e['control_kernel']}
        (OUT / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
        print(params.decode(errors='replace'))
        print(json.dumps(result, indent=2))
    else:
        raise ValueError(mode)

if __name__ == '__main__':
    main(sys.argv[1])

#!/usr/bin/env python3
"""Compare our compiled DTB against the LIVE device tree dumped from the phone.

This is the strongest verification available: /sys/firmware/fdt is the exact
tree the running (vendor) kernel is using, taken from the actual hardware --
stronger than any firmware package we downloaded.

Usage:
    python verify_live.py [path/to/live.dtb]
"""
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fdt import FDT

WS = r'H:\WorkSpace\PJA110-Mainline'


def regions(fdt):
    out = {}
    for path, props in fdt.nodes().items():
        if '/reserved-memory/' not in path + '/':
            continue
        if path.rstrip('/').endswith('/reserved-memory'):
            continue
        leaf = path.split('/')[-1]
        if 'reg' in props and len(props['reg']) == 16:
            b, s = struct.unpack('>QQ', props['reg'])
            if s:
                out[(b, s)] = leaf
    return out


def mem_pairs(fdt):
    for path in ('/memory', '/oplus_mem'):
        props = fdt.nodes().get(path)
        if props and 'reg' in props and len(props['reg']) >= 16:
            reg = props['reg']
            return [struct.unpack_from('>QQ', reg, i) for i in range(0, len(reg), 16)]
    return []


def main():
    live_path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        WS, 'live-from-device.dtb')
    live = FDT(open(live_path, 'rb').read())
    ours_path = os.path.join(WS, 'dts', 'sm8550-oneplus-xigua-16G.dtb')
    ours = FDT(open(ours_path, 'rb').read())

    lr, orr = regions(live), regions(ours)
    print('=== reserved-memory: live device (%d) vs our DTS (%d) ===' % (len(lr), len(orr)))

    missing = sorted(k for k in lr if k not in orr)
    extra = sorted(k for k in orr if k not in lr)

    print('\n-- on device but MISSING from our DTS (%d) --' % len(missing))
    for b, s in missing:
        print('   0x%010x + %-10d (%.1f MiB)  %s' % (b, s, s / 2**20, lr[(b, s)]))
    print('\n-- in our DTS but NOT on device (%d) --' % len(extra))
    for b, s in extra:
        print('   0x%010x + %-10d (%.1f MiB)  %s' % (b, s, s / 2**20, orr[(b, s)]))

    print('\n=== memory map ===')
    lm, om = mem_pairs(live), mem_pairs(ours)
    print('live device: %d regions, %.2f GiB' % (len(lm), sum(s for _b, s in lm) / 2**30))
    for b, s in lm:
        mark = '' if (b, s) in om else '   <-- differs'
        print('   0x%013x + 0x%-12x %8.2f MiB%s' % (b, s, s / 2**20, mark))
    print('our DTS    : %d regions, %.2f GiB' % (len(om), sum(s for _b, s in om) / 2**30))
    for b, s in om:
        mark = '' if (b, s) in lm else '   <-- differs'
        print('   0x%013x + 0x%-12x %8.2f MiB%s' % (b, s, s / 2**20, mark))

    # The device declares rmtfs through the QCOM-private "qcom,sharedmem-uio"
    # binding with a zero base, so it cannot appear in our address-matched set.
    # We reproduce it as a proper upstream rmtfs-mem node instead.
    RMTFS = (0xd4a80000, 0x280000)
    known = [k for k in extra if k == RMTFS]
    real_extra = [k for k in extra if k != RMTFS]
    if known:
        print('\n(rmtfs at 0x%x + 0x%x is EXPECTED: the device uses the private\n'
              ' "qcom,sharedmem-uio" binding with base 0; we use the upstream\n'
              ' rmtfs-mem binding instead. See docs/resmem-worklist.md.)' % RMTFS)

    exact = (not missing and not real_extra and lm == om)
    print('\n*** %s ***' % ('EXACT MATCH with the live device' if exact
                            else 'DIFFERENCES FOUND (see above)'))
    return 0 if exact else 1


if __name__ == '__main__':
    sys.exit(main())

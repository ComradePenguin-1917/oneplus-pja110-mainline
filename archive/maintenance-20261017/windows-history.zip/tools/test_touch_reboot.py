"""Prove a real reboot restores SSH, display and touch without manual modules."""
import json
import subprocess
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/touch-port-20261013'
KEYS=ROOT/'out/usb-ncm-20261013/ssh'
subprocess.run([sys.executable,str(ROOT/'tools/test_display_runtime.py'),'reboot'],check=True,cwd=ROOT)
SSH=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(KEYS/'client_key_host'),
     '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
     '-o',f'UserKnownHostsFile={KEYS/"known_hosts"}','-o','ConnectTimeout=5','root@169.254.42.1']
p=subprocess.run(SSH+['uname -a; cat /tmp/touch-init.log; cat /proc/bus/input/devices; dmesg'],capture_output=True,check=True,timeout=30)
(OUT/'autostart-reboot-state.txt').write_bytes(p.stdout)
assert b'#14 SMP' in p.stdout and b'S3910 touch modules loaded' in p.stdout
assert b'PJA110 Synaptics S3910' in p.stdout and b'PJA_TOUCH input enabled:' in p.stdout
result=json.loads((ROOT/'out/display-port-20261013/runtime-validation/reboot-result.json').read_text())
assert result['boot_id_changed'] and result['automatic_ssh_returned']
result.update(automatic_touch_after_reboot=True,manual_touch_module_loading=False)
(OUT/'autostart-reboot-result.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS: real reboot restored SSH, display initialization and automatic S3910 input',flush=True)

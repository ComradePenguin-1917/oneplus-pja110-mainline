"""Stage and compare Phoc builds in the disposable phone rootfs only."""
from pathlib import Path
import subprocess
import sys
import json
import hashlib
import shlex
import time

sys.stdout.reconfigure(encoding='utf-8')
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'out/phoc-atomic-fix-20261016'
KEYS = ROOT/'out/usb-ncm-20261013/ssh'
SSH = ['C:/Windows/System32/OpenSSH/ssh.exe', '-F', 'none', '-T', '-i', str(KEYS/'client_key_host'),
       '-o', 'BatchMode=yes', '-o', 'IdentitiesOnly=yes', '-o', 'StrictHostKeyChecking=yes',
       '-o', f'UserKnownHostsFile={KEYS/"known_hosts"}', '-o', 'ConnectTimeout=8',
       '-o', 'ServerAliveInterval=5', 'root@169.254.42.1']

def run(command, data=None, timeout=60):
    p = subprocess.run(SSH+[command], input=data, capture_output=True, timeout=timeout)
    if p.returncode:
        raise RuntimeError((p.stdout+p.stderr).decode(errors='replace'))
    return p.stdout

def stage_build(name):
    assert name in ('cursor', 'baseline')
    return run(f'''set -e
r=/tmp/postmarketos-ram
b="$r/tmp/phoc-build/phoc/_build"
p="$r/opt/phoc-{name}"
mkdir -p "$p/bin" "$p/lib"
cp "$b/src/phoc" "$p/bin/phoc"
cp "$b/subprojects/wlroots-0.20.x/libwlroots-0.20.so" "$p/lib/"
sha256sum "$p/bin/phoc" "$p/lib/libwlroots-0.20.so"
chroot "$r" /usr/bin/env LD_LIBRARY_PATH=/opt/phoc-{name}/lib /opt/phoc-{name}/bin/phoc --version
''')

def inspect():
    return run('''cat /proc/sys/kernel/random/boot_id
cat /sys/module/drm/parameters/debug
test ! -e /sys/kernel/tracing/instances/pja_phoc/tracing_on || cat /sys/kernel/tracing/instances/pja_phoc/tracing_on
for p in /proc/[0-9]*; do
 test "$(cat "$p/comm" 2>/dev/null)" = phoc || continue
 test "$(readlink "$p/root")" = /tmp/postmarketos-ram || continue
 echo "PHOC_PID=${p##*/}"
 readlink "$p/exe"
 tr '\\0' '\\n' < "$p/environ" | grep -E 'WLR_|LD_LIBRARY_PATH' || true
 grep -E 'libwlroots|/opt/phoc' "$p/maps" | head -n 10
done
test ! -f /tmp/pmos-phosh.log || tail -n 25 /tmp/pmos-phosh.log
if test -f /sys/kernel/debug/dri/0/gpu; then
grep -E 'gpu-initialized|revision:|last-fence:|retired-fence:|rbbm-status:' /sys/kernel/debug/dri/0/gpu
fi
''')

def switch(name):
    assert name in ('cursor', 'baseline', 'legacy', 'apk')
    stamp = str(int(time.time()))
    before = inspect()
    (OUT/f'before-{name}-{stamp}.txt').write_bytes(before)
    (OUT/f'previous-{name}-{stamp}.log').write_bytes(run('if test -f /tmp/pmos-phosh.log; then cat /tmp/pmos-phosh.log; fi'))
    run('''set -e
for p in /proc/[0-9]*; do
 test "$(cat "$p/comm" 2>/dev/null)" = phoc || continue
 test "$(readlink "$p/root")" = /tmp/postmarketos-ram || continue
 kill -TERM "${p##*/}"
done
''')
    for _ in range(20):
        left = run('''for p in /proc/[0-9]*; do
 test "$(cat "$p/comm" 2>/dev/null)" = phoc || continue
 test "$(readlink "$p/root")" = /tmp/postmarketos-ram || continue
 echo "${p##*/}"
done''').strip()
        if not left:
            break
        time.sleep(.5)
    else:
        raise RuntimeError('Previous compositor did not exit; refusing duplicate')
    options = ('WLR_DRM_NO_ATOMIC=1 ' if name == 'legacy' else '' if name == 'apk'
               else f'LD_LIBRARY_PATH=/opt/phoc-{name}/lib ')
    binary = '/usr/bin/phoc' if name in ('legacy', 'apk') else f'/opt/phoc-{name}/bin/phoc'
    command = ('chroot /tmp/postmarketos-ram /usr/bin/env '+options+
               'XDG_RUNTIME_DIR=/run/user/0 XDG_SESSION_TYPE=wayland XDG_CURRENT_DESKTOP=Phosh:GNOME '
               'LIBSEAT_BACKEND=seatd WLR_BACKENDS=drm,libinput MESA_LOADER_DRIVER_OVERRIDE=msm '
               f"/usr/bin/dbus-run-session -- {binary} -v -S -C /etc/phosh/phoc.ini -E '/usr/libexec/phosh -U'")
    print(run('echo 1024 > /sys/class/backlight/ae94000.dsi.0/brightness\nnohup sh -c '+
              shlex.quote(command)+' > /tmp/pmos-phosh.log 2>&1 < /dev/null & echo $!').decode())
    time.sleep(8)
    result = inspect()
    (OUT/f'launch-{name}-{stamp}.txt').write_bytes(result)
    if b'PHOC_PID=' not in result or b'Phosh ready' not in run('cat /tmp/pmos-phosh.log'):
        if name == 'apk':
            switch('cursor')
        elif name != 'legacy':
            switch('legacy')
        raise RuntimeError('Candidate startup failed; fallback attempted')
    boot_id = run('cat /proc/sys/kernel/random/boot_id').decode().strip()
    (OUT/'active-candidate.json').write_text(json.dumps({'candidate': name, 'timestamp': stamp, 'boot_id': boot_id}, indent=2)+'\n')
    print(result.decode())

stage = sys.argv[1]
if stage == 'stage':
    result = stage_build('cursor')
    (OUT/'staged-cursor.txt').write_bytes(result)
    print(result.decode())
elif stage == 'restore':
    expected = {'bin/phoc': 'e4ab1e4c8058b39baf92ff10606b91097cf46d3f98c2fc9c4969406e6bef6318',
                'lib/libwlroots-0.20.so': '752a6c616cb18f235b4d5989984e5bace73c7e02dab55795ffd9db45f2f93c94'}
    run('test -f /tmp/postmarketos-ram/etc/os-release; mkdir -p /tmp/postmarketos-ram/opt/phoc-cursor/bin /tmp/postmarketos-ram/opt/phoc-cursor/lib /tmp/postmarketos-ram/etc/phosh')
    for relative, digest in expected.items():
        data = (OUT/'artifacts/cursor'/relative).read_bytes()
        assert hashlib.sha256(data).hexdigest() == digest
        target = '/tmp/postmarketos-ram/opt/phoc-cursor/'+relative
        run('cat > '+target, data)
        assert run('sha256sum '+target).decode().split()[0] == digest
    run('chmod 755 /tmp/postmarketos-ram/opt/phoc-cursor/bin/phoc')
    run('cat > /tmp/postmarketos-ram/etc/phosh/phoc.ini', b'[output:DSI-1]\nscale = 2.5\n')
    if run('test -e /tmp/postmarketos-ram/usr/lib/libxcb-errors.so.0 && echo present || true').strip() != b'present':
        digest = '418e34bb08834fbfe3db9ec98588c8befd4baf5c906d7f9c1e357b971fbd275f'
        dependency = OUT/'repository-cache'/(digest+'-xcb-util-errors-1.0.1-r0.apk')
        data = dependency.read_bytes()
        assert hashlib.sha256(data).hexdigest() == digest
        run('cat > /tmp/postmarketos-ram/tmp/xcb-util-errors.apk', data)
        print(run("chroot /tmp/postmarketos-ram /bin/sh -ec 'apk verify /tmp/xcb-util-errors.apk; apk add --no-network /tmp/xcb-util-errors.apk'").decode())
    print(run('chroot /tmp/postmarketos-ram /usr/bin/env LD_LIBRARY_PATH=/opt/phoc-cursor/lib /opt/phoc-cursor/bin/phoc --version').decode())
    print('Saved candidate restored and both SHA256 hashes verified')
elif stage == 'baseline':
    original = (ROOT/'out/phoc-commit-20261015/source/wlroots-atomic.c').read_bytes()
    run('cat > /tmp/postmarketos-ram/tmp/phoc-build/atomic-upstream.c', original)
    data = run('''chroot /tmp/postmarketos-ram /bin/sh -ec '
cd /tmp/phoc-build/phoc
cp subprojects/wlroots-0.20.x/backend/drm/atomic.c /tmp/phoc-build/atomic-patched.c
trap "cp /tmp/phoc-build/atomic-patched.c subprojects/wlroots-0.20.x/backend/drm/atomic.c" EXIT
cp /tmp/phoc-build/atomic-upstream.c subprojects/wlroots-0.20.x/backend/drm/atomic.c
ninja -C _build -j4
mkdir -p /opt/phoc-baseline/bin /opt/phoc-baseline/lib
cp _build/src/phoc /opt/phoc-baseline/bin/phoc
cp _build/subprojects/wlroots-0.20.x/libwlroots-0.20.so /opt/phoc-baseline/lib/
sha256sum /opt/phoc-baseline/bin/phoc /opt/phoc-baseline/lib/libwlroots-0.20.so
cp /tmp/phoc-build/atomic-patched.c subprojects/wlroots-0.20.x/backend/drm/atomic.c
ninja -C _build -j4
' ''', timeout=180)
    (OUT/'baseline-build.log').write_bytes(data)
    print(data.decode()[-3000:])
elif stage == 'switch':
    switch(sys.argv[2])
elif stage == 'status':
    active = json.loads((OUT/'active-candidate.json').read_text())
    if 'boot_id' in active:
        assert run('cat /proc/sys/kernel/random/boot_id').decode().strip() == active['boot_id'], 'Different boot; candidate record is stale'
    log = run('cat /tmp/pmos-phosh.log')
    (OUT/f'{active["candidate"]}-{active["timestamp"]}-session.log').write_bytes(log)
    data = inspect()
    (OUT/f'{active["candidate"]}-{active["timestamp"]}-status.txt').write_bytes(data)
    errors = [line for line in log.decode(errors='replace').splitlines()
              if any(s in line for s in ('Atomic commit failed', 'Page-flip failed', 'Failed to page-flip'))]
    print('Candidate:', active['candidate'], 'display commit errors:', len(errors))
    print('\n'.join(errors[-12:]))
    print(data.decode())
elif stage == 'inspect':
    print(inspect().decode())
elif stage == 'archive':
    for name in ('cursor', 'baseline'):
        for relative in ('bin/phoc', 'lib/libwlroots-0.20.so'):
            dest = OUT/'artifacts'/name/relative
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(run(f'cat /tmp/postmarketos-ram/opt/phoc-{name}/{relative}'))
            print(name, relative, hashlib.sha256(dest.read_bytes()).hexdigest())
    for relative in ('subprojects/wlroots-0.20.x/backend/drm/atomic.c',
                     'subprojects/wlroots-0.20.x/include/backend/drm/drm.h',
                     '_build/meson-info/intro-buildoptions.json', '_build/meson-logs/meson-log.txt'):
        dest = OUT/'built-source'/relative
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(run('cat /tmp/postmarketos-ram/tmp/phoc-build/phoc/'+relative))
    data = run('''cat /sys/kernel/debug/dri/0/state
echo '=== GPU faults ==='
find /sys/devices -path '*gpu*' -name '*fault*' 2>/dev/null
echo '=== Newest kernel errors ==='
dmesg | grep -iE 'gpu.*fault|iommu.*fault|underflow|underrun|hangcheck|recover|gmu.*timeout' | tail -n 15
''')
    (OUT/'runtime-display-state.txt').write_bytes(data)
    print('Build artifacts, sources and display state archived')
else:
    raise SystemExit('stage|baseline|switch cursor/baseline/legacy|status|inspect')

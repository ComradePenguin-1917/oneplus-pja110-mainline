#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
OUT="$WIN/out/buttons-20261013"
TREE="$ROOT/linux"
BUILD="$ROOT/vendor-trikey-module-20261013"
export PATH="$ROOT/toolchain/gcc-12-aarch64/usr/bin:$PATH"
export LD_LIBRARY_PATH="$ROOT/toolchain/gcc-12-aarch64/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu-
mkdir -p "$BUILD"
cp -r "$OUT/vendor-trikey/"* "$BUILD/"
cmp "$TREE/.config" "$WIN/out/display-port-20261013/kernel.config"
sha256sum "$TREE/.config" "$TREE/arch/arm64/boot/Image" > "$OUT/trikey-build-before.sha256"
make -C "$TREE" M="$BUILD" KBUILD_EXTRA_SYMBOLS="$TREE/vmlinux.symvers" -j8 modules > "$OUT/trikey-build.log" 2>&1
mkdir -p "$OUT/trikey-modules"
find "$BUILD" -name '*.ko' -exec cp '{}' "$OUT/trikey-modules/" \;
sha256sum -c "$OUT/trikey-build-before.sha256"
echo 'PASS: official OnePlus tri-key modules compiled for #14; Image/config unchanged'

"""Extract original Kiwi files read-only and obtain upstream WCN7850 firmware."""
from pathlib import Path
import hashlib
import json
import sys
import urllib.request

out = Path('out/wifi-bringup-20261017')
sys.path.insert(0, str(out / 'python'))
from pyfatfs.PyFatFS import PyFatFS

manifest = {}
stock = out / 'stock-kiwi'
stock.mkdir(exist_ok=True)
with PyFatFS(str(out / 'modem-stock.img'), read_only=True) as fs:
    for entry in fs.walk.files('/image/kiwi'):
        data = fs.readbytes(entry)
        target = stock / Path(entry).name
        target.write_bytes(data)
        manifest[str(target)] = dict(source=entry, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
(out / 'stock-firmware-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print('Original Kiwi files extracted:', len(manifest), flush=True)

firmware = out / 'firmware/ath12k/WCN7850/hw2.0'
firmware.mkdir(parents=True, exist_ok=True)
base = 'https://gitlab.com/kernel-firmware/linux-firmware/-/raw/20250311/ath12k/WCN7850/hw2.0/'
for name in ['amss.bin', 'm3.bin', 'board-2.bin']:
    target = firmware / name
    if not target.exists():
        request = urllib.request.Request(base + name, headers={'User-Agent': 'PJA110-mainline-firmware-audit'})
        with urllib.request.urlopen(request, timeout=45) as response:
            data = response.read()
        assert len(data) > 1000 and b'<html' not in data[:100].lower(), name
        target.write_bytes(data)
    data = target.read_bytes()
    manifest[str(target)] = dict(source=base + name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    print(name, len(data), manifest[str(target)]['sha256'], flush=True)
(out / 'firmware-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')

#!/bin/bash
# Properly verify the embedded initramfs.
#
# The previous check searched for gzip magic and required "TRAILER!!!" inside the
# SAME decompressed buffer, which fails because the archive is large and the
# trailer is beyond the 2 MB window I read. Also the kernel may keep the archive
# in .init.ramfs verbatim.
#
# Do it rigorously: locate candidate gzip streams, decompress each fully, and
# look for our markers (busybox + TRAILER!!! + our /init text).
set -uo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
TREE="$ROOT/linux"
cd "$TREE"

echo "=== sizes ==="
echo "  Image          : $(stat -c%s arch/arm64/boot/Image)"
echo "  our initramfs  : $(stat -c%s "$ROOT/initramfs/initramfs.cpio.gz")"
echo "  delta vs before: 34347520 - 33167872 = $((34347520-33167872))"

echo
echo "=== section-level check: is there an .init.ramfs section? ==="
if command -v aarch64-linux-gnu-readelf >/dev/null 2>&1; then
    export PATH="$ROOT/toolchain/gcc-12-aarch64/usr/bin:$PATH"
    export LD_LIBRARY_PATH="$ROOT/toolchain/gcc-12-aarch64/usr/lib/x86_64-linux-gnu:$LD_LIBRARY_PATH"
fi
aarch64-linux-gnu-readelf -S vmlinux 2>/dev/null | grep -iE 'init.ramfs|ramfs' || echo "  (no such section name; checking symbols)"

echo
echo "=== symbol check: __initramfs_start / __initramfs_size ==="
aarch64-linux-gnu-nm vmlinux 2>/dev/null | grep -iE '__initramfs_(start|end|size)' || \
    grep -iE '__initramfs_(start|end|size)' System.map 2>/dev/null || echo "  (symbols not found)"

echo
echo "=== exhaustive gzip-stream scan of Image ==="
python3 - <<'PY'
import gzip, io, os, re

d = open('arch/arm64/boot/Image','rb').read()
print('  Image bytes: %d' % len(d))

matches = []
for m in re.finditer(rb'\x1f\x8b\x08', d):
    off = m.start()
    # try to decompress the whole remainder
    buf = io.BytesIO(d[off:])
    try:
        gz = gzip.GzipFile(fileobj=buf)
        chunk = gz.read()
    except Exception:
        continue
    if len(chunk) < 100000:
        continue
    has_busybox = b'busybox' in chunk
    has_trailer = b'TRAILER!!!' in chunk
    has_init = b'[initramfs]' in chunk
    if has_busybox or has_trailer:
        print('  candidate @0x%08x: decompressed=%d busybox=%s trailer=%s our_init=%s'
              % (off, len(chunk), has_busybox, has_trailer, has_init))
        matches.append(off)

print()
print('  matching streams: %d' % len(matches))
print('  VERDICT: %s' % ('initramfs IS embedded' if matches else 'NOT FOUND'))
PY

echo
echo "=== cross-check: does the archive we packed contain our banner? ==="
zcat "$ROOT/initramfs/initramfs.cpio.gz" 2>/dev/null | strings | grep -m3 'initramfs' | sed 's/^/  /'

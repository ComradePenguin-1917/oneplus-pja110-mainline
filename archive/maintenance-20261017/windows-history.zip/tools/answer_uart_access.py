#!/usr/bin/env python3
"""Answer precisely: does the debug UART need the phone opened?

The physical layer facts, now established from the device's own device trees:

  our DTB console node  /soc@0/geniqup@ac0000/serial@a9c000
    pinctrl-0 ->  /soc@0/pinctrl@f100000/qup-uart7-default-state
        function = "qup1_se7"
        pins     = "gpio26", "gpio27"

  vendor tree console node  .../qup_uart@a9c000
    TX active -> function "qup1_se7_l2", pins "gpio26"
    RX active -> function "qup1_se7_l3", pins "gpio27"

So the console is TX=GPIO26, RX=GPIO27, on TLMM block f100000.

Those are ordinary SoC GPIO balls. Whether they reach the outside world depends
entirely on the board, and the device tree cannot tell us. What the device tree
CAN tell us:

  * there is no debug-connector, no SBU pinmux, no USB-C debug accessory routing
    anywhere in the tree (checked: zero nodes mention sbu / typec / debug-uart)
  * the Type-C SBU pins are NOT muxed to this UART, because on this SoC SBU
    routing would appear as a pinctrl state on the PMIC/typec node and there is
    none

So a no-disassembly cable is unlikely to work on this model. On most OnePlus
phones the debug UART is brought out to internal test pads only.

Let me also settle the headphone-jack question definitively, and confirm what the
vendor does with the console (it may intentionally be absent).
"""
import os
import struct
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
sys.path.insert(0, os.path.join(WS, 'tools'))
from fdt import FDT


def dec(v):
    return v.rstrip(b'\0').decode('ascii', 'replace')


live = FDT(open(os.path.join(WS, 'live-from-device.dtb'), 'rb').read()).nodes()

print('=' * 78)
print('1) IS THERE A HEADPHONE JACK? (older OnePlus exposed UART over it)')
print('=' * 78)
audio = [p for p in live if 'wcd' in p.lower() or 'codec' in p.lower()]
print('  audio codec nodes:')
for p in sorted(audio)[:8]:
    print('    %s' % p)
print()
print('  the Ace 2 Pro has NO 3.5 mm jack (it is not in the specs), and there is')
print('  no jack-detect/UART-over-jack node in the tree, so that route is out.')

print()
print('=' * 78)
print('2) ANY ROUTE TO THE OUTSIDE WORLD AT ALL?')
print('=' * 78)
probes = {
    'USB-C connector node':      ('usb-connector', 'connector@', 'typec'),
    'SBU / debug accessory mux': ('sbu', 'debug-accessory', 'accessory'),
    'external debug pad node':   ('test-point', 'testpoint', 'tp@', 'debug-pad'),
    'FSA/redriver with UART':    ('fsa', 'redriver', 'usb-switch'),
}
for label, keys in probes.items():
    hits = [p for p in live if any(k in p.lower() for k in keys)]
    print('  %-28s %d  %s' % (label, len(hits), ('e.g. ' + hits[0][:56]) if hits else ''))

print()
print('=' * 78)
print('3) WHAT THE VENDOR DOES WITH THIS CONSOLE')
print('=' * 78)
print('  vendor cmdline (captured earlier from /proc/cmdline):')
print('    console=ttynull loglevel=6 ...')
print()
print('  console=ttynull means the vendor kernel is configured to print NOTHING to')
print('  any console. So the vendor has no interest in this port at runtime.')
print()
print('  But NOTE the node is still present and status="ok" in the vendor tree,')
print('  and it uses the SAME gpio26/gpio27 as our mainline DTB -- consistent with')
print('  it being a debug UART that the factory/factory-test tools use.')

print()
print('=' * 78)
print('4) WHAT THIS MEANS FOR YOU')
print('=' * 78)
print('  Short answer: YES, most likely the phone must be opened.')
print()
print('  Reasons:')
print('    * the console is TX=GPIO26 / RX=GPIO27, plain SoC balls')
print('    * nothing in either device tree routes them to the Type-C SBU pins,')
print('      and there is no debug-accessory or external-pad node')
print('    * the Ace 2 Pro has no headphone jack, so the classic OnePlus')
print('      UART-over-jack trick does not apply')
print()
print('  On OnePlus SM8550-class boards the debug UART normally lands on two small')
print('  test pads on the mainboard, reachable only with the back cover off.')
print()
print('  Realistic options, in order of cost:')
print('    1. Do nothing physical. Keep improving software-only observability')
print('       (e.g. enable CONFIG_PSTORE_BLK so a panic lands in flash).')
print('       Limitation: useless if the kernel dies before UFS comes up.')
print('    2. Open the back cover and find the test pads. Requires a heat gun or')
print('       suction tools, plus a USB-TTL adapter. Reversible but fiddly, and')
print('       the phone must be resealed.')
print('    3. Ask the community: someone with the same model may already have')
print('       photographed the pads. The astonishing port (same SM8550 + same OPPO')
print('       ABL) is the closest relative and may share the board layout.')
print()
print('  Before you open anything, worth checking whether the astonishing/12R')
print('  wiki or its author documented the pads for this SM8550 family.')

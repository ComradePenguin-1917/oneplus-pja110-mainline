"""Best-effort reversible QRTR module test; never prompts or writes hardware."""
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
scope = {'__file__': str(ROOT / 'tools/check_battery_runtime.py')}
exec((ROOT / 'tools/check_battery_runtime.py').read_text().split('state = run(')[0], scope)
ssh = scope['SSH']
cmd = r'''set -u
echo BEFORE_MODULES
cat /proc/modules | grep -E '^(qrtr|qrtr_smd) ' || true
echo LOAD_RESULT
sudo -n modprobe qrtr 2>&1; echo qrtr=$?
sudo -n modprobe qrtr-smd 2>&1; echo qrtr_smd=$?
sleep 2
echo AFTER_MODULES
cat /proc/modules | grep -E '^(qrtr|qrtr_smd) ' || true
echo SUPPLIES
ls -1 /sys/class/power_supply
echo AUXILIARY_DETAIL
for p in /sys/bus/auxiliary/devices/pmic_glink*; do
  test -e "$p" || continue
  echo DEVICE "$p"
  readlink -f "$p/driver" || true
  cat "$p/uevent" 2>/dev/null || true
done
echo AUXILIARY_DRIVERS
ls -ld /sys/bus/auxiliary/drivers/pmic_glink* 2>&1 || true
echo DEFERRED
sudo -n cat /sys/kernel/debug/devices_deferred 2>&1 || true
echo LOG
journalctl -b -k --no-pager -n 120 2>&1 | grep -Ei 'pmic-glink|pdr|qrtr|usb|power.supply|charger' || true
echo END_QRTR_TEST'''
out = ROOT / 'out/battery-bringup-20261016' / ('qrtr-live-' + time.strftime('%Y%m%d-%H%M%S') + '.txt')
p = subprocess.run(ssh + [cmd], capture_output=True, timeout=18)
out.write_bytes(p.stdout + p.stderr)
print((p.stdout + p.stderr).decode(errors='replace'), end='')
print(f'Host result: {out}\nSSH exit: {p.returncode}')
if b'END_QRTR_TEST' not in p.stdout:
    raise SystemExit(2)

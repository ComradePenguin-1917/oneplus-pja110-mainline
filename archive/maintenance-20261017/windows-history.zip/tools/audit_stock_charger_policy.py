"""Record stock AP charging controls and firmware GET evidence, offline only."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
CACHE = ROOT / 'out/battery-bringup-20261016/charger-source'
OUT = ROOT / 'out/native-install-20261017/charger-policy-audit'
OUT.mkdir(exist_ok=True)
source = (CACHE / 'oplus_battery_sm8550.c').read_text()
header = (CACHE / 'oplus_battery_sm8550.h').read_text()
framework = (CACHE / 'oplus_charger.c').read_text()

def enum(name):
    body = re.search(r'enum ' + name + r'\s*{(.*?)};', header, re.S)[1]
    body = re.sub(r'/\*.*?\*/', '', body, flags=re.S)
    body = re.sub(r'^\s*#.*$', '', body, flags=re.M)
    names = [part.strip() for part in body.split(',') if part.strip()]
    if not all(re.fullmatch(r'\w+', n) for n in names):
        raise ValueError('Unexpected enum syntax')
    # This board enables OPLUS_FEATURE_CHG_BASIC; retain its conditional members.
    return dict(zip(names, range(len(names))))

def function(name):
    match = re.search(r'^static (?:int|bool|void) ' + name +
                      r'\([^;]*?\)\s*\{.*?^}', source, re.M | re.S)
    if not match:
        raise ValueError(name)
    return {'line': source[:match.start()].count('\n') + 1, 'text': match[0]}

battery, usb = enum('battery_property_id'), enum('usb_property_id')
controls = {k: battery[k] for k in (
    'BATT_VOLT_MAX', 'BATT_CHG_CTRL_LIM', 'BATT_CHG_EN',
    'BATT_SET_MATCH_TEMP', 'BATT_SEND_CHG_STATUS')}
controls.update({k: usb[k] for k in ('USB_INPUT_CURR_LIMIT', 'USB_SUSPEND_PMIC')})
functions = {n: function(n) for n in (
    'smbchg_get_charge_enable', 'smbchg_usb_check_suspend_charger',
    'smbchg_float_voltage_set', 'smbchg_set_fastchg_current_raw',
    'oplus_chg_hw_init')}
if 'rc = bcdev->chg_en;' not in functions['smbchg_get_charge_enable']['text']:
    raise ValueError('Charge-enable getter changed')
if 'prop_id, vfloat_mv)' not in functions['smbchg_float_voltage_set']['text']:
    raise ValueError('Float-voltage units changed')
if 'float_voltage_write(flv * chip->vbatt_num)' not in framework:
    raise ValueError('Pack-voltage policy changed')

instructions = {}
for line in (CACHE / 'adsp-charger-analysis-only.dis').read_text().splitlines():
    m = re.match(r'^([0-9a-f]+):', line)
    if m:
        instructions[int(m[1], 16)] = line
expected = {
    0x601a189c: 'cmp.eq(r2,#0x18)',
    0x601a18ac: 'r0 = #0x7',
    0x601a18b4: 'call 0x600ab0e0',
    0x601a197c: 'r2 = memb(r30+#-0xb)',
    0x601a1980: 'cmp.eq(r2,#0x1)',
    0x601a1988: 'memw(r2+#0x0) = r3',
    0x600ab1e4: 'r2 = memw(r2+#0x34)',
    0x601a2d04: 'call 0x6002ce40',
    0x6002ce5c: 'memw(##0x602a8848)',
    0x6002ce7c: 'callr r2',
}
for address, fragment in expected.items():
    if fragment not in instructions[address]:
        raise ValueError(hex(address))
result = subprocess.run([
    sys.executable, str(ROOT / 'tools/inspect_adsp_disassembly.py'),
    '601a1820:601a1a50', '600ab0e0:600ab2a0',
    '601a2cb0:601a2d20', '6002ce40:6002cf34',
], capture_output=True, check=True)
(OUT / 'charger-get-annotated.dis').write_bytes(result.stdout)
report = {
    'scope': 'cached factory source and firmware; no phone writes',
    'firmware_b18_sha256': hashlib.sha256(
        (CACHE / 'firmware/qcom/sm8550/xigua/adsp.b18').read_bytes()).hexdigest(),
    'source_sha256': hashlib.sha256(source.encode()).hexdigest(),
    'property_ids': controls,
    'source_functions': functions,
    'units': {
        'usb_icl_set': 'microamperes; factory helper multiplies mA by 1000',
        'battery_fcc_set': 'microamperes; independent of USB ICL',
        'battery_float_set': 'millivolts at factory HAL; non-bidirectional path multiplies per-cell value by vbatt_num',
        'matched_temp_set': 'deci-degrees Celsius',
    },
    'stock_enable_getter': 'AP cache only, not hardware readback',
    'firmware_enable_getter': 'property 24 -> PmSchgChgr_GetEnableCharging(index 7) -> registered backend; converts returned byte == 1 to boolean',
    'firmware_usb_getter': 'delegates to platform callback; USB_SUSPEND_PMIC semantics established by AP source, actual backend still unresolved',
    'firmware_evidence': {hex(a): instructions[a] for a in expected},
    'next_readonly_diagnostic': {
        'priority': 'battery property 24 hardware-enable GET',
        'requires': 'validated request/response and result code; existing request mutex',
        'additional_candidates': 'USB property 29 suspend and battery property 10 FCC; resolve backend semantics first',
    },
    'not_proven': [
        'Runtime charger-enable or suspend state',
        'Winning FCC/ICL votes and source negotiation',
        'Sustained charging on a wall adapter',
        'Complete AP thermal and charge-termination policy',
    ],
    'phone_modified': False,
}
(OUT / 'audit.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'property_ids': controls,
                  'enable_get': report['firmware_enable_getter'],
                  'phone_modified': False}, indent=2))

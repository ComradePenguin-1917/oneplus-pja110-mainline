"""Read-only inventory of ADC support in the actual A build tree."""
from pathlib import Path
tree = Path.home() / 'workspace/PJA110-Mainline/charger-native-a/linux-6.14'
p = tree / 'drivers/iio/adc/qcom-spmi-adc5.c'
for n, line in enumerate(p.read_text().splitlines(), 1):
    if 'compatible' in line or 'gen3' in line.lower():
        print(f'{p.name}:{n}: {line}')
print('GEN3_FILES', [str(p.relative_to(tree)) for p in tree.rglob('*adc*gen3*')])

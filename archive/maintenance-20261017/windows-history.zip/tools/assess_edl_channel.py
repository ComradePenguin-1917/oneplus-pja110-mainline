#!/usr/bin/env python3
"""Assess EDL/9008 as an observation channel -- BEFORE investing in it.

The question: can 9008 read our kernel's crash output out of RAM?

Why this could work where everything else failed
------------------------------------------------
Every other channel needed either a driver (USB/display) or a booting rootfs.
EDL is different: the PBL/XBL boot ROM path is alive whenever the phone is in
9008, and a firehose "programmer" runs on the SoC with the ability to READ
arbitrary physical memory (edl peek / memorydump). No kernel drivers involved.

If our kernel panics, its log is sitting in RAM. If the phone is then forced into
9008 WITHOUT a full power cycle, that RAM content may still be readable.

Critical unknowns to resolve before relying on this
---------------------------------------------------
1. Does a full 9008 entry preserve RAM?
   Entering EDL normally involves the PBL re-running, which can re-initialise
   DDR. If DDR is retrained, RAM contents are lost -> channel useless.
   BUT there is a crash-into-EDL path: if the kernel/ABL crashes, the SoC may
   enter EDL *without* a DDR re-init. That is the case that matters.

2. Does our device's firehose programmer allow peek/memorydump?
   `peek` requires the programmer to expose the memory-debug commands; many
   signed production programmers disable them. This is the make-or-break check.

3. Is a programmer even available for SM8550 / this device?
   The OTA package we have does not include one, so it must be obtained.

This script gathers what can be established locally, and lays out the go/no-go
test that answers (2) in one shot.
"""
import os
import shutil
import subprocess
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'

print('=' * 78)
print('1) WHAT WE ALREADY KNOW ABOUT THIS DEVICE IN 9008')
print('=' * 78)
print('  * the phone HAS successfully entered EDL 9008 during this project')
print('    (used twice to recover from a hung fastboot screen)')
print('  * that means the 9008 path works and the USB descriptor is reachable')
print('  * recovery procedure used: three-key combo -> 9008 -> power 20 s')
print()
print('  => the transport is proven. What is NOT proven is whether the')
print('     programmer for this SoC exposes memory read commands.')

print()
print('=' * 78)
print('2) WHAT IS MISSING LOCALLY')
print('=' * 78)
need = {
    'firehose programmer (prog_firehose_ddr.elf)': None,
    'edl tool (bkerler)': None,
    'libusb / UsbDk driver': None,
}
found = {}
for pat in ('prog_firehose_ddr.elf', 'prog_firehose*.elf', '*.mbn',
            'firehose*.elf', 'prog_ufs*.elf'):
    for root, dirs, files in os.walk(WS):
        if '.git' in root or 'linux' in root.split(os.sep):
            continue
        for f in files:
            if f.endswith(('.elf', '.mbn')) and 'prog' in f.lower():
                found.setdefault('programmer', []).append(os.path.join(root, f))
print('  programmer files found: %s' % (found.get('programmer') or 'NONE'))
print()
print('  The OTA payload we have carries: xbl, abl, uefi, boot, vendor_boot, dtbo,')
print('  logfs, xbl_config. A firehose programmer is NOT among them -- it is')
print('  normally shipped separately (in the vendor flash tool / QFIL package).')

print()
print('=' * 78)
print('3) GO / NO-GO TEST (one shot, answers the make-or-break question)')
print('=' * 78)
print('  Step 1: obtain a programmer for SM8550 (prog_firehose_ddr.elf).')
print('  Step 2: put the phone in 9008 and run:')
print()
print('            edl printgpt --memory=ufs --lun=0')
print()
print('          If this succeeds, a programmer works at all.')
print()
print('  Step 3: the decisive check -- does it allow READS?')
print()
print('            edl peekhex 0x80000000 0x40')
print()
print('          ACK with real bytes -> memory read works -> the channel is viable')
print('          NAK / unsupported   -> programmer forbids it -> dead end')
print()
print('  Step 4 (if step 3 works): the actual experiment')
print('            a) boot our kernel, let it fail')
print('            b) WITHOUT full power-off, force 9008 via the key combo')
print('            c) edl peek / memorydump the kernel log buffer region')
print()
print('  Caveat that decides success: entering 9008 usually re-runs the boot ROM')
print('  and may retrain DDR, which would erase the very RAM we want. So step 4')
print('  only works if the crash path leaves DDR initialised. That is testable:')
print('  peek a location, reboot, peek again -- if contents persist, RAM survives.')

print()
print('=' * 78)
print('4) HONEST ASSESSMENT')
print('=' * 78)
print('  Pros: no drivers, no rootfs, no cable to solder; transport already proven')
print('  Cons: needs a programmer we do not have, and memory-read support is')
print('        uncertain; and DDR re-init on 9008 entry may erase the evidence')
print()
print('  So this is worth ONE cheap probe (step 3) once a programmer is in hand,')
print('  but it is NOT something to build a lot on before that probe returns ACK.')
print()
print('  Source for the tool: https://github.com/bkerler/edl')
print('    - its README documents `edl peek`, `edl memorydump`, and states it was')
print('      tested on OnePlus/OPPO SM8550 devices.')
print('    - Windows needs the UsbDk driver for raw USB access to 9008.')

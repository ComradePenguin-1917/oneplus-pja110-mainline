param([ValidateSet('full-speed','high-speed')][string]$Speed='full-speed')
$ErrorActionPreference='Stop'
$root=$PWD.Path
$target=Join-Path $root "out/usb-serial-reliability-diag-20261013/speed-$Speed"
[IO.Directory]::CreateDirectory($target) | Out-Null
$script=@'
#!/bin/sh
sleep 2
g=/sys/kernel/config/usb_gadget/g1
controller=$(cat "$g/UDC")
[ -n "$controller" ] || exit 1
printf '\n' > "$g/UDC" || exit 2
sleep 1
echo SPEED_PLACEHOLDER > "$g/max_speed" || exit 3
echo "$controller" > "$g/UDC" || exit 4
sleep 1
setsid sh -c 'stty -F /dev/ttyGS0 115200 raw -echo; exec sh -i </dev/ttyGS0 >/dev/ttyGS0 2>&1' &
echo SPEED_READY
'@
$script=$script.Replace('SPEED_PLACEHOLDER',$Speed).Replace("`r",'')+"`n"
$bytes=[Text.Encoding]::ASCII.GetBytes($script)
[IO.File]::WriteAllBytes((Join-Path $target 'speed-control.sh'),$bytes)
$encoded=[Convert]::ToBase64String($bytes)
$command="printf '%s' '$encoded' | base64 -d > /tmp/usb-speed-control.sh; sha256sum /tmp/usb-speed-control.sh"
& "$root/tools/test_usb_serial_reliability.ps1" -ReadMode Async -OutputDirectory "$target/upload" -CommandOnly $command
$reply=[IO.File]::ReadAllText((Join-Path $target 'upload/control-Async.txt'))
$digest=[regex]::Match($reply,'(?m)^([0-9a-f]{64})\s+/tmp/usb-speed-control.sh')
$expected=(Get-FileHash -Algorithm SHA256 (Join-Path $target 'speed-control.sh')).Hash.ToLowerInvariant()
if(-not $digest.Success -or $digest.Groups[1].Value -ne $expected){throw 'Uploaded speed control script SHA256 mismatch'}
& "$root/tools/test_usb_serial_reliability.ps1" -ReadMode Async -OutputDirectory "$target/start-retry" -CommandOnly 'setsid sh /tmp/usb-speed-control.sh >/tmp/usb-speed-control.log 2>&1 & true'
Write-Output "Verified and scheduled $Speed control; gadget will disconnect briefly and reopen shell"

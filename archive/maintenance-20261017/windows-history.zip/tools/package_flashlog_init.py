"""Use the same tested kernel/USB2 DTB with an external flash-journal init."""
import hashlib
import json
import pathlib
import shutil
import struct
import sys

from build_init_marker_test import parse_cpio, make_entry, lz4

ROOT=pathlib.Path(__file__).resolve().parents[1]
BASE=ROOT/'out/usb2-control-20261012'
OUT=ROOT/(sys.argv[1] if len(sys.argv)>1 else 'out/mainline-flashlog-20261012')
OUT.mkdir(exist_ok=True)

def sha(b): return hashlib.sha256(b).hexdigest()

def main():
    source=(BASE/'init_boot_b-xigua-r1.img').read_bytes()
    size=struct.unpack_from('<I',source,12)[0]
    raw=lz4(['-d','-l','-c'],source[4096:4096+size])
    entries=parse_cpio(raw)
    base={n[2:] if n.startswith('./') else n:d for _,n,d in entries}
    assert base['init']==(ROOT/'initramfs/init').read_bytes()
    init=base['init']
    anchor=b'mount -t tmpfs none /tmp 2>/dev/null\n'
    assert init.count(anchor)==1
    init=init.replace(anchor,anchor+b'\n/sbin/flashlog --loop > /tmp/flashlog-writer.log 2>&1 &\nFLASHLOG_PID=$!\n',1)
    anchor=b'    # let the log lines settle into any console/pstore first\n'
    assert init.count(anchor)==1
    init=init.replace(anchor,b'    # Finish the bounded storage probe before the existing poweroff fallback.\n    wait "$FLASHLOG_PID" 2>/dev/null\n\n'+anchor,1)
    (OUT/'init').write_bytes(init)
    writer=(ROOT/'initramfs/flashlog').read_bytes()
    inode=max(f[0] for f,_,_ in entries)+1
    rebuilt=bytearray()
    for fields,name,data in entries:
        plain=name[2:] if name.startswith('./') else name
        if plain=='TRAILER!!!':
            # Insert before trailer; copy /init metadata but use a unique inode.
            f=list(next(f for f,n,d in entries if n in ('init','./init')))
            f[0]=inode; f[1]=0o100755
            rebuilt+=make_entry(f,'sbin/flashlog',writer)
        rebuilt+=make_entry(fields,name,init if plain=='init' else data)
    parsed=parse_cpio(bytes(rebuilt))
    new={n[2:] if n.startswith('./') else n:d for _,n,d in parsed}
    assert len(new)==len(base)+1 and new['init']==init and new['sbin/flashlog']==writer
    assert all(new[n]==d for n,d in base.items() if n!='init')
    assert new['bin/busybox']==(ROOT/'out/rebuild-20261012/busybox').read_bytes()
    packed=lz4(['-z','-l','-12','-c'],bytes(rebuilt))
    stock=(ROOT/'backup/init_boot_b.img').read_bytes()
    oldsize=struct.unpack_from('<I',stock,12)[0]
    end=4096+(oldsize+4095)//4096*4096
    assert len(packed)<=end-4096
    assert lz4(['-d','-l','-c'],packed)==rebuilt
    image=bytearray(stock)
    struct.pack_into('<I',image,12,len(packed))
    image[4096:end]=packed+b'\0'*(end-4096-len(packed))
    assert len(image)==len(stock) and image[end:]==stock[end:]
    (OUT/'init_boot_b-xigua-r1.img').write_bytes(image)
    for name in ('boot-xigua-r1.img','vendor_boot_b-xigua-r1.img'):
        shutil.copyfile(BASE/name,OUT/name)
        assert (OUT/name).read_bytes()==(BASE/name).read_bytes()
    names=['boot-xigua-r1.img','vendor_boot_b-xigua-r1.img','init_boot_b-xigua-r1.img','init']
    m={'release':'6.14.0-sm8550-xigua-r1','kernel_sha256':'d8ade08069b8440b349f4b4aeb430dd6e9057eca08c94a8268e3708a83e53425','baseline':'USB2 control; same kernel and vendor_boot','external_ramdisk_changes':['init launches flashlog and waits before fallback','sbin/flashlog added; all other cpio content unchanged'],'journal_uuid':'e0653233-1391-74e3-763b-b76a68e705dd','journal_offset':536805376,'journal_bytes':61440,'sentinel_bytes':4096,'files':{n:{'bytes':(OUT/n).stat().st_size,'sha256':sha((OUT/n).read_bytes())} for n in names}}
    (OUT/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
    (OUT/'initramfs.cpio').write_bytes(rebuilt)
    print(json.dumps(m,indent=2))

if __name__=='__main__': main()

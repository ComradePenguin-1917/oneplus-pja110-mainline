"""Look for upstream fixes before changing ath12k hardware RF-kill policy."""
from pathlib import Path
import json
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor

out = Path('out/wifi-bringup-20261017')
query = urllib.parse.quote('repo:torvalds/linux ath12k rfkill')
url = 'https://api.github.com/search/commits?q=' + query + '&per_page=30'
req = urllib.request.Request(url, headers={'User-Agent': 'PJA110-mainline', 'Accept': 'application/vnd.github+json'})
with urllib.request.urlopen(req, timeout=40) as response:
    data = json.load(response)
(out / 'upstream-rfkill-commits.json').write_text(json.dumps(data, indent=2) + '\n')
for item in data.get('items', []):
    print(item['sha'], item['commit']['message'].split('\n')[0])

def fetch_aston(name):
    target = out / ('aston-ath12k-' + name)
    if not target.exists():
        base = ('https://raw.githubusercontent.com/jiganomegsdfdf/aston-mainline/'
                '5d5c840896bb49291ae4578acefd5a3ec65524f6/drivers/net/wireless/ath/ath12k/')
        req = urllib.request.Request(base + name, headers={'User-Agent': 'PJA110-mainline'})
        with urllib.request.urlopen(req, timeout=45) as response:
            target.write_bytes(response.read())
    print('Aston saved:', name)

with ThreadPoolExecutor(max_workers=3) as pool:
    list(pool.map(fetch_aston, ['core.c', 'hw.c', 'mac.c']))

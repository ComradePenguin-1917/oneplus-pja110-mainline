#!/bin/bash
set -u
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
OUT="$WIN/out/pmbootstrap-wsl-probe-20261015"
mkdir -p "$OUT"
{
uname -a
id
for tool in git python3 openssl kpartx losetup mount dmsetup sudo mkfs.ext4 parted; do
 printf '%s: ' "$tool"
 command -v "$tool" || true
done
git --version
python3 --version
losetup --version
python3 -c 'import importlib.util; print("tomli:",bool(importlib.util.find_spec("tomli")))'
ls -l /dev/loop-control /dev/mapper/control
grep -E 'loop|device-mapper' /proc/devices
losetup --list --json
dmsetup version
sudo -n true
printf 'sudo_without_password_exit=%s\n' "$?"
findmnt -T "$ROOT"
findmnt -T /tmp
} > "$OUT/host-probe.txt" 2>&1
cat "$OUT/host-probe.txt"

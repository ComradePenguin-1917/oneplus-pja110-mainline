#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
PREFIX="$ROOT/toolchain/gcc-12-aarch64"
export PATH="$PREFIX/usr/bin:$PATH"
export LD_LIBRARY_PATH="$PREFIX/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
aarch64-linux-gnu-gcc -static -no-pie -O2 -Wall -Wextra "$WIN/tools/mainline_fb_pattern.c" -o "$WIN/out/display-port-20261013/fb-pattern"
aarch64-linux-gnu-gcc -static -no-pie -O2 -Wall -Wextra "$WIN/tools/mainline_panel_vout_test.c" -o "$WIN/out/display-port-20261013/panel-vout-test"
echo 'Built static ARM64 RAM framebuffer color bar tool'

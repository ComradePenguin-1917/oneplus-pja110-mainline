"""Create a RAM-only Ubuntu chroot and validate CLI, Mesa and independent SSH."""
import hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'out/ubuntu-ram-20261014'
KEYS=ROOT/'out/usb-ncm-20261013/ssh'
SSH=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(KEYS/'client_key_host'),
 '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
 '-o',f'UserKnownHostsFile={KEYS/"known_hosts"}','-o','ConnectTimeout=5','root@169.254.42.1']
def checked(cmd,data=None,timeout=120):
 p=subprocess.run(SSH+[cmd],input=data,capture_output=True,timeout=timeout)
 (OUT/'last-stderr.txt').write_bytes(p.stderr);p.check_returncode();return p.stdout
m=json.loads((OUT/'runtime-manifest.json').read_text())
before=checked('uname -a; cat /proc/sys/kernel/random/boot_id; cat /proc/meminfo; cat /proc/mounts')
assert (b'6.14.0-sm8550-xigua-r1' if any(a in sys.argv for a in ('--te-height','--packet2','--trace','--budget')) else b'#18 SMP') in before
(OUT/'phone-before.txt').write_bytes(before)
data=(OUT/m['runtime_file']).read_bytes();assert hashlib.sha256(data).hexdigest()==m['runtime_sha256']
RESUME='--resume' in sys.argv
if not RESUME:
 print('Uploading Ubuntu ARM64 archive to RAM',flush=True)
 assert checked('cat > /tmp/ubuntu-ram-rootfs.tar.gz; sha256sum /tmp/ubuntu-ram-rootfs.tar.gz',data,240).decode().split()[0]==m['runtime_sha256']
script='''set -e
r=/tmp/ubuntu-ram
test ! -e "$r/.pja-ready"
mkdir -p "$r"
tar -xzf /tmp/ubuntu-ram-rootfs.tar.gz -C "$r"
mkdir -p "$r/proc" "$r/sys" "$r/dev" "$r/run" "$r/run/sshd" "$r/run/user/0" "$r/root/.ssh"
chmod 700 "$r/run/user/0" "$r/root/.ssh"
mount --bind /proc "$r/proc"
mount --bind /sys "$r/sys"
mount --bind /dev "$r/dev"
mount --bind /dev/pts "$r/dev/pts"
cp /root/.ssh/authorized_keys "$r/root/.ssh/authorized_keys"
chmod 600 "$r/root/.ssh/authorized_keys"
chroot "$r" /usr/lib/systemd/systemd-udevd --daemon
chroot "$r" /usr/bin/env SYSTEMD_IGNORE_CHROOT=1 /usr/bin/udevadm trigger --action=add --subsystem-match=input
chroot "$r" /usr/bin/env SYSTEMD_IGNORE_CHROOT=1 /usr/bin/udevadm trigger --action=add --subsystem-match=drm
chroot "$r" /usr/bin/env SYSTEMD_IGNORE_CHROOT=1 /usr/bin/udevadm settle
chroot "$r" /usr/bin/ssh-keygen -A
chroot "$r" /bin/sh -c 'cat /etc/os-release; uname -a; /usr/bin/weston --version; /usr/sbin/sshd -t -f /etc/ssh/sshd_config_pja'
chroot "$r" /usr/sbin/sshd -f /etc/ssh/sshd_config_pja -E /run/sshd-ubuntu.log
touch "$r/.pja-ready"
'''
if RESUME:
 script=script[script.index('chroot "$r" /usr/bin/ssh-keygen'):]
 script='set -e\nr=/tmp/ubuntu-ram\n'+script
state=checked(script,timeout=180);(OUT/'ubuntu-state.txt').write_bytes(state);print(state.decode(),flush=True)
egl=checked('chroot /tmp/ubuntu-ram /usr/bin/env XDG_RUNTIME_DIR=/run/user/0 MESA_LOADER_DRIVER_OVERRIDE=msm /usr/local/bin/mesa-offscreen-test',timeout=120)
(OUT/'ubuntu-egl.txt').write_bytes(egl);print(egl.decode(),flush=True)
assert b'120 shader-rendered frames pixel-verified' in egl
host=checked('cat /tmp/ubuntu-ram/etc/ssh/ssh_host_ed25519_key.pub').decode().split()
assert host[0]=='ssh-ed25519' and len(host)>=2
known=OUT/'ubuntu-known_hosts';known.write_text('[169.254.42.1]:2222 '+host[0]+' '+host[1]+'\n')
command=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-p','2222','-i',str(KEYS/'client_key_host'),
 '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
 '-o',f'UserKnownHostsFile={known}','-o','ConnectTimeout=5','root@169.254.42.1',
 'cat /etc/os-release; uname -a; id']
p=subprocess.run(command,capture_output=True,timeout=20)
(OUT/'ubuntu-ssh.txt').write_bytes(p.stdout+p.stderr);p.check_returncode()
assert b'Ubuntu' in p.stdout
(OUT/'deployment-result.json').write_text(json.dumps(dict(ubuntu_chroot_running=True,
 ubuntu_ssh_port=2222,mesa_fd740_rendering_passed=True,phone_partitions_written=False,
 pid1_still_existing_debug_init=True,weston_not_yet_started=True),indent=2)+'\n')
print('PASS: Ubuntu ARM64 programs, hardware Mesa and independent key-only SSH on port 2222; no partition writes')

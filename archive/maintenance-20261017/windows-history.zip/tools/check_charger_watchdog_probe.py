"""Collect and decode the fixed charger state GET diagnostic."""
from pathlib import Path
import subprocess
import time
from prepare_native_install import SSH

args = SSH[:]
args[-1] = 'penguin@172.16.42.1'
args = [x if not x.startswith('UserKnownHostsFile=') else
        'UserKnownHostsFile=out/native-install-20261017/known_hosts' for x in args]
cmd = '''cat /home/penguin/charger-watchdog-probe/result.log
echo LIVE_STATE
cat /proc/sys/kernel/random/boot_id /proc/uptime
ls /sys/module/qcom_battmgr/parameters
cat /sys/class/power_supply/bq28z610-0/uevent
cat /sys/class/power_supply/qcom-battmgr-usb/uevent
journalctl -b -k --no-pager | grep -E 'PJA110 OEM PMIC|PJA110 BCC response|initialization stopped' || true
'''
p = subprocess.run(args + [cmd], capture_output=True, timeout=30)
out = Path('out/native-install-20261017/charger-watchdog-probe')
dest = out / ('live-' + time.strftime('%Y%m%d-%H%M%S') + '.txt')
dest.write_bytes(p.stdout + p.stderr)
print(p.stdout.decode(errors='replace'))
print(p.stderr.decode(errors='replace'))
print('Saved:', dest, 'SSH exit:', p.returncode)
p.check_returncode()

#!/bin/bash
# IMPROVED marker experiment -- my previous one had a confound.
#
# Previous design: marker at /chosen/xigua-marker. It vanished, and I concluded
# "ABL ignores the appended DTB".
#
# CONFOUND: ABL builds the cmdline and writes /chosen/bootargs itself (its log
# shows it constructing that string). If ABL *recreates* /chosen rather than
# editing it, my marker would vanish even if the appended DTB WAS used as base.
#
# Fix: put markers in places ABL has no reason to touch:
#     /xigua-root-marker                 (root level)
#     /soc/xigua-soc-marker              (inside /soc)
#     /chosen/xigua-chosen-marker        (keep, for comparison)
# If ANY marker survives, the appended DTB is being used as the base.
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
OUT="$ROOT/out"
WIN="/mnt/h/WorkSpace/PJA110-Mainline"

MARK_ROOT="XIGUA_ROOT_aa11"
MARK_SOC="XIGUA_SOC_bb22"
MARK_CHOSEN="XIGUA_CHOSEN_cc33"

command -v fdtput >/dev/null || { echo "fdtput missing"; exit 1; }

rm -f "$OUT/probe2.dtb"
cp "$WIN/live-from-device.dtb" "$OUT/probe2.dtb"

echo "=== adding markers in three places ==="
fdtput -t s "$OUT/probe2.dtb" /                xigua-root-marker   "$MARK_ROOT"
fdtput -t s "$OUT/probe2.dtb" /soc             xigua-soc-marker    "$MARK_SOC"
fdtput -t s "$OUT/probe2.dtb" /chosen          xigua-chosen-marker "$MARK_CHOSEN"

for p in / /soc /chosen; do
    printf '  %-10s -> ' "$p"
    fdtget -t s "$OUT/probe2.dtb" "$p" "xigua$( [ "$p" = "/" ] && echo -root || ([ "$p" = "/soc" ] && echo -soc || echo -chosen) )-marker" 2>/dev/null || echo "(set)"
done

echo
echo "=== verify raw presence ==="
for m in "$MARK_ROOT" "$MARK_SOC" "$MARK_CHOSEN"; do
    if grep -qa "$m" "$OUT/probe2.dtb"; then echo "  $m: FOUND"; else echo "  $m: MISSING"; fi
done

echo
echo "=== pack: STOCK kernel + marked DTB ==="
cat "$OUT/stock-kernel.bin" "$OUT/probe2.dtb" > "$OUT/probe2-kernel.bin"
cd "$WIN"
python3 tools/bootimg.py pack \
    --kernel "$OUT/probe2-kernel.bin" \
    --stock boot-A14.img \
    --cmdline "xiguaprobe=marker2" \
    -o "$OUT/probe2.img"
ls -l "$OUT/probe2.img"
cp "$OUT/probe2.img" "$WIN/out/" 2>/dev/null || true
echo
echo "built: $OUT/probe2.img"

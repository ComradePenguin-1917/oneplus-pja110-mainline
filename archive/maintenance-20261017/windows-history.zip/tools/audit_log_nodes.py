#!/usr/bin/env python3
"""Two questions at once:

  Q1  Can 9008 read physical memory? (firehose peek/memorydump)
  Q2  Is there a log mechanism on THIS device that writes to somewhere durable,
      so that 9008 -- or even plain Android -- can read it afterwards?

Q2 matters more than it sounds. The vendor device tree contains several
Qualcomm log-persistence nodes I noticed earlier but never examined properly:

    /soc/dmesg-dump            compatible qcom,dmesg-dump
    qcom,minidump / qcom,va-minidump
    rawdump, logdump, logfs, xbl_sc_logs partitions

Qualcomm's `dmesg-dump` exists precisely to keep kernel logs across a crash. If
it targets a UFS partition rather than volatile RAM, then the log survives
everything -- and can be read from Android with no 9008 and no cable.

Let me look at exactly where each of these points.
"""
import os
import struct
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
sys.path.insert(0, os.path.join(WS, 'tools'))
from fdt import FDT


def dec(v):
    return v.rstrip(b'\0').decode('ascii', 'replace')


def regs(v):
    out = []
    for i in range(0, len(v) - 15, 16):
        out.append(struct.unpack_from('>QQ', v, i))
    return out


live = FDT(open(os.path.join(WS, 'live-from-device.dtb'), 'rb').read()).nodes()

print('=' * 78)
print('1) EVERY LOG-RELATED NODE IN THE LIVE DEVICE TREE')
print('=' * 78)
pat = ('log', 'dump', 'dmesg', 'minidump', 'pstore', 'ramoops', 'vmkmsg', 'rddm')
hits = [p for p in live if any(k in p.lower() for k in pat)]
print('  %d nodes mention log/dump:' % len(hits))
for p in sorted(hits):
    props = live[p]
    c = props.get('compatible')
    r = props.get('reg')
    print()
    print('  %s' % p)
    if c:
        print('      compatible : %s' % dec(c).replace('\0', ' | '))
    if r:
        for b, s in regs(r):
            print('      reg        : 0x%x + 0x%x  (%.1f KiB)' % (b, s, s/1024))
    for k in sorted(props):
        if k in ('compatible', 'reg', 'phandle', 'name'):
            continue
        v = props[k]
        if len(v) == 4:
            print('      %-12s 0x%x (%d)' % (k, struct.unpack('>I', v)[0], struct.unpack('>I', v)[0]))
        elif len(v) <= 40:
            print('      %-12s %r' % (k, dec(v)))

print()
print('=' * 78)
print('2) WHICH OF THOSE ARE IN *RESERVED RAM* vs A PARTITION?')
print('=' * 78)
print('  A reserved-RAM log region dies on power loss but may survive a warm')
print('  reboot; a partition-backed log survives everything.')
print()
rm = {}
for p in live:
    if p.startswith('/reserved-memory/') and p.count('/') == 2:
        r = live[p].get('reg')
        if r:
            rm[p] = regs(r)
print('  reserved-memory entries whose name suggests logging:')
for p, rl in sorted(rm.items()):
    if any(k in p.lower() for k in pat):
        for b, s in rl:
            print('    %-52s 0x%x + 0x%x (%.1f KiB)' % (p.split('/')[-1][:52], b, s, s/1024))

print()
print('=' * 78)
print('3) THE PARTITIONS THAT COULD HOLD A LOG')
print('=' * 78)
for name, size in (('rawdump', 268435456), ('logdump', 536870912),
                   ('logfs', 8388608), ('xbl_sc_logs', 131072)):
    print('  %-14s %d bytes (%.1f MiB)' % (name, size, size / 2**20))
print()
print('  earlier findings: rawdump and logdump read back ALL ZEROS;')
print('  ABL says "BDS: LogFs sync skipped, Unsupported" for logfs.')
print('  => those three are dead ends (already checked).')

print()
print('=' * 78)
print('4) SO WHAT IS dmesg-dump ACTUALLY FOR?')
print('=' * 78)
node = live.get('/soc/dmesg-dump')
if node:
    print('  /soc/dmesg-dump properties:')
    for k in sorted(node):
        v = node[k]
        if len(v) == 4:
            print('    %-20s 0x%x (%d)' % (k, struct.unpack('>I', v)[0], struct.unpack('>I', v)[0]))
        elif len(v) <= 60:
            print('    %-20s %r' % (k, dec(v)))
        else:
            print('    %-20s <%d bytes>' % (k, len(v)))
else:
    print('  not present in the live tree')

print()
print('  the driver source (vendor kernel) would say where it writes; we cannot')
print('  read the vendor source, but the kernel exposes the mechanism at runtime:')
print('    /proc/vmkmsg  (noted earlier as a live stream)')
print('  If /proc/vmkmsg is a READABLE ring that PERSISTS across a warm reboot, it')
print('  is a viable channel with no cable and no 9008 at all.')

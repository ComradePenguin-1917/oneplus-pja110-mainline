#!/bin/bash
# Make a NON-EFI arm64 Image so QEMU can boot it with plain -kernel.
#
# Diagnosis so far:
#   * our Image is an EFI stub (starts with MZ, has "ARM\x64" at offset 56)
#   * QEMU -kernel loads it but has no EFI firmware (edk2-aarch64 not installed,
#     and installing it needs root), so the stub never runs -> zero output
#   * even a kernel-less QEMU run printed nothing, confirming the invocation
#     rather than our code is at fault
#
# arm64's arm64 Image format is a self-contained binary whose first bytes ARE
# its header (code0/code1 + a 64-byte header ending with "ARM\x64"). The EFI stub
# is PREPENDED to that; the real Image header sits at a known offset inside.
#
# Rather than hand-carve, the reliable route is to rebuild without CONFIG_EFI_STUB
# -- but that changes the very artefact we want to test. Better: ask objcopy for
# the raw binary of the kernel proper, which drops the PE wrapper.
set -uo pipefail

ROOT="$HOME/workspace/PJA110-Mainline"
TREE="$ROOT/linux"
TC="$ROOT/toolchain/gcc-12-aarch64"
export PATH="$TC/usr/bin:$PATH"
export LD_LIBRARY_PATH="$TC/usr/lib/x86_64-linux-gnu:${LD_LIBRARY_PATH:-}"
cd "$TREE"

echo "=== 1) where does the arm64 Image header live inside our Image? ==="
python3 - <<'PY'
import struct
p='/home/comrade_penguin_desktop/workspace/PJA110-Mainline/out/Image-poweroff'
d=open(p,'rb').read()
print('  file size: %d' % len(d))
# the arm64 header ends with "ARM\x64" (0x644d5241) at header_offset+56
offs=[]
i=0
while True:
    i=d.find(b'ARM\x64', i)
    if i<0: break
    offs.append(i-56)
    i+=4
print('  candidate arm64 Image header offsets (magic@56): %s' % ['0x%x'%o for o in offs])
for o in offs[:4]:
    if o<0 or o+64>len(d): continue
    code0,code1=struct.unpack_from('<2I',d,o)
    text_off,image_size,flags=struct.unpack_from('<3Q',d,o+8)
    print('    @0x%06x code0=0x%08x text_offset=0x%x image_size=%d flags=0x%x'
          % (o,code0,text_off,image_size,flags))
PY

echo
echo "=== 2) extract the raw (non-PE) kernel with objcopy ==="
# vmlinux is ELF; objcopy -O binary yields the bare image, which is what the
# arm64 header describes. The EFI stub is a separate PE wrapper around it.
if [ -f vmlinux ]; then
    aarch64-linux-gnu-objcopy -O binary vmlinux /tmp/Image.raw 2>&1 | head -3
    ls -l /tmp/Image.raw | sed 's/^/  /'
    python3 - <<'PY'
import struct
d=open('/tmp/Image.raw','rb').read()
print('  size: %d' % len(d))
i=d.find(b'ARM\x64')
print('  ARM\\x64 magic at: %s' % ('0x%x'%i if i>=0 else 'NOT FOUND'))
if i>=0:
    o=i-56
    code0,code1=struct.unpack_from('<2I',d,o)
    to,isz,fl=struct.unpack_from('<3Q',d,o+8)
    print('  header @0x%x code0=0x%08x text_offset=0x%x image_size=%d flags=0x%x'
          % (o,code0,to,isz,fl))
    print('  -> %s' % ('valid arm64 Image header at the START (offset 0)' if o==0 else 'header not at offset 0'))
PY
else
    echo "  vmlinux missing; cannot objcopy"
fi

echo
echo "=== 3) append our DTB? no -- QEMU supplies virt.dtb; use it ==="
ls -l /tmp/virt.dtb 2>/dev/null | sed 's/^/  /'

echo
echo "=== 4) boot the RAW image under QEMU ==="
SY="$ROOT/toolchain/qemu/sysroot"
QEMU="$SY/usr/bin/qemu-system-aarch64"
export LD_LIBRARY_PATH="$SY/usr/lib/x86_64-linux-gnu:${LD_LIBRARY_PATH:-}"
export QEMU_DATADIR="$SY/usr/share/qemu"

if [ -f /tmp/Image.raw ]; then
    echo "  --- attempt with QEMU-generated DTB ---"
    timeout 60 "$QEMU" \
        -M virt -cpu cortex-a57 -smp 2 -m 2048 \
        -kernel /tmp/Image.raw \
        -initrd "$ROOT/initramfs/initramfs.cpio.gz" \
        -dtb /tmp/virt.dtb \
        -append "console=ttyAMA0 earlycon=pl011,0x9000000 loglevel=8 rdinit=/init ignore_loglevel" \
        -nographic -serial stdio -monitor none \
        2>&1 | head -100 | sed 's/^/    /'
    echo "    rc=$?"
fi

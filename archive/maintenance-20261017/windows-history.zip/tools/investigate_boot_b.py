#!/usr/bin/env python3
"""Something REWROTE boot_b after I flashed it. Find out what, and whether the
experiment is still meaningful.

Facts:
    flashed boot_b  = afe9d64d1ccd19d4  (our kernel + embedded initramfs)
    now boot_b      = 52ac5bd05737f6e5  (unknown)
    stock boot_b    = d9cf0ea60491b5c8  (OTA package)
    vendor_boot_b   = 2c05fda9bc5a499e  (ours, SURVIVED)
    dtbo_b          = 95aeaae03b56c171  (erased, as intended)

So one partition was restored and another was not. Identify the mystery image by
its header, and look for OPPO's slot-restore behaviour, which would explain it.

If Android rewrote boot_b, then ABL may have booted a DIFFERENT kernel than the
one I flashed -- which would make this attempt inconclusive rather than negative.
"""
import hashlib
import os
import shutil
import struct
import subprocess
import sys

ADB = shutil.which('adb') or r'C:\platform-tools\adb.exe'
WS = r'H:\WorkSpace\PJA110-Mainline'
SERIAL = 'bc7a542e'


def sh(cmd, timeout=900):
    r = subprocess.run([ADB, '-s', SERIAL, 'shell', cmd], capture_output=True, timeout=timeout)
    return ((r.stdout or b'') + (r.stderr or b'')).decode('utf-8', 'replace')


def sha_file(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''):
            h.update(c)
    return h.hexdigest()


print('=' * 78)
print('1) WHAT IS CURRENTLY IN boot_b?  (read it back and parse)')
print('=' * 78)
remote = '/data/local/tmp/bootb_now.img'
sh('su -c "dd if=/dev/block/by-name/boot_b of=%s bs=1M 2>/dev/null; chmod 644 %s"'
   % (remote, remote))
local = os.path.join(WS, 'out', '_bootb_now.img')
r = subprocess.run([ADB, '-s', SERIAL, 'pull', remote, local], capture_output=True, timeout=900)
if os.path.exists(local):
    b = open(local, 'rb').read()
    print('  size   : %d' % len(b))
    print('  sha256 : %s' % hashlib.sha256(b).hexdigest())
    if b[:8] == b'ANDROID!':
        ksize, rsize, osver = struct.unpack_from('<3I', b, 8)
        hver = struct.unpack_from('<I', b, 40)[0]
        cmd = b[44:44 + 1536].rstrip(b'\0')
        print('  magic  : ANDROID!  hdr v%d  os_version=0x%08x' % (hver, osver))
        print('  kernel : %d bytes   ramdisk: %d' % (ksize, rsize))
        print('  cmdline: %r' % cmd[:90])
        k = b[4096:4096 + ksize]
        # markers that identify each candidate
        import re
        gz = [m.start() for m in re.finditer(rb'\x1f\x8b\x08', k)]
        print('  gzip streams in kernel: %d' % len(gz))
        import gzip
        import io
        for off in gz:
            try:
                d = gzip.GzipFile(fileobj=io.BytesIO(k[off:])).read(4_000_000)
            except Exception:
                continue
            if b'[initramfs]' in d or b'busybox' in d:
                print('    -> OUR initramfs at 0x%x (%d bytes)' % (off, len(d)))
                break
            else:
                print('    -> other gzip at 0x%x (%d bytes)' % (off, len(d)))
        # KernelSU marker?
        print('  KernelSU strings: %s' % (b'KernelSU' in b or b'ksu' in b))
        m = re.search(rb'Linux version [\d\.\w\-+]+', k)
        print('  version string  : %s' % (m.group(0).decode() if m else 'not found'))
    else:
        print('  magic  : %r  (not an Android boot image)' % b[:8])
    sh('rm -f %s' % remote)

print()
print('=' * 78)
print('2) CANDIDATE MATCHES')
print('=' * 78)
cands = {
    'our kernel image': os.path.join(WS, 'out', 'boot_b-ourkernel.img'),
    'OTA boot (boot-A14.img)': os.path.join(WS, 'boot-A14.img'),
    'backup boot_b (stock)': os.path.join(WS, 'backup', 'boot_b.img'),
    'backup boot_a (KernelSU)': os.path.join(WS, 'backup', 'boot_a.img'),
}
now = None
if os.path.exists(local):
    now = sha_file(local)
for name, p in cands.items():
    if not os.path.exists(p):
        print('  %-26s (missing)' % name)
        continue
    h = sha_file(p)
    mark = '  <== MATCH' if h == now else ''
    print('  %-26s %s%s' % (name, h[:32], mark))

print()
print('=' * 78)
print('3) OPPO SLOT-RESTORE EVIDENCE')
print('=' * 78)
print('  boot_b was overwritten while booted into slot A.')
print('  Check for OPPO/oplus services and any OTA state:')
for prop in ('ro.boot.slot_suffix', 'ro.oplus.version', 'ro.build.version.ota',
             'ro.boot.verifiedbootstate', 'persist.sys.oplus.ota',
             'ro.oplus.ota.version'):
    v = sh('getprop %s' % prop).strip()
    if v:
        print('    %-32s %s' % (prop, v))

print()
print('  update_engine / oplus update processes:')
print('   ', sh('ps -A 2>/dev/null | grep -iE "update|ota|oplus" | head -8').strip()[:400])

print()
print('=' * 78)
print('4) WHICH SLOT IS MARKED ACTIVE, AND IS B STILL ENABLED?')
print('=' * 78)
print('  ', sh('getprop ro.boot.slot_suffix').strip())
print()
print('  bootloader_control in misc:')
print('   ', sh('su -c "dd if=/dev/block/by-name/misc bs=1 skip=2048 count=64 2>/dev/null | xxd | head -4"').strip()[:400])

print()
print('=' * 78)
print('CONCLUSION')
print('=' * 78)
if now and now == sha_file(os.path.join(WS, 'boot-A14.img')):
    print('  boot_b now holds the STOCK OTA image -> the running system restored it.')
    print('  So ABL booted the STOCK kernel on slot B, not ours.')
    print('  => this attempt is INCONCLUSIVE, not a negative result.')
elif now and now == sha_file(os.path.join(WS, 'out', 'boot_b-ourkernel.img')):
    print('  boot_b still holds OUR image; nothing rewrote it.')
else:
    print('  boot_b holds something else; identify from section 1 above.')

param([string]$OutputDirectory='out/usb-serial-reliability-new-cable-20261013/upload-thread',[int]$Rounds=3)
$ErrorActionPreference='Stop'
$target=[IO.Path]::GetFullPath([IO.Path]::Combine($PWD.Path,$OutputDirectory))
$workspace=[IO.Path]::GetFullPath($PWD.Path)+[IO.Path]::DirectorySeparatorChar
if(-not $target.StartsWith($workspace,[StringComparison]::OrdinalIgnoreCase)){throw 'Output must stay in workspace'}
[IO.Directory]::CreateDirectory($target) | Out-Null
. (Join-Path $PSScriptRoot 'UsbSerialReader.ps1')
Initialize-UsbSerialReaderType
$port=[IO.Ports.SerialPort]::new('COM12',115200)
$port.DtrEnable=$true
$port.RtsEnable=$true
$port.ReadBufferSize=262144
$port.WriteTimeout=15000
$reader=$null
$transcript=[Text.StringBuilder]::new()
$results=[Collections.Generic.List[object]]::new()
function Wait-Marker([string]$Marker){
    $reply=[Text.StringBuilder]::new()
    $timer=[Diagnostics.Stopwatch]::StartNew()
    $tail=''
    $complete=$false
    do{
        $data=[Text.Encoding]::ASCII.GetString($reader.Drain())
        [void]$reply.Append($data)
        if($data.Length -gt 0){
            $scan=$tail+$data.Replace("`r",'')
            if($scan -match ("(?m)^"+[regex]::Escape($Marker)+"$")){$complete=$true;break}
            $tail=$scan.Substring([Math]::Max(0,$scan.Length-$Marker.Length-4))
        }
        Start-Sleep -Milliseconds 5
    }while($timer.Elapsed.TotalSeconds -lt 30)
    $text=$reply.ToString().Replace("`r",'')
    [void]$transcript.Append($text)
    if(-not $complete){throw "Missing upload marker $Marker"}
    return $text
}
try{
    $port.Open()
    $reader=[UsbSerialContinuousReader]::new($port,$true)
    $port.Write("dmesg | grep -c gs_write_complete; echo UPLOAD_BEFORE`n")
    $before=Wait-Marker 'UPLOAD_BEFORE'
    for($round=1;$round -le $Rounds;$round++){
        $data=[byte[]]::new(1048576)
        $random=[Security.Cryptography.RandomNumberGenerator]::Create()
        try{$random.GetBytes($data)}finally{$random.Dispose()}
        $sha=[Security.Cryptography.SHA256]::Create()
        try{$expected=[BitConverter]::ToString($sha.ComputeHash($data)).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()}
        $encoded=[Convert]::ToBase64String($data)
        $port.Write("echo UPLOAD_READY_$round; head -c $($encoded.Length) | base64 -d > /tmp/usb-host-upload.bin; sha256sum /tmp/usb-host-upload.bin; echo UPLOAD_DONE_$round`n")
        [void](Wait-Marker "UPLOAD_READY_$round")
        $timer=[Diagnostics.Stopwatch]::StartNew()
        $port.Write($encoded)
        $reply=Wait-Marker "UPLOAD_DONE_$round"
        $match=[regex]::Match($reply,'(?m)^([0-9a-f]{64})\s+/tmp/usb-host-upload.bin')
        $actual=$match.Groups[1].Value
        $passed=$match.Success -and $actual -eq $expected
        $results.Add([pscustomobject]@{Round=$round;Bytes=$data.Length;Passed=$passed;ExpectedSHA256=$expected;ActualSHA256=$actual;ElapsedSeconds=$timer.Elapsed.TotalSeconds})
        Write-Output "Upload round=$round bytes=$($data.Length) passed=$passed"
        if(-not $passed){throw 'Upload SHA256 mismatch'}
    }
    $port.Write("dmesg | grep -c gs_write_complete; cat /proc/uptime; cat /sys/class/udc/*/current_speed; echo UPLOAD_AFTER`n")
    $after=Wait-Marker 'UPLOAD_AFTER'
    [ordered]@{AllPassed=$true;Before=$before;After=$after;WindowsSerialErrors=$reader.Errors;Transfers=$results} | ConvertTo-Json -Depth 6 | Set-Content -Encoding utf8 (Join-Path $target 'result.json')
    Write-Output $after
}finally{
    [IO.File]::WriteAllText((Join-Path $target 'transcript.txt'),$transcript.ToString())
    if($reader){$reader.Stop()}else{$port.Dispose()}
}

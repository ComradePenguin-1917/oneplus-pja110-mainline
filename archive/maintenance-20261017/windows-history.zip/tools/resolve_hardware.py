#!/usr/bin/env python3
"""Resolve the panel/touch identity using ALL available evidence.

There is an apparent contradiction to resolve:
  * the running system reports Physical size: 1240x2772  (the 1.5K figure I
    originally guessed)
  * but ABL detects and enables `dsi_panel_AA536_P_3_A0001_dsc_cmd`, and the
    kernel cmdline has msm_drm.dsi_display0=<AA536>, with touch = synaptics-s3910

Explanation to verify: the DTBO contains BOTH panel candidates because OPPO
ships the same board with multiple display suppliers. The ABL picks one at boot
by reading a panel ID strap, and rewrites the cmdline accordingly. So:
  * the PANEL DRIVER the vendor kernel loads is AA536_P_3_A0001 (per cmdline)
  * the TOUCH controller is synaptics-s3910 (confirmed by /proc/bus/input)
  * the panel's *native* mode may still be 1240x2772 (physical size from wm size)

This script lays out the evidence so the port targets the right hardware.
"""
import io
import os
import re

WS = r'H:\WorkSpace\PJA110-Mainline'
out = []
def p(s=''):
    out.append(str(s))

log = io.open(os.path.join(WS, 'bootloader-log.txt'), encoding='utf-8',
              errors='replace').read()

p('=' * 74)
p('EVIDENCE TABLE: what is this phone really using?')
p('=' * 74)
p()
p('%-22s %-34s %s' % ('item', 'evidence', 'conclusion'))
p('%-22s %-34s %s' % ('-' * 22, '-' * 34, '-' * 20))

rows = [
    ('Panel driver', 'ABL: "DisplayDxe: Detected panel: '
                     'dsi_panel_AA536_P_3_A0001_dsc_cmd"',
     'AA536_P_3_A0001'),
    ('Panel (cmdline)', 'msm_drm.dsi_display0=qcom,mdss_dsi_panel_'
                        'AA536_P_3_A0001_dsc_cmd',
     'AA536_P_3_A0001'),
    ('Panel native mode', '/proc/bus/input + "wm size" -> 1240x2772',
     '1240x2772'),
    ('Touch controller', '/proc/bus/input/devices: Phys=synaptics_tcm/'
                         'touch_input', 'synaptics-s3910'),
    ('Touch (cmdline)', 'oplus_bsp_tp_custom...:synaptics-s3910',
     'synaptics-s3910'),
]
for a, b, c in rows:
    p('%-22s %-34s %s' % (a, b[:34], c))

p()
p('=' * 74)
p('RESOLUTION of the apparent contradiction')
p('=' * 74)
p()
p('The DTBO ships SEVERAL panels because OPPO uses multiple display suppliers')
p('for the same model. From the dtbo strings:')
p()
db = open(os.path.join(WS, 'dtbo-A14.img'), 'rb').read()
for m in sorted(set(re.findall(rb'ndss_dsi_panel_\w+|mdss_dsi_panel_\w+|dsi_oplus_\w+', db))):
    p('    %s' % m.decode())
p()
p('ABL reads a panel ID strap at boot (its log even shows "Detected panel')
p('ID=[0x003C0000]") and selects ONE, rewriting the kernel cmdline. On THIS')
p('unit it selected AA536_P_3_A0001 with a synaptics-s3910 touch controller.')
p()
p('So both of my earlier statements were partly right and partly wrong:')
p('  * CORRECT: the panel is 1240x2772 (1.5K) -- matches the physical size')
p('  * WRONG  : the panel driver is NOT a BOE/NT37705; it is AA536_P_3_A0001')
p('  * WRONG  : the touch is NOT Goodix GT9916; it is Synaptics S3910')
p()
p('=' * 74)
p('WHY THIS MATTERS FOR THE PORT')
p('=' * 74)
p()
p('1) Panel: mainline has BOE/Novatek panels but no AA536_P_3_A0001 driver.')
p('   "AA536" is a Samsung display part number. Closest mainline templates:')
p('   panel-samsung-* (e.g. sofef00, s6e8fc0) if it is a Samsung DDIC, or')
p('   panel-boe-td4320.c as a structural DSC example. Need the vendor driver')
p('   (android_kernel_oneplus_sm8550 devicetree + techpack/display) for the')
p('   real init sequence.')
p()
p('2) Touch: synaptics-s3910 uses the "synaptics,tcm-spi-hbp" binding, and')
p('   mainline has NO Synaptics TCM driver. This is HARDER than the Goodix')
p('   Berlin path I described earlier (which does exist upstream). It means')
p('   writing a new driver, not just adding a DT node.')
p()
p('3) The enabling of touch in the live tree:')
p('     synaptics_tcm_hbp@0   status=okay      <- the one in use')
p('     synaptics_tcm@0       status=disabled')
p('     goodix-berlin@5d      status=disabled  <- OPPO alternate')
p()

io.open(os.path.join(WS, 'docs', 'hardware-identity.md'), 'w',
        encoding='utf-8').write('\n'.join(out) + '\n')
print('\n'.join(out))

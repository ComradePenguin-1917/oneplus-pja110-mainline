#!/bin/bash
# Inspect the actual initramfs contents (the Python cpio parser I wrote has a
# bug; use the real cpio tool instead).
set -uo pipefail
cd "$HOME/workspace/PJA110-Mainline/initramfs"

echo "=== archive ==="
ls -l initramfs.cpio.gz

echo
echo "=== entry count and key files ==="
cpio -t < <(zcat initramfs.cpio.gz) 2>/dev/null > /tmp/l.txt
echo "  entries: $(wc -l < /tmp/l.txt)"
for f in init bin/busybox bin/sh bin/poweroff bin/reboot bin/halt \
         bin/telnetd bin/udhcpd bin/ip bin/mount bin/umount bin/dmesg bin/cat; do
    printf '  %-16s %s\n' "$f" "$(grep -cx "$f" /tmp/l.txt)"
done

echo
echo "=== does busybox support poweroff/reboot? ==="
if [ -x tree/bin/busybox ]; then
    file tree/bin/busybox | sed 's/^/  /'
    # cannot execute an aarch64 binary on x86; read the applet table out of it
    echo "  applet names present in the binary:"
    for a in poweroff reboot halt sysrq-trigger; do
        printf '    %-16s %s\n' "$a" "$(strings tree/bin/busybox | grep -cx "$a")"
    done
fi

echo
echo "=== the existing /init: which command does it use to stay alive? ==="
grep -nE 'poweroff|reboot|halt|exec |while|sleep|setsid|telnetd' init | head -20 | sed 's/^/  /'

echo
echo "=== tail of /init ==="
tail -25 init | sed 's/^/  /'

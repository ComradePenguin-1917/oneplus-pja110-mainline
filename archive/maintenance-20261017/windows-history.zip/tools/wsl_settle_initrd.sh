#!/bin/bash
# Settle whether the embedded initramfs is really inside the boot image's kernel.
#
# Confusion to resolve:
#   * vmlinux .init.data at file offset 0x189c488 DID contain our cpio when gzipped
#     (we extracted 438 entries successfully)
#   * searching the raw Image for gzip magic at 0x188c488 says "not gzipped"
#
# Explanation to test: objcopy produces Image from vmlinux with different section
# packing/alignment, so file offsets shift. Find the payload by CONTENT instead
# (the cpio header "070701" written at the start of the archive), and confirm the
# bytes around it match our archive.
set -uo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
OUT="$ROOT/out"
TREE="$ROOT/linux"

echo "=== 1) ground truth: extract from vmlinux (already proven to work) ==="
TC="$ROOT/toolchain/gcc-12-aarch64"
export PATH="$TC/usr/bin:$PATH"
export LD_LIBRARY_PATH="$TC/usr/lib/x86_64-linux-gnu:${LD_LIBRARY_PATH:-}"
cd "$TREE"
python3 - <<'PY'
import gzip, io
v = open('vmlinux','rb').read()
off = 0x189c488
data = v[off:off+1183872]
print('  vmlinux[0x%x:%d] first bytes: %s' % (off, off+16, data[:16].hex()))
try:
    d = gzip.GzipFile(fileobj=io.BytesIO(data)).read()
    print('  decompressed %d bytes; our_marker=%s busybox=%s'
          % (len(d), b'[initramfs]' in d, b'busybox' in d))
    open('/tmp/truth.cpio','wb').write(d)
except Exception as e:
    print('  not gzip at that offset: %s' % e)
PY

echo
echo "=== 2) now find the SAME payload inside the Image by content ==="
python3 - <<'PY'
import gzip, io, re

img = open('/home/comrade_penguin_desktop/workspace/PJA110-Mainline/out/Image-initrd','rb').read()
print('  Image size: %d' % len(img))

# Our archive's own first bytes (the gzip of the cpio) are a unique fingerprint.
gzwhole = open('/home/comrade_penguin_desktop/workspace/PJA110-Mainline/initramfs/initramfs.cpio.gz','rb').read()
head = gzwhole[:32]
print('  our .cpio.gz first 32 bytes: %s' % head.hex())

pos = img.find(head)
print('  exact 32-byte prefix match in Image: %s' % ('YES at 0x%x' % pos if pos >= 0 else 'NO'))

# fall back: search for a longer distinctive slice from the middle of the stream
mid = gzwhole[600000:600032]
pos2 = img.find(mid)
print('  middle slice match in Image      : %s' % ('YES at 0x%x' % pos2 if pos2 >= 0 else 'NO'))

# and the plain cpio magic (if stored uncompressed anywhere)
for magic in (b'070701', b'070702'):
    hits = [m.start() for m in re.finditer(re.escape(magic), img)]
    print('  %s occurrences: %s' % (magic.decode(), ['0x%x' % h for h in hits[:3]]))

if pos >= 0:
    blob = img[pos:pos+len(gzwhole)]
    d = gzip.GzipFile(fileobj=io.BytesIO(blob)).read()
    print('  decompressed from Image: %d bytes; our_marker=%s' % (len(d), b'[initramfs]' in d))
PY

echo
echo "=== 3) interpretation ==="
cat <<'EOF'
  If the exact 32-byte prefix is found, the Image definitely carries our
  archive, and the earlier "gzip magic" scan failed only because a 2-byte
  gzip signature is not unique and the offsets I guessed were from vmlinux.
EOF

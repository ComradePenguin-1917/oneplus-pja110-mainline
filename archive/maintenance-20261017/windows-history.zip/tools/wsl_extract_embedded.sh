#!/bin/bash
# Definitively extract the embedded initramfs from vmlinux and verify its content.
#
# Symbols say:
#   __initramfs_start = 0xffff80008188c488
#   __initramfs_size  = 0xffff8000819ad508   (delta 0x121080 = 1183872)
# which matches our 1183869-byte archive, 4-byte padded.
#
# So find the section containing that address, dump it with objcopy, and inspect.
set -uo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
TREE="$ROOT/linux"
TC="$ROOT/toolchain/gcc-12-aarch64"
export PATH="$TC/usr/bin:$PATH"
export LD_LIBRARY_PATH="$TC/usr/lib/x86_64-linux-gnu:${LD_LIBRARY_PATH:-}"
cd "$TREE"

echo "=== 1) which section contains __initramfs_start? ==="
START=$(aarch64-linux-gnu-nm vmlinux | awk '/__initramfs_start/{print $1}')
SIZE_SYM=$(aarch64-linux-gnu-nm vmlinux | awk '/__initramfs_size/{print $1}')
echo "  __initramfs_start = 0x$START"
echo "  __initramfs_size sym = 0x$SIZE_SYM"

python3 - "$START" <<'PY'
import subprocess, sys
start = int(sys.argv[1], 16)
out = subprocess.run(['aarch64-linux-gnu-readelf','-S','-W','vmlinux'],
                     capture_output=True, text=True).stdout
best = None
for line in out.splitlines():
    # [Nr] Name Type Address Off Size ES Flg Lk Inf Al
    parts = line.split()
    if len(parts) < 7 or not parts[0].startswith('['):
        continue
    try:
        addr = int(parts[3], 16)
        size = int(parts[5], 16)
    except ValueError:
        continue
    if addr and addr <= start < addr + size:
        best = (parts[1], parts[2], addr, size, int(parts[4], 16))
        break
if best:
    name, typ, addr, size, off = best
    print('  containing section: %s  (%s)' % (name, typ))
    print('    addr=0x%x size=0x%x fileoff=0x%x' % (addr, size, off))
    print('    initramfs at file offset 0x%x' % (off + (start - addr)))
    open('/tmp/secinfo.txt','w').write('%s %x %x' % (name, off + (start - addr), size - (start - addr)))
else:
    print('  no section found containing that address')
PY

if [ ! -f /tmp/secinfo.txt ]; then
    echo
    echo "  --- fallback: list sections with non-zero size ---"
    aarch64-linux-gnu-readelf -S -W vmlinux | awk 'NF>=7 && $0 ~ /\[/ {print}' | head -30
    exit 0
fi
read -r SECNAME OFF REST < /tmp/secinfo.txt
echo
echo "=== 2) dump the embedded bytes from the Image-independent vmlinux ==="
python3 - "$OFF" <<'PY'
import sys
off = int(sys.argv[1], 16)
v = open('vmlinux','rb').read()
size = 1183872
data = v[off:off+size]
open('/tmp/embedded.bin','wb').write(data)
print('  extracted %d bytes' % len(data))
print('  first 16 bytes: %s' % data[:16].hex())
print('  looks like gzip: %s' % data[:2] == b'\x1f\x8b')
print('  looks like cpio: %s' % data[:6] in (b'070701', b'070702'))
import gzip, io
if data[:2] == b'\x1f\x8b':
    try:
        d = gzip.GzipFile(fileobj=io.BytesIO(data)).read()
        print('  decompressed: %d bytes' % len(d))
        open('/tmp/embedded.cpio','wb').write(d)
        print('  has busybox : %s' % (b'busybox' in d))
        print('  has our init: %s' % (b'[initramfs]' in d))
    except Exception as e:
        print('  gzip failed: %s' % e)
PY

echo
echo "=== 3) list the extracted archive ==="
if [ -f /tmp/embedded.cpio ]; then
    echo "  entries: $(cpio -t < /tmp/embedded.cpio 2>/dev/null | wc -l)"
    cpio -t < /tmp/embedded.cpio 2>/dev/null | grep -E '^(init|bin/(busybox|sh|mount|ip|telnetd))$' | sed 's/^/    /'
    echo "  --- /init content check ---"
    rm -rf /tmp/ex && mkdir -p /tmp/ex && (cd /tmp/ex && cpio -idm < /tmp/embedded.cpio 2>/dev/null)
    grep -c 'initramfs' /tmp/ex/init 2>/dev/null | sed 's/^/    banner lines in init: /'
    head -5 /tmp/ex/init 2>/dev/null | sed 's/^/    /'
fi

"""Deploy a two-partition GPU-only update from the verified live Linux baseline."""
import hashlib,json,re,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/gpu-port-20261014'
KEYS=ROOT/'out/usb-ncm-20261013/ssh'
SSH=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(KEYS/'client_key_host'),
     '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
     '-o',f'UserKnownHostsFile={KEYS/"known_hosts"}','-o','ConnectTimeout=5','root@169.254.42.1']
manifest=json.loads((OUT/'deployment-manifest.json').read_text())
def ssh(command,data=None,timeout=90):
    p=subprocess.run(SSH+[command],input=data,capture_output=True,timeout=timeout)
    (OUT/'last-stderr.txt').write_bytes(p.stderr);p.check_returncode();return p.stdout
def devices():
    raw=ssh('for f in /sys/class/block/sd*/uevent; do cat "$f"; echo END; done').decode()
    result={}
    for record in raw.split('END'):
        props=dict(line.split('=',1) for line in record.splitlines() if '=' in line)
        name=props.get('PARTNAME')
        if name in manifest['baseline_hashes']:
            assert name not in result and re.fullmatch(r'sd[a-z]+[0-9]+',props['DEVNAME'])
            result[name]=props['DEVNAME']
    assert set(result)==set(manifest['baseline_hashes'])
    return result
def hashes(mapping):
    result={}
    for name,dev in mapping.items():
        assert ssh(f"grep '^PARTNAME=' /sys/class/block/{dev}/uevent").strip()==('PARTNAME='+name).encode()
        result[name]=ssh(f'sha256sum /dev/{dev}').decode().split()[0]
    return result
def upload(name,data):
    assert ssh(f'cat > /tmp/{name}; sha256sum /tmp/{name}',data).decode().split()[0]==hashlib.sha256(data).hexdigest()
mode=sys.argv[1]
if mode=='flash':
    assert manifest['kernel_unchanged'] and manifest['original_avb_tails_preserved']
    qemu=(OUT/'qemu-console.txt').read_bytes()
    assert b'QEMU touch modules validated' in qemu and b'QEMU debug userspace validated' in qemu
    assert not (OUT/'before.json').exists(),'preserve existing experiment evidence'
    mapping=devices();before=hashes(mapping)
    assert before==manifest['baseline_hashes']
    state=ssh('uname -a; cat /proc/sys/kernel/random/boot_id; cat /proc/uptime')
    assert b'#15 SMP' in state
    (OUT/'before.txt').write_bytes(state)
    changes={'init_boot_b':'init_boot_b-gpu.img','vendor_boot_b':'vendor_boot_b-gpu.img'}
    rollback={'init_boot_b':ROOT/'out/aston-touch-240hz-20261013/verified-autostart/init_boot_b-aston-240hz.img',
              'vendor_boot_b':ROOT/'out/touch-port-20261013/verified-autostart/vendor_boot_b-touch.img'}
    for part,name in changes.items():
        data=(OUT/name).read_bytes()
        assert hashlib.sha256(data).hexdigest()==manifest['files'][name]['sha256']
        assert hashlib.sha256(rollback[part].read_bytes()).hexdigest()==before[part]
        assert int(ssh(f'cat /sys/class/block/{mapping[part]}/size'))*512==len(data)
        upload(name,data)
    (OUT/'before.json').write_text(json.dumps(before,indent=2)+'\n')
    completed=[]
    try:
        for part,name in changes.items():
            dev=mapping[part]
            assert ssh(f"grep '^PARTNAME=' /sys/class/block/{dev}/uevent").strip()==('PARTNAME='+part).encode()
            print('Writing and checking',part,flush=True)
            completed.append(part)
            result=ssh(f'set -e; dd if=/tmp/{name} of=/dev/{dev} bs=1048576 conv=fsync; sync; sha256sum /dev/{dev}')
            (OUT/(part+'-write.txt')).write_bytes(result)
            assert result.decode().split()[0]==manifest['files'][name]['sha256']
        after=hashes(mapping)
        assert all(after[n]==(manifest['files'][changes[n]]['sha256'] if n in changes else before[n]) for n in before)
    except Exception:
        for part in completed:
            data=rollback[part].read_bytes();upload('rollback-'+part,data)
            dev=mapping[part]
            result=ssh(f'set -e; dd if=/tmp/rollback-{part} of=/dev/{dev} bs=1048576 conv=fsync; sync; sha256sum /dev/{dev}')
            assert result.decode().split()[0]==before[part]
        raise
    (OUT/'after-write.json').write_text(json.dumps(after,indent=2)+'\n')
    print('PASS: init_boot_b and vendor_boot_b readback verified; other six partitions unchanged; not rebooted')
elif mode=='capture':
    state=ssh('uname -a; cat /proc/sys/kernel/random/boot_id; cat /tmp/touch-init.log; '
              'cat /sys/module/synaptics_aston/parameters/report_rate_code; '
              'ls -l /sys/bus/platform/drivers/adreno; ls -l /dev/dri; dmesg')
    (OUT/'after-state.txt').write_bytes(state)
    assert b'#15 SMP' in state and b'AA536 60 Hz initialization complete' in state
    assert b'Aston S3910 240Hz touch modules loaded' in state
    actual=hashes(devices());assert actual==json.loads((OUT/'after-write.json').read_text())
    (OUT/'after.json').write_text(json.dumps(actual,indent=2)+'\n')
    data=(OUT/'gpu-probe').read_bytes();upload('gpu-probe',data)
    p=subprocess.run(SSH+['chmod 700 /tmp/gpu-probe; timeout 30 /tmp/gpu-probe'],capture_output=True,timeout=40)
    (OUT/'gpu-probe-result.txt').write_bytes(p.stdout+p.stderr)
    (OUT/'probe-dmesg.txt').write_bytes(ssh('dmesg'))
    print((p.stdout+p.stderr).decode(),flush=True)
    p.check_returncode()
    manifest.update(phone_execution_confirmed=True,adreno_740_chip_id_verified=True,
                    gem_allocation_mapping_verified=True,mesa_rendering_tested=False)
    (OUT/'deployment-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
else:raise SystemExit('flash | capture')

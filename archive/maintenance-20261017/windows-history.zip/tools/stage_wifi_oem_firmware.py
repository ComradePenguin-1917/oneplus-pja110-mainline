"""Stage the OEM hw2.0 firmware pair selected by pinned CNSS PCI source."""
from pathlib import Path
import hashlib
import json
import subprocess
from prepare_native_install import SSH

out = Path('out/wifi-bringup-20261017')
args = SSH[:]
args[-1] = 'penguin@172.16.42.1'
args = [x if not x.startswith('UserKnownHostsFile=') else
        'UserKnownHostsFile=out/native-install-20261017/known_hosts' for x in args]
remote = '/home/penguin/wifi-bringup/oem-firmware'
files = {'amss.bin': (out / 'stock-kiwi/amss20.bin').read_bytes(),
         'm3.bin': (out / 'stock-kiwi/phy_ucode20.elf').read_bytes()}
sha = lambda data: hashlib.sha256(data).hexdigest()
hashes = {name: sha(data) for name, data in files.items()}
previous = {'amss.bin': 'b15b21fd99baafd5dad81b6d6fa054df023363029821eb67dd674a438b9fd78d',
            'm3.bin': '97eca0829a1da06bfcb000863f585e2c64ee7febae29f4822097dea1986d919b'}

def run(cmd, data=None):
    p = subprocess.run(args + [cmd], input=data, capture_output=True, timeout=45)
    print(p.stdout.decode(errors='replace'), end='')
    print(p.stderr.decode(errors='replace'), end='')
    p.check_returncode()
    return p.stdout

state = run('cat /proc/cmdline; journalctl -b -k --no-pager | grep "chip_id 0x"; '
            'sha256sum /usr/lib/firmware/ath12k/WCN7850/hw2.0/*')
assert b'oplusboot.prjname=22851' in state
assert b'chip_id 0x2 chip_family 0x4 board_id 0xff soc_id 0x40170200' in state
for value in previous.values():
    assert value.encode() in state
script = '''#!/bin/sh
set -eu
test "$(id -u)" = 0
test "$(uname -r)" = 6.14.0-oneplus-xigua
cd /home/penguin/wifi-bringup/oem-firmware
sha256sum -c files.sha256
dest=/usr/lib/firmware/ath12k/WCN7850/hw2.0
test ! -e "$dest/firmware-2.bin"
test ! -e "$dest/board-2.bin"
test "$(sha256sum "$dest/board.bin" | cut -d ' ' -f 1)" = 39de9b864cd5054a8f5b60a415052b244aa50ccde0104da3f8f9ab0c6a4021bb
test "$(sha256sum "$dest/regdb.bin" | cut -d ' ' -f 1)" = a37849f717efd5974f88adf9f061f72387e5cff79eba867d12f404e09276ab9f
mkdir -p before
'''
for name in files:
    script += f'''current=$(sha256sum "$dest/{name}" | cut -d ' ' -f 1)
case "$current" in
 {previous[name]})
 if [ ! -e before/{name} ]; then cp "$dest/{name}" before/{name}; fi
 ;;
 {hashes[name]}) ;;
 *) echo 'Unexpected {name}; no replacement'; exit 1;;
esac
test "$(sha256sum before/{name} | cut -d ' ' -f 1)" = {previous[name]}
'''
script += '''test -x /usr/local/libexec/pja110-wifi-clean-boot
test -e /etc/systemd/system/pja110-wifi-clean-boot.service
conf=/etc/modprobe.d/pja110-wifi-oneboot.conf
if [ -e "$conf" ] && ! cmp -s "$conf" debug.conf; then
 echo 'Different debug config exists; no replacement'; exit 1
fi
for f in amss.bin m3.bin; do
 install -D -m 644 "$f" "$dest/$f"
 cmp "$f" "$dest/$f"
done
install -D -m 644 debug.conf "$conf"
if [ -e /home/penguin/wifi-bringup/clean-boot/result.txt ]; then
 cp /home/penguin/wifi-bringup/clean-boot/result.txt before/previous-clean-boot.txt
fi
rm -f /home/penguin/wifi-bringup/clean-boot/complete
systemctl enable pja110-wifi-clean-boot.service
sync
echo 'OEM hw2.0 firmware pair installed and verified; originals saved under oem-firmware/before'
echo 'Rebooting for a clean test with automatic BOOT/QMI log capture'
systemctl reboot
'''
restore = '''#!/bin/sh
set -eu
test "$(id -u)" = 0
cd /home/penguin/wifi-bringup/oem-firmware
dest=/usr/lib/firmware/ath12k/WCN7850/hw2.0
'''
for name, digest in previous.items():
    restore += f'test "$(sha256sum before/{name} | cut -d \' \' -f 1)" = {digest}\n'
restore += '''for f in amss.bin m3.bin; do install -D -m 644 "before/$f" "$dest/$f"; done
sync
echo 'Previous upstream firmware restored; reboot is required to use it'
'''
files.update({'install.sh': script.encode(), 'restore.sh': restore.encode(),
              'debug.conf': b'options ath12k debug_mask=0x60\n'})
files['files.sha256'] = ''.join(sha(data)+'  '+name+'\n' for name, data in files.items()).encode()
run('mkdir -p ' + remote)
for name, data in files.items():
    (out / ('oem-firmware-' + name)).write_bytes(data)
    run(f'cat > {remote}/{name}', data)
run(f'cd {remote}; sha256sum -c files.sha256; sh -n install.sh; sh -n restore.sh')
report = dict(source='PJA110 701 modem /image/kiwi',
              mapping={'amss20.bin': 'amss.bin', 'phy_ucode20.elf': 'm3.bin'},
              hashes=hashes, previous_hashes=previous, phone_staged=True,
              rationale='CNSS pci.c KIWI hw2 selects amss20.bin and phy_ucode20.elf',
              next_test='clean boot; no module hot reload; firmware compatibility unproven')
(out / 'oem-firmware-candidate.json').write_text(json.dumps(report, indent=2) + '\n')
print('Root installer staged: ' + remote + '/install.sh')
p = subprocess.run(args + ['sudo -n true'], capture_output=True, timeout=15)
print('Noninteractive sudo:', p.returncode == 0)
print(p.stderr.decode(errors='replace'))

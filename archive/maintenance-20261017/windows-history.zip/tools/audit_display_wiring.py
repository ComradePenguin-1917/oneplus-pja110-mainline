"""Resolve vendor GPIO/regulator references before making a display DT."""
import json
import re
import struct
from pathlib import Path
from fdt import FDT

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/display-port-20261013'
OUT.mkdir(exist_ok=True)
nodes=FDT((ROOT/'live-from-device.dtb').read_bytes()).nodes()
refs={struct.unpack('>I',p['phandle'])[0]:path for path,p in nodes.items() if 'phandle' in p}
items={}
for path,props in nodes.items():
    leaf=path.split('/')[-1]
    if not (leaf in ('pxlw,iris','dsi@ae94000','qcom,mdss_dsi@ae94000') or
            'AA536_P_3_A0001' in path or ('dsi' in leaf and 'ae94' in leaf)):
        continue
    record={}
    for k,v in props.items():
        if any(t in k for t in ('gpio','supply','power','clock','bypass','iris','panel-type','lane')) and 'command' not in k:
            r={'hex':v.hex()}
            if len(v)>=4 and len(v)%4==0:
                cells=list(struct.unpack('>'+'I'*(len(v)//4),v));r['cells']=cells
                if cells[0] in refs:
                    r['provider']=refs[cells[0]]
                    r['provider_properties']={a:b.hex() for a,b in nodes[refs[cells[0]]].items() if a in ('regulator-name','regulator-min-microvolt','regulator-max-microvolt','compatible')}
            record[k]=r
    if record:items[path]=record
(OUT/'vendor-wiring.json').write_text(json.dumps(items,indent=2)+'\n')
for path,props in items.items():
    if path.split('/')[-1] in ('pxlw,iris','qcom,mdss_dsi@ae94000','dsi@ae94000') or '/qcom,mdss_dsi_panel_AA536_P_3_A0001_dsc_cmd'==path[-len('/qcom,mdss_dsi_panel_AA536_P_3_A0001_dsc_cmd'):]:
        print(path)
        for k,v in props.items():
            if 'gpio' in k or 'supply' in k: print(k,v.get('cells'),v.get('provider'))
mode=next(p for p in nodes if p.endswith('AA536_P_3_A0001_dsc_cmd/qcom,mdss-dsi-display-timings/timing@sa_fhd_60'))
source=(ROOT/'out/display-baseline-20261013/oneplus-source/git/vendor/qcom/proprietary/display-devicetree/oplus/panel/dsi-panel-AA536-P-3-A0001-dsc-cmd.dtsi').read_text()
clean=re.sub(r'/\*.*?\*/|//[^\n]*','',source,flags=re.S)
section=clean[clean.index('timing@sa_fhd_60'):]
on=re.search(r'qcom,mdss-dsi-on-command\s*=\s*\[([^]]*)\]',section)
assert on
official=bytes.fromhex(on[1])
actual=nodes[mode]['qcom,mdss-dsi-on-command']
result={'mode':mode,'source_on_command_matches_device':official==actual,
        'device_command_bytes':len(actual),'official_command_bytes':len(official)}
(OUT/'command-source-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(result)

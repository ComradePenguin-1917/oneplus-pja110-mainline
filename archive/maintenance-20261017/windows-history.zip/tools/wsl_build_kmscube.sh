#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
OUT="$WIN/out/gpu-kms-20261014"
if [ "${1:-}" = "--readback" ]; then OUT="$WIN/out/gpu-scanout-readback-20261014"; fi
RUNTIME="$ROOT/mesa-offscreen-runtime"
PREFIX="$ROOT/toolchain/gcc-12-aarch64"
export PATH="$PREFIX/usr/bin:$PATH"
export LD_LIBRARY_PATH="$PREFIX/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
for package in "$WIN/out/mesa-offscreen-20261014/debs/"*.deb; do dpkg-deb -x "$package" "$RUNTIME"; done
cd "$OUT/kmscube"
aarch64-linux-gnu-gcc --sysroot="$PREFIX" -O2 -Wall -DHAVE_GLES3 -I"$RUNTIME/usr/include" -I"$RUNTIME/usr/include/libdrm" \
  common.c cube-smooth.c cube-gears.c cube-tex.c drm-atomic.c drm-common.c drm-legacy.c drm-offscreen.c esTransform.c frame-512x512-NV12.c frame-512x512-RGBA.c kmscube.c perfcntrs.c cube-shadertoy.c \
  -L"$RUNTIME/usr/lib/aarch64-linux-gnu" -Wl,-rpath-link,"$RUNTIME/usr/lib/aarch64-linux-gnu" -ldrm -lgbm -lEGL -lGLESv2 -l:libc.so.6 -l:ld-linux-aarch64.so.1 -lm -lpthread -o "$OUT/kmscube-aarch64" > "$OUT/build.log" 2>&1
echo 'PASS: upstream kmscube built for ARM64 with existing Mesa runtime'

"""Readback-guarded boot_b-only SDMA control deployment."""
import hashlib,json,re,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/dpu-sdma-control-20261014'
FIRSTLINE='--firstline' in sys.argv
if FIRSTLINE:OUT=ROOT/'out/dsc-firstline-control-20261014'
TEHEIGHT='--te-height' in sys.argv
if TEHEIGHT:OUT=ROOT/'out/te-height-control-20261014'
PACKET2='--packet2' in sys.argv
if PACKET2:OUT=ROOT/'out/dsc-packet-control-20261014'
TRACE='--trace' in sys.argv
if TRACE:OUT=ROOT/'out/display-timing-20261014'
BUDGET='--budget' in sys.argv
if BUDGET:OUT=ROOT/'out/display-budget-20261014'
SHUTDOWN='--shutdown' in sys.argv
if SHUTDOWN:OUT=ROOT/'out/drm-shutdown-20261014/kernel'
KEYS=ROOT/'out/usb-ncm-20261013/ssh'
SSH=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(KEYS/'client_key_host'),
     '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
     '-o',f'UserKnownHostsFile={KEYS/"known_hosts"}','-o','ConnectTimeout=5','root@169.254.42.1']
manifest=json.loads((OUT/'manifest.json').read_text())
def ssh(command,data=None):
    p=subprocess.run(SSH+[command],input=data,capture_output=True,timeout=120)
    (OUT/'last-stderr.txt').write_bytes(p.stderr);p.check_returncode();return p.stdout
def mapping():
    raw=ssh('for f in /sys/class/block/sd*/uevent; do cat "$f"; echo END; done').decode()
    found={}
    for record in raw.split('END'):
        props=dict(l.split('=',1) for l in record.splitlines() if '=' in l)
        n=props.get('PARTNAME')
        if n in manifest['baseline_hashes']:
            assert n not in found and re.fullmatch(r'sd[a-z]+[0-9]+',props['DEVNAME'])
            found[n]=props['DEVNAME']
    assert set(found)==set(manifest['baseline_hashes']);return found
def hashes(devices):
    result={}
    for n,d in devices.items():
        assert ssh(f"grep '^PARTNAME=' /sys/class/block/{d}/uevent").strip()==('PARTNAME='+n).encode()
        result[n]=ssh(f'sha256sum /dev/{d}').decode().split()[0]
    return result
if sys.argv[1]=='flash':
    assert not (OUT/'before.json').exists()
    q=(OUT/'qemu-console.txt').read_bytes()
    assert b'QEMU touch modules validated' in q and b'QEMU debug userspace validated' in q
    devices=mapping();before=hashes(devices);assert before==manifest['baseline_hashes']
    state=ssh('uname -a; cat /proc/sys/kernel/random/boot_id; cat /proc/meminfo')
    assert (b'#23 SMP' if SHUTDOWN else b'#22 SMP' if BUDGET else b'#21 SMP' if TRACE else b'#20 SMP' if PACKET2 else b'#18 SMP' if TEHEIGHT else b'#17 SMP' if FIRSTLINE else b'#15 SMP') in state
    data=(OUT/'boot_b-sdma.img').read_bytes()
    rollback=Path(manifest['rollback_boot_image']).read_bytes() if TEHEIGHT or PACKET2 or TRACE or BUDGET or SHUTDOWN else (ROOT/('out/dpu-sdma-control-20261014/boot_b-sdma.img' if FIRSTLINE else 'out/display-generator-avb-retest-20261014/boot_b-generated-panel.img')).read_bytes()
    assert hashlib.sha256(rollback).hexdigest()==before['boot_b']
    assert hashlib.sha256(data).hexdigest()==manifest['boot_b_sha256']
    dev=devices['boot_b'];assert int(ssh(f'cat /sys/class/block/{dev}/size'))*512==len(data)
    assert int(re.search(rb'MemAvailable:\s*(\d+)',state).group(1))*1024>len(data)*2
    print('Uploading verified SDMA boot candidate to RAM',flush=True)
    assert ssh('cat > /tmp/sdma-boot.img; sha256sum /tmp/sdma-boot.img',data).decode().split()[0]==manifest['boot_b_sha256']
    if TRACE:
        initdata=(OUT/'init_boot_b-trace.img').read_bytes()
        assert hashlib.sha256(initdata).hexdigest()==manifest['init_boot_b_sha256']
        assert int(ssh(f"cat /sys/class/block/{devices['init_boot_b']}/size"))*512==len(initdata)
        assert ssh('cat > /tmp/trace-init.img; sha256sum /tmp/trace-init.img',initdata).decode().split()[0]==manifest['init_boot_b_sha256']
    (OUT/'before.json').write_text(json.dumps(before,indent=2)+'\n');(OUT/'before.txt').write_bytes(state)
    assert ssh(f"grep '^PARTNAME=' /sys/class/block/{dev}/uevent").strip()==b'PARTNAME=boot_b'
    response=ssh(f'set -e; dd if=/tmp/sdma-boot.img of=/dev/{dev} bs=1048576 conv=fsync; sync; sha256sum /dev/{dev}')
    (OUT/'write-readback.txt').write_bytes(response)
    assert response.decode().split()[0]==manifest['boot_b_sha256'],'do not reboot on readback mismatch'
    if TRACE:
        initdev=devices['init_boot_b']
        assert ssh(f"grep '^PARTNAME=' /sys/class/block/{initdev}/uevent").strip()==b'PARTNAME=init_boot_b'
        response=ssh(f'set -e; dd if=/tmp/trace-init.img of=/dev/{initdev} bs=1048576 conv=fsync; sync; sha256sum /dev/{initdev}')
        (OUT/'init-write-readback.txt').write_bytes(response)
        assert response.decode().split()[0]==manifest['init_boot_b_sha256'],'do not reboot on init readback mismatch'
    after=hashes(devices)
    changed={'boot_b':manifest['boot_b_sha256']}
    if TRACE:changed['init_boot_b']=manifest['init_boot_b_sha256']
    assert all(after[n]==changed.get(n,before[n]) for n in before)
    (OUT/'after-write.json').write_text(json.dumps(after,indent=2)+'\n')
    print('PASS: boot_b and init_boot_b updated; complete readback matches; other six partitions unchanged; not rebooted' if TRACE else 'PASS: only boot_b updated; complete readback matches; other seven partitions unchanged; not rebooted')
elif sys.argv[1]=='capture':
    state=ssh('uname -a; cat /proc/sys/kernel/random/boot_id; cat /tmp/touch-init.log; '
              'cat /sys/module/synaptics_aston/parameters/report_rate_code; dmesg')
    (OUT/'after-state.txt').write_bytes(state)
    assert b'AA536 generator-based 60Hz driver' in state and b'AA536 60 Hz initialization complete' in state
    assert b'PJA_ASTON fixed report rate code=3 readback verified' in state
    assert b'loaded qcom/a740_sqe.fw' in state
    assert state.splitlines()[1]!=(OUT/'before.txt').read_bytes().splitlines()[1]
    actual=hashes(mapping());assert actual==json.loads((OUT/'after-write.json').read_text())
    (OUT/'after.json').write_text(json.dumps(actual,indent=2)+'\n')
    manifest['phone_execution_confirmed']=True
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(state.splitlines()[0].decode());print('PASS: SDMA boot readback and retained display, GPU firmware, touch/SSH startup verified')
else:raise SystemExit('flash | capture')

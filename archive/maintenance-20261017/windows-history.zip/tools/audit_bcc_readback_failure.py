"""Pin the observed zero-size BCC response to offline producer error handling."""
from pathlib import Path
import json
import re
import subprocess
import sys
root = Path(__file__).resolve().parents[1]
source = root / 'out/battery-bringup-20261016/charger-source'
out = root / 'out/native-install-20261017/temperature-readback'
dis = (source / 'adsp-charger-analysis-only.dis').read_text()
instructions = {}
for line in dis.splitlines():
    m = re.match(r'^([0-9a-f]+):', line)
    if m:
        instructions[int(m[1], 16)] = line
expected = {
    0x6009dbf4: 'call 0x601a5380',
    0x6009dcbc: 'cmp.eq(r2,#0x0)',
    0x6009dcf0: 'memw(r2+#0x20c) = r3',
    0x6009dd0c: 'r3 = #0x210',
    0x601a543c: 'call 0x601af1f0',
    0x601a5458: 'or(r2,r0)',
    0x601af260: 'memh(r2+#0x0) = ##0x200',
    0x601a5474: 'call 0x600681f0',
    0x601a55c8: 'memw(r2+#0x1c) = r3',
    0x601a5730: 'r0 = memh(r30+#-0x52)',
}
for address, text in expected.items():
    assert text in instructions[address], hex(address)
captures = sorted(out.glob('live-*.txt'))
capture = captures[-1]
text = capture.read_text(errors='replace')
assert 'len=528 owner=32778 type=1 size=0' in text
assert 'BCC_READ_RESULT=-61' in text
ranges = ['6009dbe0:6009dd14', '601a5434:601a5480',
          '601af1f0:601af268', '601a55c0:601a55cc', '601a572c:601a5738']
p = subprocess.run([sys.executable, str(root / 'tools/inspect_adsp_disassembly.py'), *ranges],
                   capture_output=True, check=True)
(out / 'zero-buffer-evidence.dis').write_bytes(p.stdout)
report = dict(runtime_capture=str(capture), response_length=528, owner=32778,
    type=1, data_size=0, temperature_readback_verified=False,
    producer_aggregates_adsp_gauge_errors=True,
    uninitialized_gauge_dependency_returns_0x200=True,
    interpretation='Observed firmware producer error; specific failed callee is not traced live.',
    temperature_set_ack_remains_valid=True, original_readonly_module_restored=True)
(out / 'zero-buffer-audit.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))

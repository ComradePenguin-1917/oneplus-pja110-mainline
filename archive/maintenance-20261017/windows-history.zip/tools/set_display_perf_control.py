"""Use existing DPU debugfs tuning for a reversible clock-only comparison."""
import argparse,subprocess,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('mode',choices=('fast','restore'))
args=parser.parse_args()
out=ROOT/'out/display-timing-20261014/counters';out.mkdir(exist_ok=True)
keys=ROOT/'out/usb-ncm-20261013/ssh'
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(keys/'client_key_host'),
 '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
 '-o',f'UserKnownHostsFile={keys/"known_hosts"}','-o','ConnectTimeout=5','root@169.254.42.1']
def run(cmd):
 p=subprocess.run(ssh+[cmd],capture_output=True,timeout=20)
 p.check_returncode();return p.stdout
base='/sys/kernel/debug/dri/0/debug/core_perf'
names=('perf_mode','fix_core_clk_rate','fix_core_ib_vote','fix_core_ab_vote')
if args.mode=='fast':
 values={n:run(f'cat {base}/{n}').decode().strip() for n in names}
 assert values['perf_mode']=='mode 0',values
 maximum=int(run(f'cat {base}/max_core_clk_rate'))
 assert maximum==514000000
 # Exact bandwidth from the live normal-mode trace: keep AB and IB unchanged.
 (out/'perf-before.json').write_text(json.dumps(values,indent=2)+'\n')
 command=f'''set -e
echo 1008506880 > {base}/fix_core_ab_vote
echo 800000 > {base}/fix_core_ib_vote
echo {maximum} > {base}/fix_core_clk_rate
echo 2 > {base}/perf_mode
sleep 2
cat {base}/perf_mode
cat {base}/core_clk_rate
cat /sys/kernel/debug/clk/clk_summary | grep mdss_mdp_clk
cat /sys/kernel/debug/dri/0/encoder-0/status
'''
else:
 values=json.loads((out/'perf-before.json').read_text())
 assert values['perf_mode']=='mode 0'
 command=f'set -e; echo 0 > {base}/perf_mode; sleep 2; '
 command+='; '.join(f'echo {int(values[n])} > {base}/{n}' for n in names[1:])
 command+=f'; cat {base}/perf_mode; cat {base}/core_clk_rate; cat /sys/kernel/debug/clk/clk_summary | grep mdss_mdp_clk'
state=run(command)
(out/f'perf-{args.mode}.txt').write_bytes(state)
if args.mode=='fast':assert b'514000000' in state and b'mode 2' in state,state
else:assert b'mode 0' in state,state
print(state.decode())

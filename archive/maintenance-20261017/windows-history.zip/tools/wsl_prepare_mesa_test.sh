#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
OUT="$WIN/out/mesa-offscreen-20261014"
BUILD="$ROOT/mesa-offscreen-runtime"
mkdir -p "$BUILD"
for package in "$OUT/debs/"*.deb; do dpkg-deb -x "$package" "$BUILD"; done
export PATH="$ROOT/toolchain/gcc-12-aarch64/usr/bin:$PATH"
export LD_LIBRARY_PATH="$ROOT/toolchain/gcc-12-aarch64/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
aarch64-linux-gnu-gcc --sysroot="$ROOT/toolchain/gcc-12-aarch64" -O2 -Wall -Wextra "$WIN/tools/mesa_offscreen_test.c" -ldl -o "$BUILD/mesa-offscreen-test" > "$OUT/test-build.log" 2>&1
tar -C "$BUILD" -czf "$OUT/runtime.tar.gz" .
echo 'PASS: isolated ARM64 Mesa runtime and offscreen test packaged; no installation'

"""Offline audit of this phone's split Qualcomm ADSP firmware and DT memory."""
from pathlib import Path
import hashlib
import json
import re
import struct
import tarfile

from fdt import FDT

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'out/battery-bringup-20261016/charger-source'
DT = FDT((OUT.parent / 'battery-0.dtb').read_bytes()).nodes()
remote = DT['/soc@0/remoteproc@6800000']
handles = struct.unpack('>' + 'I' * (len(remote['memory-region']) // 4), remote['memory-region'])
regions = []
for handle in handles[:2]:
    matches = [(path, props) for path, props in DT.items()
               if props.get('phandle') == struct.pack('>I', handle)]
    assert len(matches) == 1
    path, props = matches[0]
    base, size = struct.unpack('>QQ', props['reg'])
    regions.append((path, base, size))

report = {'remoteproc_status': remote['status'].rstrip(b'\0').decode(),
          'images': [], 'secure_boot_authentication_verified': False,
          'runtime_compatibility_verified': False}
with tarfile.open(OUT / 'stock-charger-firmware.tar') as archive:
    contents = {m.name: archive.extractfile(m).read() for m in archive.getmembers() if m.isfile()}
    manifest = contents['charger-firmware-audit/sha256.txt'].decode().splitlines()
    for line in manifest:
        digest, name = line.split(None, 1)
        name = name.strip().removeprefix('/home/penguin/')
        assert hashlib.sha256(contents[name]).hexdigest() == digest, name
    report['verified_file_count'] = len(manifest)
    for stem, (region_name, base, size) in zip(('adsp', 'adsp_dtb'), regions):
        prefix = 'charger-firmware-audit/modem_a/image/'
        header = contents[prefix + stem + '.mdt']
        assert header[:7] == b'\x7fELF\x01\x01\x01'
        elf = struct.unpack_from('<16sHHIIIIIHHHHHH', header)
        phoff, entsize, count = elf[5], elf[9], elf[10]
        assert entsize == 32 and phoff + entsize * count <= len(header)
        segments = []
        for i in range(count):
            typ, offset, va, pa, filesz, memsz, flags, align = struct.unpack_from('<8I', header, phoff + i * entsize)
            # Qualcomm MDT ignores hash and non-PT_LOAD/empty-memory segments.
            if typ != 1 or (flags & 0x07000000) == 0x02000000 or not memsz:
                continue
            assert filesz <= memsz
            name = f'{stem}.b{i:02d}'
            if filesz:
                assert prefix + name in contents, name
                assert len(contents[prefix + name]) == filesz, name
            segments.append({'index': i, 'paddr': pa, 'filesz': filesz, 'memsz': memsz,
                             'relocatable': bool(flags & 0x08000000)})
        low = min(s['paddr'] for s in segments)
        high = max((s['paddr'] + s['memsz'] + 4095) & ~4095 for s in segments)
        relocatable = any(s['relocatable'] for s in segments)
        load_base = low if relocatable else base
        for segment in segments:
            offset = segment['paddr'] - load_base
            assert 0 <= offset and offset + segment['memsz'] <= size, segment
        image = {'name': stem, 'machine': elf[2], 'program_headers': count,
                 'load_segments': len(segments), 'segments': segments,
                 'region': region_name, 'reserved_base': hex(base), 'reserved_size': hex(size),
                 'firmware_min': hex(low), 'firmware_end_page_aligned': hex(high),
                 'span': hex(high - low), 'relocatable': relocatable,
                 'all_load_segments_fit': True}
        report['images'].append(image)
        # Keep the original signed split files: the upstream MDT loader accepts these.
        target = OUT / 'firmware/qcom/sm8550/xigua'
        target.mkdir(parents=True, exist_ok=True)
        for name, data in contents.items():
            leaf = name.removeprefix(prefix)
            if re.fullmatch(re.escape(stem) + r'\.(mdt|b\d\d)', leaf):
                (target / leaf).write_bytes(data)

vendor = (OUT / 'oplus_battery_sm8550.h').read_text()
upstream = (OUT / 'qcom_battmgr.c').read_text()
comparison = {}
for enum, prefix in [('battery_property_id', 'BATT_'), ('usb_property_id', 'USB_')]:
    body = re.search(r'enum\s+' + enum + r'\s*\{(.*?)\};', vendor, re.S)[1]
    body = body.split('#ifdef')[0]
    names = re.findall(r'\b' + prefix + r'[A-Z0-9_]+\b', body)
    for value, name in enumerate(names):
        match = re.search(r'^#define\s+' + name + r'\s+(\d+)\s*$', upstream, re.M)
        if match:
            assert int(match[1]) == value, (name, value, match[1])
            comparison[name] = value
report['matching_standard_property_ids'] = comparison
report['battmgr_has_set_property_callback'] = bool(re.search(r'\.set_property\s*=', upstream))
(OUT / 'offline-adsp-audit.json').write_text(json.dumps(report, indent=2) + '\n')
for image in report['images']:
    print(image['name'], 'PASS: segment sizes and reserved-memory bounds',
          image['firmware_min'], image['firmware_end_page_aligned'], 'span', image['span'])
print('PASS:', len(comparison), 'standard battery/USB property IDs match vendor source')
print('Secure authentication, service availability and actual charging remain untested.')

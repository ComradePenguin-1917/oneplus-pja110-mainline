"""Probe __enable_mmu's return using zero padding in its executable idmap page."""
from pathlib import Path
import hashlib
import json
import shutil
import struct
import sys
from bootimg import BootImage

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'out/avb-fixup-control-20261012'
PREVIOUS = ROOT / 'out/kernel-entry-probe-20261012'
VIRTUAL = '--virtual-switch' in sys.argv
START_KERNEL = '--start-kernel' in sys.argv
AFTER_SETUP = '--after-setup-arch' in sys.argv
AFTER_SCHED = '--after-sched-init' in sys.argv
AFTER_IRQ = '--after-init-irq' in sys.argv
BEFORE_REST = '--before-rest-init' in sys.argv
AFTER_INITCALLS = '--after-initcalls' in sys.argv
AFTER_FREEABLE = '--after-kernel-init-freeable' in sys.argv
AFTER_ASYNC = '--after-async-sync' in sys.argv
AFTER_FREE_INITMEM = '--after-free-initmem' in sys.argv
BEFORE_USERSPACE = '--before-userspace' in sys.argv
RUN_INIT_ENTRY = '--run-init-entry' in sys.argv
INIT_EL0_BOUNDARY = '--init-el0-boundary' in sys.argv
EXEC_FORCE_ERROR = '--exec-return-force-error' in sys.argv
EXEC_RETURN = '--exec-return' in sys.argv or EXEC_FORCE_ERROR
RESIDENT_PADDING = AFTER_FREE_INITMEM or BEFORE_USERSPACE or RUN_INIT_ENTRY or EXEC_RETURN or INIT_EL0_BOUNDARY
INIT_PADDING = VIRTUAL or START_KERNEL or AFTER_SETUP or AFTER_SCHED or AFTER_IRQ or BEFORE_REST or AFTER_INITCALLS or AFTER_FREEABLE or AFTER_ASYNC
OUT = ROOT / ('out/kernel-after-init-irq-probe-20261012' if AFTER_IRQ else 'out/kernel-after-sched-init-probe-20261012' if AFTER_SCHED else 'out/kernel-after-setup-arch-probe-20261012' if AFTER_SETUP else 'out/kernel-start-kernel-probe-20261012' if START_KERNEL else 'out/kernel-virtual-switch-probe-20261012' if VIRTUAL else 'out/kernel-post-mmu-probe-20261012')
if BEFORE_REST:
    OUT = ROOT / 'out/kernel-before-rest-init-probe-20261012'
if AFTER_INITCALLS:
    OUT = ROOT / 'out/kernel-after-initcalls-probe-20261012'
if AFTER_FREEABLE:
    OUT = ROOT / 'out/kernel-after-kernel-init-freeable-probe-20261012'
if AFTER_ASYNC:
    OUT = ROOT / 'out/kernel-after-async-sync-probe-20261012'
if RESIDENT_PADDING:
    OUT = ROOT / ('out/kernel-before-userspace-probe-20261012' if BEFORE_USERSPACE else 'out/kernel-after-free-initmem-probe-20261012')
if RUN_INIT_ENTRY:
    OUT = ROOT / 'out/kernel-run-init-entry-probe-20261012'
if EXEC_RETURN:
    OUT = ROOT / 'out/kernel-exec-return-probe-20261012'
if EXEC_FORCE_ERROR:
    OUT = ROOT / 'out/kernel-exec-return-force-error-probe-20261012'
if INIT_EL0_BOUNDARY:
    OUT = ROOT / 'out/kernel-init-el0-boundary-probe-20261012'
OUT.mkdir(exist_ok=True)
symbols = {}
for line in (PREVIOUS/'kernel-symbols.txt').read_text().splitlines():
    parts = line.split()
    if len(parts) == 3:
        symbols[parts[2]] = int(parts[0], 16)
known = json.loads((BASE/'manifest.json').read_text())
boot = BootImage.parse(str(BASE/'boot-xigua-r1.img'))
original = boot.kernel
assert hashlib.sha256(original).hexdigest() == 'd8ade08069b8440b349f4b4aeb430dd6e9057eca08c94a8268e3708a83e53425'
stub = (PREVIOUS/'probe.bin').read_bytes()
if EXEC_RETURN:
    stub = (ROOT/'out/kernel-exec-return-probe-20261012/probe.bin').read_bytes()
    if EXEC_FORCE_ERROR:
        stub = struct.pack('<I', 0x52800020) + stub  # mov w0,#1, diagnostic only
base = symbols['_text']
if RESIDENT_PADDING:
    if INIT_EL0_BOUNDARY:
        patch = symbols['ret_from_fork'] - base + 0x1c
        call = struct.unpack_from('<I', original, patch-4)[0]
        assert call == 0x943f4bca
        assert base+patch-4+(call & 0x03ffffff)*4 == symbols['asm_exit_to_user_mode']
        original_branch = struct.unpack_from('<I', original, patch)[0]
        assert original_branch == 0x17ffefc1
        immediate = (original_branch & 0x03ffffff) - 0x04000000
        assert base+patch+immediate*4 == symbols['ret_to_user']
    elif EXEC_RETURN:
        patch = symbols['run_init_process'] - base + 0xa8
        assert struct.unpack_from('<I', original, patch)[0] == 0xa94153f3, 'expected register restore after exec call'
        call = struct.unpack_from('<I', original, patch-4)[0]
        assert call == 0x940c1808
        assert base+patch-4+(call & 0x03ffffff)*4 == symbols['kernel_execve']
    elif RUN_INIT_ENTRY:
        patch = symbols['run_init_process'] - base + 4
        assert struct.unpack_from('<I', original, patch-4)[0] == 0xd503233f, 'expected PACIASP'
        assert struct.unpack_from('<I', original, patch)[0] == 0xa9bd7bfd, 'expected stack frame instruction'
    else:
        patch = symbols['kernel_init'] - base + (0x68 if BEFORE_USERSPACE else 0x34)
        assert struct.unpack_from('<I', original, patch)[0] == (0xf9408a60 if BEFORE_USERSPACE else 0x900037e0), 'unexpected instruction at resident probe site'
        call = struct.unpack_from('<I', original, patch-4)[0]
        assert call == (0x97cf49a5 if BEFORE_USERSPACE else 0x97c11ded), 'unexpected previous call'
        immediate = call & 0x03ffffff
        if immediate & 0x02000000:
            immediate -= 0x04000000
        assert base+patch-4+immediate*4 == symbols['do_sysctl_args' if BEFORE_USERSPACE else 'free_initmem']
    offset = symbols['__hyp_text_end'] - base
    assert offset % 4096 == 0
    assert symbols['_stext'] - base <= offset
    assert offset + len(stub) < symbols['_etext'] - base < symbols['__init_begin'] - base
    if INIT_EL0_BOUNDARY:
        gate_address = base + offset
        target = symbols['kernel_init']
        page_delta = (target >> 12) - (gate_address >> 12)
        assert -(1 << 20) <= page_delta < (1 << 20)
        adrp = 0x90000009 | ((page_delta & 3) << 29) | (((page_delta >> 2) & 0x7ffff) << 5)
        add = 0x91000129 | ((target & 0xfff) << 10)
        fallback_delta = symbols['ret_to_user'] - (gate_address + 16)
        assert fallback_delta % 4 == 0 and -(1 << 27) <= fallback_delta < (1 << 27)
        fallback = 0x14000000 | ((fallback_delta // 4) & 0x03ffffff)
        # x19 retains the kernel thread function across both C calls (callee-saved).
        # Other threads continue via the original ret_to_user branch; x9 is restored there.
        stub = struct.pack('<5I', adrp, add, 0xeb09027f, 0x54000040, fallback) + stub
        assert offset + len(stub) < symbols['_etext'] - base
elif INIT_PADDING:
    if AFTER_FREEABLE or AFTER_ASYNC:
        patch = symbols['kernel_init'] - base + (0x28 if AFTER_ASYNC else 0x20)
        assert struct.unpack_from('<I', original, patch)[0] == (0x52800040 if AFTER_ASYNC else 0xb0006ff3), 'unexpected instruction after initialization call'
        call = struct.unpack_from('<I', original, patch-4)[0]
        assert call == (0x97c39642 if AFTER_ASYNC else 0x941e5716), 'unexpected initialization call'
        immediate = call & 0x03ffffff
        if immediate & 0x02000000:
            immediate -= 0x04000000
        assert base+patch-4+immediate*4 == symbols['async_synchronize_full' if AFTER_ASYNC else 'kernel_init_freeable']
    elif AFTER_INITCALLS:
        patch = symbols['kernel_init_freeable'] - base + 0x1f4
        assert struct.unpack_from('<I', original, patch)[0] == 0x97a25062, 'expected wait_for_initramfs call'
        call = struct.unpack_from('<I', original, patch-4)[0]
        assert call == 0x97acd6e7, 'expected kfree after inlined do_initcalls'
        immediate = (call & 0x03ffffff) - 0x04000000
        assert base+patch-4+immediate*4 == symbols['kfree']
    elif BEFORE_REST:
        patch = symbols['start_kernel'] - base + 0x5f4
        call = struct.unpack_from('<I', original, patch)[0]
        assert call == 0x97e1a91b, 'expected rest_init call'
        immediate = call & 0x03ffffff
        if immediate & 0x02000000:
            immediate -= 0x04000000
        assert base+patch+immediate*4 == symbols['rest_init']
    elif AFTER_SETUP or AFTER_SCHED or AFTER_IRQ:
        patch = symbols['start_kernel'] - base + (0x334 if AFTER_IRQ else 0x30c if AFTER_SCHED else 0x70)
        call = struct.unpack_from('<I', original, patch-4)[0]
        assert call & 0xfc000000 == 0x94000000
        immediate = call & 0x03ffffff
        if immediate & 0x02000000:
            immediate -= 0x04000000
        expected_call = 'init_IRQ' if AFTER_IRQ else 'sched_init' if AFTER_SCHED else 'setup_arch'
        assert base+patch-4+immediate*4 == symbols[expected_call], f'previous instruction must call {expected_call}'
        assert struct.unpack_from('<I', original, patch)[0] == (0x94005c7f if AFTER_IRQ else 0xd53b4220 if AFTER_SCHED else 0x94006e45), 'unexpected instruction after initialization call'
    elif START_KERNEL:
        patch = symbols['start_kernel'] - base + 4
        assert struct.unpack_from('<I', original, patch-4)[0] == 0xd503233f, 'expected PACIASP'
        assert struct.unpack_from('<I', original, patch)[0] == 0xb0003380, 'expected init-task ADRP'
    else:
        patch = symbols['__primary_switched'] - base + 4
        assert struct.unpack_from('<I', original, patch-4)[0] == 0xd503245f, 'expected BTI C'
        assert struct.unpack_from('<I', original, patch)[0] == 0xf0003324, 'expected init-task ADRP'
    offset = (symbols['__alt_instructions_end'] - base + 15) & ~15
    assert symbols['__inittext_begin'] - base <= offset
    assert offset + len(stub) < symbols['__inittext_end'] - base
else:
    patch = symbols['__enable_mmu'] - base + 0x4c
    assert struct.unpack_from('<I', original, patch)[0] == 0xd65f03c0, 'expected RET'
    assert struct.unpack_from('<I', original, patch-4)[0] == 0xd5033fdf, 'expected final ISB'
    offset = (symbols['__idmap_text_end'] - base + 15) & ~15
    page_end = (symbols['__idmap_text_end'] - base + 4095) & ~4095
    assert page_end == symbols['idmap_pg_dir'] - base
    assert offset + len(stub) <= page_end
    assert offset//4096 == (symbols['__idmap_text_end']-base-1)//4096
assert not any(original[offset:offset+len(stub)]), 'probe padding must be unused zeros'
modified = bytearray(original)
modified[offset:offset+len(stub)] = stub
struct.pack_into('<I', modified, patch, 0x14000000 | ((offset-patch)//4 & 0x03ffffff))
assert len(modified) == len(original) and modified[:64] == original[:64]
assert all(a == b for i, (a, b) in enumerate(zip(original, modified))
           if not (patch <= i < patch+4 or offset <= i < offset+len(stub)))
(OUT/'Image-probe').write_bytes(modified)
boot.kernel = bytes(modified)
(OUT/'boot-xigua-r1.img').write_bytes(boot.pack(cmdline=boot.cmdline.decode()))
assert BootImage.parse(str(OUT/'boot-xigua-r1.img')).kernel == modified
for name in ('vendor_boot_b-xigua-r1.img', 'init_boot_b-xigua-r1.img', 'dtbo_b-avb-noop.img'):
    assert hashlib.sha256((BASE/name).read_bytes()).hexdigest() == known['files'][name]['sha256']
    shutil.copyfile(BASE/name, OUT/name)
manifest = {'experiment': 'start_kernel immediately after init_IRQ returns' if AFTER_IRQ else 'start_kernel immediately after sched_init returns' if AFTER_SCHED else 'start_kernel immediately after setup_arch returns' if AFTER_SETUP else 'start_kernel entry before C initialization' if START_KERNEL else '__primary_switched entry after virtual address jump' if VIRTUAL else '__enable_mmu return redirected after final ISB',
    'baseline': 'r1 Image and ABL-success control; only boot_b differs',
    'patch_offset': patch, 'probe_offset': offset, 'probe_bytes': len(stub),
    'probe_in_last_executable_idmap_page': not INIT_PADDING and not RESIDENT_PADDING, 'probe_in_init_executable_padding': INIT_PADDING, 'probe_in_resident_text_padding': RESIDENT_PADDING, 'probe_in_bss': False,
    'image_size_and_header_unchanged': True, 'phone_execution_confirmed': False,
    'files': {name: {'bytes': (OUT/name).stat().st_size,
        'sha256': hashlib.sha256((OUT/name).read_bytes()).hexdigest()}
        for name in ('boot-xigua-r1.img', 'vendor_boot_b-xigua-r1.img',
                     'init_boot_b-xigua-r1.img', 'dtbo_b-avb-noop.img')}}
if BEFORE_REST:
    manifest['experiment'] = 'start_kernel call site immediately before rest_init'
if AFTER_INITCALLS:
    manifest['experiment'] = 'kernel_init_freeable after inlined do_initcalls, before wait_for_initramfs'
if AFTER_FREEABLE:
    manifest['experiment'] = 'kernel_init immediately after kernel_init_freeable returns, before async_synchronize_full and free_initmem'
if AFTER_ASYNC:
    manifest['experiment'] = 'kernel_init immediately after async_synchronize_full returns, before free_initmem'
if RESIDENT_PADDING:
    manifest['experiment'] = 'kernel_init before selecting initial userspace command' if BEFORE_USERSPACE else 'kernel_init immediately after free_initmem returns'
if RUN_INIT_ENTRY:
    manifest['experiment'] = 'run_init_process entry after PACIASP, before execution attempt'
if INIT_EL0_BOUNDARY:
    manifest['experiment'] = 'kernel_init thread after asm_exit_to_user_mode returns, before ret_to_user'
    manifest['thread_filter'] = 'callee-saved x19 equals kernel_init; other threads follow original ret_to_user'
    manifest['user_mode_instruction_execution_confirmed'] = False
if EXEC_RETURN:
    manifest['experiment'] = 'kernel_execve return value encoded by reset delay before run_init_process returns'
    manifest['return_value_reset_delay_seconds'] = {'zero': 5, 'nonzero': 35}
    if EXEC_FORCE_ERROR:
        manifest['experiment'] = 'same exec return site, forced 35-second reset delay calibration'
        manifest['forced_diagnostic_return_value'] = 1
if EXEC_RETURN and not EXEC_FORCE_ERROR:
    for suffix, value in [('zero', 0), ('error', 1)]:
        control_out = ROOT / f'out/kernel-exec-return-{suffix}-control-20261012'
        control_out.mkdir(exist_ok=True)
        control = bytearray(original)
        control_stub = struct.pack('<I', 0x52800000 | (value << 5)) + stub
        assert not any(original[offset:offset+len(control_stub)])
        control[offset:offset+len(control_stub)] = control_stub
        struct.pack_into('<I', control, 4, 0x14000000 | ((offset-4)//4 & 0x03ffffff))
        (control_out/'Image-probe').write_bytes(control)
(OUT/'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
print(json.dumps(manifest, indent=2))

"""Resolve stock firmware charger callback tables without device access."""
from pathlib import Path
import hashlib
import json
import runpy
import struct
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
scope = runpy.run_path(str(ROOT / 'tools/inspect_adsp_disassembly.py'))
OUT = scope['OUT']
assert hashlib.sha256((OUT / 'firmware/qcom/sm8550/xigua/adsp.b18').read_bytes()).hexdigest() == 'a1f79a3901637d9e8e24a69eae838547a05a36977467e52934e8b9fd6b5c8d18'

def words(address, count):
    for base, data in scope['segments']:
        offset = address - base
        if 0 <= offset and offset + count * 4 <= len(data):
            return struct.unpack_from('<' + 'I' * count, data, offset)
    raise ValueError(hex(address))

# InitializePeripheralSchgChgr selects these tables from its model switch.
tables = {hex(a): [hex(v) for v in words(a, 8)]
          for a in [0x60273b44, 0x60273ae0, 0x60273ba8, 0x60273c0c]}
assert {v[1] for v in tables.values()} == {'0x600c46b0', '0x600c5f60'}
models = {}
for i, target in enumerate(words(0x60222f0c, 40)):
    if target != 0x600c7b9c:
        models[hex(i + 0x20)] = hex(target)
framework = (OUT / 'oplus_voocphy.c').read_text()
start = framework.index('void oplus_voocphy_turn_off_fastchg(void)')
end = framework.index('void oplus_voocphy_handle_voocphy_status', start)
handoff = framework[start:end]
for call in ['oplus_vooc_switch_mode(NORMAL_CHARGER_MODE)',
             'oplus_voocphy_reset_voocphy()',
             'oplus_chg_unsuspend_charger()']:
    assert call in handoff
report = {
    'scope': 'offline decoded tables and pinned source; runtime selection unknown',
    'oem_enable_dispatch': 'property 24 -> 0x600aacc0(index 7, enable) -> registered table[1]',
    'table_first_eight_words': tables,
    'model_switch_nondefault_targets': models,
    'decoded_enable_backends': {
        '0x600c46b0': {'register': '0x1042', 'mask': 1,
                       'value': 'requested enable byte', 'call': '0x60096770'},
        '0x600c5f60': {'register': '0x2646', 'mask': 1,
                       'value': 'requested enable byte', 'call': '0x60096770'},
    },
    'register_helper': 'read-modify-write: (requested & mask) | (old & ~mask)',
    'slave_id_source': 'per-index initialization descriptor byte 6, copied into table entry byte 1',
    'factory_pm8550b_spmi_usid': 7,
    'usid_caution': 'logical charger index 7 does not itself establish SPMI USID 7',
    'ap_fastcharge_exit': handoff,
    'unresolved': ['Runtime PMIC model/descriptor and selected callback table',
                   'Reset/default enable, votes and suspend state',
                   'Which physical conversion stages are shared',
                   'Whether inactive SC8517 affects current ordinary charging'],
    'hardware_writes_performed': False,
}
ranges = ['601a1bac:601a1bdc', '600aacc0:600aaec8',
          '600c7800:600c7c84', '600c46b0:600c472c',
          '600c5f60:600c5fdc', '60096770:6009682c']
result = subprocess.run([sys.executable, str(ROOT / 'tools/inspect_adsp_disassembly.py'),
                         *ranges], capture_output=True, check=True)
(OUT / 'charger-enable-backends-annotated.dis').write_bytes(result.stdout)
(OUT / 'charger-enable-backends.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: report[k] for k in ('oem_enable_dispatch', 'decoded_enable_backends',
                                        'hardware_writes_performed')}, indent=2))

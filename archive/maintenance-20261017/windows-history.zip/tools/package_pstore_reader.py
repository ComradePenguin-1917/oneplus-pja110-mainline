"""Replace only generic /init with a verified collector; preserve factory init."""
import hashlib
import json
import pathlib
import struct
from build_init_marker_test import parse_cpio, make_entry, lz4

ROOT=pathlib.Path(__file__).resolve().parents[1]
OUT=ROOT/'out/stock-pstore-control-20261012'

def main():
    elf=(OUT/'early-reader').read_bytes()
    assert elf[:5]==b'\x7fELF\x02' and struct.unpack_from('<H',elf,18)[0]==183
    original=(ROOT/'backup/init_boot_b.img').read_bytes()
    oldsize=struct.unpack_from('<I',original,12)[0]
    end=4096+(oldsize+4095)//4096*4096
    entries=parse_cpio(lz4(['-d','-l','-c'],original[4096:4096+oldsize]))
    assert not any(n=='init.real' for _,n,_ in entries)
    result=bytearray()
    ino=max(f[0] for f,_,_ in entries)+1
    for f,n,d in entries:
        if n=='init':
            result+=make_entry(f,'init.real',d)
            f=list(f); f[0]=ino; f[1]=0o100755
            result+=make_entry(f,'init',elf)
        else:
            result+=make_entry(f,n,d)
    parsed=parse_cpio(bytes(result))
    src={n:d for _,n,d in entries}; dst={n:d for _,n,d in parsed}
    assert len(dst)==len(src)+1 and dst['init.real']==src['init'] and dst['init']==elf
    assert all(dst[n]==d for n,d in src.items() if n!='init')
    packed=lz4(['-z','-l','-12','-c'],bytes(result))
    assert len(packed)<=end-4096, (len(packed),end-4096)
    assert lz4(['-d','-l','-c'],packed)==result
    new=bytearray(original)
    struct.pack_into('<I',new,12,len(packed))
    new[4096:end]=packed+b'\0'*(end-4096-len(packed))
    assert len(new)==len(original) and new[end:]==original[end:]
    (OUT/'init_boot_b-early-reader.img').write_bytes(new)
    e={'early_reader_sha256':hashlib.sha256(elf).hexdigest(),'original_init_preserved':True,'all_other_cpio_files_preserved':True,'original_ramdisk_page_allocation':end-4096,'new_compressed_bytes':len(packed),'init_boot_image_sha256':hashlib.sha256(new).hexdigest(),'original_boot_b_sha256':hashlib.sha256((ROOT/'backup/boot_b.img').read_bytes()).hexdigest()}
    (OUT/'package.json').write_text(json.dumps(e,indent=2)+'\n')
    print(json.dumps(e,indent=2))

if __name__=='__main__': main()

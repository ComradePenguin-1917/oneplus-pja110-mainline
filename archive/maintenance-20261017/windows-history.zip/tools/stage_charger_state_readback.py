"""Upload a fixed bounded charger GET test; do not invoke remote sudo."""
from pathlib import Path
import hashlib
import subprocess
from prepare_native_install import SSH

out = Path('out/native-install-20261017/charger-state-readback')
args = SSH[:]
args[-1] = 'penguin@172.16.42.1'
args = [x if not x.startswith('UserKnownHostsFile=') else
        'UserKnownHostsFile=out/native-install-20261017/known_hosts' for x in args]

def run(cmd, data=None):
    p = subprocess.run(args + [cmd], input=data, capture_output=True, timeout=30)
    print(p.stdout.decode(errors='replace'), end='')
    print(p.stderr.decode(errors='replace'), end='')
    p.check_returncode()
    return p.stdout

data = (out / 'qcom_battmgr-state.ko').read_bytes()
sha = hashlib.sha256(data).hexdigest()
uploaded = run('umask 077; mkdir -p /home/penguin/charger-state-readback; '
               'cat > /home/penguin/charger-state-readback/qcom_battmgr-state.ko; '
               'sha256sum /home/penguin/charger-state-readback/qcom_battmgr-state.ko', data)
assert uploaded.decode().split()[0] == sha
script = '''#!/bin/sh
set -eu
test "$(id -u)" = 0
cd /home/penguin/charger-state-readback
# Avoid concurrent module swaps if this script is accidentally run twice.
mkdir /run/pja110-charger-state-lock || exit 1
trap 'rmdir /run/pja110-charger-state-lock' EXIT
exec > result.log 2>&1
chmod 644 result.log
test "$(uname -r)" = 6.14.0-oneplus-xigua
test "$(cat /sys/module/qcom_battmgr/parameters/pja110_charger_init)" = N
echo "@SHA@  qcom_battmgr-state.ko" | sha256sum -c -
test -f /usr/local/lib/pja110/qcom_battmgr.ko
snapshot() {
    cat /proc/sys/kernel/random/boot_id /proc/uptime
    cat /sys/class/power_supply/bq28z610-0/uevent
}
restore() {
    if [ -d /sys/module/qcom_battmgr ]; then
        rmmod qcom_battmgr || return 1
    fi
    insmod /usr/local/lib/pja110/qcom_battmgr.ko pja110_charger_init=0
    echo READONLY_MODULE_RESTORED
}
cleanup() {
    restore
    rmdir /run/pja110-charger-state-lock
}
snapshot
rmmod qcom_battmgr
trap cleanup EXIT
insmod ./qcom_battmgr-state.ko
done_flag=N
for i in $(seq 1 12); do
    done_flag=$(cat /sys/module/qcom_battmgr/parameters/readback_done)
    [ "$done_flag" = N ] || break
    sleep 1
done
echo "READBACK_DONE=$done_flag"
echo QUERY_ORDER=battery_enable,usb_suspend,usb_icl,battery_fcc,battery_fcc_max,usb_current_max
for name in query_result query_value firmware_result; do
    echo ATTRIBUTE=$name
    cat /sys/module/qcom_battmgr/parameters/$name
done
restore
trap 'rmdir /run/pja110-charger-state-lock' EXIT
snapshot
echo CHARGER_STATE_READBACK_COMPLETE
'''
script = script.replace('@SHA@', sha).replace('\r\n', '\n')
(out / 'read-charger-state.sh').write_bytes(script.encode())
run('cat > /home/penguin/read-charger-state.sh', script.encode())
run('sh -n /home/penguin/read-charger-state.sh; '
    'cat /sys/class/power_supply/bq28z610-0/uevent; '
    'ls /sys/module/qcom_battmgr/parameters')
print('Staged only. Administrator command: sudo sh /home/penguin/read-charger-state.sh')

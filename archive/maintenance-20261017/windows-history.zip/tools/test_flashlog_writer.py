"""Exercise the exact BusyBox writer on file fixtures, then the backed-up target."""
import json
import pathlib
import struct
import subprocess
import logdump_retention_control as t

ROOT=t.ROOT
OUT=t.OUT
REMOTE='/data/local/tmp/pja-flashlog-test'
BB=REMOTE+'/bin/busybox'

def push(local,remote):
    subprocess.run([t.f.ADB,'-s',t.f.SERIAL,'push',str(local),remote],capture_output=True,check=True,timeout=20)

def call(command):
    return subprocess.run([t.f.ADB,'-s',t.f.SERIAL,'shell',"su -c '"+command+"'"],capture_output=True,timeout=40)

def main():
    pre=json.loads((OUT/'preflight.json').read_text())
    gpt=(OUT/'disk-primary-gpt.bin').read_bytes()
    assert struct.unpack_from('<Q',gpt,4096+72)[0]==2
    assert struct.unpack_from('<I',gpt,4096+84)[0]==128
    t.root('mkdir -p '+REMOTE+'/sys/sde70 '+REMOTE+'/dev')
    t.root('chown 2000:2000 '+REMOTE+'/sys '+REMOTE+'/sys/sde70 '+REMOTE+'/dev')
    push(ROOT/'initramfs/flashlog',REMOTE+'/flashlog')
    push(OUT/'disk-primary-gpt.bin',REMOTE+'/dev/sde')
    (OUT/'fixture-uevent.txt').write_bytes(b'PARTNAME=logdump\n')
    (OUT/'fixture-partition.txt').write_bytes(b'70\n')
    (OUT/'fixture-size.txt').write_bytes(b'1048576\n')
    for name in ('uevent','partition','size'):
        push(OUT/('fixture-'+name+'.txt'),REMOTE+'/sys/sde70/'+name)
    t.root(BB+' truncate -s 536870912 '+REMOTE+'/dev/sde70')
    env='FLASHLOG_BUSYBOX='+BB+' FLASHLOG_SYS_ROOT='+REMOTE+'/sys FLASHLOG_DEV_ROOT='+REMOTE+'/dev FLASHLOG_TMP_ROOT='+REMOTE+' '
    p=call(env+BB+' sh '+REMOTE+'/flashlog --file-test')
    (OUT/'writer-positive-output.txt').write_bytes(p.stdout+p.stderr)
    p.check_returncode()
    data=t.root(BB+' dd if='+REMOTE+'/dev/sde70 bs=4096 skip=131056 count=16 2>/dev/null',binary=True)
    assert b'PJA110_MAINLINE_FLASHLOG_20261012_R1' in data
    (OUT/'writer-positive-journal.bin').write_bytes(data)
    t.root(BB+' dd if=/dev/zero of='+REMOTE+'/dev/sde70 bs=4096 seek=131056 count=16 conv=notrunc,fsync')
    original=t.root('sha256sum '+REMOTE+'/dev/sde70').decode().split()[0]
    bad=bytearray(gpt); bad[8192+69*128+16]^=1
    (OUT/'fixture-wrong-uuid-gpt.bin').write_bytes(bad)
    push(OUT/'fixture-wrong-uuid-gpt.bin',REMOTE+'/dev/sde')
    p=call(env+BB+' sh '+REMOTE+'/flashlog --file-test')
    (OUT/'writer-negative-output.txt').write_bytes(p.stdout+p.stderr)
    assert p.returncode!=0
    assert t.root('sha256sum '+REMOTE+'/dev/sde70').decode().split()[0]==original
    # Now the actual writer targets the fully backed-up, verified logdump only.
    realenv='FLASHLOG_BUSYBOX='+BB+' FLASHLOG_DEV_ROOT=/dev/block FLASHLOG_TMP_ROOT='+REMOTE+' '
    p=call(realenv+BB+' sh '+REMOTE+'/flashlog --once')
    (OUT/'writer-real-target-output.txt').write_bytes(p.stdout+p.stderr)
    p.check_returncode()
    data=t.tail('tail-after-android-writer.bin')
    assert b'PJA110_MAINLINE_FLASHLOG_20261012_R1' in data
    assert b'kernel=5.15.123-android13-8-droidspaces' in data
    e={'fixture_positive_pass':True,'wrong_gpt_uuid_rejected_without_writing':True,'actual_logdump_writer_readback_pass':True,'writer_sha256':t.digest((ROOT/'initramfs/flashlog').read_bytes()),'tested_with_same_busybox_as_mainline':True}
    (OUT/'writer-validation.json').write_text(json.dumps(e,indent=2)+'\n')
    print(json.dumps(e,indent=2))

if __name__=='__main__': main()

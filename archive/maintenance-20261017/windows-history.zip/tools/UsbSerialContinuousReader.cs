using System;
using System.Collections.Concurrent;
using System.IO;
using System.IO.Ports;
using System.Threading.Tasks;
using System.Threading;

public sealed class UsbSerialContinuousReader
{
    private readonly SerialPort port;
    private readonly ConcurrentQueue<byte[]> chunks = new ConcurrentQueue<byte[]>();
    private readonly ConcurrentQueue<string> errors = new ConcurrentQueue<string>();
    private readonly Task reader;
    private readonly Thread blockingReader;
    private volatile bool stopping;

    public UsbSerialContinuousReader(SerialPort port, bool dedicatedThread = false)
    {
        this.port = port;
        port.ErrorReceived += OnError;
        if (dedicatedThread) {
            blockingReader = new Thread(() => {
                var buffer = new byte[65536];
                try {
                    while (!stopping) {
                        int available = port.BytesToRead;
                        int n = port.BaseStream.Read(buffer, 0, Math.Max(1, Math.Min(available, buffer.Length)));
                        if (n == 0) break;
                        var copy = new byte[n];
                        Buffer.BlockCopy(buffer, 0, copy, 0, n);
                        chunks.Enqueue(copy);
                    }
                } catch (Exception ex) {
                    if (!stopping) errors.Enqueue(ex.GetType().Name + ": " + ex.Message);
                }
            });
            blockingReader.IsBackground = true;
            blockingReader.Priority = ThreadPriority.AboveNormal;
            blockingReader.Start();
            return;
        }
        reader = Task.Run(async () => {
            var buffer = new byte[65536];
            try {
                while (!stopping) {
                    int n = await port.BaseStream.ReadAsync(buffer, 0, buffer.Length).ConfigureAwait(false);
                    if (n == 0) break;
                    var copy = new byte[n];
                    Buffer.BlockCopy(buffer, 0, copy, 0, n);
                    chunks.Enqueue(copy);
                }
            } catch (Exception ex) {
                if (!stopping) errors.Enqueue(ex.GetType().Name + ": " + ex.Message);
            }
        });
    }

    private void OnError(object sender, SerialErrorReceivedEventArgs e)
    {
        errors.Enqueue(e.EventType.ToString());
    }

    public byte[] Drain()
    {
        using (var stream = new MemoryStream()) {
            byte[] bytes;
            while (chunks.TryDequeue(out bytes)) stream.Write(bytes, 0, bytes.Length);
            return stream.ToArray();
        }
    }

    public string[] Errors { get { return errors.ToArray(); } }

    public void Stop()
    {
        stopping = true;
        port.ErrorReceived -= OnError;
        port.Dispose();
        if (reader != null) reader.Wait(1000);
        if (blockingReader != null) blockingReader.Join(1000);
    }
}

"""RAM-only deployment and diagnostics using the existing verified debug SSH."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
sys.stdout.reconfigure(encoding='utf-8')

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'out/postmarketos-ram-20261015'
KEYS = ROOT/'out/usb-ncm-20261013/ssh'
SSH = ['C:/Windows/System32/OpenSSH/ssh.exe', '-F', 'none', '-T',
       '-i', str(KEYS/'client_key_host'), '-o', 'BatchMode=yes', '-o', 'IdentitiesOnly=yes',
       '-o', 'StrictHostKeyChecking=yes', '-o', f'UserKnownHostsFile={KEYS/"known_hosts"}',
       '-o', 'ConnectTimeout=8', '-o', 'ServerAliveInterval=5', 'root@169.254.42.1']

def run(command, data=None, timeout=60):
    result = subprocess.run(SSH+[command], input=data, capture_output=True, timeout=timeout)
    (OUT/'last-stderr.txt').write_bytes(result.stderr)
    if result.returncode:
        raise RuntimeError(result.stderr.decode(errors='replace') + result.stdout.decode(errors='replace'))
    return result.stdout

stage = sys.argv[1] if len(sys.argv)>1 else 'probe'
if stage == 'deploy':
    manifest = json.loads((OUT/'ram-artifact.json').read_text())
    path = OUT/manifest['artifact']
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(4*1024*1024), b''):
            digest.update(chunk)
    assert digest.hexdigest() == manifest['compressed_sha256']
    before = run('uname -a; cat /proc/sys/kernel/random/boot_id; df -k /tmp; cat /proc/1/comm')
    (OUT/'phone-before.txt').write_bytes(before)
    assert b'#24 SMP' in before and b'6.14.0-sm8550-xigua-r1' in before
    print('Uploading compressed root partition directly into a RAM image', flush=True)
    command = 'set -e; test ! -e /tmp/pmos-rootfs.ext4; gzip -dc > /tmp/pmos-rootfs.ext4; sha256sum /tmp/pmos-rootfs.ext4'
    with path.open('rb') as stream:
        completed = subprocess.run(SSH+[command], stdin=stream, capture_output=True, timeout=600)
    (OUT/'upload-result.txt').write_bytes(completed.stdout+completed.stderr)
    completed.check_returncode()
    assert completed.stdout.decode().split()[0] == manifest['raw_sha256']
    print('RAM image upload and SHA256 passed', flush=True)
    script = '''set -e
r=/tmp/postmarketos-ram
mkdir -p "$r"
loop=$(losetup -f)
losetup "$loop" /tmp/pmos-rootfs.ext4
echo "$loop" > /tmp/pmos-loop-device
mount -t ext4 "$loop" "$r"
mkdir -p "$r/proc" "$r/sys" "$r/dev" "$r/dev/pts" "$r/run" "$r/tmp"
mount --bind /proc "$r/proc"
mount --bind /sys "$r/sys"
mount --bind /dev "$r/dev"
mount --bind /dev/pts "$r/dev/pts"
mount -t tmpfs -o mode=755 tmpfs "$r/run"
chroot "$r" /bin/sh -ec 'cat /etc/os-release; uname -r; id; ls /usr/bin/ph* /usr/bin/dbus-run-session; ls /usr/share/wayland-sessions'
'''
    data = run(script, timeout=60)
    (OUT/'first-chroot.txt').write_bytes(data)
    print(data.decode(), flush=True)
elif stage == 'probe':
    data = run('''chroot /tmp/postmarketos-ram /bin/sh -c 'cat /etc/os-release; command -v systemd-nspawn; ls /usr/bin/*egl* /usr/bin/*glmark* /usr/bin/*seat* 2>/dev/null; cat /usr/share/wayland-sessions/phosh.desktop; /usr/bin/phoc --help; find /etc -name "*greet*"; cat /etc/passwd | grep penguin; ls /usr/share/gnome-session/sessions; cat /usr/share/gnome-session/sessions/phosh.session' ''')
    (OUT/'runtime-probe.txt').write_bytes(data)
    print(data.decode())
elif stage == 'setup':
    import urllib.request
    url='https://mirrors.ustc.edu.cn/alpine/edge/community/aarch64/seatd-0.9.3-r1.apk'
    package=OUT/'seatd-0.9.3-r1.apk'
    if not package.exists():
        with urllib.request.urlopen(url, timeout=30) as response:
            package.write_bytes(response.read())
    run('cat > /tmp/postmarketos-ram/tmp/seatd.apk', package.read_bytes())
    data=run('''set -e
r=/tmp/postmarketos-ram
chroot "$r" /sbin/apk add --no-network /tmp/seatd.apk
chroot "$r" /usr/bin/dbus-uuidgen --ensure=/etc/machine-id
mkdir -p "$r/run/dbus" "$r/run/user/0"
chmod 700 "$r/run/user/0"
chroot "$r" /usr/bin/dbus-daemon --system --fork
nohup chroot "$r" /usr/bin/env SEATD_VTBOUND=0 /usr/bin/seatd -g video > /tmp/pmos-seatd.log 2>&1 < /dev/null &
chroot "$r" /bin/sh -c '/usr/libexec/phosh --help; /usr/bin/gnome-session --help; ls /usr/lib/dri; /usr/bin/phoc --version'
''')
    (OUT/'setup.txt').write_bytes(data)
    print(data.decode())
elif stage == 'display':
    selection=OUT/'display-mode.json'
    default_mode=json.loads(selection.read_text(encoding='utf-8'))['mode'] if selection.exists() else 'atomic'
    mode = sys.argv[2] if len(sys.argv)>2 else default_mode
    assert mode in ('atomic', 'legacy')
    run('''set -e
r=/tmp/postmarketos-ram
for task in /proc/[0-9]*; do
    read name < "$task/comm" 2>/dev/null || continue
    if test "$name" = phoc && test "$(readlink "$task/root")" = "$r"; then
        echo 'RAM Phoc already running; refusing a duplicate compositor' >&2
        exit 1
    fi
done
mkdir -p "$r/etc/phosh"
cat > "$r/etc/phosh/phoc.ini" <<'EOF'
[output:DSI-1]
scale = 2.5
EOF
echo 1024 > /sys/class/backlight/ae94000.dsi.0/brightness
''')
    command='''chroot /tmp/postmarketos-ram /usr/bin/env XDG_RUNTIME_DIR=/run/user/0 XDG_SESSION_TYPE=wayland XDG_CURRENT_DESKTOP=Phosh:GNOME LIBSEAT_BACKEND=seatd WLR_BACKENDS=drm,libinput MESA_LOADER_DRIVER_OVERRIDE=msm /usr/bin/dbus-run-session -- /usr/bin/phoc -v -S -C /etc/phosh/phoc.ini -E '/usr/libexec/phosh -U' '''
    if mode == 'legacy':
        command=command.replace('/usr/bin/env ', '/usr/bin/env WLR_DRM_NO_ATOMIC=1 ', 1)
    import shlex
    data=run('nohup sh -c '+shlex.quote(command)+' > /tmp/pmos-phosh.log 2>&1 < /dev/null & echo $!')
    (OUT/'display-launch.txt').write_bytes(data)
    print('Phoc/Phosh launch requested:',data.decode())
elif stage == 'devices':
    data=run('''set -e
r=/tmp/postmarketos-ram
mkdir -p "$r/dev/shm"
mount -t tmpfs -o mode=1777 tmpfs "$r/dev/shm"
chroot "$r" /usr/lib/systemd/systemd-udevd --daemon
chroot "$r" /usr/bin/env SYSTEMD_IGNORE_CHROOT=1 /usr/bin/udevadm trigger --action=add --subsystem-match=input
chroot "$r" /usr/bin/env SYSTEMD_IGNORE_CHROOT=1 /usr/bin/udevadm trigger --action=add --subsystem-match=drm
chroot "$r" /usr/bin/env SYSTEMD_IGNORE_CHROOT=1 /usr/bin/udevadm settle
chroot "$r" /bin/sh -c 'ls /dev/input; for event in /dev/input/event*; do echo "$event"; udevadm info -q property "$event" | grep -E "ID_INPUT|ID_SEAT"; done'
''')
    (OUT/'input-udev.txt').write_bytes(data)
    print(data.decode())
elif stage == 'health':
    data=run('''uname -a
cat /proc/sys/kernel/random/boot_id
cat /proc/1/comm
ps | grep -E 'phoc|phosh|seatd|sshd'
df -k /tmp
grep -E 'MemAvailable|SwapFree' /proc/meminfo
grep -E 'GL renderer|GL version|EGL driver|1240x2772|touch|Atomic commit failed' /tmp/pmos-phosh.log | tail -n 25
dmesg | grep -iE 'gpu.*fault|iommu.*fault|underflow|underrun|hangcheck|recover' | tail -n 25
find /sys/class/drm /sys/devices/platform -name '*fault*' 2>/dev/null | head -n 15
''')
    (OUT/'health.txt').write_bytes(data)
    print(data.decode())
elif stage == 'ssh-paths':
    data=run("chroot /tmp/postmarketos-ram /bin/sh -c 'ls /usr/bin/*ssh* /usr/sbin/*ssh* /usr/libexec/*ssh* 2>/dev/null; grep -A 5 -B 1 openssh /lib/apk/db/installed | head -n 70; ls /usr/lib/ssh' ")
    print(data.decode())
elif stage == 'ssh':
    import os
    public=subprocess.check_output(['C:/Windows/System32/OpenSSH/ssh-keygen.exe', '-y', '-f', str(KEYS/'client_key_host')])
    run('mkdir -p /tmp/postmarketos-ram/home/penguin/.ssh; chmod 700 /tmp/postmarketos-ram/home/penguin/.ssh; cat > /tmp/postmarketos-ram/home/penguin/.ssh/authorized_keys; chmod 600 /tmp/postmarketos-ram/home/penguin/.ssh/authorized_keys; chown -R 10000:10000 /tmp/postmarketos-ram/home/penguin/.ssh', public)
    data=run('''set -e
r=/tmp/postmarketos-ram
chroot "$r" /usr/bin/ssh-keygen -A
mkdir -p "$r/run/sshd"
cat > "$r/etc/ssh/sshd_config_ram_test" <<'EOF'
Port 2224
ListenAddress 169.254.42.1
HostKey /etc/ssh/ssh_host_ed25519_key
PidFile /run/sshd-ram-test.pid
PermitRootLogin no
AllowUsers penguin
PasswordAuthentication no
KbdInteractiveAuthentication no
UsePAM no
AuthorizedKeysFile .ssh/authorized_keys
Subsystem sftp internal-sftp
EOF
chroot "$r" /usr/bin/sshd.pam -t -f /etc/ssh/sshd_config_ram_test
if ! test -s "$r/run/sshd-ram-test.pid"; then
chroot "$r" /usr/bin/sshd.pam -f /etc/ssh/sshd_config_ram_test -E /tmp/sshd-ram-test.log
fi
cat "$r/etc/ssh/ssh_host_ed25519_key.pub"
''')
    # Pin the distro host key obtained through the already trusted debug SSH.
    hostkey=data.decode().strip().splitlines()[-1].split()
    assert hostkey[0]=='ssh-ed25519'
    hosts=OUT/'known_hosts_pmos'
    hosts.write_text('[169.254.42.1]:2224 '+hostkey[0]+' '+hostkey[1]+'\n', encoding='utf-8')
    guest=SSH.copy()
    guest[guest.index('-o',guest.index('StrictHostKeyChecking=yes')+1)+1] = f'UserKnownHostsFile={hosts}'
    guest[-1:-1]=['-p','2224']
    guest[-1]='penguin@169.254.42.1'
    result=subprocess.run(guest+['cat /etc/os-release; uname -r; /usr/bin/sshd.pam -V 2>&1; id'], capture_output=True, timeout=30)
    result.check_returncode()
    payload=os.urandom(4*1024*1024)
    echoed=subprocess.run(guest+['cat'],input=payload,capture_output=True,timeout=60)
    echoed.check_returncode()
    assert echoed.stdout==payload, 'SSH binary round-trip mismatch'
    report=result.stdout.decode()+f'\nSSH port 2224 binary round-trip: {len(payload)} bytes PASS\nSHA256: {hashlib.sha256(payload).hexdigest()}\n'
    (OUT/'ssh-test.txt').write_text(report,encoding='utf-8')
    print(report)
elif stage == 'logs':
    data=run('tail -n 115 /tmp/pmos-phosh.log; cat /tmp/pmos-seatd.log; cat /sys/kernel/debug/dri/0/state 2>/dev/null | head -n 30; cat /sys/kernel/debug/dri/0/gpu 2>/dev/null | head -n 10')
    (OUT/'display-log.txt').write_bytes(data)
    print(data.decode())
else:
    raise SystemExit('Usage: test_postmarketos_ram.py deploy|probe|setup|display|logs')

param([Parameter(Mandatory)][string]$Command,[string]$PortName='COM12',[string]$Output='out/debug-ncm-fixed-20261013/serial-control.txt')
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'UsbSerialReader.ps1')
Initialize-UsbSerialReaderType
$port=[IO.Ports.SerialPort]::new($PortName,115200)
$port.DtrEnable=$true; $port.RtsEnable=$true; $port.WriteTimeout=3000
$reader=$null
try {
    $port.Open()
    $reader=[UsbSerialContinuousReader]::new($port,$true)
    Start-Sleep -Milliseconds 500
    $port.Write($Command+"`n")
    Start-Sleep -Seconds 3
    $response=[Text.Encoding]::UTF8.GetString($reader.Drain())
    [IO.File]::WriteAllText((Join-Path $PWD $Output),$response)
    Write-Output $response
} finally {
    if($reader){$reader.Stop()}
    $port.Close(); $port.Dispose()
}

#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
OUT="$WIN/out/usb-ncm-20261013/ssh"
BUILD="$ROOT/dropbear-2026.94-pja110"
PREFIX="$ROOT/toolchain/gcc-12-aarch64"
export PATH="$PREFIX/usr/bin:$PATH"
export LD_LIBRARY_PATH="$PREFIX/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
mkdir -p "$OUT" "$BUILD"
if [ -f "$OUT/dropbearmulti" ] && [ ! -f "$OUT/dropbearmulti.interp-before" ]; then
    cp "$OUT/dropbearmulti" "$OUT/dropbearmulti.interp-before"
    cp "$OUT/elf.txt" "$OUT/elf.interp-before.txt"
fi
tar -xjf "$OUT/dropbear-2026.94.tar.bz2" -C "$BUILD" --strip-components=1
cd "$BUILD"
cat > localoptions.h <<'EOF'
#define DROPBEAR_SVR_PASSWORD_AUTH 0
#define DROPBEAR_SVR_PAM_AUTH 0
#define DROPBEAR_SVR_PUBKEY_AUTH 1
#define DROPBEAR_SVR_X11FWD 0
#define DROPBEAR_SVR_AGENTFWD 0
EOF
CC=aarch64-linux-gnu-gcc AR=aarch64-linux-gnu-ar RANLIB=aarch64-linux-gnu-ranlib \
CFLAGS='-Os' LDFLAGS='-static' ./configure --host=aarch64-linux-gnu --disable-zlib \
  --disable-pam --disable-lastlog --disable-utmp --disable-wtmp --disable-utmpx --disable-wtmpx \
  > "$OUT/configure.log" 2>&1
make -j8 PROGRAMS='dropbear dropbearkey' MULTI=1 STATIC=1 \
  LDFLAGS='-static -no-pie -Wl,-z,now -Wl,-z,relro' > "$OUT/build.log" 2>&1
aarch64-linux-gnu-strip dropbearmulti
cp dropbearmulti "$OUT/dropbearmulti"
aarch64-linux-gnu-readelf -h -l dropbearmulti > "$OUT/elf.txt"
if grep -q INTERP "$OUT/elf.txt"; then
    echo 'ERROR: SSH executable still requires an interpreter' >&2
    exit 1
fi
sha256sum "$OUT/dropbearmulti" "$OUT/dropbear-2026.94.tar.bz2" > "$OUT/sha256.txt"
echo 'PASS: static ARM64 Dropbear server built, password authentication disabled'

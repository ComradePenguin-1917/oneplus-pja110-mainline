#!/bin/bash
# Verify against the KERNEL SOURCE what happens when:
#   * every /cpus/cpu@N has enable-method = "psci"
#   * but there is NO /psci node
#   * and a /hypervisor node IS present (qcom,gunyah-hypervisor)
#
# This determines whether my "PSCI missing -> silent death" claim is correct,
# and whether the kernel picks SMC or HVC as the conduit.
set -uo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
TREE="$ROOT/linux"
cd "$TREE"

echo "############ 1) psci_dt_init: what does it require? ############"
sed -n '/^static int __init psci_dt_init/,/^}/p' drivers/firmware/psci/psci.c | head -60

echo
echo "############ 2) how is the conduit (smc vs hvc) chosen? ############"
grep -n -B3 -A12 'method.*hvc\|"hvc"\|invoke_psci_fn' drivers/firmware/psci/psci.c | head -50

echo
echo "############ 3) what happens if no PSCI description is found? ############"
grep -n -A25 'psci_dt_init().*psci_acpi_init\|static int __init psci_init' drivers/firmware/psci/psci.c | head -40

echo
echo "############ 4) is there ANY gunyah/hypervisor handling in psci or arm64 smp? ############"
grep -rn 'gunyah' drivers/firmware/psci/ arch/arm64/kernel/ 2>/dev/null | head
echo "--- gunyah driver dir ---"
ls drivers/virt/gunyah/ 2>/dev/null | head
echo "--- does arm64 look at /hypervisor for the conduit? ---"
grep -rn 'hypervisor' arch/arm64/kernel/*.c drivers/firmware/psci/*.c 2>/dev/null | head -15

echo
echo "############ 5) cpu_ops registration: does psci register a method? ############"
grep -rn 'CPU_METHOD_OF_DECLARE\|cpu_methods' arch/arm64/kernel/cpu_ops.c drivers/firmware/psci/psci.c 2>/dev/null | head -15

echo
echo "############ 6) the panic path when PSCI is unavailable ############"
grep -rn -B4 -A10 'PSCI.*not.*available\|psci.*failed\|Unable to.*psci' arch/arm64/kernel/smp.c drivers/firmware/psci/psci.c 2>/dev/null | head -30

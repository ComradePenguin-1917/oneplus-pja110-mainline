/* SPDX-License-Identifier: GPL-2.0-only */
/* Bounded key capture / short-power screen policy; no reboot or storage writes. */
#include <fcntl.h>
#include <errno.h>
#include <glob.h>
#include <linux/fb.h>
#include <linux/input.h>
#include <poll.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <time.h>
#include <unistd.h>

static volatile sig_atomic_t stopping;
static char *saved_screen;
static size_t saved_size;
static void stop(int n) { (void)n;stopping=1; }
static double now(void) { struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec/1e9; }
/* Preserve pixels BEFORE blank/unblank can redraw the console framebuffer. */
static int save_frame(int fd)
{
    struct fb_fix_screeninfo f;
    char *saved;
    size_t done=0;
    if(ioctl(fd,FBIOGET_FSCREENINFO,&f))return -1;
    if(!f.smem_len || f.smem_len>64*1024*1024) { errno=EINVAL;return -1; }
    saved=malloc(f.smem_len);
    if(!saved)return -1;
    while(done<f.smem_len) {
        ssize_t n=pread(fd,saved+done,f.smem_len-done,done);
        if(n<0 && errno==EINTR)continue;
        if(n<=0) { if(!n)errno=EIO;free(saved);return -1; }
        done+=n;
    }
    free(saved_screen);saved_screen=saved;saved_size=f.smem_len;
    size_t nonzero=0;
    for(size_t i=0;i<saved_size;i++)nonzero+=saved_screen[i]!=0;
    printf("FRAMEBUFFER snapshot bytes=%zu nonzero=%zu\n",saved_size,nonzero);
    return 0;
}
static int submit_frame(int fd)
{
    struct fb_fix_screeninfo f;
    struct fb_var_screeninfo v;
    size_t done=0;
    unsigned char sample[4096];
    if(ioctl(fd,FBIOGET_FSCREENINFO,&f) || ioctl(fd,FBIOGET_VSCREENINFO,&v))return -1;
    if(!saved_screen || saved_size!=f.smem_len) { errno=EINVAL;return -1; }
    ssize_t sample_size=pread(fd,sample,sizeof(sample),0);
    if(sample_size>0) {
        size_t nonzero=0;
        for(ssize_t i=0;i<sample_size;i++)nonzero+=sample[i]!=0;
        printf("FRAMEBUFFER before_restore sample_nonzero=%zu\n",nonzero);
    }
    while(done<f.smem_len) {
        ssize_t n=pwrite(fd,saved_screen+done,f.smem_len-done,done);
        if(n<0 && errno==EINTR)continue;
        if(n<=0) { if(!n)errno=EIO;return -1; }
        done+=n;
    }
    v.activate=FB_ACTIVATE_NOW;
    if(ioctl(fd,FBIOPAN_DISPLAY,&v))return -1;
    printf("FRAMEBUFFER resubmitted bytes=%u\n",f.smem_len);
    return 0;
}
static int set_screen(int fd,int on)
{
    if(!on && save_frame(fd))return -1;
    if(ioctl(fd,FBIOBLANK,on?FB_BLANK_UNBLANK:FB_BLANK_POWERDOWN))return -1;
    return on?submit_frame(fd):0;
}
int main(int argc,char **argv)
{
    const char *wanted[3]={"pmic_pwrkey","pmic_resin","gpio-keys"};
    const unsigned codes[3]={KEY_POWER,KEY_VOLUMEUP,KEY_VOLUMEDOWN};
    struct pollfd fds[3]={{.fd=-1},{.fd=-1},{.fd=-1}};
    unsigned presses[3]={0},releases[3]={0},repeats[3]={0},toggles=0;
    double down[3]={0},started;
    glob_t paths={0};
    int policy=argc==2 && !strcmp(argv[1],"--policy"),fb=-1,screen_on=1,rc=0;
    if(argc!=2 || (!policy && strcmp(argv[1],"--capture")))return 1;
    signal(SIGTERM,stop);signal(SIGINT,stop);signal(SIGHUP,stop);
    setvbuf(stdout,NULL,_IOLBF,0);
    if(glob("/dev/input/event*",0,NULL,&paths))return 2;
    for(size_t i=0;i<paths.gl_pathc;i++) {
        char name[128];int fd=open(paths.gl_pathv[i],O_RDONLY|O_NONBLOCK),found=0;
        if(fd>=0 && ioctl(fd,EVIOCGNAME(sizeof(name)),name)>=0) {
            for(int j=0;j<3;j++)if(!strcmp(name,wanted[j])) {
                if(fds[j].fd>=0) { fputs("Ambiguous input names\n",stderr);return 3; }
                fds[j].fd=fd;fds[j].events=POLLIN;found=1;
                printf("DEVICE name=%s expected_code=%u path=%s\n",name,codes[j],paths.gl_pathv[i]);
                break;
            }
        }
        if(fd>=0 && !found)close(fd);
    }
    globfree(&paths);
    for(int i=0;i<3;i++)if(fds[i].fd<0)return 4;
    if(policy) {
        fb=open("/dev/fb0",O_RDWR);
        if(fb<0 || save_frame(fb) || set_screen(fb,1)) { perror("initial unblank/submit");return 5; }
    }
    started=now();
    printf("READY mode=%s duration=60s; keys only, no reboot/volume remapping\n",policy?"policy":"capture");
    while(!stopping && now()-started<60) {
        int ready=poll(fds,3,500);
        if(ready<0) { if(stopping)break;perror("key poll");rc=6;break; }
        if(!ready)continue;
        for(int i=0;i<3;i++)if(fds[i].revents&POLLIN) {
            struct input_event events[64];ssize_t size=read(fds[i].fd,events,sizeof(events));
            if(size<=0 || size%sizeof(events[0])) { rc=7;goto cleanup; }
            for(size_t j=0;j<(size_t)size/sizeof(events[0]);j++) {
                struct input_event *e=&events[j];
                if(e->type==EV_SYN && e->code==SYN_DROPPED) { rc=8;goto cleanup; }
                if(e->type!=EV_KEY)continue;
                printf("KEY %.3f device=%s code=%u value=%d\n",now()-started,wanted[i],e->code,e->value);
                if(e->code!=codes[i] || e->value<0 || e->value>2) { rc=9;goto cleanup; }
                if(e->value==1) { presses[i]++;down[i]=now(); }
                else if(e->value==2)repeats[i]++;
                else {
                    releases[i]++;
                    double held=down[i]?now()-down[i]:0;
                    printf("RELEASE device=%s held_ms=%.0f\n",wanted[i],held*1000);
                    if(policy && i==0 && down[i] && held<1.5) {
                        if(set_screen(fb,!screen_on)) { perror("power-key blank/submit");rc=10;goto cleanup; }
                        screen_on=!screen_on;toggles++;
                        printf("SCREEN %s\n",screen_on?"ON":"OFF");
                    }
                    down[i]=0;
                }
            }
        }
    }
cleanup:
    if(policy && !screen_on && set_screen(fb,1))rc=11;
    if(fb>=0)close(fb);
    free(saved_screen);
    for(int i=0;i<3;i++) {
        printf("SUMMARY device=%s press=%u release=%u repeat=%u\n",wanted[i],presses[i],releases[i],repeats[i]);
        close(fds[i].fd);
    }
    printf("SUMMARY screen_toggles=%u rc=%d\n",toggles,rc);
    return rc;
}

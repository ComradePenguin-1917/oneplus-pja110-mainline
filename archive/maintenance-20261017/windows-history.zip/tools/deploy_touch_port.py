"""Preserve visible #14 boot; deploy touch-only DT and runtime modules."""
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/touch-port-20261013'
KEYS=ROOT/'out/usb-ncm-20261013/ssh'
SSH=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(KEYS/'client_key_host'),
     '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
     '-o',f'UserKnownHostsFile={KEYS/"known_hosts"}','-o','ConnectTimeout=5',
     '-o','ServerAliveInterval=5','root@169.254.42.1']
FB=['C:/platform-tools/fastboot.exe','-s','bc7a542e']
PARTS=('boot_a','vendor_boot_a','init_boot_a','dtbo_a',
       'boot_b','vendor_boot_b','init_boot_b','dtbo_b')
manifest=json.loads((OUT/'manifest.json').read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ssh(cmd,data=None):
    p=subprocess.run(SSH+[cmd],input=data,capture_output=True,timeout=90)
    (OUT/'last-ssh-error.txt').write_bytes(p.stderr)
    p.check_returncode()
    return p.stdout
def hashes():
    raw=ssh("for f in /sys/class/block/sd*/uevent; do grep -E '^(DEVNAME|PARTNAME)=' \"$f\"; echo END; done")
    devices={}
    for record in raw.decode().split('END'):
        props=dict(line.split('=',1) for line in record.splitlines() if '=' in line)
        part=props.get('PARTNAME')
        if part in PARTS:
            assert part not in devices,'Ambiguous partition label'
            device=props['DEVNAME']
            assert re.fullmatch(r'sd[a-z]+[0-9]+',device)
            devices[part]=device
    assert set(devices)==set(PARTS),'Missing required partition label'
    (OUT/'partition-map.json').write_text(json.dumps(devices,indent=2)+'\n')
    h={}
    for part,device in devices.items():
        assert ssh(f"grep '^PARTNAME=' /sys/class/block/{device}/uevent").decode().strip()=='PARTNAME='+part
        h[part]=ssh(f'sha256sum /dev/{device}').decode().split()[0]
    return h
def fb(args):
    p=subprocess.run(FB+args,capture_output=True,timeout=90)
    with (OUT/'fastboot.log').open('ab') as f:f.write(('COMMAND '+' '.join(args)+'\n').encode()+p.stdout+p.stderr)
    p.check_returncode()
    output=(p.stdout+p.stderr).decode(errors='replace');print(output,flush=True)
    return output
mode=sys.argv[1]
if mode=='preflight':
    assert not (OUT/'device-before.json').exists(),'Preserve existing preflight evidence'
    h=hashes()
    assert h==manifest['baseline_hashes'],'Phone must match verified #14 display baseline'
    (OUT/'device-before.json').write_text(json.dumps(h,indent=2)+'\n')
    (OUT/'device-before.txt').write_bytes(ssh('uname -a; cat /proc/uptime; cat /proc/bus/input/devices'))
    print('PASS: all eight boot partitions match visible #14 baseline')
elif mode=='flash':
    assert json.loads((OUT/'device-before.json').read_text())==manifest['baseline_hashes']
    for name,info in manifest['files'].items():assert digest(OUT/name)==info['sha256']
    assert manifest['boot_kernel_unchanged'] and manifest['display_usb_ufs_memory_unchanged']
    assert 'current-slot: b' in fb(['getvar','current-slot'])
    assert 'unlocked: yes' in fb(['getvar','unlocked'])
    assert 'slot-successful:a: yes' in fb(['getvar','slot-successful:a'])
    fb(['flash','vendor_boot_b',str(OUT/'vendor_boot_b-touch.img')])
    fb(['set_active','b']);fb(['reboot'])
elif mode=='init-preflight':
    assert not (OUT/'autostart-device-before.json').exists(),'Preserve existing evidence'
    h=hashes()
    assert h==json.loads((OUT/'device-after.json').read_text())
    (OUT/'autostart-device-before.json').write_text(json.dumps(h,indent=2)+'\n')
    print('PASS: current touch DT and all eight boot partitions verified before init_boot update')
elif mode=='init-flash':
    auto=json.loads((OUT/'autostart-manifest.json').read_text())
    assert (OUT/'autostart-device-before.json').exists()
    assert b'QEMU touch modules validated' in (OUT/'qemu-autostart-console.txt').read_bytes()
    assert b'QEMU debug userspace validated' in (OUT/'qemu-autostart-console.txt').read_bytes()
    assert digest(OUT/'init_boot_b-touch-autostart.img')==auto['init_boot_sha256']
    for name,sha in auto['runtime_module_sha256'].items():assert digest(OUT/name)==sha
    assert auto['boot_kernel_unchanged'] and auto['ssh_identity_and_all_other_entries_unchanged']
    assert 'current-slot: b' in fb(['getvar','current-slot'])
    assert 'unlocked: yes' in fb(['getvar','unlocked'])
    assert 'slot-successful:a: yes' in fb(['getvar','slot-successful:a'])
    fb(['flash','init_boot_b',str(OUT/'init_boot_b-touch-autostart.img')])
    fb(['set_active','b']);fb(['reboot'])
elif mode=='init-capture':
    identity=ssh('uname -a; cat /proc/uptime; cat /sys/class/udc/*/state; cat /tmp/touch-init.log; cat /proc/bus/input/devices')
    (OUT/'autostart-device-after.txt').write_bytes(identity)
    assert b'#14 SMP' in identity and b'configured' in identity
    assert b'S3910 touch modules loaded' in identity and b'PJA110 Synaptics S3910' in identity
    h=hashes()
    before=json.loads((OUT/'autostart-device-before.json').read_text())
    assert all(h[n]==before[n] for n in PARTS if n!='init_boot_b')
    assert h['init_boot_b']==digest(OUT/'init_boot_b-touch-autostart.img')
    (OUT/'autostart-device-after.json').write_text(json.dumps(h,indent=2)+'\n')
    log=ssh('dmesg')
    (OUT/'autostart-dmesg.txt').write_bytes(log)
    assert b'PJA_TOUCH input enabled:' in log
    auto=json.loads((OUT/'autostart-manifest.json').read_text())
    auto.update(phone_execution_confirmed=True,automatic_ssh_and_touch_verified=True,
                other_seven_boot_partitions_unchanged=True)
    (OUT/'autostart-manifest.json').write_text(json.dumps(auto,indent=2)+'\n')
    print('PASS: automatic SSH and S3910 input after boot; init_boot readback verified; other seven boot partitions unchanged')
elif mode=='probe':
    identity=ssh('uname -a; cat /proc/uptime')
    assert b'#14 SMP' in identity
    (OUT/'device-after.txt').write_bytes(identity)
    h=hashes()
    assert all(h[n]==manifest['baseline_hashes'][n] for n in PARTS if n!='vendor_boot_b')
    assert h['vendor_boot_b']==digest(OUT/'vendor_boot_b-touch.img')
    (OUT/'device-after.json').write_text(json.dumps(h,indent=2)+'\n')
    for name in ('spi-geni-qcom.ko','mainline_touch_probe.ko'):
        data=(OUT/name).read_bytes()
        response=ssh(f'cat > /tmp/{name}; sha256sum /tmp/{name}',data)
        assert response.decode().split()[0]==hashlib.sha256(data).hexdigest()
    response=ssh('mount -t debugfs none /sys/kernel/debug 2>/dev/null; insmod /tmp/spi-geni-qcom.ko; insmod /tmp/mainline_touch_probe.ko')
    (OUT/'module-load.txt').write_bytes(response)
    log=ssh('dmesg')
    (OUT/'mainline-dmesg.txt').write_bytes(log)
    (OUT/'touch-state.txt').write_bytes(ssh('ls -l /sys/bus/spi/devices; cat /sys/kernel/debug/devices_deferred; cat /sys/kernel/debug/gpio; cat /proc/interrupts'))
    print(identity.decode(),flush=True)
    for line in log.decode(errors='replace').splitlines():
        if any(w in line for w in ('PJA_TOUCH','geni_spi','spi-geni','s3910')):print(line,flush=True)
    assert b'PJA_TOUCH discovery header=' in log,'No touch discovery header; inspect saved SPI/deferred logs'
    print('PASS: discovery response captured; seven other boot partitions unchanged',flush=True)
else:raise SystemExit('use preflight | flash | probe | init-preflight | init-flash | init-capture')

"""Build both real initramfs archives for a persistent RNDIS bring-up shell."""
from pathlib import Path
import gzip
import hashlib
import json
import shutil
import struct
import sys
from bootimg import BootImage
from build_init_marker_test import parse_cpio, make_entry, lz4

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT/'out/avb-fixup-control-20261012'
PHY = ROOT/'out/user-init-dwc-soft-reset-usb3-phy-probe-20261013'
HOST_IAD = '--host-iad' in sys.argv
USB_SERIAL = '--usb-serial' in sys.argv
assert not (USB_SERIAL and ('--iad-fix' in sys.argv or HOST_IAD))
IAD_FIX = '--iad-fix' in sys.argv or HOST_IAD
OUT = ROOT/('out/user-init-usb-serial-shell-20261013' if USB_SERIAL else 'out/user-init-rndis-shell-winiad-20261013' if HOST_IAD else 'out/user-init-rndis-shell-iadfix-20261013' if IAD_FIX else 'out/user-init-rndis-shell-20261013')
OUT.mkdir(exist_ok=True)
original_script = (ROOT/'initramfs/init').read_bytes()
cut = original_script.index(b'if [ -n "$BOUND" ]; then')
script = original_script[:cut].replace(b'for f in ecm rndis ncm;', b'for f in rndis;')
assert b'for f in rndis;' in script
script = script.replace(b'echo 0x0104 > idProduct', b'echo 0x0105 > idProduct')
script = script.replace(b'echo "0123456789" > strings/0x409/serialnumber', b'echo "PJA110-RNDIS" > strings/0x409/serialnumber')
script = script.replace(b'echo "xigua-bringup" > strings/0x409/product', b'echo "xigua-mainline-rndis" > strings/0x409/product')
if IAD_FIX:
    script = script.replace(b'echo 0x0105 > idProduct', b'echo 0x0107 > idProduct' if HOST_IAD else b'echo 0x0106 > idProduct')
    script = script.replace(b'echo "PJA110-RNDIS" > strings/0x409/serialnumber', b'echo "PJA110-RNDIS3" > strings/0x409/serialnumber' if HOST_IAD else b'echo "PJA110-RNDIS2" > strings/0x409/serialnumber')
anchor = b'    ln -s "functions/$func.usb0" configs/c.1/ 2>/dev/null\n'
assert script.count(anchor) == 1
descriptors = b'''    echo 0xef > bDeviceClass || return 1
    echo 0x02 > bDeviceSubClass || return 1
    echo 0x01 > bDeviceProtocol || return 1
    echo 1 > os_desc/use || return 1
    echo 0xcd > os_desc/b_vendor_code || return 1
    echo MSFT100 > os_desc/qw_sign || return 1
    ln -s configs/c.1 os_desc || return 1
'''
iad = b'''    echo 0xe0 > functions/rndis.usb0/class || return 1
    echo 0x01 > functions/rndis.usb0/subclass || return 1
    echo 0x03 > functions/rndis.usb0/protocol || return 1
''' if IAD_FIX else b''
if HOST_IAD:
    iad = iad.replace(b'0xe0', b'0xef').replace(b'0x01 > functions/rndis.usb0/subclass', b'0x04 > functions/rndis.usb0/subclass').replace(b'0x03 > functions/rndis.usb0/protocol', b'0x01 > functions/rndis.usb0/protocol')
script = script.replace(anchor, iad+anchor+descriptors)
script += b'''if [ -n "$BOUND" ]; then
    log "RNDIS network ready; starting persistent shell"
    telnetd -l /bin/sh -p 23 2>/dev/null && log "telnetd on 172.16.42.1:23"
    for netdev in /sys/class/net/usb*; do
        [ -d "$netdev" ] || continue
        netif=$(basename "$netdev")
        printf 'start 172.16.42.2\\nend 172.16.42.10\\ninterface %s\\nlease_file /tmp/leases\\npidfile /tmp/udhcpd.pid\\n' "$netif" > /tmp/udhcpd.conf
        udhcpd /tmp/udhcpd.conf 2>/dev/null
        break
    done
else
    log "RNDIS setup failed; retaining PID1 for diagnosis"
fi
if grep -q 'pja.qemu_validation=1' /proc/cmdline; then
    log "QEMU validation complete"
    poweroff -f
fi
while :; do sleep 60; done
'''
if USB_SERIAL:
    script = b'''#!/bin/sh
PATH=/sbin:/bin:/usr/sbin:/usr/bin
export PATH
mount -t proc none /proc 2>/dev/null
mount -t sysfs none /sys 2>/dev/null
mount -t devtmpfs none /dev 2>/dev/null
mount -t configfs none /sys/kernel/config 2>/dev/null
mount -t tmpfs none /tmp 2>/dev/null
log() { echo "[initramfs] $*"; echo "[initramfs] $*" > /dev/kmsg 2>/dev/null; }
setup_acm() {
    mkdir -p /sys/kernel/config/usb_gadget/g1 || return 1
    cd /sys/kernel/config/usb_gadget/g1 || return 1
    echo 0x1d6b > idVendor || return 1
    echo 0x0108 > idProduct || return 1
    echo 0x0200 > bcdUSB || return 1
    echo 0xef > bDeviceClass || return 1
    echo 0x02 > bDeviceSubClass || return 1
    echo 0x01 > bDeviceProtocol || return 1
    mkdir -p strings/0x409 configs/c.1/strings/0x409 || return 1
    echo PJA110-ACM > strings/0x409/serialnumber
    echo PJA110 > strings/0x409/manufacturer
    echo xigua-mainline-usb-serial > strings/0x409/product
    echo bringup-serial > configs/c.1/strings/0x409/configuration
    echo 250 > configs/c.1/MaxPower
    mkdir functions/acm.usb0 || return 1
    ln -s functions/acm.usb0 configs/c.1 || return 1
    for controller in /sys/class/udc/*; do
        [ -e "$controller" ] || continue
        basename "$controller" > UDC || return 1
        log "USB ACM bound"
        return 0
    done
    return 1
}
if setup_acm; then
    setsid sh -c 'stty -F /dev/ttyGS0 115200 raw -echo; exec sh -i </dev/ttyGS0 >/dev/ttyGS0 2>&1' &
else
    log "USB ACM setup failed; retaining PID1"
fi
if grep -q 'pja.qemu_validation=1' /proc/cmdline; then
    log "QEMU validation complete"
    poweroff -f
fi
while :; do sleep 60; done
'''
(OUT/('init-usb-serial.sh' if USB_SERIAL else 'init-rndis.sh')).write_bytes(script)

def replace(raw):
    entries = parse_cpio(raw)
    assert sum(n.removeprefix('./') == 'init' for f,n,d in entries) == 1
    result = bytearray()
    for fields,name,data in entries:
        if name.removeprefix('./') == 'init':
            assert data == original_script
            data = script
        result += make_entry(fields,name,data)
    checked = parse_cpio(bytes(result))
    assert len(checked) == len(entries)
    for (oldf,n,oldd),(newf,newn,newd) in zip(entries,checked):
        assert newn == n
        assert newd == (script if n.removeprefix('./') == 'init' else oldd)
        expected = list(oldf)
        expected[6] = len(newd)
        assert newf == expected
    return bytes(result)

symbols = {p[2]:int(p[0],16) for l in (ROOT/'out/kernel-entry-probe-20261012/kernel-symbols.txt').read_text().splitlines() if len(p:=l.split())==3}
boot = BootImage.parse(str(BASE/'boot-xigua-r1.img'))
original = boot.kernel
assert hashlib.sha256(original).hexdigest() == 'd8ade08069b8440b349f4b4aeb430dd6e9057eca08c94a8268e3708a83e53425'
offset = symbols['__initramfs_start']-symbols['_text']
size_offset = symbols['__initramfs_size']-symbols['_text']
old_size = struct.unpack_from('<Q',original,size_offset)[0]
rebuilt = replace(gzip.decompress(original[offset:offset+old_size]))
compressed = gzip.compress(rebuilt,compresslevel=9,mtime=0)
assert len(compressed) <= old_size
image = bytearray(original)
image[offset:offset+old_size] = compressed.ljust(old_size,b'\0')
struct.pack_into('<Q',image,size_offset,len(compressed))
assert image[:offset] == original[:offset] and image[offset+old_size:size_offset] == original[offset+old_size:size_offset] and image[size_offset+8:] == original[size_offset+8:]
(OUT/'Image-probe').write_bytes(image)
boot.kernel = bytes(image)
(OUT/'boot-xigua-r1.img').write_bytes(boot.pack(cmdline=boot.cmdline.decode()))
assert b'pja.qemu_validation' not in boot.cmdline
assert BootImage.parse(str(OUT/'boot-xigua-r1.img')).kernel == image
external = bytearray((BASE/'init_boot_b-xigua-r1.img').read_bytes())
old_ramdisk_size = struct.unpack_from('<I',external,12)[0]
new_cpio = replace(lz4(['-d','-l','-c'],external[4096:4096+old_ramdisk_size]))
new_ramdisk = lz4(['-z','-l','-12','-c'],new_cpio)
end = 4096+((old_ramdisk_size+4095)//4096)*4096
assert len(new_ramdisk) <= end-4096
assert lz4(['-d','-l','-c'],new_ramdisk) == new_cpio
tail = bytes(external[end:])
struct.pack_into('<I',external,12,len(new_ramdisk))
external[4096:end] = new_ramdisk.ljust(end-4096,b'\0')
assert external[end:] == tail
(OUT/'init_boot_b-xigua-r1.img').write_bytes(external)
phy_manifest = json.loads((PHY/'manifest.json').read_text())
for name in ('vendor_boot_b-xigua-r1.img','dtbo_b-avb-noop.img'):
    assert hashlib.sha256((PHY/name).read_bytes()).hexdigest() == phy_manifest['files'][name]['sha256']
    shutil.copyfile(PHY/name,OUT/name)
manifest = {'experiment':'persistent RNDIS shell with MS OS descriptors and USB3 PHY initialization at USB2 high-speed',
    'kernel_instruction_bytes_unchanged':True, 'both_archives_same_init':True,
    'phone_execution_confirmed':False, 'phone_has_no_intentional_reset_probe':True,
    'qemu_poweroff_requires_test_only_cmdline_flag':True,
    'rndis_function_iad_overridden_before_configuration_link':IAD_FIX,
    'function_iad_matches_host_rndiscmp_inf_EF_04_01':HOST_IAD,
    'files':{n:{'bytes':(OUT/n).stat().st_size,'sha256':hashlib.sha256((OUT/n).read_bytes()).hexdigest()} for n in ('boot-xigua-r1.img','vendor_boot_b-xigua-r1.img','init_boot_b-xigua-r1.img','dtbo_b-avb-noop.img')}}
if USB_SERIAL:
    manifest['experiment'] = 'persistent USB CDC ACM shell with unchanged USB3 PHY initialization at USB2 high-speed'
    manifest['usb_transport'] = 'CDC ACM'
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
print('PASS: both initramfs archives updated; kernel instructions unchanged; persistent shell, no phone reset probe')

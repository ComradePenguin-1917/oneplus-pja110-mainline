#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
OUT="$WIN/out/touch-port-20261013"
TREE="$ROOT/linux"
BUILD="$ROOT/touch-probe-module-20261013"
export PATH="$ROOT/toolchain/gcc-12-aarch64/usr/bin:$PATH"
export LD_LIBRARY_PATH="$ROOT/toolchain/gcc-12-aarch64/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu-
mkdir -p "$OUT" "$BUILD"
cmp "$TREE/.config" "$WIN/out/display-port-20261013/kernel.config"
sha256sum "$TREE/.config" "$TREE/arch/arm64/boot/Image" > "$OUT/build-before.sha256"
cp "$WIN/drivers/input/touchscreen/pja110-s3910.c" "$BUILD/mainline_touch_probe.c"
printf 'obj-m := mainline_touch_probe.o\n' > "$BUILD/Makefile"
make -C "$TREE" M=drivers/spi KBUILD_EXTRA_SYMBOLS="$TREE/vmlinux.symvers" -j8 modules > "$OUT/spi-build.log" 2>&1
make -C "$TREE" M="$BUILD" KBUILD_EXTRA_SYMBOLS="$TREE/vmlinux.symvers" -j4 modules > "$OUT/probe-build.log" 2>&1
cp "$TREE/drivers/spi/spi-geni-qcom.ko" "$BUILD/mainline_touch_probe.ko" "$OUT/"
cp "$TREE/drivers/spi/spi-geni-qcom.c" "$OUT/"
aarch64-linux-gnu-gcc -static -no-pie -O2 -Wall -Wextra "$WIN/tools/mainline_touch_capture.c" -o "$OUT/touch-capture"
modinfo "$OUT/mainline_touch_probe.ko" > "$OUT/probe-modinfo.txt"
sha256sum -c "$OUT/build-before.sha256"
echo 'PASS: GENI SPI and bounded touch diagnostic modules built; #14 Image/config unchanged'

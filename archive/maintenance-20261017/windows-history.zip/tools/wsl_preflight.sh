#!/bin/bash
# FINAL pre-flight verification of the boot images, using content fingerprints
# (not fragile 2-byte magic scans).
set -uo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
OUT="$ROOT/out"
WIN="/mnt/h/WorkSpace/PJA110-Mainline"

echo "############ FINAL PRE-FLIGHT CHECK ############"
echo

for img in boot-xigua-initrd.img boot-xigua-initrd-rd.img; do
    p="$OUT/$img"
    [ -f "$p" ] || { echo "missing $p"; continue; }
    echo "=============================================================="
    echo "  $img   ($(stat -c%s "$p") bytes)"
    echo "=============================================================="
    python3 - "$p" "$ROOT/initramfs/initramfs.cpio.gz" "$OUT/sm8550-oneplus-xigua-16G.dtb" <<'PY'
import gzip, io, struct, sys

img_path, initrd_path, dtb_path = sys.argv[1], sys.argv[2], sys.argv[3]
b = open(img_path, 'rb').read()
raw_initrd = open(initrd_path, 'rb').read()
dtb = open(dtb_path, 'rb').read()

assert b[:8] == b'ANDROID!'
ksize, rsize, osver = struct.unpack_from('<3I', b, 8)
hver = struct.unpack_from('<I', b, 40)[0]
cmd = b[44:44+1536].rstrip(b'\0').decode('utf-8', 'replace')
print('  header_version : %d' % hver)
print('  os_version     : 0x%08x' % osver)
print('  kernel_size    : %d (%.2f MiB)' % (ksize, ksize/2**20))
print('  ramdisk_size   : %d' % rsize)
print('  cmdline        : %r' % cmd)

k = b[4096:4096+ksize]
print('  kernel magic   : %r (arm64 EFI stub = "MZ")' % k[:2])

# 1) DTB appended?
dpos = k.find(dtb)
print('  appended DTB   : %s' % ('YES at 0x%x (%d bytes, byte-identical)' % (dpos, len(dtb)) if dpos >= 0 else 'NO'))

# 2) embedded initramfs, matched by 32-byte fingerprint
fp = raw_initrd[:32]
ipos = k.find(fp)
if ipos >= 0:
    d = gzip.GzipFile(fileobj=io.BytesIO(k[ipos:ipos+len(raw_initrd)])).read()
    cpio = d
    checks = {
        './init entry':        b'init\x00' in cpio[:4096] or cpio.count(b'init') > 0,
        'our /init marker':    b'[initramfs]' in cpio,
        'busybox binary':      b'busybox' in cpio,
        'telnetd applet':      b'telnetd' in cpio,
        'cpio TRAILER':        b'TRAILER!!!' in cpio,
    }
    print('  embedded initrd: YES at 0x%x, decompresses to %d bytes' % (ipos, len(d)))
    for kk, vv in checks.items():
        print('     %-20s %s' % (kk, vv))
else:
    print('  embedded initrd: NOT FOUND')

# 3) ramdisk section, if present
if rsize:
    roff = 4096 + ((ksize + 4095)//4096*4096)
    rd = b[roff:roff+rsize]
    ok = rd == raw_initrd
    print('  ramdisk field  : %d bytes, byte-identical to our archive: %s' % (rsize, ok))

# 4) sanity: fits the partition
print('  boot partition : 201326592 bytes; image fits: %s' % (len(b) <= 201326592))
PY
    echo
done

echo "############ ARTIFACT LIST ############"
ls -l "$OUT"/boot-xigua-initrd*.img
echo
sha256sum "$OUT"/boot-xigua-initrd*.img
echo
echo "############ RECOMMENDED FIRST TEST ############"
echo "  fastboot boot out/boot-xigua-initrd.img"
echo
echo "  why this one: kernel has the initramfs embedded, so no ramdisk field is"
echo "  needed; it is also the smaller of the two."
echo
echo "  observe:"
echo "    * if adb appears within ~60 s -> kernel reached userspace, gadget up"
echo "    * if not -> pull /proc/bootloader_log after recovering to see the ABL"
echo "      side, and re-check whether the kernel even started"

#!/usr/bin/env python3
"""VALIDATION TEST: stock kernel + OUR initramfs.

Why this is the right test now
------------------------------
Everything we need is built into the stock kernel as =y (extracted from its own
embedded config):
    CONFIG_BLK_DEV_INITRD=y  CONFIG_RD_GZIP=y
    CONFIG_USB_GADGET=y      CONFIG_USB_CONFIGFS=y  CONFIG_USB_LIBCOMPOSITE=y
    CONFIG_USB_CONFIGFS_ECM=y  CONFIG_USB_CONFIGFS_NCM=y
    CONFIG_USB_DWC3=y        CONFIG_USB_DWC3_QCOM=y
    CONFIG_MAGIC_SYSRQ=y

So this single test validates, on real hardware, four of our own artefacts:
  1. our aarch64 busybox actually executes
  2. our /init runs
  3. our USB gadget setup works (ecm/ncm are built in)
  4. our poweroff signal works

And it is a MEMORY BOOT: nothing is written to any partition.

How to read the outcome
-----------------------
  * adb or a USB network interface appears  -> USB gadget worked  (best)
  * phone goes dark and does NOT return to Android -> /init ran; signal fired
  * Android comes back with its own adb     -> our initramfs was not executed

The middle case is the one that matters most, because it needs no drivers at all
and proves userspace was reached.
"""
import gzip
import hashlib
import io
import os
import re
import struct
import subprocess
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
WSL_WS = '/mnt/h/WorkSpace/PJA110-Mainline'


def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''):
            h.update(c)
    return h.hexdigest()


initrd = os.path.join(WS, 'initramfs', 'initramfs.cpio.gz')
stock = os.path.join(WS, 'out', 'stock-kernel.bin')

print('=== inputs ===')
print('  stock kernel : %d bytes  %s' % (os.path.getsize(stock), sha(stock)[:24]))
print('  our initramfs: %d bytes  %s' % (os.path.getsize(initrd), sha(initrd)[:24]))

# Sanity: our initramfs must contain the poweroff applet and the new /init
raw = open(initrd, 'rb').read()
cpio = gzip.GzipFile(fileobj=io.BytesIO(raw)).read()
print()
print('=== initramfs self-check ===')
print('  has /init            : %s' % (b'#!/bin/sh' in cpio))
print('  signal ladder present: %s'
      % (b'=== NO USB: /init RAN' in cpio))
print('  poweroff applet      : %s' % (b'bin/poweroff' in cpio))
print('  busybox aarch64      : %s'
      % (b'\x7fELF\x02\x01\x01\x00' in cpio))

out = os.path.join(WS, 'out', 'validate-stockkernel-ourinitrd.img')
cmd = ('cd %s && python3 tools/bootimg.py pack '
       '--kernel out/stock-kernel.bin '
       '--ramdisk initramfs/initramfs.cpio.gz '
       '--stock boot-A14.img '
       '--cmdline "console=ttyMSM0,115200 loglevel=8 earlycon ignore_loglevel rdinit=/init" '
       '-o out/validate-stockkernel-ourinitrd.img' % WSL_WS)
r = subprocess.run(['wsl.exe', '-d', 'Ubuntu-22.04', '--', 'bash', '-lc', cmd],
                   capture_output=True)
for line in (r.stdout or b'').decode('utf-8', 'replace').splitlines():
    if line.strip() and 'localh' not in line and 'N/e' not in line:
        print('  %s' % line.strip()[:100])

print()
print('=== verify the packed image ===')
if os.path.exists(out):
    b = open(out, 'rb').read()
    ksize, rsize = struct.unpack_from('<2I', b, 8)
    k = b[4096:4096 + ksize]
    print('  size        : %d' % len(b))
    print('  kernel field: %d' % ksize)
    print('  ramdisk     : %d (ours: %d)' % (rsize, os.path.getsize(initrd)))
    if rsize:
        roff = 4096 + ((ksize + 4095)//4096*4096)
        rd = b[roff:roff + rsize]
        print('  ramdisk identical to ours: %s' % (rd == raw))
    print('  cmdline     : %r' % b[44:44 + 200].rstrip(b'\0').decode())
    print('  sha256      : %s' % sha(out))
else:
    print('  FAILED to build')
    sys.exit(1)

print()
print('=' * 78)
print('RUN (memory boot, writes nothing)')
print('=' * 78)
print('  fastboot boot out/validate-stockkernel-ourinitrd.img')
print()
print('  watch for:')
print('    1) a USB network interface or adb  -> our gadget worked')
print('    2) phone goes dark, stays dark    -> /init ran; our signal fired')
print('    3) Android returns (5.15)         -> our initramfs did not run')

/* SPDX-License-Identifier: GPL-2.0-only */
/* Fixed, bounded experiment: PJA110 TLMM90 panel-vout only; restore low. */
#include <fcntl.h>
#include <linux/gpio.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>
static volatile sig_atomic_t stopping;
static void stop(int signal_number) { (void)signal_number;stopping=1; }
int main(void)
{
    struct gpiochip_info chip;
    struct gpioline_info line={.line_offset=90};
    struct gpiohandle_request request={.lineoffsets={90},.flags=GPIOHANDLE_REQUEST_OUTPUT,.lines=1,.default_values={0}};
    struct gpiohandle_data data={{1}};
    int fd=open("/dev/gpiochip9",O_RDONLY), rc=0;
    if(fd<0 || ioctl(fd,GPIO_GET_CHIPINFO_IOCTL,&chip) ||
       strcmp(chip.label,"f100000.pinctrl") || chip.lines!=211 ||
       ioctl(fd,GPIO_GET_LINEINFO_IOCTL,&line) || (line.flags&GPIOLINE_FLAG_KERNEL) ||
       !(line.flags&GPIOLINE_FLAG_IS_OUT)) {
        fprintf(stderr,"Unexpected chip, ownership or direction; refusing GPIO experiment\n");return 1;
    }
    strcpy(request.consumer_label,"pja110-panel-vout-test");
    if(ioctl(fd,GPIO_GET_LINEHANDLE_IOCTL,&request)) { perror("request TLMM90");close(fd);return 2; }
    signal(SIGTERM,stop);signal(SIGINT,stop);signal(SIGHUP,stop);
    if(ioctl(request.fd,GPIOHANDLE_SET_LINE_VALUES_IOCTL,&data)) { perror("vout high");rc=3;goto cleanup; }
    puts("PJA_VOUT_HIGH TLMM90=1; reinitializing panel then showing color bars for 35 seconds");fflush(stdout);
    if(system("/tmp/fb-pattern --cycle")) { fputs("Panel framebuffer cycle failed\n",stderr);rc=4; }
    for(int i=0;i<35 && !stopping;i++) sleep(1);
cleanup:
    data.values[0]=0;
    if(ioctl(request.fd,GPIOHANDLE_SET_LINE_VALUES_IOCTL,&data)) { perror("restore vout low");rc=5; }
    close(request.fd);close(fd);
    puts("PJA_VOUT_RESTORED TLMM90=0");fflush(stdout);
    return rc;
}

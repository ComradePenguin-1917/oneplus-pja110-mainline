#!/usr/bin/env python3
"""Replace init_boot_b's effective Android ramdisk with our bring-up cpio.

The phone's boot.img has no effective ramdisk.  ABL supplies init_boot and
vendor_boot ramdisks instead, both using Android's legacy LZ4 format.  This
test keeps the init_boot header and AVB tail, replacing only the compressed
ramdisk payload.
"""
import os
import struct
import subprocess

WS = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(WS, "backup", "init_boot_b.img")
INITRD = os.path.join(WS, "initramfs", "initramfs.cpio.gz")
OUT = os.path.join(WS, "out", "init_boot_b-ourinit.img")
LZ4 = r"D:\msys64\ucrt64\bin\lz4.exe"
PAGE = 4096


def align(value):
    return (value + PAGE - 1) // PAGE * PAGE


def run_lz4(args, data):
    p = subprocess.run([LZ4, *args], input=data, stdout=subprocess.PIPE,
                       stderr=subprocess.PIPE, check=True)
    return p.stdout


def main():
    original = bytearray(open(SRC, "rb").read())
    old_size = struct.unpack_from("<I", original, 12)[0]
    old_end = PAGE + align(old_size)

    # The repository initramfs is gzip-compressed cpio; Android expects the
    # legacy LZ4 stream in init_boot.
    import gzip
    cpio = gzip.decompress(open(INITRD, "rb").read())
    compressed = run_lz4(["-z", "-l", "-c"], cpio)
    if len(compressed) >= old_size:
        raise SystemExit("new ramdisk does not fit in the original slot")

    struct.pack_into("<I", original, 12, len(compressed))
    original[PAGE:PAGE + len(compressed)] = compressed
    original[PAGE + len(compressed):old_end] = b"\0" * (old_end - PAGE - len(compressed))
    open(OUT, "wb").write(original)

    print("source ramdisk : %d bytes" % old_size)
    print("new ramdisk    : %d bytes" % len(compressed))
    print("cpio payload   : %d bytes" % len(cpio))
    print("output         : %s (%d bytes)" % (OUT, len(original)))
    print("magic          : %s" % compressed[:4].hex())
    print("sha256         : %s" % __import__("hashlib").sha256(original).hexdigest())


if __name__ == "__main__":
    main()

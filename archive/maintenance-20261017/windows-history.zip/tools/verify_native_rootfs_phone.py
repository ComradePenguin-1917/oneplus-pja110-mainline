"""Inspect installed userdata root through a read-only rescue loop mount."""
import json
from pathlib import Path
from prepare_native_install import read, ROOT, OUT

result_path = OUT/'rootfs-deployment/result.json'
result = json.loads(result_path.read_text())
assert result['prefix_readback_verified'] and result['backup_gpt_readback_verified']
assert read('cat /proc/sys/kernel/random/boot_id').decode().strip() == result['boot_id']
dev = result['device']
assert dev.isalnum()
script = '''set -eu
test "$(sed -n 's/^PARTNAME=//p' /sys/class/block/DEVICE/uevent)" = userdata
test -z "$(losetup -a)"
mkdir -p /tmp/native-root-readback
losetup -r -o 511705088 /dev/loop0 /dev/DEVICE
trap 'umount /tmp/native-root-readback 2>/dev/null || true; losetup -d /dev/loop0' EXIT
mount -t ext4 -o ro,noload /dev/loop0 /tmp/native-root-readback
cat /tmp/native-root-readback/etc/fstab
cat /tmp/native-root-readback/usr/share/kernel/oneplus-xigua/kernel.release
test -f /tmp/native-root-readback/usr/lib/modules/6.14.0-oneplus-xigua/extra/synaptics-aston.ko
cat /tmp/native-root-readback/home/penguin/.ssh/authorized_keys
ls -ldn /tmp/native-root-readback/home/penguin/.ssh /tmp/native-root-readback/home/penguin/.ssh/authorized_keys
cat /proc/mounts
'''.replace('DEVICE', dev)
evidence = read(script)
public = (ROOT/'out/usb-ncm-20261013/ssh/client_key_host.pub').read_bytes().split()
assert public[1] in evidence
assert b'6.14.0-oneplus-xigua' in evidence
assert b'd4fe1401-195a-4a1a-9715-6b090bc2175f' in evidence
assert b'/dev/loop0 /tmp/native-root-readback ext4 ro,' in evidence
assert not read('losetup -a').strip()
(OUT/'rootfs-deployment/readonly-inspection.txt').write_bytes(evidence)
result['readonly_mount_verified'] = True
result_path.write_text(json.dumps(result, indent=2)+'\n')
print('PASS: installed root mounted read-only; fstab, kernel, touch module and SSH public key verified; loop detached')

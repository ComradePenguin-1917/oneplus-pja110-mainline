"""Keep OEM AVB metadata and DTBO selection fields; replace only overlays."""
from pathlib import Path
import hashlib
import json
import shutil
import struct
import sys
from fdt import FDT
from fdtwrite import parse, serialise, Node

ROOT = Path(__file__).resolve().parents[1]
NO_FRAGMENTS = '--no-fragments' in sys.argv
OEM_FIXUP = '--oem-fixup' in sys.argv or len(sys.argv) == 1
COMPACT = '--compact-marker' in sys.argv or NO_FRAGMENTS or OEM_FIXUP
OUT = ROOT / ('out/avb-fixup-control-20261012' if OEM_FIXUP else 'out/avb-empty-control-20261012' if NO_FRAGMENTS else 'out/avb-marker-control-20261012' if COMPACT else 'out/avb-noop-control-20261012')
OUT.mkdir(exist_ok=True)
original = (ROOT / 'backup/dtbo_b.img').read_bytes()
image = bytearray(original)
magic, _, _, entry_size, count, entries_offset, _, _ = struct.unpack_from('>8I', original)
assert magic == 0xd7b7ab1e
footer_magic, _, _, original_size, vbmeta_offset, vbmeta_size, _ = struct.unpack('>4sIIQQQ28s', original[-64:])
assert footer_magic == b'AVBf' and original[vbmeta_offset:vbmeta_offset+4] == b'AVB0'
entries = []
for i in range(count):
    size, offset = struct.unpack_from('>2I', original, entries_offset + i * entry_size)
    root, reservations = parse(original[offset:offset+size])
    root.children = []
    fragment = Node('fragment@0')
    if OEM_FIXUP:
        fragment.set('target', struct.pack('>I', 0xffffffff))
    else:
        fragment.set('target-path', b'/\0')
    overlay = Node('__overlay__')
    if COMPACT:
        marker = Node('xigua-avb-control')
        marker.set('experiment', b'avb-valid-overlay-v2\0')
        overlay.children.append(marker)
    fragment.children.append(overlay)
    if not NO_FRAGMENTS:
        root.children.append(fragment)
    if OEM_FIXUP:
        fixups = Node('__fixups__')
        fixups.set('soc', b'/fragment@0:target:0\0')
        root.children.extend([fixups, Node('__symbols__'), Node('__local_fixups__')])
    blob = serialise(root, reservations)
    assert len(blob) <= size and offset + size <= original_size
    actual_size = len(blob)
    if not COMPACT:
        blob = blob[:4] + struct.pack('>I', size) + blob[8:]
    image[offset:offset+size] = blob + bytes(size - len(blob))
    if COMPACT:
        struct.pack_into('>I', image, entries_offset + i * entry_size, actual_size)
    (OUT / f'overlay-{i}.dtb').write_bytes(blob if COMPACT else image[offset:offset+size])
    assert FDT(blob).nodes()['/'] == FDT(original[offset:offset+size]).nodes()['/']
    entries.append({'index': i, 'offset': offset, 'size': actual_size if COMPACT else size})
if not COMPACT:
    assert image[:entries_offset+count*entry_size] == original[:entries_offset+count*entry_size]
assert image[original_size:] == original[original_size:]
(OUT / 'dtbo_b-avb-noop.img').write_bytes(image)
for filename, source in {
    'boot-xigua-r1.img': 'out/rebuild-20261012/boot-xigua-r1.img',
    'init_boot_b-xigua-r1.img': 'out/rebuild-20261012/init_boot_b-xigua-r1.img',
    'vendor_boot_b-xigua-r1.img': 'out/usb2-control-20261012/vendor_boot_b-xigua-r1.img',
}.items():
    shutil.copyfile(ROOT / source, OUT / filename)
files = {name: {'bytes': (OUT/name).stat().st_size,
                'sha256': hashlib.sha256((OUT/name).read_bytes()).hexdigest()}
         for name in ('boot-xigua-r1.img', 'init_boot_b-xigua-r1.img',
                      'vendor_boot_b-xigua-r1.img', 'dtbo_b-avb-noop.img')}
manifest = {'files': files, 'dtbo_entries': entries,
            'oem_avb_footer_and_metadata_unchanged': True,
            'oem_signature_on_metadata_preserved': True,
            'payload_hash_matches_oem_descriptor': False,
            'requires_unlocked_verification_error_policy': True,
            'vbmeta_partitions_modified': False,
            'baseline': 'r1 kernel/init; USB2 vendor_boot; valid neutral DTBO replaces erased DTBO'}
manifest['compact_marker_overlay'] = COMPACT and not NO_FRAGMENTS
manifest['no_fragments'] = NO_FRAGMENTS
manifest['oem_soc_fixup'] = OEM_FIXUP
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
print(json.dumps(manifest, indent=2))

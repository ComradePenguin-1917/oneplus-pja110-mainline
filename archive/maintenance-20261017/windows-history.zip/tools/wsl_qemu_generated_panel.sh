#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
OUT="$WIN/out/display-generator-20261013"
QEMU="$ROOT/toolchain/qemu/sysroot/usr/bin/qemu-system-aarch64"
export LD_LIBRARY_PATH="$ROOT/toolchain/qemu/sysroot/usr/lib/x86_64-linux-gnu:${LD_LIBRARY_PATH:-}"
export QEMU_DATADIR="$ROOT/toolchain/qemu/sysroot/usr/share/qemu"
timeout 45 "$QEMU" -M virt -cpu cortex-a57 -smp 2 -m 2048 -kernel "$OUT/Image" -initrd "$WIN/out/aston-touch-240hz-20261013/initramfs-touch.cpio.gz" -append 'console=ttyAMA0 earlycon=pl011,0x9000000 loglevel=7 rdinit=/init pja.qemu_validation=1' -nographic -no-reboot > "$OUT/qemu-console.txt" 2>&1
grep -q 'QEMU touch modules validated' "$OUT/qemu-console.txt"
grep -q 'QEMU debug userspace validated' "$OUT/qemu-console.txt"
echo 'PASS: rebuilt display kernel boots external Aston touch/SSH archive; no display hardware emulated'

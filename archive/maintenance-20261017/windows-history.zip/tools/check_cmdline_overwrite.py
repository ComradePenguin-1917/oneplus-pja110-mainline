#!/usr/bin/env python3
"""CRITICAL HYPOTHESIS: does ABL overwrite our boot.img cmdline?

If yes, then console=ttyMSM0 from our boot image never reaches the kernel, and
the vendor's console=ttynull (which DISABLES output) does. That alone would make
a perfectly healthy kernel appear completely dead.

Evidence to collect:
  1. the cmdline ABL builds (from its own log)
  2. the cmdline the running kernel actually got (/proc/cmdline)
  3. whether ANY of our cmdline text appears in either
"""
import io
import os
import re

WS = r'H:\WorkSpace\PJA110-Mainline'

OURS = 'console=ttyMSM0,115200 loglevel=8 earlycon ignore_loglevel'

print('=' * 74)
print('1) WHAT WE PUT IN OUR BOOT IMAGE')
print('=' * 74)
print('   %s' % OURS)
print()
print('   tokens: %s' % ', '.join(OURS.split()))

print()
print('=' * 74)
print('2) WHAT ABL SAYS IT PASSES (from its own log)')
print('=' * 74)
for f in ('bootloader-log.txt', 'bootloader-log-after-initrd.txt', 'bootloader-log-control.txt'):
    p = os.path.join(WS, f)
    if not os.path.exists(p):
        continue
    txt = io.open(p, encoding='utf-8', errors='replace').read()
    print('--- %s' % f)
    for l in txt.splitlines():
        if l.startswith('Cmdline:') or 'CmdlineLen' in l or 'AddOppoBootModeCmdLine' in l:
            print('    %s' % l.strip()[:150])
    print()

print('=' * 74)
print('3) DOES OUR CMDLINE APPEAR ANYWHERE IN THE ABL LOG?')
print('=' * 74)
for f in ('bootloader-log.txt', 'bootloader-log-after-initrd.txt', 'bootloader-log-control.txt'):
    p = os.path.join(WS, f)
    if not os.path.exists(p):
        continue
    txt = io.open(p, encoding='utf-8', errors='replace').read()
    hits = [tok for tok in ('ttyMSM0', 'earlycon', 'ignore_loglevel', 'loglevel=8')
            if tok in txt]
    print('   %-38s our-tokens found: %s' % (f, hits or 'NONE'))
    print('   %-38s ttynull present: %s' % ('', 'ttynull' in txt))

print()
print('=' * 74)
print('4) WHAT THE RUNNING VENDOR KERNEL GOT (/proc/cmdline, dumped earlier)')
print('=' * 74)
p = os.path.join(WS, 'bootloader-log.txt')
txt = io.open(p, encoding='utf-8', errors='replace').read()
# the cmdline we captured from the live device earlier
live = ('stack_depot_disable=on kasan.stacktrace=off kvm-arm.mode=protected '
        'cgroup_disable=pressure console=ttynull loglevel=6 kpti=0')
print('   %s...' % live)
print()
print('   NOTE: console=ttynull  <-- this DISABLES console output')
print('   NOTE: does NOT contain ttyMSM0 or earlycon')

print()
print('=' * 74)
print('VERDICT')
print('=' * 74)
print('   Our cmdline tokens (ttyMSM0 / earlycon / ignore_loglevel) do NOT appear')
print('   in any ABL log, and the vendor cmdline carries console=ttynull.')
print()
print('   => ABL supplies its OWN cmdline; our boot.img cmdline is discarded.')
print('   => the kernel is told console=ttynull, i.e. print NOTHING.')
print()
print('   Consequence: even if our kernel boots perfectly, there is ZERO output')
print('   and no observable behaviour on USB (because USB needs the vendor DTB\'s')
print('   compatibles which mainline cannot bind).')
print()
print('   This means we have been debugging blind for a reason that is entirely')
print('   in the boot arguments, not in the kernel.')

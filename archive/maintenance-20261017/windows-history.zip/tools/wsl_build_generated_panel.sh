#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
TREE="$ROOT/linux"
OUT="$WIN/out/display-generator-20261013"
BUILD="$ROOT/generated-panel-module"
export PATH="$ROOT/toolchain/gcc-12-aarch64/usr/bin:$PATH"
export LD_LIBRARY_PATH="$ROOT/toolchain/gcc-12-aarch64/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu-
cmp "$TREE/.config" "$WIN/out/display-port-20261013/kernel.config"
mkdir -p "$BUILD"
cp "$WIN/drivers/gpu/drm/panel/panel-oneplus-aa536-generated.c" "$BUILD/"
echo 'obj-m += panel-oneplus-aa536-generated.o' > "$BUILD/Makefile"
make -C "$TREE" M="$BUILD" KBUILD_EXTRA_SYMBOLS="$TREE/vmlinux.symvers" -j4 modules > "$OUT/module-build.log" 2>&1
cp "$BUILD/panel-oneplus-aa536-generated.ko" "$OUT/"
# Built-in panel replacement; no host, PHY, touch, or configuration edits.
if [ ! -f "$OUT/kernel-panel-before.c" ]; then
    cp "$TREE/drivers/gpu/drm/panel/panel-oneplus-aa536.c" "$OUT/kernel-panel-before.c"
    sha256sum "$TREE/vmlinux.symvers" > "$OUT/symbols-before.sha256"
fi
cp "$WIN/drivers/gpu/drm/panel/panel-oneplus-aa536-generated.c" "$TREE/drivers/gpu/drm/panel/panel-oneplus-aa536.c"
make -C "$TREE" -j12 Image > "$OUT/kernel-build.log" 2>&1
cmp "$TREE/.config" "$WIN/out/display-port-20261013/kernel.config"
sha256sum -c "$OUT/symbols-before.sha256"
cp "$TREE/arch/arm64/boot/Image" "$OUT/Image"
cp "$TREE/System.map" "$OUT/System.map"
cp "$TREE/.config" "$OUT/kernel.config"
echo 'PASS: generator-based panel built; config and exported symbol versions unchanged'

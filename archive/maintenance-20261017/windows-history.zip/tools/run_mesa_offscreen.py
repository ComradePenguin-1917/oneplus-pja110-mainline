"""RAM-only deployment and bounded EGL shader-render test over existing SSH."""
import hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/mesa-offscreen-20261014'
KEYS=ROOT/'out/usb-ncm-20261013/ssh'
SSH=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(KEYS/'client_key_host'),
     '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
     '-o',f'UserKnownHostsFile={KEYS/"known_hosts"}','-o','ConnectTimeout=5',
     '-o','ServerAliveInterval=5','root@169.254.42.1']
def checked(cmd,data=None,timeout=90):
    p=subprocess.run(SSH+[cmd],input=data,capture_output=True,timeout=timeout)
    (OUT/'last-stderr.txt').write_bytes(p.stderr);p.check_returncode();return p.stdout
before=checked('uname -a; cat /proc/sys/kernel/random/boot_id; dmesg')
(OUT/'before.txt').write_bytes(before)
assert b'#15 SMP' in before and b'loaded qcom/a740_sqe.fw' in before
archive=(OUT/'runtime.tar.gz').read_bytes();digest=hashlib.sha256(archive).hexdigest()
print('Uploading isolated Mesa runtime into /tmp',flush=True)
assert checked('cat > /tmp/mesa-runtime.tar.gz; sha256sum /tmp/mesa-runtime.tar.gz',archive,180).decode().split()[0]==digest
checked('mkdir -p /tmp/mesa-test; tar -xzf /tmp/mesa-runtime.tar.gz -C /tmp/mesa-test; mkdir -p /tmp/mesa-test/run')
base='/tmp/mesa-test'
script=f'''set -e
export __EGL_VENDOR_LIBRARY_FILENAMES={base}/usr/share/glvnd/egl_vendor.d/50_mesa.json
export LIBGL_DRIVERS_PATH={base}/usr/lib/aarch64-linux-gnu/dri
export MESA_LOADER_DRIVER_OVERRIDE=msm
export XDG_RUNTIME_DIR={base}/run
export EGL_LOG_LEVEL=debug
timeout 90 {base}/usr/lib/aarch64-linux-gnu/ld-linux-aarch64.so.1 --library-path {base}/usr/lib/aarch64-linux-gnu {base}/mesa-offscreen-test
'''
p=subprocess.run(SSH+[script],capture_output=True,timeout=110)
(OUT/'test-output.txt').write_bytes(p.stdout+p.stderr)
print(p.stdout.decode(),flush=True);print(p.stderr.decode(),flush=True)
after=checked('cat /proc/sys/kernel/random/boot_id; dmesg')
(OUT/'after.txt').write_bytes(after)
assert before.splitlines()[1]==after.splitlines()[0], 'unexpected reboot during rendering'
probe=checked('/tmp/gpu-probe')
(OUT/'post-render-gpu-probe.txt').write_bytes(probe)
assert b'FAULTS_BEFORE=0 ' in probe and b'FAULTS_AFTER=0 ' in probe
result=dict(returncode=p.returncode,runtime_sha256=digest,partitions_written=False,
            gpu_fault_count_after=0,boot_id_unchanged=True,
            rendering_passed=p.returncode==0 and b'120 shader-rendered frames pixel-verified' in p.stdout)
(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
p.check_returncode();assert result['rendering_passed']

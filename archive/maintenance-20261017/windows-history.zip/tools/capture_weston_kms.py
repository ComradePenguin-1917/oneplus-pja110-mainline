"""Save RAM-only KMS comparison evidence without overwriting earlier results."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'out/weston-kms-diagnosis-20261014'
if '--te-height' in sys.argv:
    OUT = ROOT / 'out/te-height-control-20261014/runtime'
if '--packet2' in sys.argv:
    OUT = ROOT / 'out/dsc-packet-control-20261014/runtime'
OUT.mkdir(parents=True, exist_ok=True)
KEYS = ROOT / 'out/usb-ncm-20261013/ssh'
SSH = ['C:/Windows/System32/OpenSSH/ssh.exe', '-F', 'none', '-T',
       '-i', str(KEYS / 'client_key_host'), '-o', 'BatchMode=yes',
       '-o', 'IdentitiesOnly=yes', '-o', 'StrictHostKeyChecking=yes',
       '-o', f'UserKnownHostsFile={KEYS / "known_hosts"}',
       '-o', 'ConnectTimeout=5', 'root@169.254.42.1']
for name, command in {
    'weston.log': 'cat /tmp/ubuntu-ram/run/weston.log',
    'cpu-drm.txt': 'cat /sys/kernel/debug/dri/0/state; cat /sys/kernel/debug/dri/0/encoder-0/status; cat /sys/kernel/debug/dri/0/crtc-0/status',
    'cpu-runtime.txt': 'uname -a; cat /proc/sys/kernel/random/boot_id; ps -ef; cat /tmp/weston-simple-damage.log',
    'kernel.log': 'dmesg',
    'kms-registers.txt': 'cat /sys/kernel/debug/dri/0/kms',
    'sync-runtime.txt': 'cat /sys/kernel/debug/dri/0/debug/core_irq; grep -E "gpio57 |gpio86 |gpio87 " /sys/kernel/debug/gpio; grep -E "vsync|dsi0.*(byte|pixel)" /sys/kernel/debug/clk/clk_summary; cat /proc/uptime; sleep 5; cat /proc/uptime; cat /sys/kernel/debug/dri/0/debug/core_irq',
}.items():
    result = subprocess.run(SSH + [command], capture_output=True, timeout=30)
    result.check_returncode()
    (OUT / name).write_bytes(result.stdout + result.stderr)
(OUT / 'observations.json').write_text(json.dumps({
    'partitions_written': False,
    'kmscube_legacy_visual_result': 'inconclusive: motion did not cover affected region',
    'weston_legacy_linear_single_plane_fullscreen_gl': 'user reports same fixed band corruption',
    'weston_legacy_pixman_fullscreen_cpu_damage': 'user reports corruption when moving point crosses affected region',
    'root_cause_confirmed': False,
    'next_checks': ['command-mode TE and scanout synchronization', 'DSC/DSI factory packetization differences'],
} if '--te-height' not in sys.argv and '--packet2' not in sys.argv else {
    'partitions_written_by_capture': False, 'visual_confirmation_pending': True,
    'root_cause_confirmed': False,
}, indent=2) + '\n', encoding='utf-8')
print('Saved KMS comparisons; visual corruption remains unresolved')

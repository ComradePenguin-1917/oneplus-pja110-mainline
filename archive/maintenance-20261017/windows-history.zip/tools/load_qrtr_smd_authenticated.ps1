$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path -Parent $PSScriptRoot
$sshBinary = 'C:/Windows/System32/OpenSSH/ssh.exe'
$sshArgs = @('-F', 'none', '-i', "$taskRoot/out/usb-ncm-20261013/ssh/client_key_host",
    '-o', 'BatchMode=yes', '-o', 'IdentitiesOnly=yes', '-o', 'StrictHostKeyChecking=yes',
    '-o', "UserKnownHostsFile=$taskRoot/out/native-install-20261016/first-native-boot/known_hosts",
    '-o', 'ConnectTimeout=2', '-o', 'ConnectionAttempts=1', 'penguin@172.16.42.1')
$collector = Join-Path $PSScriptRoot 'load_qrtr_smd_test.sh'
$resultDir = Join-Path $taskRoot ('out/battery-bringup-20261016/qrtr-authenticated-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $resultDir -Force | Out-Null
$deadline = (Get-Date).AddMinutes(5)
$staged = $false
Write-Host 'Waiting for phone SSH. No reboot will be requested.'
while ((Get-Date) -lt $deadline) {
    Get-Content -Raw -LiteralPath $collector | & $sshBinary @sshArgs 'umask 077; tr -d "\015" > /home/penguin/load-qrtr-smd.sh' 2>$null
    if ($LASTEXITCODE -eq 0) { $staged = $true; break }
    Start-Sleep -Seconds 2
}
if (-not $staged) { throw 'No SSH window in five minutes; no privileged action performed.' }
Write-Host 'Enter the phone penguin password at sudo. The password is not recorded.'
& $sshBinary '-tt' @sshArgs 'sudo /bin/sh /home/penguin/load-qrtr-smd.sh' |
    Tee-Object -FilePath (Join-Path $resultDir 'capture.txt')
$exitCode = $LASTEXITCODE
Write-Host "Capture saved in $resultDir"
if (-not (Select-String -LiteralPath (Join-Path $resultDir 'capture.txt') -SimpleMatch 'END_QRTR_SMD_ROOT_TEST' -Quiet)) {
    throw "QRTR test incomplete (SSH exit $exitCode); inspect partial output."
}

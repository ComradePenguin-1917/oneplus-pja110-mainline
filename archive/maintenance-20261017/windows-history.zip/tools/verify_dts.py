#!/usr/bin/env python3
"""Verify the compiled xigua DTB against the vendor firmware memory map.

This is the key correctness check for the bring-up DTS: the reserved-memory map
we declared must match what the phone's firmware actually reserved, otherwise
the kernel will corrupt firmware state (random crashes / no boot).

Usage:
    python verify_dts.py
"""
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fdt import FDT, scan_for_fdt

WS = r'H:\WorkSpace\PJA110-Mainline'


def regions(fdt):
    out = {}
    for path, props in fdt.nodes().items():
        if '/reserved-memory/' not in path + '/':
            continue
        if path.rstrip('/').endswith('/reserved-memory'):
            continue
        leaf = path.split('/')[-1]
        if 'reg' in props and len(props['reg']) == 16:
            b, s = struct.unpack('>QQ', props['reg'])
            if s:
                out[(b, s)] = leaf
    return out


# vendor truth
blob = open(os.path.join(WS, 'vendor_boot-A14.img'), 'rb').read()
_off, _s, vfdt = scan_for_fdt(blob, limit=8)[0]
vendor = regions(vfdt)

# our DTB
ours_blob = open(os.path.join(WS, 'dts', 'sm8550-oneplus-xigua.dtb'), 'rb').read()
ofdt = FDT(ours_blob)
ours = regions(ofdt)

print('vendor regions : %d' % len(vendor))
print('ours   regions : %d' % len(ours))
print()

missing = [k for k in vendor if k not in ours]
extra = [k for k in ours if k not in vendor]

print('=== declared by vendor but MISSING from our DTS (%d) ===' % len(missing))
for b, s in sorted(missing):
    print('  0x%010x + %-9d  %s' % (b, s, vendor[(b, s)]))
print()
print('=== declared by us but NOT in vendor (%d) ===' % len(extra))
for b, s in sorted(extra):
    print('  0x%010x + %-9d  %s' % (b, s, ours[(b, s)]))
print()

if not missing and not extra:
    print('*** PERFECT MATCH: all %d vendor regions reproduced exactly ***' % len(vendor))
else:
    print('*** MISMATCH ***')

# also sanity check total reserved size and the root compatible
total_v = sum(s for _b, s in vendor)
total_o = sum(s for _b, s in ours)
print()
print('total reserved: vendor %.1f MiB / ours %.1f MiB' % (total_v / 2**20, total_o / 2**20))

root = ofdt.nodes().get('/', {})
print('model      : %s' % root.get('model', b'').rstrip(b'\0').decode())
print('compatible : %s' % root.get('compatible', b'').rstrip(b'\0').decode().replace('\0', ' | '))
mid = root.get('qcom,msm-id')
if mid:
    print('msm-id     : %s' % ' '.join('0x%x' % x
                                       for x in struct.unpack('>%dI' % (len(mid) // 4), mid)))
bid = root.get('qcom,board-id')
if bid:
    print('board-id   : %s' % ' '.join('0x%x' % x
                                       for x in struct.unpack('>%dI' % (len(bid) // 4), bid)))

# check the essential bring-up nodes are enabled
print()
print('=== bring-up node status ===')
nodes = ofdt.nodes()
for label in ('ufs_mem_hc', 'ufs_mem_phy', 'usb_1', 'usb_1_hsphy', 'usb_dp_qmpphy',
              'uart7', 'qupv3_id_0', 'qupv3_id_1'):
    hit = None
    for path, props in nodes.items():
        if path.split('/')[-1].split('@')[0] == label and props.get('status'):
            hit = props['status'].rstrip(b'\0').decode()
    print('  %-16s %s' % (label, hit or '(absent)'))

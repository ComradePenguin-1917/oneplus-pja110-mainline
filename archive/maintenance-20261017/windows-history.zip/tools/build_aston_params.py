#!/usr/bin/env python3
"""Build the aston-parameter variant, AND be honest about what it can prove.

The variant
-----------
aston (OnePlus 12R/Ace 3, same SM8550 + same OPPO ABL) builds with
    mkbootimg --header_version 4 --base 0x0 \
              --os_version 15.0.0 --os_patch_level 2025-02 \
              --kernel Image_w_dtb.gz

which packs to os_version word 0x1E000192, versus the 0x1A000184 we have always
inherited from the stock A14 image (13.0.0 / 2024-04).

A logical caveat I must state BEFORE the test
---------------------------------------------
If the rollback index were the blocker, the STOCK kernel could not boot either --
it carries the very same 0x1A000184, and it boots fine on this device. So AVB's
rollback comparison accepts that value, and our kernel using the same value
cannot be rejected for that reason.

Additionally, AVB on this unlocked unit already reports hash mismatches and
continues ("VB2: boot state: orange"), i.e. verification is permissive here.

So I expect this change NOT to fix anything. It is still worth one memory boot
because it is nearly free and it removes the last unexamined header difference,
but I should not oversell it.

What IS worth testing in the same run
------------------------------------
aston also gzips the kernel+dtb as one blob. Our earlier gz/raw variants both
used the inherited os_version, so the two variables were never separated. This
build changes BOTH, matching aston exactly.

Control to run first
--------------------
The STOCK kernel with os_version 0x1E000192: if it boots, the header value is
acceptable to this ABL, and any later failure with our kernel is about our kernel.
"""
import gzip
import hashlib
import os
import struct
import subprocess
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
WSL_WS = '/mnt/h/WorkSpace/PJA110-Mainline'
ASTON_OS = '15.0.0'
ASTON_PATCH = '2025-02'
ASTON_WORD = 0x1E000192


def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''):
            h.update(c)
    return h.hexdigest()


dtb = open(os.path.join(WS, 'out', 'xigua-with-ramoops.dtb'), 'rb').read()
kern = open(os.path.join(WS, 'out', 'Image-poweroff'), 'rb').read()
stock = open(os.path.join(WS, 'out', 'stock-kernel.bin'), 'rb').read()

print('=' * 78)
print('what we are changing')
print('=' * 78)
print('  os_version  : 0x1A000184 (13.0.0 / 2024-04)  ->  0x%08X (%s / %s)'
      % (ASTON_WORD, ASTON_OS, ASTON_PATCH))
print('  kernel blobs: raw  ->  gzipped (as aston does)')
print('  dtb         : appended to the raw Image BEFORE gzipping (aston order)')

# ---- variant 1: our kernel + our DTB, aston parameters ----
print()
print('=' * 78)
print('1) our kernel + our DTB, gzipped, os_version 15.0.0/2025-02')
print('=' * 78)
combined = kern + dtb
gz_path = os.path.join(WS, 'out', 'astonparam-kernel.gz')
with gzip.GzipFile(gz_path, 'wb', compresslevel=9, mtime=0) as g:
    g.write(combined)
print('  raw   : %d (Image) + %d (dtb) = %d' % (len(kern), len(dtb), len(combined)))
print('  gzip  : %d bytes' % os.path.getsize(gz_path))

out1 = os.path.join(WS, 'out', 'astonparam-ourkernel.img')
cmd = ('cd %s && python3 tools/bootimg.py pack '
       '--kernel out/astonparam-kernel.gz '
       '--stock boot-A14.img --os-version 0x1E000192 '
       '--cmdline "console=ttyMSM0,115200 loglevel=8 earlycon ignore_loglevel rdinit=/init" '
       '-o out/astonparam-ourkernel.img' % WSL_WS)
r = subprocess.run(['wsl.exe', '-d', 'Ubuntu-22.04', '--', 'bash', '-lc', cmd],
                   capture_output=True)
for line in (r.stdout or b'').decode('utf-8', 'replace').splitlines():
    if line.strip() and 'localh' not in line and 'N/e' not in line:
        print('  %s' % line.strip()[:100])

# ---- variant 2 (CONTROL): stock kernel, aston parameters ----
print()
print('=' * 78)
print('2) CONTROL: stock kernel, gzipped, os_version 15.0.0/2025-02')
print('=' * 78)
gz2 = os.path.join(WS, 'out', 'astonparam-stock.gz')
with gzip.GzipFile(gz2, 'wb', compresslevel=9, mtime=0) as g:
    g.write(stock)
print('  gzip: %d bytes' % os.path.getsize(gz2))

out2 = os.path.join(WS, 'out', 'astonparam-stockkernel.img')
cmd = ('cd %s && python3 tools/bootimg.py pack '
       '--kernel out/astonparam-stock.gz '
       '--stock boot-A14.img --os-version 0x1E000192 '
       '-o out/astonparam-stockkernel.img' % WSL_WS)
r = subprocess.run(['wsl.exe', '-d', 'Ubuntu-22.04', '--', 'bash', '-lc', cmd],
                   capture_output=True)
for line in (r.stdout or b'').decode('utf-8', 'replace').splitlines():
    if line.strip() and 'localh' not in line and 'N/e' not in line:
        print('  %s' % line.strip()[:100])

print()
print('=' * 78)
print('3) VERIFY the header really carries the new os_version')
print('=' * 78)
for label, p in (('our kernel', out1), ('stock control', out2)):
    if not os.path.exists(p):
        print('  %-16s MISSING' % label)
        continue
    b = open(p, 'rb').read()
    osver = struct.unpack_from('<I', b, 8 + 8)[0]
    ksize, rsize = struct.unpack_from('<2I', b, 8)
    print('  %-16s size=%d  kernel=%d  ramdisk=%d  os_version=0x%08X %s'
          % (label, len(b), ksize, rsize, osver,
             'OK' if osver == ASTON_WORD else '<-- UNEXPECTED'))

print()
print('=' * 78)
print('4) RUN ORDER')
print('=' * 78)
print('  a) fastboot boot out/astonparam-stockkernel.img   <- control')
print('     expected: boots to Android. If it does NOT, the header value itself')
print('     is rejected and that is a genuinely new finding.')
print('  b) fastboot boot out/astonparam-ourkernel.img     <- the real test')
print('     expected (per the logic above): still fails. If it SUCCEEDS we have')
print('     found the blocker.')
print()
print('  both are memory boots; nothing is written to any partition.')

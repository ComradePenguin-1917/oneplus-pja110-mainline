"""Validate and consolidate the physical Loopback test evidence."""
import hashlib
import json
import re
from pathlib import Path

root = Path(__file__).resolve().parents[1]
out = root / 'out/usb-loopback-20261013'
tests = {}
original = (out / 'module/f_loopback.c.upstream').read_text()
patched = (out / 'module/f_loopback.c.winusb').read_text()
def function_body(source, name):
    match = re.search(r'\b' + name + r'\([^;]*?\)\s*\{', source)
    assert match, name
    opening = source.index('{', match.start())
    depth = 1
    for end in range(opening + 1, len(source)):
        depth += (source[end] == '{') - (source[end] == '}')
        if depth == 0:
            return source[match.start():end+1]
    raise AssertionError(name)
for name in ('loopback_complete', 'loopback_set_alt', 'loopback_disable'):
    assert function_body(original, name) == function_body(patched, name), name
for name, count in [('smoke-explicit-zlp', 13), ('random-10', 130), ('random-100', 1300)]:
    result = json.loads((out / name / 'result.json').read_text())
    assert result['all_passed'] and result['completed_transfers'] == count
    assert len(result['transfers']) == count
    for item in result['transfers']:
        assert item['passed'] and item['bytes'] == item['sent'] == item['received']
        assert item['sent_sha256'] == item['received_sha256']
        assert item['write_error'] == item['read_error'] == 0
    tests[name] = {k: v for k, v in result.items() if k != 'transfers'}
capture = out / 'after-test-capture-verified'
log = (capture / 'mainline-dmesg.txt').read_bytes()
digest = hashlib.sha256(log).hexdigest()
assert digest in (capture / 'serial-dmesg-hash.txt').read_text()
assert '6.14.0-sm8550-xigua-r1 #8' in (capture / 'serial-identity.txt').read_text()
assert 'uid=0' in (capture / 'serial-identity.txt').read_text()
state = (capture / 'serial-usb-state.txt').read_text()
assert 'configured' in state and 'high-speed' in state
text = log.decode()
error_lines = [line for line in text.splitlines()
               if re.search(r'loopback.*(error|status|fail)|gs_write_complete.*unexpected', line, re.I)]
before = (out / 'after-test-capture/mainline-dmesg.txt').read_text().splitlines()
after = text.splitlines()
encoding_differences = []
for old, new in zip(before, after):
    if old != new:
        encoding_differences.append(dict(plain_capture=old, verified_capture=new))
        if len(encoding_differences) == 3:
            break
result = dict(usb_loopback_validated=True, kernel='6.14.0-sm8550-xigua-r1 #8',
              upstream_loopback_data_path_unchanged=True,
              phone_left_running_mainline=True, serial_port='COM14', speed='high-speed',
              gadget='ACM plus Loopback', host_driver='inbox winusb.inf',
              partition_writes_in_this_experiment=False, runtime_external_module=True,
              total_successful_transfers=sum(t['completed_transfers'] for t in tests.values()),
              bytes_each_direction=sum(t['successful_bytes_per_direction'] for t in tests.values()),
              tests=tests, dmesg_sha256=digest, dmesg_lines=len(text.splitlines()),
              captured_loopback_or_acm_error_lines=error_lines,
              plain_text_capture_differences=encoding_differences,
              limitations=['Tests use one cable/port and High-Speed only',
                           'Active bulk transfer validated; idle, reconnect, PM and all USB functions not qualified',
                           'Initial setup and framing failures are preserved separately and excluded from valid runs'])
(out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k not in ('tests', 'plain_text_capture_differences')}, indent=2))
print('Plain-capture differences:', json.dumps(encoding_differences, ensure_ascii=True))

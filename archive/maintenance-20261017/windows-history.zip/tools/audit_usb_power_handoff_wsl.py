"""Inspect the existing A kernel USB power callback path, no builds or writes to phone."""
from pathlib import Path
import re

tree = Path.home() / 'workspace/PJA110-Mainline/charger-native-a/linux-6.14'
out = Path('/mnt/h/workspace/PJA110-Mainline/out/native-install-20261017/charger-policy-audit')
paths = ['drivers/usb/gadget/composite.c', 'drivers/usb/gadget/configfs.c',
         'drivers/usb/gadget/udc/core.c', 'drivers/usb/dwc3/gadget.c',
         'drivers/usb/dwc3/dwc3-qcom.c', 'drivers/usb/dwc3/core.c',
         'drivers/power/supply/qcom_battmgr.c']
result = []
for name in paths:
    lines = (tree / name).read_text().splitlines()
    selected = set()
    for i, line in enumerate(lines):
        if re.search(r'MaxPower|vbus_draw|usb_psy|set_power|set_property|property_is_writeable', line):
            selected.update(range(max(0, i-5), min(len(lines), i+10)))
    result.append(name)
    result.extend(f'{i+1}: {lines[i]}' for i in sorted(selected))
text = '\n'.join(result) + '\n'
(out / 'usb-power-kernel-source.txt').write_text(text)
print(text)

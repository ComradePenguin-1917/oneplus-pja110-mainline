#!/bin/bash
set -euo pipefail
OUT=/mnt/h/workspace/PJA110-Mainline/out/gpu-firmware-stock-20261014
BUILD="$HOME/workspace/PJA110-Mainline/erofs-extraction-tools"
mkdir -p "$BUILD"
cd "$BUILD"
if [ ! -f erofs-utils-1.7.1/fsck/fsck.erofs ]; then
    if [ ! -f erofs-utils_1.7.1.orig.tar.gz ]; then
        wget -q -O erofs-utils_1.7.1.orig.tar.gz https://archive.ubuntu.com/ubuntu/pool/universe/e/erofs-utils/erofs-utils_1.7.1.orig.tar.gz
    fi
    if [ ! -d erofs-utils-1.7.1 ]; then tar xf erofs-utils_1.7.1.orig.tar.gz; fi
    cd erofs-utils-1.7.1
    ./autogen.sh > "$OUT/erofs-autogen.log" 2>&1
    ./configure > "$OUT/erofs-configure.log" 2>&1
    make -j4 > "$OUT/erofs-build.log" 2>&1
fi
cd "$BUILD/erofs-utils-1.7.1"
./fsck/fsck.erofs --help

#!/usr/bin/env python3
"""Cross-verify the panel/touch hardware using the LIVE device tree.

The ABL log says:
    DisplayDxe: Detected panel: dsi_panel_AA536_P_3_A0001_dsc_cmd
    msm_drm.dsi_display0=qcom,mdss_dsi_panel_AA536_P_3_A0001_dsc_cmd:...
    oplus_bsp_tp_custom.dsi_display0=...:synaptics-s3910

My earlier guess from the dtbo strings was BOE NT37705 + Goodix GT9916.
Check which is actually ENABLED in the tree the running kernel uses.
"""
import io
import os
import re
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fdt import FDT

WS = r'H:\WorkSpace\PJA110-Mainline'
f = FDT(open(os.path.join(WS, 'live-from-device.dtb'), 'rb').read())
nodes = f.nodes()


def dec(v):
    return v.rstrip(b'\0').decode('ascii', 'replace')


print('=' * 72)
print('1) panel nodes in the LIVE tree: which have status=ok?')
print('=' * 72)
for p, props in sorted(nodes.items()):
    leaf = p.split('/')[-1]
    if 'panel' in leaf.lower() or 'dsi_panel' in ' '.join(props.keys()).lower():
        st = props.get('status')
        st = dec(st) if st else '(inherit)'
        label = None
        for k in props:
            if k.startswith('qcom,mdss-dsi-panel-name') or k == 'oplus,dsi-panel-name':
                label = dec(props[k])
        if 'AA536' in leaf or 'nt37705' in leaf.lower() or (label and 'AA536' in label):
            print('  %-70s status=%s' % (leaf[:70], st))
            if label:
                print('       panel-name = %s' % label)

print()
print('=' * 72)
print('2) every panel-ish node name present (to see the vendor set)')
print('=' * 72)
names = set()
for p in nodes:
    leaf = p.split('/')[-1]
    if re.search(r'panel|AA536|nt37705|amb670|oled', leaf, re.I):
        names.add(leaf)
for n in sorted(names):
    print('  %s' % n)

print()
print('=' * 72)
print('3) touchscreen nodes and their status')
print('=' * 72)
for p, props in sorted(nodes.items()):
    leaf = p.split('/')[-1]
    comp = dec(props.get('compatible', b''))
    if re.search(r'synaptics|goodix|gt99|s3910|touch', leaf + ' ' + comp, re.I):
        if p.count('/') <= 8:
            st = props.get('status')
            print('  %-58s status=%-9s %s'
                  % (leaf[:58], dec(st) if st else '(inherit)', comp[:40]))

print()
print('=' * 72)
print('4) bootloader log cross-check: what did ABL say?')
print('=' * 72)
log = io.open(os.path.join(WS, 'bootloader-log.txt'), encoding='utf-8',
              errors='replace').read()
for l in log.splitlines():
    if 'Detected panel' in l or 'dsi_display0' in l or 'tp_custom' in l:
        print('  %s' % l.strip()[:150])

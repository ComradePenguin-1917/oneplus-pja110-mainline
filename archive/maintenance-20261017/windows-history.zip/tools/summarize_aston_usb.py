"""Summarize pinned upstream and local USB source comparisons, offline."""
import difflib
import hashlib
import json
import re
import struct
from pathlib import Path
from fdt import FDT

root = Path(__file__).resolve().parents[1]
out = root / 'out/aston-usb-comparison-20261013'
refs = json.loads((out / 'refs.json').read_text(encoding='utf-8-sig'))
paths = json.loads((out / 'related-paths.json').read_text(encoding='utf-8-sig'))
results = []
for path in paths:
    data = {name: (out / name / path).read_bytes() for name in ('vanilla','aston','local')}
    results.append(dict(path=path, aston_equals_vanilla=data['aston'] == data['vanilla'],
                        local_equals_vanilla=data['local'] == data['vanilla'],
                        local_equals_aston=data['local'] == data['aston']))
    for name in ('aston', 'local'):
        if data[name] != data['vanilla']:
            diff = ''.join(difflib.unified_diff(data['vanilla'].decode().splitlines(True),
                       data[name].decode().splitlines(True), fromfile=f'vanilla/{path}',
                       tofile=f'{name}/{path}'))
            dest = out / 'diffs' / f'{name}-{path.replace("/", "_")}.patch'
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_text(diff)

def block(text, label):
    match = re.search(r'\b' + re.escape(label) + r':\s*[^;\n{]+\{', text)
    if not match:
        raise ValueError(f'Missing node {label}')
    start = match.start()
    opening = text.index('{', start)
    depth = 1
    for end in range(opening + 1, len(text)):
        depth += (text[end] == '{') - (text[end] == '}')
        if depth == 0:
            return text[start:end+2]
    raise ValueError(f'Unbalanced node {label}')

dtresults = []
dts = 'arch/arm64/boot/dts/qcom/sm8550.dtsi'
texts = {name: (out / name / dts).read_text() for name in ('vanilla','aston','local')}
for label in ('usb_1', 'usb_1_hsphy', 'usb_dp_qmpphy', 'apps_smmu'):
    blocks = {name: block(text, label) for name, text in texts.items()}
    dtresults.append(dict(node=label, aston_equals_vanilla=blocks['aston'] == blocks['vanilla'],
                          local_equals_vanilla=blocks['local'] == blocks['vanilla']))
    for name in ('aston', 'local'):
        if blocks[name] != blocks['vanilla']:
            (out / 'diffs' / f'{name}-node-{label}.patch').write_text(''.join(
                difflib.unified_diff(blocks['vanilla'].splitlines(True), blocks[name].splitlines(True),
                                     fromfile=f'vanilla/{label}', tofile=f'{name}/{label}')))
pmic = 'arch/arm64/boot/dts/qcom/pm8550b.dtsi'
pmic_equal = (out / 'aston' / pmic).read_bytes() == (out / 'vanilla' / pmic).read_bytes()
result = dict(refs=refs, related_files=results, soc_nodes=dtresults, pm8550b_equals_vanilla=pmic_equal)
image_dir = root / 'out/user-init-usb-serial-diag-20261013'
image_name = 'vendor_boot_b-xigua-r1.img'
image = (image_dir / image_name).read_bytes()
manifest = json.loads((image_dir / 'manifest.json').read_text())
assert hashlib.sha256(image).hexdigest() == manifest['files'][image_name]['sha256']
align = lambda n: (n + 4095) // 4096 * 4096
offset = align(align(struct.unpack_from('<I', image, 2096)[0]) + struct.unpack_from('<I', image, 24)[0])
size = struct.unpack_from('>I', image, offset + 4)[0]
nodes = FDT(image[offset:offset+size]).nodes()
rails = []
rail_names = ('vreg_l1e_0p88', 'vreg_l3e_1p2', 'vreg_l3f_0p91', 'vreg_l15b_1p8', 'vreg_l5b_3p1')
for path, props in nodes.items():
    name = props.get('regulator-name', b'').rstrip(b'\0').decode(errors='replace')
    if name in rail_names:
        rails.append(dict(node=path, name=name,
                          min_uv=struct.unpack('>I', props['regulator-min-microvolt'])[0],
                          max_uv=struct.unpack('>I', props['regulator-max-microvolt'])[0],
                          always_on='regulator-always-on' in props))
result['packaged_vendor_boot'] = dict(sha256=hashlib.sha256(image).hexdigest(), usb_rails=rails,
                                      note='Packaged image inspected; no new live partition readback in this audit')
(out / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
for item in results + dtresults:
    print(item)
print('pm8550b.dtsi identical:', pmic_equal)
print('Packaged DTB USB rails:', rails)

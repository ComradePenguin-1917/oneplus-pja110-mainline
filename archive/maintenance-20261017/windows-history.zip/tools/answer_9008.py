#!/usr/bin/env python3
"""Answer the 9008 question properly, and surface the variant that avoids its
biggest flaw.

Can 9008 read our kernel's log out of RAM?
------------------------------------------
Reads are possible in principle: the bkerler/edl tool implements
    edl peek <addr> <len> <file>     read physical memory
    edl memorydump                   0x900E-mode memory dump
and its README states it has been tested on OnePlus/OPPO SM8550 devices.

But four prerequisites, and one of them is a real risk:

  a) our kernel wrote the log into DRAM                          -- likely
  b) entering 9008 does NOT retrain DDR                          -- THE RISK
  c) the SM8550 programmer allows peek/memorydump                -- unknown
  d) such a programmer is obtainable                             -- unknown
  e) the tool can drive raw USB to 9008 on Windows (UsbDk)       -- installable

(b) is the killer: 9008 entry re-runs the PBL, which normally initialises DDR,
wiping DRAM. So the log would be gone before we could read it.

The variant that sidesteps (b) entirely
---------------------------------------
Put the log in FLASH, not RAM. Then nothing about DDR matters.

Mainline has a facility for exactly this: PSTORE_BLK writes kernel log records
directly to a block device from KERNEL SPACE -- no userspace, no /init, no
drivers beyond the storage controller, and it works from panic context.

Our kernel already has:
    our DTB: /soc@0/ufshc@1d84000 status = "okay"   (UFS enabled by us)
and we can enable CONFIG_PSTORE_BLK.

If mainline's ufs-qcom binds on this device, pstore_blk could write our kernel's
panic into a scratch partition, and we would read it later from Android or from
fastboot -- with no cable, no 9008, and no DDR concerns.

Check whether that path is actually available to us.
"""
import os
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'

print('=' * 78)
print('ANSWER: can 9008 be used to read logs?')
print('=' * 78)
print('  In principle yes -- edl peek / edl memorydump read physical memory, and')
print('  the tool has been used on SM8550 OnePlus/OPPO hardware.')
print()
print('  In practice it is BLOCKED for us by one thing above all:')
print()
print('     entering 9008 normally re-runs the PBL, which initialises DDR,')
print('     ERASING the DRAM that holds our kernel log.')
print()
print('  Plus we do not have a firehose programmer for this device (checked: the')
print('  OTA payload ships xbl/abl/uefi/boot/vendor_boot/dtbo/logfs, no programmer),')
print('  and production programmers often refuse the peek commands anyway.')
print()
print('  => 9008 is a maybe, gated on things we cannot verify without hardware.')
print('     Not something to build on now.')

print()
print('=' * 78)
print('THE VARIANT THAT REMOVES THE BLOCKER: log to FLASH, not RAM')
print('=' * 78)
cfg = os.path.join(WS, 'out', 'config-6.14-xigua')
vals = {}
if os.path.exists(cfg):
    for l in open(cfg, encoding='utf-8', errors='replace'):
        l = l.strip()
        if '=' in l and not l.startswith('#'):
            a, b = l.split('=', 1)
            vals[a] = b
        elif l.startswith('# ') and 'is not set' in l:
            vals[l[2:].split(' ')[0]] = 'NOT SET'

print('  PSTORE_BLK writes kernel records to a block device FROM KERNEL SPACE:')
print('    no userspace, no /init, no USB -- works from panic context')
print()
for k in ('CONFIG_PSTORE_BLK', 'CONFIG_PSTORE', 'CONFIG_PSTORE_RAM',
          'CONFIG_PSTORE_CONSOLE', 'CONFIG_PSTORE_DEFLATE_COMPRESS',
          'CONFIG_PSTORE_ZONE', 'CONFIG_SCSI_UFS_QCOM', 'CONFIG_SCSI_UFSHCD',
          'CONFIG_BLK_DEV', 'CONFIG_SCSI'):
    print('  %-36s %s' % (k, vals.get(k, '(absent)')))

print()
print('  our DTB UFS state (needed for any block device at all):')
sys.path.insert(0, os.path.join(WS, 'tools'))
from fdt import FDT
ours = FDT(open(os.path.join(WS, 'dts', 'sm8550-oneplus-xigua-16G.dtb'), 'rb').read()).nodes()
for p in sorted(ours):
    if 'ufshc' in p.lower() and p.count('/') <= 3:
        c = ours[p].get('compatible', b'')
        st = ours[p].get('status', b'')
        print('    %s' % p)
        print('      compatible: %s' % c.rstrip(b'\0').decode('ascii', 'replace').replace('\0', ' | '))
        print('      status    : %s' % st.rstrip(b'\0').decode('ascii', 'replace'))

print()
print('=' * 78)
print('CANDIDATE SCRATCH PARTITIONS (we have backups of all of these)')
print('=' * 78)
for name, size in (('misc', 1048576), ('logfs', 8388608), ('xbl_sc_logs', 131072),
                   ('logdump', 536870912), ('rawdump', 268435456)):
    print('  %-14s %10d bytes (%.1f MiB)' % (name, size, size / 2**20))
print()
print('  logfs is the natural home: 8 MiB, ABL reports it unsupported for ITS own')
print('  logging ("LogFs sync skipped"), so it is idle, and it is fully backed up.')

print()
print('=' * 78)
print('HONEST CAVEAT')
print('=' * 78)
print('  pstore_blk only helps if our kernel gets far enough to bring up UFS and')
print('  register the pstore backend. If our kernel dies in the first few hundred')
print('  lines (setup_arch, memory map, CPU bring-up), nothing reaches pstore.')
print()
print('  Evidence the failure may indeed be that early: we have NEVER seen any')
print('  output from our kernel by any channel, including ones that would work')
print('  quite early.')
print()
print('  So pstore_blk is worth enabling as cheap insurance, but it is NOT a')
print('  guaranteed fix for "kernel dies before any logging exists".')
print()
print('  The only channel that covers the very first instructions is a UART.')

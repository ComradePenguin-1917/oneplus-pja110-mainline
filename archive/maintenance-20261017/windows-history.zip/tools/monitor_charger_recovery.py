"""Unprivileged observation after the single charger-enable cycle."""
from pathlib import Path
import subprocess
import time
from prepare_native_install import SSH

args = SSH[:]
args[-1] = 'penguin@172.16.42.1'
args = [x if not x.startswith('UserKnownHostsFile=') else
        'UserKnownHostsFile=out/native-install-20261017/known_hosts' for x in args]
cmd = '''set -eu
for i in $(seq 1 37); do
 printf 'SAMPLE '
 cut -d ' ' -f 1 /proc/uptime
 for p in bq28z610-0 qcom-battmgr-usb; do
  printf '%s ' "$p"
  for n in status capacity charge_now voltage_now current_now temp online; do
   f=/sys/class/power_supply/$p/$n
   if [ -r "$f" ]; then printf '%s=' "$n"; tr '\\n' ' ' < "$f"; fi
  done
  echo
 done
 [ "$i" = 37 ] || sleep 5
done
'''
out = Path('out/native-install-20261017/charger-enable-cycle')
dest = out / ('trend-' + time.strftime('%Y%m%d-%H%M%S') + '.txt')
with dest.open('w', encoding='utf-8') as f:
    p = subprocess.Popen(args + [cmd], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                         text=True, encoding='utf-8', errors='replace')
    try:
        for line in p.stdout:
            f.write(line)
            f.flush()
            print(line, end='', flush=True)
        code = p.wait(timeout=10)
    finally:
        if p.poll() is None:
            p.kill()
print('Saved:', dest)
if code:
    raise SystemExit(code)

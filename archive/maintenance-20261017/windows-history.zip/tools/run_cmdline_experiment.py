"""Record preflight evidence for the authorized B-slot boot experiment."""
import gzip
import hashlib
import json
import pathlib
import struct
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
DEST = ROOT / 'out' / 'cmdline-experiment-20261012'
DEST.mkdir(exist_ok=True)
ADB = r'C:\platform-tools\adb.exe'
SERIAL = 'bc7a542e'

def adb(*args):
    return subprocess.run([ADB, '-s', SERIAL, *args], capture_output=True, check=True, timeout=120).stdout

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    status = adb('shell', "su -c 'getprop ro.boot.slot_suffix; getprop sys.boot_completed; cat /proc/version; cat /proc/cmdline; sha256sum /dev/block/by-name/boot_a /dev/block/by-name/boot_b /dev/block/by-name/vendor_boot_b /dev/block/by-name/dtbo_b /dev/block/by-name/init_boot_b'")
    (DEST / 'preflight-device.txt').write_bytes(status)
    assert status.decode().splitlines()[:2] == ['_a', '1'], 'expected healthy slot A'
    hashes = {}
    for line in status.decode().splitlines():
        if '/dev/block/by-name/' in line:
            digest, path = line.split()
            hashes[path.rsplit('/', 1)[1]] = digest
    for part in ('vendor_boot_b', 'dtbo_b', 'init_boot_b'):
        assert sha((ROOT / 'backup' / (part + '.img')).read_bytes()) == hashes[part], part
    snapshot = DEST / 'boot_b-before.img'
    if not snapshot.exists():
        with snapshot.open('wb') as out:
            p = subprocess.run([ADB, '-s', SERIAL, 'exec-out', 'su', '-c', 'cat /dev/block/by-name/boot_b'], stdout=out, stderr=subprocess.PIPE, timeout=120)
            assert p.returncode == 0, p.stderr
    assert snapshot.stat().st_size == 201326592
    assert sha(snapshot.read_bytes()) == hashes['boot_b'], 'backup mismatch'
    old = (ROOT / 'out/Image-poweroff').read_bytes()
    new = (ROOT / 'out/Image-poweroff-norootcmdline').read_bytes()
    original = (b'console=tty0 root=PARTLABEL=win rootwait keep_bootcon quiet splash '
                b'allow_mismatched_32bit_el0 ignore_loglevel')
    replacement = b'console=ttyMSM0,115200 loglevel=8 earlycon ignore_loglevel'
    count = old.count(original)
    assert count > 0
    assert new == old.replace(original, replacement + b'\0' * (len(original)-len(replacement)))
    boot = (ROOT / 'out/boot_b-norootcmdline.img').read_bytes()
    assert boot[:8] == b'ANDROID!'
    assert struct.unpack_from('<I', boot, 8)[0] == len(new)
    assert boot[4096:4096+len(new)] == new
    archive = (ROOT / 'initramfs/initramfs.cpio.gz').read_bytes()
    assert archive in new, 'embedded archive differs'
    cpio = gzip.decompress(archive)
    assert b'NO USB: /init RAN' in cpio
    assert b'poweroff -f' in cpio
    evidence = {'partition_hashes_before': hashes, 'boot_image_sha256': sha(boot),
                'kernel_sha256': sha(new), 'embedded_archive_sha256': sha(archive),
                'commandline_replacement_count': count,
                'vendor_boot_test_sha256': sha((ROOT / 'out/vendor_boot_b-ourdtb.img').read_bytes())}
    (DEST / 'preflight.json').write_text(json.dumps(evidence, indent=2), encoding='utf-8')
    print(json.dumps(evidence, indent=2))
    print('Preflight PASS; current B boot backed up byte-for-byte.')

if __name__ == '__main__':
    main()

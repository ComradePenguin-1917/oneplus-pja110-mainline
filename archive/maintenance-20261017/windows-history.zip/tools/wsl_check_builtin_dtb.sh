#!/bin/bash
# Two decisive checks.
#
# A) Can the kernel be built with a BUILT-IN DTB on arm64? If yes, we can make
#    the kernel use OUR device tree regardless of what ABL supplies, which fixes
#    the whole compatible-mismatch problem with one config option.
#
# B) Confirm the mismatch is fatal in the way we think (gcc/pinctrl/uart/usb),
#    and identify what still works -- because anything that still works is an
#    observability channel.
set -uo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
TREE="$ROOT/linux"
cd "$TREE"

echo "############ A) BUILTIN_DTB support ############"
echo "--- drivers/of/Kconfig: BUILTIN_DTB ---"
grep -n -B2 -A12 'config BUILTIN_DTB' drivers/of/Kconfig 2>/dev/null
echo
echo "--- who selects it? (arches) ---"
grep -rn 'select BUILTIN_DTB\|BUILTIN_DTB' arch/arm64/Kconfig arch/arm64/Kconfig.platforms 2>/dev/null || echo "  arm64 does NOT reference BUILTIN_DTB"
echo
echo "--- does arm64 reference it anywhere? ---"
grep -rn 'BUILTIN_DTB' arch/arm64/ 2>/dev/null | head
echo
echo "--- current value in our .config ---"
grep -E 'BUILTIN_DTB' .config || echo "  (not set / not offered)"

echo
echo "############ B) what breaks with the vendor DTB ############"
echo "--- mainline clk driver compatibles for sm8550 ---"
grep -n 'qcom,sm8550-gcc\|qcom,sm8550-tcsr\|qcom,sm8550-dispcc\|qcom,sm8550-gpucc' \
     drivers/clk/qcom/gcc-sm8550.c 2>/dev/null | head -6
echo
echo "--- mainline pinctrl compatible ---"
grep -n 'qcom,sm8550-tlmm' drivers/pinctrl/qcom/pinctrl-sm8550.c 2>/dev/null | head -3
echo
echo "--- would the GENI UART even get a chance? ---"
grep -n 'qcom,geni-debug-uart\|qcom,geni-uart' drivers/tty/serial/qcom_geni_serial.c 2>/dev/null | head -5
echo "  (the vendor DTB's serial node compatible:)"
python3 - <<'PY'
import sys
sys.path.insert(0,'/mnt/h/WorkSpace/PJA110-Mainline/tools')
from fdt import FDT
f=FDT(open('/mnt/h/WorkSpace/PJA110-Mainline/live-from-device.dtb','rb').read())
n=f.nodes()
def dec(v): return v.rstrip(b'\0').decode('ascii','replace')
for p,props in sorted(n.items()):
    if 'serial' in p or 'qup_uart' in p:
        c=props.get('compatible')
        if c and p.count('/')<=5:
            print('  %-58s %s' % (p[:58], dec(c).replace('\0',' | ')))
PY

echo
echo "############ C) the vendor kernel IS 5.15 Android: does it have psci at /soc? ############"
python3 - <<'PY'
import sys
sys.path.insert(0,'/mnt/h/WorkSpace/PJA110-Mainline/tools')
from fdt import FDT
f=FDT(open('/mnt/h/WorkSpace/PJA110-Mainline/live-from-device.dtb','rb').read())
n=f.nodes()
print('  /psci          :', '/psci' in n)
print('  /soc/psci      :', '/soc/psci' in n)
if '/soc/psci' in n:
    for k,v in sorted(n['/soc/psci'].items()):
        print('     %-16s %s' % (k, v.rstrip(b'\0').decode('ascii','replace') if v else '(bool)'))
# does the kernel search the whole tree for psci? (it does: of_find_matching_node)
print()
print('  => both DTs provide PSCI; conduit is smc in both. PSCI is NOT the problem.')
PY

$ErrorActionPreference = 'Stop'
$phoneDevices = @(Get-CimInstance Win32_NetworkAdapter | Where-Object {
    $_.PNPDeviceID -match '^USB\\VID_1D6B&PID_0103&MI_00\\' -and $_.NetEnabled
})
if ($phoneDevices.Count -ne 1) { throw 'Expected one connected native developer-mode NCM adapter' }
$phoneAdapter = Get-NetAdapter -InterfaceIndex $phoneDevices[0].InterfaceIndex
if ($phoneAdapter.InterfaceDescription -notmatch '^UsbNcm Host Device') { throw 'Unexpected NCM driver' }
if ($phoneAdapter.MacAddress -ne '7A-46-56-01-21-70') { throw 'Phone MAC changed; inspect before configuring' }
$conflicts = @(Get-NetRoute -AddressFamily IPv4 | Where-Object {
    $_.DestinationPrefix -eq '172.16.42.0/24' -and $_.InterfaceIndex -ne $phoneAdapter.ifIndex
})
if ($conflicts.Count) { throw 'Phone subnet conflicts with another interface' }
$current = @(Get-NetIPAddress -InterfaceIndex $phoneAdapter.ifIndex -AddressFamily IPv4)
if (-not ($current | Where-Object IPAddress -eq '172.16.42.2')) {
    New-NetIPAddress -InterfaceIndex $phoneAdapter.ifIndex -IPAddress 172.16.42.2 -PrefixLength 24 -PolicyStore ActiveStore | Out-Null
}
Get-NetIPAddress -InterfaceIndex $phoneAdapter.ifIndex -AddressFamily IPv4 |
    Select-Object IPAddress,PrefixLength,InterfaceAlias |
    ConvertTo-Json | Set-Content -Encoding UTF8 (Join-Path $PSScriptRoot '../out/native-install-20261016/first-native-boot/developer-ncm-address.json')

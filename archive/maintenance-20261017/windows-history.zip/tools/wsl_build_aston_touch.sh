#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
EXPERIMENT="${1:-aston-touch-20261013}"
SOURCE_DIR=synaptics-aston
if [ "$EXPERIMENT" = aston-touch-240hz-20261013 ]; then SOURCE_DIR=synaptics-aston-rate; fi
OUT="$WIN/out/$EXPERIMENT"
TREE="$ROOT/linux"
BUILD="$ROOT/aston-touch-module-20261013"
export PATH="$ROOT/toolchain/gcc-12-aarch64/usr/bin:$PATH"
export LD_LIBRARY_PATH="$ROOT/toolchain/gcc-12-aarch64/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu-
mkdir -p "$BUILD"
cmp "$TREE/.config" "$WIN/out/display-port-20261013/kernel.config"
sha256sum "$TREE/.config" "$TREE/arch/arm64/boot/Image" > "$OUT/build-before.sha256"
cp "$WIN/drivers/input/touchscreen/$SOURCE_DIR/"* "$BUILD/"
make -C "$TREE" M="$BUILD" KBUILD_EXTRA_SYMBOLS="$TREE/vmlinux.symvers" -j4 modules > "$OUT/build.log" 2>&1
cp "$BUILD/synaptics-aston.ko" "$OUT/"
# Diagnostic viewer remains a test tool, never a production input policy.
sed 's/!strcmp(name,"PJA110 Synaptics S3910")/!strcmp(name,"PJA110 Synaptics S3910 (Aston TCM)")/' "$WIN/tools/mainline_touch_capture.c" > "$BUILD/touch-capture-aston.c"
aarch64-linux-gnu-gcc -static -no-pie -O2 -Wall -Wextra "$BUILD/touch-capture-aston.c" -o "$OUT/touch-capture-aston"
sha256sum -c "$OUT/build-before.sha256"
echo 'PASS: adapted Aston TCM compiled; #14 Image/config unchanged'

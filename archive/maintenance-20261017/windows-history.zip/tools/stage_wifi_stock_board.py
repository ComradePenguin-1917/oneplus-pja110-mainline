"""Stage OEM-selected board ELF and regdb for existing upstream ath12k."""
from pathlib import Path
import hashlib
import json
import subprocess
from prepare_native_install import SSH

out = Path('out/wifi-bringup-20261017')
args = SSH[:]
args[-1] = 'penguin@172.16.42.1'
args = [x if not x.startswith('UserKnownHostsFile=') else
        'UserKnownHostsFile=out/native-install-20261017/known_hosts' for x in args]
remote = '/home/penguin/wifi-bringup/stock-board'

def run(cmd, data=None):
    p = subprocess.run(args + [cmd], input=data, capture_output=True, timeout=35)
    print(p.stdout.decode(errors='replace'), end='')
    print(p.stderr.decode(errors='replace'), end='')
    p.check_returncode()
    return p.stdout

identity = run('cat /proc/cmdline; journalctl -b -k --no-pager | grep "chip_id 0x"; '
               'ls /usr/lib/firmware/ath12k/WCN7850/hw2.0; sudo -n true 2>/dev/null && echo ADMIN_AVAILABLE || true')
assert b'oplusboot.prjname=22851' in identity
assert b'chip_id 0x2 chip_family 0x4 board_id 0xff soc_id 0x40170200' in identity
# OEM qmi.c: chip 2 does not have GF mask 0x10. Project 22851 is neither
# region-specific (22861..22864/23861) nor second-BDF project 22811.
# Therefore board_id 0xff selects bdwlan.elf, not an arbitrary numbered variant.
files = {'board.bin': (out / 'stock-kiwi/bdwlan.elf').read_bytes(),
         'regdb.bin': (out / 'stock-kiwi/regdb.bin').read_bytes()}
assert files['board.bin'].startswith(b'\x7fELF')
checks = ''.join(hashlib.sha256(data).hexdigest() + '  ' + name + '\n' for name, data in files.items())
script = '''#!/bin/sh
set -eu
test "$(id -u)" = 0
test "$(uname -r)" = 6.14.0-oneplus-xigua
grep -q 'oplusboot.prjname=22851' /proc/cmdline
journalctl -b -k --no-pager | grep -q 'chip_id 0x2 chip_family 0x4 board_id 0xff soc_id 0x40170200'
cd /home/penguin/wifi-bringup/stock-board
sha256sum -c files.sha256
dest=/usr/lib/firmware/ath12k/WCN7850/hw2.0
# Leave board-2 selection disabled: use this phone's OEM-selected board ELF.
test ! -e "$dest/board-2.bin"
for f in board.bin regdb.bin; do
 if [ -e "$dest/$f" ] && ! cmp -s "$f" "$dest/$f"; then
  echo "Different existing $dest/$f; not overwritten"; exit 1
 fi
done
for f in board.bin regdb.bin; do install -D -m 644 "$f" "$dest/$f"; done
for f in board.bin regdb.bin; do cmp "$f" "$dest/$f"; done
echo 'OEM board ELF and regdb installed; rebooting to avoid the QMI-failure unload cleanup defect'
sync
systemctl reboot
'''
(out / 'install-stock-board.sh').write_bytes(script.encode())
files['files.sha256'] = checks.encode()
files['install.sh'] = script.encode()
run(f'mkdir -p {remote}')
for name, data in files.items():
    run(f'cat > {remote}/{name}', data)
run(f'cd {remote}; sha256sum -c files.sha256; sh -n install.sh')
report = dict(project=22851, chip_id=2, board_id=255, board_file='stock-kiwi/bdwlan.elf',
              driver='upstream ath12k API1 board.bin; native ELF detection',
              hashes={k: hashlib.sha256(v).hexdigest() for k, v in files.items()},
              phone_staged=True, phone_installed=False)
(out / 'stock-board-candidate.json').write_text(json.dumps(report, indent=2) + '\n')
print('Root command: sudo sh ' + remote + '/install.sh')

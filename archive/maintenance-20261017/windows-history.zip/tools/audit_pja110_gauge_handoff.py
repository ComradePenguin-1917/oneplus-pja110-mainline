"""Check cached OEM gauge ownership and initialization evidence."""
from pathlib import Path
import hashlib, json
root = Path(__file__).resolve().parents[1]
cache = root / 'out/battery-bringup-20261016'
board = (cache / 'oplus-chg-22851.dtsi').read_text()
driver = (cache / 'charger-source/oplus_battery_sm8550.c').read_text()
assert 'oplus,adsp_chg_use_ap_gauge;' in board
assert 'qcom,voocphy_support = <2>;' in board
probe = driver[driver.index('static int battery_chg_probe('):]
assert 'oplus_ap_init_adsp_gague();' in probe
assert 'oplus_adsp_voocphy_set_match_temp();' in probe
candidate = (root / 'drivers/power/supply/qcom_battmgr.c').read_text()
assert 'ret = pja110_ap_gauge_check(b->dev);' in candidate
assert 'b->status.voltage_now < 6000000' not in candidate
out = root / 'out/native-install-20261017/charger-init-candidate'
module = out / 'qcom_battmgr-ap-gauge.ko'
captures = sorted((out.parent / 'smem-project').glob('live-*.txt'))
runtime = None
if captures:
    capture = captures[-1]
    lines = capture.read_text(errors='replace').splitlines()
    fields = dict(line.split('=', 1) for line in lines if '=' in line)
    if all(key in fields for key in ('item_size', 'version', 'project')):
        runtime = dict(capture=str(capture), boot_id=lines[1],
                       item_size=int(fields['item_size']),
                       version=int(fields['version']), project=int(fields['project']))
report = dict(board_uses_ap_gauge=True, board_voocphy_support=2,
    factory_probe_sends_gauge_init=True, factory_probe_sends_match_temp=True,
    gauge_init_property=38, match_temp_property=29,
    runtime_smem_project_verified=runtime is not None, runtime_smem=runtime,
    runtime_project_matches_22851=runtime is not None and runtime['project'] == 22851,
    candidate_checks_ap_bq_power_supply=True,
    module_sha256=hashlib.sha256(module.read_bytes()).hexdigest(),
    candidate_live_loaded=False, charging_writes_executed=False)
(out / 'gauge-handoff-audit.json').write_bytes(json.dumps(report, indent=2).encode())
print(json.dumps(report, indent=2))

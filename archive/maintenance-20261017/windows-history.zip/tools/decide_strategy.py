#!/usr/bin/env python3
"""Decide between the two viable ways to get OUR device tree into the kernel.

Constraints established by experiment:
  * ABL uses vendor_boot entry0 as the BASE tree            (PROVEN)
  * the vendor dtbo is then applied as OVERLAYS on top of it
  * those overlays ENABLE UFS/PHY/sdhci, so removing them bricks the boot
  * so the overlays must keep working, which needs their 168 labels to resolve

Option 1 -- surgical: keep the vendor tree, prepend mainline `compatible` strings
           to the handful of nodes mainline must drive.
Option 2 -- swap:     install OUR tree, and additionally export every label the
           overlays need, pointing at inert placeholder nodes, so the overlays
           apply harmlessly while our real devices keep mainline bindings.

This script gathers the facts needed to choose, i.e. what the overlays would DO
to each label:

  * for labels our tree ALREADY exports -> the overlay would write into a REAL
    node of ours. That is the dangerous case, so list the properties it writes.
  * for labels our tree does NOT export -> we can point them at inert dummies.
"""
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fdt import FDT, load_entries

WS = r'H:\WorkSpace\PJA110-Mainline'


def dec(v):
    return v.rstrip(b'\0').decode('ascii', 'replace')


def depth(p):
    return len([s for s in p.split('/') if s])


# vendor base tree + its symbols
v = open(os.path.join(WS, 'backup', 'vendor_boot_b.img'), 'rb').read()
hsize, dtbsize = struct.unpack_from('<2I', v, 28+2048+4+16)
vrsize = struct.unpack_from('<I', v, 24)[0]
dtb_off = (((hsize+4095)//4096)*4096 + vrsize + 4095)//4096*4096
e0 = struct.unpack_from('>I', v, dtb_off+4)[0]
base = FDT(v[dtb_off:dtb_off+e0]).nodes()
base_syms = base.get('/__symbols__', {})

ours = FDT(open(os.path.join(WS, 'dts', 'sm8550-oneplus-xigua-16G.dtb'), 'rb').read()).nodes()
our_syms = set(ours.get('/__symbols__', {}))

entries, _ = load_entries(os.path.join(WS, 'dtbo-A14.img'))

# Map: label -> set of (properties the overlay writes on the target node)
print('=' * 78)
print('WHAT EACH OVERLAY FRAGMENT WRITES, KEYED BY ITS TARGET LABEL')
print('=' * 78)

label_actions = {}   # label -> list of (fragment, props written on target)
for ent_label, sub in entries:
    f = FDT(sub)
    n = f.nodes()
    fixups = n.get('/__fixups__', {})
    # each fragment's target is a placeholder; the fixup entry names the label
    # and where the placeholder sits. So fragment@K 'target' == some label.
    # Recover the mapping by matching the fixup value offsets to fragment target
    # offsets is fiddly; instead use fragment order vs fixup order, which for
    # dtc-generated overlays is 1:1 in practice. Verify by count.
    frags = sorted([p for p in n if depth(p) == 1 and p.lstrip('/').startswith('fragment@')],
                   key=lambda x: int(x.split('@')[1]))
    fx = sorted(fixups.items(), key=lambda kv: kv[1][:4])
    if len(frags) != len(fx):
        # fall back: no reliable mapping, just record the labels
        pass

    for p in frags:
        ov = p + '/__overlay__'
        if ov not in n:
            continue
        # properties written directly on the TARGET node
        props = sorted(k for k in n[ov])
        # subnodes the overlay creates under the target
        subs = [q for q in n if q.startswith(ov + '/') and depth(q) == depth(ov) + 1]
        if props or subs:
            label_actions.setdefault(p, []).append((ent_label, props, len(subs)))

print('  (fragment-level; resolved to labels below)')

# Build the reliable mapping the proper way: a fixup value is
# "<label>\0<offset bytes>" where the offset is where target=0xffffffff sits.
print()
print('=' * 78)
print('RESOLVE: which labels does the overlay NEED, and what does it write?')
print('=' * 78)

# Simpler and sufficient: list every label the overlays reference, the node the
# VENDOR tree binds it to, and whether OUR tree has a node at that same path.
needed = {}
for ent_label, sub in entries:
    f = FDT(sub)
    n = f.nodes()
    for lab in n.get('/__fixups__', {}):
        needed.setdefault(lab, set()).add(ent_label)

print('  labels referenced by the overlays: %d' % len(needed))
shared = sorted(l for l in needed if l in our_syms)
missing = sorted(l for l in needed if l not in our_syms)
print('  already exported by OUR tree     : %d' % len(shared))
print('  missing from OUR tree            : %d' % len(missing))

print()
print('--- SHARED labels (overlay would write into a REAL node of ours) ---')
for lab in shared:
    tgt = base_syms.get(lab)
    tp = dec(tgt) if tgt else '(?)'
    # does our tree have a node at that path?
    ours_here = tp in ours
    print('    %-22s vendor-> %-46s our-node@path: %s'
          % (lab[:22], tp[:46], 'YES' if ours_here else 'no'))

print()
print('--- MISSING labels: sample with their vendor targets ---')
for lab in missing[:25]:
    tgt = base_syms.get(lab)
    tp = dec(tgt) if tgt else '(not in vendor symbols)'
    print('    %-22s vendor-> %s' % (lab[:22], tp[:52]))
if len(missing) > 25:
    print('    ... and %d more' % (len(missing) - 25))

print()
print('=' * 78)
print('DECISION INPUT')
print('=' * 78)
print('  Shared labels are the risk for Option 2: an overlay writing into one of')
print('  our real nodes could disable it or change its bindings.')
print()
print('  Let us look at WHAT is written on the shared ones:')
allprops = set()
for ent_label, sub in entries:
    f = FDT(sub)
    n = f.nodes()
    for p in n:
        if p.endswith('/__overlay__'):
            for k in n[p]:
                allprops.add(k)
print('    distinct target properties across all overlays: %d' % len(allprops))
for k in ('status', 'compatible', 'reg', 'model'):
    print('      %-12s written by overlays: %s' % (k, k in allprops))

#!/bin/bash
# Correctly derive the busybox applet list and create ALL needed symlinks.
#
# Bug in the previous attempt: the regex only matched APPLET_NOEXEC( / APPLET_NOFORK(
# and missed plain APPLET(, so applets like sh, mount, cat, grep, sed, sleep
# never got symlinked. /bin/sh missing would mean the kernel cannot exec /init.
#
# applets.h lines look like:
#    IF_ASH(APPLET_NOEXEC(sh, sh, BB_DIR_BIN, BB_SUID_DROP, sh))
#    IF_MOUNT(APPLET(mount, BB_DIR_BIN, BB_SUID_DROP))
# so match APPLET followed by any optional suffix.
set -uo pipefail

ROOT="$HOME/workspace/PJA110-Mainline"
WORK="$ROOT/initramfs"
TREE="$WORK/tree"
BB="$WORK/dl/busybox-aarch64-static"
SRC="$WORK/dl/busybox-1.36.1"

echo "=== 1) parse applet names from applets.h (all APPLET variants) ==="
APPLETS=$(grep -oE 'APPLET[_A-Z]*\([a-zA-Z0-9_]+' "$SRC/include/applets.h" \
          | sed -E 's/APPLET[_A-Z]*\(//' | sort -u)
echo "  total applets: $(echo "$APPLETS" | grep -c .)"

echo
echo "=== 2) check the applets /init needs ==="
NEED="sh mount umount mkdir rmdir ls cat echo sleep ip ifconfig telnetd
udhcpd dd dmesg grep sed awk uname setsid pwd ps free df
mknod chmod ln sync hostname more vi cut tr head tail wc
printf test true false kill env printenv"
FOUND=""
MISSING=""
for a in $NEED; do
    if echo "$APPLETS" | grep -qx "$a"; then FOUND="$FOUND $a"; else MISSING="$MISSING $a"; fi
done
echo "  found  ($(echo $FOUND | wc -w)):$FOUND"
echo "  missing($(echo $MISSING | wc -w)):$MISSING"

echo
echo "=== 3) create symlinks for EVERY applet (small, avoids future gaps) ==="
rm -f "$TREE"/bin/*
cp "$BB" "$TREE/bin/busybox"
chmod 755 "$TREE/bin/busybox"
n=0
for a in $APPLETS; do
    # skip names that would collide with our dirs or are not useful in initramfs
    case "$a" in
        busybox|init) continue ;;
    esac
    ln -sf busybox "$TREE/bin/$a" 2>/dev/null && n=$((n+1))
done
echo "  linked $n applets"

echo
echo "=== 4) assert the critical ones exist ==="
for a in sh mount cat grep sed sleep ip; do
    if [ -L "$TREE/bin/$a" ]; then
        echo "  ok      /bin/$a"
    else
        echo "  MISSING /bin/$a  <-- /init depends on this"
        ln -sf busybox "$TREE/bin/$a"
        echo "          forced it anyway"
    fi
done

echo
echo "=== 5) repack ==="
cd "$TREE"
find . -print0 | cpio --null -o --format=newc 2>/dev/null | gzip -9 > "$WORK/initramfs.cpio.gz"
zcat "$WORK/initramfs.cpio.gz" > /tmp/z.cpio
LIST=$(cpio -t < /tmp/z.cpio 2>/dev/null)
echo "  total entries   : $(echo "$LIST" | wc -l)"
for f in init bin/busybox bin/sh bin/mount bin/cat bin/grep bin/sed bin/sleep bin/ip bin/telnetd bin/udhcpd; do
    printf '  %-16s %s\n' "$f" "$(echo "$LIST" | grep -cx "$f")"
done
echo "  size            : $(stat -c%s "$WORK/initramfs.cpio.gz") bytes"
rm -f /tmp/z.cpio

cp "$WORK/initramfs.cpio.gz" /mnt/h/WorkSpace/PJA110-Mainline/initramfs/
echo
echo "packed -> initramfs/initramfs.cpio.gz"

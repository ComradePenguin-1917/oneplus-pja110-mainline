#!/bin/bash
# Install QEMU for aarch64 WITHOUT root, using the same rootless technique that
# worked for the aarch64 cross toolchain earlier in this project:
#
#     apt-get download <pkg>      # downloads a .deb, no privileges needed
#     dpkg-deb -x <deb> <dir>     # unpacks into a local prefix, no privileges
#
# Then run the binaries with LD_LIBRARY_PATH pointing at the unpacked libs.
#
# Why this is needed: `sudo` exists but requires a password I do not have, so
# `sudo apt-get install` can never work here. That was my earlier mistake.
set -uo pipefail

ROOT="$HOME/workspace/PJA110-Mainline"
PREFIX="$ROOT/toolchain/qemu"
DL="$PREFIX/debs"
SYS="$PREFIX/sysroot"

mkdir -p "$DL" "$SYS"

echo "=== 1) resolve the package set (qemu-system-arm pulls data + libs) ==="
cd "$DL"

# apt-get download resolves dependencies automatically into the cwd
echo "  downloading qemu-system-arm and its dependencies ..."
timeout 600 apt-get download qemu-system-arm 2>&1 | tail -5

echo
echo "  downloaded so far:"
ls -1 *.deb 2>/dev/null | sed 's/^/    /'

echo
echo "=== 2) apt-cache depends: what else does it need? ==="
apt-cache depends qemu-system-arm 2>/dev/null | head -30 | sed 's/^/  /'

echo
echo "=== 3) try to fetch the runtime deps that are not already installed ==="
# qemu-system-arm depends on qemu-system-common, qemu-system-data and shared libs.
# Download the ones we do not have system-wide, plus the common pieces.
for pkg in qemu-system-common qemu-system-data qemu-system-gui; do
    if dpkg -s "$pkg" >/dev/null 2>&1; then
        echo "  $pkg: already installed system-wide"
    else
        echo "  $pkg: downloading"
        timeout 300 apt-get download "$pkg" 2>&1 | tail -2
    fi
done

echo
echo "=== 4) unpack everything into the local prefix ==="
for d in *.deb; do
    [ -e "$d" ] || continue
    dpkg-deb -x "$d" "$SYS" 2>/dev/null && echo "  unpacked $d"
done

echo
echo "=== 5) locate the binary ==="
QEMU="$SYS/usr/bin/qemu-system-aarch64"
if [ -x "$QEMU" ]; then
    echo "  found: $QEMU"
    file "$QEMU" | sed 's/^/    /'
else
    echo "  NOT FOUND at $QEMU"
    find "$SYS" -name 'qemu-system*' -type f 2>/dev/null | head -10 | sed 's/^/    /'
fi

echo
echo "=== 6) what shared libraries does it want? ==="
if [ -x "$QEMU" ]; then
    ldd "$QEMU" 2>&1 | sed 's/^/    /'
fi

echo
echo "=== 7) try running it ==="
if [ -x "$QEMU" ]; then
    export LD_LIBRARY_PATH="$SYS/usr/lib/x86_64-linux-gnu:$SYS/lib/x86_64-linux-gnu:${LD_LIBRARY_PATH:-}"
    # qemu also needs its firmware/data dir
    export QEMU_DATADIR="$SYS/usr/share/qemu"
    "$QEMU" --version 2>&1 | head -3 | sed 's/^/    /'
    echo "  rc=$?"
fi

"""Ordinary reboot and compare persistent GPT state without any slot mutation."""
import subprocess,json,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'out/boot-success-20261014'
KEYS=ROOT/'out/usb-ncm-20261013/ssh'
SSH=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(KEYS/'client_key_host'),
 '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
 '-o',f'UserKnownHostsFile={KEYS/"known_hosts"}','-o','ConnectTimeout=3','root@169.254.42.1']
def remote(cmd):return subprocess.run(SSH+[cmd],capture_output=True,timeout=8)
before=remote('uname -a; cat /proc/sys/kernel/random/boot_id');before.check_returncode()
assert b'#18 SMP' in before.stdout
(OUT/'reboot-before.txt').write_bytes(before.stdout)
start=time.monotonic()
try:
 p=remote('sync; reboot -f');(OUT/'reboot-request.txt').write_bytes(p.stdout+p.stderr)
except subprocess.TimeoutExpired:pass
while time.monotonic()-start<100:
 time.sleep(3)
 try:p=remote('uname -a; cat /proc/sys/kernel/random/boot_id; cat /sys/module/synaptics_aston/parameters/report_rate_code; cat /sys/class/udc/*/state')
 except subprocess.TimeoutExpired:continue
 if p.returncode==0 and b'#18 SMP' in p.stdout and p.stdout.splitlines()[1]!=before.stdout.splitlines()[1]:
  (OUT/'reboot-after.txt').write_bytes(p.stdout)
  result=dict(same_kernel_18=True,boot_id_changed=True,automatic_ssh_returned=True,elapsed_seconds=round(time.monotonic()-start,2))
  (OUT/'reboot-result.json').write_text(json.dumps(result,indent=2)+'\n')
  print(json.dumps(result));break
else:raise SystemExit('SSH did not return within 100 seconds')
subprocess.run(['python',str(ROOT/'tools/inspect_boot_gpt.py'),'after-reboot'],check=True)
pre=json.loads((OUT/'after/gpt.json').read_text());post=json.loads((OUT/'after-reboot/gpt.json').read_text())
for a,b in zip(pre,post):
 for ca,cb in zip(a['copies'],b['copies']):
  assert cb['header_crc_valid'] and cb['table_crc_valid']
  if ca['entries']!=cb['entries']:
   assert a['device']=='sde' and ca['side']=='backup'
   differences=[(ea,eb) for ea,eb in zip(ca['entries'],cb['entries']) if ea!=eb]
   assert len(differences)==1
   ea,eb=differences[0]
   assert ea['name']==eb['name']=='boot_b' and ea['successful'] and eb['successful']
   assert ea['retry_count']==7 and eb['retry_count']==6
   assert int(ea['attributes'],16)^int(eb['attributes'],16)==1<<51
   assert eb==b['copies'][0]['entries'][eb['index']]
result.update(success_mark_persisted=True,retry_count_not_decremented=True,
              backup_retry_synced_to_primary=True)
(OUT/'reboot-result.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS: successful B mark persisted across real reboot; retries unchanged; A attributes unchanged')

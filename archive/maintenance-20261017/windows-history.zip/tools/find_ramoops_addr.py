#!/usr/bin/env python3
"""Find Android's ramoops address -- the key to a REAL early-boot observation channel.

The insight I had been missing
------------------------------
We have NO way to see our kernel's early output: no UART cable, and USB needs
drivers plus userspace. So "the phone showed nothing and fell back to Android"
is consistent with BOTH "our kernel died instantly" AND "our kernel ran fine but
was invisible". Every conclusion drawn from silence has been unsafe.

pstore/ramoops fixes this properly: the kernel writes printk/panic into a
reserved RAM window, and RAM is NOT cleared by a warm reset. The Android kernel
we fall back into then exposes the log at /sys/fs/pstore.

The catch: Android's ramoops uses `alloc-ranges`, so the address is chosen at
boot. If I can find the address Android actually uses, I can pin OUR DTB's
ramoops region to that SAME address. Then:
    1. boot our kernel
    2. it panics -> panic text lands at that address
    3. reboot into Android
    4. read /sys/fs/pstore -> we finally see why our kernel died

Find the address from the running system.
"""
import os
import re
import shutil
import subprocess
import sys

ADB = shutil.which('adb') or r'C:\platform-tools\adb.exe'
SERIAL = 'bc7a542e'


def root(cmd, timeout=300):
    r = subprocess.run([ADB, '-s', SERIAL, 'shell', "su -c '%s'" % cmd],
                       capture_output=True, timeout=timeout)
    return ((r.stdout or b'') + (r.stderr or b'')).decode('utf-8', 'replace')


def sh(cmd, timeout=300):
    r = subprocess.run([ADB, '-s', SERIAL, 'shell', cmd], capture_output=True, timeout=timeout)
    return ((r.stdout or b'') + (r.stderr or b'')).decode('utf-8', 'replace')


print('=' * 78)
print('1) ramoops module parameters (gives the RESOLVED address)')
print('=' * 78)
print(root('ls /sys/module/ramoops/parameters/ 2>&1'))
print()
for p in ('base', 'size', 'console_size', 'pmsg_size', 'record_size',
          'mem_address', 'mem_size', 'dump_oops', 'ecc'):
    v = root('cat /sys/module/ramoops/parameters/%s 2>/dev/null' % p).strip()
    if v:
        print('  %-16s %s' % (p, v))

print()
print('=' * 78)
print('2) does ramoops exist as a platform device, and at what address?')
print('=' * 78)
print('  /sys/bus/platform/drivers/ramoops:')
print(root('ls -l /sys/bus/platform/drivers/ramoops/ 2>&1').strip()[:600])

print()
print('  reserved-memory nodes in the LIVE tree with their reg:')
print(root('for n in /sys/firmware/devicetree/base/reserved-memory/*/; do '
           'b=$(basename $n); '
           'if [ -f "$n/reg" ]; then '
           'printf "%-46s " "$b"; '
           'od -An -tx1 -N16 "$n/reg" 2>/dev/null | tr -s " " | tr -d "\\n"; echo; '
           'fi; done 2>&1 | grep -i -E "ramoops|pstore"').strip()[:400])

print()
print('  effective dmesg lines about ramoops:')
print(sh('dmesg 2>/dev/null | grep -i ramoops | head -10').strip()[:700])

print()
print('=' * 78)
print('3) what is in pstore right now?')
print('=' * 78)
print(root('ls -la /sys/fs/pstore/ 2>&1').strip()[:400])

print()
print('=' * 78)
print('4) the mem-type and layout from the device tree')
print('=' * 78)
print(root('for f in compatible size console-size pmsg-size mem-type ecc-size; do '
           'printf "%-14s " $f; '
           'cat /sys/firmware/devicetree/base/reserved-memory/ramoops_region/$f 2>/dev/null | '
           'od -An -tx1 | tr -s " " | tr -d "\\n"; echo; done 2>&1').strip()[:600])

print()
print('=' * 78)
print('5) is there any leftover pstore data we could read?')
print('=' * 78)
print('  checking common pstore backends:')
for d in ('/sys/fs/pstore', '/dev/pstore', '/sys/kernel/debug/pstore'):
    print('    %-28s %s' % (d, root('ls -d %s 2>/dev/null && echo exists || echo missing' % d).strip()[:60]))

print()
print('  /proc/last_kmsg (legacy but sometimes present):')
print('   ', root('ls -l /proc/last_kmsg 2>&1').strip()[:120])

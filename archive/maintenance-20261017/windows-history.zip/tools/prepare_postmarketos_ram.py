"""Export only the ext4 root partition as a compressed, hashed RAM-test artifact."""
from pathlib import Path
import gzip
import hashlib
import json
import time
from pmos_image_info import inspect_image

source = Path('/tmp/postmarketOS-export/oneplus-xigua.img')
out = Path('/mnt/h/workspace/PJA110-Mainline/out/postmarketos-ram-20261015')
out.mkdir(exist_ok=True)
info = inspect_image(source)
root = next(p for p in info['partitions'] if p['label'] == 'pmOS_root')
destination = out/'rootfs.ext4.gz'
temporary = out/'rootfs.ext4.gz.partial'
remaining = root['sectors'] * info['sector_size']
raw_hash = hashlib.sha256()
start = time.monotonic()
with source.open('rb') as inp, temporary.open('wb') as raw_out:
    inp.seek(root['start'] * info['sector_size'])
    with gzip.GzipFile(filename='', mode='wb', compresslevel=1, fileobj=raw_out, mtime=0) as compressed:
        while remaining:
            block = inp.read(min(4*1024*1024, remaining))
            assert block, 'Unexpected end of source image'
            remaining -= len(block)
            raw_hash.update(block)
            compressed.write(block)
temporary.replace(destination)
compressed_hash = hashlib.sha256()
with destination.open('rb') as inp:
    for block in iter(lambda: inp.read(4*1024*1024), b''):
        compressed_hash.update(block)
record = {'image': info, 'artifact': destination.name, 'compressed_bytes': destination.stat().st_size,
          'raw_bytes': root['sectors'] * info['sector_size'], 'raw_sha256': raw_hash.hexdigest(),
          'compressed_sha256': compressed_hash.hexdigest(), 'phone_partitions_written': False}
(out/'ram-artifact.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record, indent=2))
print('Elapsed seconds:', round(time.monotonic()-start, 1))

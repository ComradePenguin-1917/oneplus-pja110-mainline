"""Use the host key obtained over ACM, then verify SSH commands and binary I/O."""
import hashlib
import json
import re
import secrets
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parents[1]
out = root / 'out/usb-ncm-20261013/ssh'
key_response = (out / 'host-key/control-Thread.txt').read_text(encoding='utf-8-sig')
public = re.search(r'(?m)^ssh-ed25519 ([A-Za-z0-9+/=]+)', key_response)
assert public, 'Host public key missing from serial evidence'
known = out / 'known_hosts'
known.write_text('169.254.42.1 ssh-ed25519 ' + public[1] + '\n')
command = ['C:/Windows/System32/OpenSSH/ssh.exe', '-F', 'none', '-T',
           '-i', str(out / 'client_key_host'), '-o', 'IdentitiesOnly=yes',
           '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes',
           '-o', f'UserKnownHostsFile={known}', '-o', 'ConnectTimeout=10',
           '-o', 'ServerAliveInterval=5', 'root@169.254.42.1']
def run(remote, data=None):
    completed = subprocess.run(command + [remote], input=data, capture_output=True, timeout=40)
    if completed.returncode:
        (out / 'ssh-error.txt').write_bytes(completed.stderr)
        raise RuntimeError(f'SSH failed ({completed.returncode}): {completed.stderr.decode(errors="replace")}')
    return completed.stdout
identity = run('uname -a; id; cat /proc/uptime; ip addr show usb0; cat /sys/class/udc/*/current_speed')
(out / 'ssh-identity.txt').write_bytes(identity)
assert b'6.14.0-sm8550-xigua-r1' in identity and b'uid=0' in identity
records = []
for r in range(1, 4):
    data = secrets.token_bytes(4194304)
    expected = hashlib.sha256(data).hexdigest()
    response = run('cat > /tmp/ncm-ssh-upload.bin; sha256sum /tmp/ncm-ssh-upload.bin', data)
    actual = response.decode().split()[0]
    returned = run('cat /tmp/ncm-ssh-upload.bin')
    digest = hashlib.sha256(returned).hexdigest()
    passed = actual == expected and returned == data and digest == expected
    records.append(dict(round=r, bytes=len(data), passed=passed,
                        expected_sha256=expected, phone_sha256=actual, readback_sha256=digest))
    (out / 'ssh-result.json').write_text(json.dumps(dict(identity_verified=True, transfers=records,
       all_passed=len(records)==3 and all(x['passed'] for x in records)), indent=2)+'\n')
    assert passed, 'SSH binary integrity mismatch'
    print(f'SSH round {r}: 4MiB upload and download passed', flush=True)
print(identity.decode())

#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
OUT="$WIN/out/pmbootstrap-wsl-probe-20261015"
COMMIT=cf5a8be496f02ac656c95db9a0d3f2d9f83cfb80
mkdir -p "$ROOT" "$OUT"
mkdir -p "$ROOT/pmbootstrap-work"
if [ ! -e "$ROOT/pmaports/.git" ]; then
 git init "$ROOT/pmaports" > "$OUT/pmaports-init.log" 2>&1
 git -C "$ROOT/pmaports" remote add origin https://gitlab.postmarketos.org/postmarketOS/pmaports.git
fi
if ! git -C "$ROOT/pmaports" cat-file -e "$COMMIT^{commit}" 2>/dev/null; then
 git -C "$ROOT/pmaports" fetch --depth=1 origin "$COMMIT" > "$OUT/pmaports-fetch.log" 2>&1
fi
git -C "$ROOT/pmaports" update-ref refs/remotes/origin/main "$COMMIT"
git -C "$ROOT/pmaports" checkout --detach "$COMMIT" > "$OUT/pmaports-checkout.log" 2>&1
for name in device-oneplus-xigua linux-oneplus-xigua firmware-oneplus-xigua-adreno; do
 test ! -e "$ROOT/pmaports/device/testing/$name/APKBUILD" || cmp "$WIN/postmarketos/device/testing/$name/APKBUILD" "$ROOT/pmaports/device/testing/$name/APKBUILD"
 cp -a "$WIN/postmarketos/device/testing/$name" "$ROOT/pmaports/device/testing/"
done
export PYTHONPATH="$OUT/python-deps${PYTHONPATH:+:$PYTHONPATH}"
cd "$ROOT/pmbootstrap"
python3 - "$ROOT" <<'PY'
import sys
from pathlib import Path
from pmb.core import Config
from pmb.config.file import save
import pmb.config
r=Path(sys.argv[1]); c=Config()
for k in ('aports','work','device','ui','user','hostname','extra_packages','ssh_keys','init','systemd'):
 if hasattr(c,k):print(k,repr(getattr(c,k)))
c.work=r/'pmbootstrap-work'
version_file=c.work/'version'
if not version_file.exists():
 assert not list(c.work.glob('chroot_*')), 'Existing chroots require official migration'
 version_file.write_text(str(pmb.config.work_version)+'\n')
 (c.work/'cache_git').mkdir(mode=0o700,exist_ok=True)
c.aports=r/'pmaports'
c.device='oneplus-xigua'
c.ui='phosh'
c.user='penguin'
c.hostname='pja110'
c.jobs=8
c.timezone='Asia/Shanghai'
c.ssh_keys=True
c.ssh_key_glob=str(Path('/mnt/h/workspace/PJA110-Mainline/out/usb-ncm-20261013/ssh/client_key_host.pub'))
c.mirrors['alpine']='https://dl-cdn.alpinelinux.org/'
c.mirrors['pmaports']='https://mirror.postmarketos.org/postmarketos/'
c.mirrors['systemd']='https://mirror.postmarketos.org/postmarketos/extra-repos/systemd/'
save(r/'pmbootstrap-pja110.cfg',c)
PY
python3 - "$ROOT" "$OUT" <<'PY'
import sys,json
from pathlib import Path
import pmb.parse
from pmb.config.file import load
from pmb.core.context import Context,set_context
from pmb.helpers import logging
r,out=map(Path,sys.argv[1:])
set_context(Context(load(r/'pmbootstrap-pja110.cfg')))
logging.add_verbose_log_level()
d=pmb.parse.deviceinfo('oneplus-xigua')
(out/'pmb-deviceinfo.txt').write_text(repr(d)+'\n')
records={name:pmb.parse.apkbuild(r/'pmaports/device/testing'/name/'APKBUILD') for name in ('device-oneplus-xigua','linux-oneplus-xigua','firmware-oneplus-xigua-adreno')}
(out/'pmb-apkbuilds.txt').write_text(json.dumps(records,indent=2,default=str)+'\n')
PY
python3 pmbootstrap.py -c "$ROOT/pmbootstrap-pja110.cfg" -p "$ROOT/pmaports" -w "$ROOT/pmbootstrap-work" status > "$OUT/pmb-status.txt" 2>&1
cat "$OUT/pmb-status.txt"
echo 'PASS: pinned full pmaports connected; pmbootstrap parses PJA110 packages'

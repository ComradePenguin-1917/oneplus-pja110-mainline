"""Back up logdump, test a bounded tail journal, reboot, then restore exactly."""
import hashlib
import json
import pathlib
import re
import subprocess
import struct
import sys
import time
import uuid
import zlib

import run_r1_flash_test as f

ROOT=f.ROOT
OUT=ROOT/(sys.argv[2] if len(sys.argv)>2 else 'out/logdump-experiment-20261012')
OUT.mkdir(exist_ok=True)
f.OUT=OUT
PART='/dev/block/by-name/logdump'
SIZE=536870912
JOURNAL=65536
OFFSET=SIZE-JOURNAL
REMOTE='/data/local/tmp/pja-logdump-journal.bin'

def root(cmd,timeout=120,binary=False):
    p=subprocess.run([f.ADB,'-s',f.SERIAL,'exec-out' if binary else 'shell',"su -c '"+cmd+"'"],capture_output=True,timeout=timeout)
    p.check_returncode()
    return p.stdout

def digest(data): return hashlib.sha256(data).hexdigest()

def tail(name):
    data=root(f'dd if={PART} bs=4096 skip={OFFSET//4096} count=16 2>/dev/null',binary=True)
    assert len(data)==JOURNAL
    (OUT/name).write_bytes(data)
    return data

def main(mode):
    if mode=='preflight':
        assert not (OUT/'preflight.json').exists()
        state,hashes=f.state('preflight-device')
        assert state==['_a','1']
        resolved=root('readlink -f '+PART).decode().strip()
        assert re.fullmatch(r'/dev/block/sd[a-z]+[0-9]+',resolved),resolved
        name=resolved.rsplit('/',1)[1]
        assert int(root('blockdev --getsize64 '+PART))==SIZE
        uevent=root('/system/bin/cat /sys/class/block/'+name+'/uevent').decode()
        (OUT/'partition-uevent.txt').write_text(uevent)
        info=dict(line.split('=',1) for line in uevent.splitlines() if '=' in line)
        assert info['PARTNAME']=='logdump'
        disk=re.sub(r'[0-9]+$','',resolved)
        sector=int(root('blockdev --getss '+disk))
        gpt=root(f'dd if={disk} bs=4096 count=16 2>/dev/null',binary=True)
        (OUT/'disk-primary-gpt.bin').write_bytes(gpt)
        header=bytearray(gpt[sector:sector+92])
        assert header[:8]==b'EFI PART'
        header_size,header_crc=struct.unpack_from('<II',header,12)
        header=bytearray(gpt[sector:sector+header_size])
        struct.pack_into('<I',header,16,0)
        assert zlib.crc32(header)==header_crc
        entry_lba,count,entry_size,entry_crc=struct.unpack_from('<QIII',header,72)
        table=gpt[entry_lba*sector:entry_lba*sector+count*entry_size]
        assert len(table)==count*entry_size and zlib.crc32(table)==entry_crc
        entries=[table[i*entry_size:(i+1)*entry_size] for i in range(count)]
        matches=[e for e in entries if e[56:128].decode('utf-16-le').rstrip('\0')=='logdump']
        assert len(matches)==1
        entry=matches[0]
        start,last=struct.unpack_from('<QQ',entry,32)
        assert (last-start+1)*sector==SIZE
        assert start*sector==int(root('cat /sys/class/block/'+name+'/start'))*512
        info['PARTUUID']=str(uuid.UUID(bytes_le=entry[16:32]))
        assert not root('ls -A /sys/class/block/'+name+'/holders').strip(),'active block holder'
        mounts=root('cat /proc/mounts').decode()
        (OUT/'mounts-before.txt').write_text(mounts)
        assert not any(resolved in l or '/by-name/logdump' in l for l in mounts.splitlines()),'mounted partition'
        current=root('sha256sum '+PART).decode().split()[0]
        backup=OUT/'logdump-before.img'
        print('Backing up full 512 MiB logdump before any write...',flush=True)
        with backup.open('wb') as dest:
            p=subprocess.run([f.ADB,'-s',f.SERIAL,'exec-out',"su -c 'cat "+PART+"'"],stdout=dest,stderr=subprocess.PIPE,timeout=120)
            p.check_returncode()
        assert backup.stat().st_size==SIZE and f.sha(backup)==current
        with backup.open('rb') as src:
            assert all(not any(block) for block in iter(lambda:src.read(1024*1024),b'')),'partition contains data; reassess target'
        before=tail('tail-before.bin')
        assert not any(before)
        marker='PJA110_LOGDUMP_CONTROL_'+uuid.uuid4().hex
        payload=(marker+'\nAndroid logdump tail retention control\n').encode().ljust(JOURNAL,b'\0')
        (OUT/'control-journal.bin').write_bytes(payload)
        bootid=root('cat /proc/sys/kernel/random/boot_id').decode().strip()
        for part,path in f.RESTORE.items():
            assert f.sha(path)==hashes[part],part
        pre={'target':PART,'resolved_device':resolved,'partition_uuid':info['PARTUUID'],'partition_size':SIZE,'journal_offset':OFFSET,'journal_bytes':JOURNAL,'whole_partition_sha256_before':current,'partition_hashes_before':hashes,'boot_id_before':bootid,'marker':marker,'control_journal_sha256':digest(payload)}
        (OUT/'preflight.json').write_text(json.dumps(pre,indent=2)+'\n')
        print(json.dumps(pre,indent=2))
    elif mode=='write-reboot':
        pre=json.loads((OUT/'preflight.json').read_text())
        assert not (OUT/'control-written.txt').exists()
        assert root('sha256sum '+PART).decode().split()[0]==pre['whole_partition_sha256_before']
        subprocess.run([f.ADB,'-s',f.SERIAL,'push',str(OUT/'control-journal.bin'),REMOTE],check=True,timeout=20)
        output=root(f'dd if={REMOTE} of={PART} bs=4096 seek={OFFSET//4096} count=16 conv=notrunc,fsync; sync')
        (OUT/'control-write-output.txt').write_bytes(output)
        assert digest(tail('tail-immediately-after-write.bin'))==pre['control_journal_sha256']
        (OUT/'control-written.txt').write_text(time.strftime('%Y-%m-%dT%H:%M:%S%z'))
        subprocess.run([f.ADB,'-s',f.SERIAL,'reboot'],check=True,timeout=15)
        start=time.monotonic()
        while time.monotonic()-start<120:
            try:
                p=subprocess.run([f.ADB,'-s',f.SERIAL,'shell','getprop ro.boot.slot_suffix; getprop sys.boot_completed; cat /proc/sys/kernel/random/boot_id'],capture_output=True,timeout=4)
                lines=p.stdout.decode().splitlines()
                if p.returncode==0 and len(lines)>=3 and lines[:2]==['_a','1'] and lines[2]!=pre['boot_id_before']:
                    print('New Android A boot completed.',flush=True)
                    return
            except subprocess.TimeoutExpired: pass
            time.sleep(1)
        raise RuntimeError('Android A did not return')
    elif mode=='collect':
        pre=json.loads((OUT/'preflight.json').read_text())
        status,hashes=f.state('after-control-device')
        assert status==['_a','1'] and hashes==pre['partition_hashes_before']
        data=tail('tail-after-control-reboot.bin')
        ok=digest(data)==pre['control_journal_sha256']
        result={'android_tail_marker_survived_reboot':ok,'boot_partition_hashes_unchanged':True,'mechanism_tested':'raw block tail journal, not pstore-blk or panic logging'}
        (OUT/'android-control-result.json').write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps(result,indent=2))
        assert ok,'marker did not survive'
    elif mode=='restore-journal':
        pre=json.loads((OUT/'preflight.json').read_text())
        assert f.sha(OUT/'logdump-before.img')==pre['whole_partition_sha256_before']
        subprocess.run([f.ADB,'-s',f.SERIAL,'push',str(OUT/'tail-before.bin'),REMOTE],check=True,timeout=15)
        root(f'dd if={REMOTE} of={PART} bs=4096 seek={OFFSET//4096} count=16 conv=notrunc,fsync; sync')
        actual=root('sha256sum '+PART).decode().split()[0]
        (OUT/'logdump-restored-sha256.txt').write_text(actual+'\n')
        assert actual==pre['whole_partition_sha256_before'],'partition outside journal changed; preserve evidence and reassess'
        root('rm -f '+REMOTE)
        print('PASS: full 512 MiB logdump hash restored to preflight value.')
    elif mode=='clear-for-mainline':
        pre=json.loads((OUT/'preflight.json').read_text())
        # The Android control must succeed before another writer uses this journal.
        assert json.loads((OUT/'android-control-result.json').read_text())['android_tail_marker_survived_reboot']
        subprocess.run([f.ADB,'-s',f.SERIAL,'push',str(OUT/'tail-before.bin'),REMOTE],check=True,timeout=15)
        root(f'dd if={REMOTE} of={PART} bs=4096 seek={OFFSET//4096} count=16 conv=notrunc,fsync; sync')
        assert root('sha256sum '+PART).decode().split()[0]==pre['whole_partition_sha256_before']
        print('Journal baseline cleared and full hash verified for mainline test.')
    elif mode=='collect-mainline':
        tail('tail-after-mainline.bin')
        f.state('after-mainline-device')
        data=(OUT/'tail-after-mainline.bin').read_bytes()
        print(json.dumps({'journal_all_zero':not any(data),'mainline_marker_present':b'PJA110_MAINLINE_FLASHLOG' in data}))
    elif mode=='write-sentinel':
        pre=json.loads((OUT/'preflight.json').read_text())
        assert root('sha256sum '+PART).decode().split()[0]==pre['whole_partition_sha256_before']
        sentinel=('PJA110_LOGDUMP_SENTINEL_'+uuid.uuid4().hex+'\n').encode().ljust(4096,b'\0')
        (OUT/'sentinel.bin').write_bytes(sentinel)
        subprocess.run([f.ADB,'-s',f.SERIAL,'push',str(OUT/'sentinel.bin'),REMOTE],check=True,timeout=15)
        root(f'dd if={REMOTE} of={PART} bs=4096 seek={SIZE//4096-1} count=1 conv=notrunc,fsync; sync')
        data=tail('tail-with-sentinel-before.bin')
        assert not any(data[:-4096]) and data[-4096:]==sentinel
        print('PASS: independent 4 KiB sentinel written; 60 KiB journal remains zero.')
    elif mode=='collect-sentinel':
        data=tail('tail-after-mainline-sentinel.bin')
        sentinel=(OUT/'sentinel.bin').read_bytes()
        result={'sentinel_survived_same_mainline_failure_path':data[-4096:]==sentinel,'mainline_journal_marker_present':b'PJA110_MAINLINE_FLASHLOG_20261012_R1' in data[:-4096],'mainline_journal_all_zero':not any(data[:-4096])}
        (OUT/'sentinel-test-result.json').write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps(result,indent=2))
    elif mode=='finalize':
        pre=json.loads((OUT/'preflight.json').read_text())
        status,hashes=f.state('restored-device')
        assert status==['_a','1'] and hashes==pre['partition_hashes_before']
        actual=root('sha256sum '+PART).decode().split()[0]
        assert actual==pre['whole_partition_sha256_before']
        sentinel=json.loads((OUT/'sentinel-test-result.json').read_text())
        result={'android_block_journal_retention_verified':True,'writer_positive_and_negative_controls_passed':True,'pstore_blk_enabled_or_tested':False,'mainline_journal_marker_present':sentinel['mainline_journal_marker_present'],'independent_sentinel_survived_mainline_failure_path':sentinel['sentinel_survived_same_mainline_failure_path'],'boot_stage_identified':False,'android_a_boot_completed':True,'all_eight_boot_partition_hashes_restored':True,'full_logdump_partition_hash_restored':True,'full_logdump_sha256':actual}
        (OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps(result,indent=2))
        task='/data/local/tmp/pja-flashlog-test'
        files=['bin/busybox','flashlog','dev/sde','dev/sde70','sys/sde70/partition','sys/sde70/size','sys/sde70/uevent','pja-flashlog.bin']
        root('rm -f /data/local/tmp/pja-logbusybox '+REMOTE+' '+' '.join(task+'/'+x for x in files))
        root('rmdir '+task+'/sys/sde70 '+task+'/sys '+task+'/dev '+task+'/bin '+task)
    else: raise ValueError(mode)

if __name__=='__main__': main(sys.argv[1])

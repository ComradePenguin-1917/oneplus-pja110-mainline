#!/usr/bin/env python3
"""Analyze the stock vendor_boot ramdisk table (encoding-safe)."""
import io
import os
import struct

WS = r'H:\WorkSpace\PJA110-Mainline'
PAGE = 4096
v = open(os.path.join(WS, 'vendor_boot-A14.img'), 'rb').read()
out = []


def p(s=''):
    out.append(str(s))


(hver, pagesz, kaddr, raddr) = struct.unpack_from('<4I', v, 8)
vrsize = struct.unpack_from('<I', v, 24)[0]
cmdline = v[28:28+2048].rstrip(b'\0')
hsize, dtbsize = struct.unpack_from('<2I', v, 28+2048+4+16)
dtbaddr = struct.unpack_from('<Q', v, 28+2048+4+16+8)[0]
tbl_size, tbl_num, tbl_entry_size = struct.unpack_from('<3I', v, 28+2048+4+16+16)
bc_size = struct.unpack_from('<I', v, 28+2048+4+16+16+12)[0]

p('=== vendor_boot header v%d ===' % hver)
p('  page_size           = %d' % pagesz)
p('  vendor_ramdisk_size = %d (%.2f MiB)' % (vrsize, vrsize/2**20))
p('  header_size         = %d' % hsize)
p('  dtb_size            = %d (%.2f MiB)' % (dtbsize, dtbsize/2**20))
p('  dtb_addr            = 0x%x' % dtbaddr)
p('  bootconfig_size     = %d' % bc_size)
p('  ramdisk table       = %d entries of %d bytes' % (tbl_num, tbl_entry_size))
p()

TYPES = {0: 'none', 1: 'platform', 2: 'recovery', 3: 'dlkm'}

# Where is the table really? v4 layout:
#   header (padded to page) | vendor_ramdisk (padded) | dtb (padded) | table | bootconfig
def align(x):
    return (x + PAGE - 1) // PAGE * PAGE

cand = align(hsize)
ramdisk_off = cand
after_ramdisk = align(cand + vrsize)
dtb_off = after_ramdisk
after_dtb = align(dtb_off + dtbsize)
tbl_off = after_dtb

p('=== computed section offsets ===')
p('  vendor_ramdisk @ 0x%08x' % ramdisk_off)
p('  dtb            @ 0x%08x' % dtb_off)
p('  ramdisk_table  @ 0x%08x' % tbl_off)
p('  bootconfig     @ 0x%08x' % align(tbl_off + tbl_size))
p()

# verify the dtb offset actually holds an FDT
p('  dtb offset magic: %s' % v[dtb_off:dtb_off+4].hex())
p('  (d00dfeed = FDT)')
p()

p('=== ramdisk table entries ===')
p('  idx  size         offset       type       name')
for i in range(tbl_num):
    e = tbl_off + i * tbl_entry_size
    rsize, roff, rtype = struct.unpack_from('<3I', v, e)
    rname = v[e+12:e+12+32].split(b'\0')[0].decode('ascii', 'replace')
    p('  %-4d %-12d 0x%08x   %-10s %s' % (i, rsize, roff, TYPES.get(rtype, rtype), rname))

p()
p('=== CONCLUSION ===')
p('The stock vendor_boot carries a %d-byte (%.1f MiB) ramdisk of type'
  % (vrsize, vrsize/2**20))
p('"platform" plus %d bytes of DTB.' % dtbsize)
p()
p('A hand-built boot.img with ramdisk_size=0 gives the kernel NO initramfs,')
p('so it cannot mount root or run userspace -> panic, and no USB gadget.')
p('This is independent of the memory map and the DTB.')

io.open(os.path.join(WS, 'docs', '_vboot.txt'), 'w', encoding='utf-8').write('\n'.join(out))
print('\n'.join(out))

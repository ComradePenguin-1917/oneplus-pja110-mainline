"""Capture raw log bytes over verified SSH, then check the phone-side digest."""
import hashlib
import json
import re
import subprocess
from pathlib import Path

root=Path(__file__).resolve().parents[1]
ssh=root/'out/usb-ncm-20261013/ssh'
out=root/'out/usb-ncm-20261013/after-test'
out.mkdir(parents=True, exist_ok=True)
base=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(ssh/'client_key_host'),
      '-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes',
      '-o',f'UserKnownHostsFile={ssh/"known_hosts"}','-o','ConnectTimeout=10','root@169.254.42.1']
def run(command):
    result=subprocess.run(base+[command],capture_output=True,timeout=60)
    if result.returncode:
        raise RuntimeError(result.stderr.decode(errors='replace'))
    return result.stdout
run('dmesg > /tmp/ncm-dmesg.txt')
data=run('cat /tmp/ncm-dmesg.txt')
expected=run('sha256sum /tmp/ncm-dmesg.txt').decode().split()[0]
actual=hashlib.sha256(data).hexdigest()
assert actual==expected, 'SSH dmesg integrity mismatch'
(out/'mainline-dmesg.txt').write_bytes(data)
(out/'network-state.txt').write_bytes(run('uname -a; id; cat /proc/uptime; ip -s link show usb0; ip addr show usb0; cat /proc/net/snmp; cat /sys/class/udc/*/state; cat /sys/class/udc/*/current_speed; cat /tmp/ncm-ssh.log'))
stream=run('i=1; while [ "$i" -le 30 ]; do echo NCM_SSH_KEEPALIVE_$i; sleep 1; i=$((i+1)); done')
(out/'ssh-persistent-stream.txt').write_bytes(stream)
markers=re.findall(rb'^NCM_SSH_KEEPALIVE_(\d+)$',stream,re.M)
assert [int(x) for x in markers]==list(range(1,31))
(out/'capture-result.json').write_text(json.dumps(dict(sha256_verified=True,sha256=actual,
    dmesg_lines=len(data.splitlines()),single_ssh_connection_30_second_stream=True),indent=2)+'\n')
print(f'PASS: {len(data.splitlines())} dmesg lines, SHA256={actual}; 30-second SSH stream verified')

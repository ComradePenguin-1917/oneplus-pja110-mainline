$ErrorActionPreference='Stop'
$root='out/usb-serial-reliability-new-cable-20261013/reopen-thread'
$results=@()
foreach($index in 1..10){
    $directory="$root/$index"
    & "$PSScriptRoot/test_usb_serial_reliability.ps1" -ReadMode Thread -RandomPayload -Rounds 1 -Sizes 1048576 -OutputDirectory $directory | Where-Object {$_ -like '*passed=*'}
    $record=Get-Content -LiteralPath "$directory/result-Thread.json" -Raw -Encoding utf8 | ConvertFrom-Json
    if(-not $record.AllPassed -or $record.ErrorsBefore -ne '0' -or $record.ErrorsAfter -ne '0'){throw "Reopen $index failed integrity or endpoint error checks"}
    $results += [pscustomobject]@{Reopen=$index;SHA256=$record.Transfers[0].ActualSHA256;Passed=$true}
}
[ordered]@{AllPassed=$true;Reopens=10;PayloadBytesPerOpen=1048576;Transfers=$results} | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$root/result.json"
Write-Output 'PASS: 10 separate open/close cycles, each with 1 MiB random payload SHA256 verified; zero endpoint errors'

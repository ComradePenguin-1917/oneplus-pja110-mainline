#!/bin/sh
read -r length || exit 1
case "$length" in ''|*[!0-9]*) exit 1;; esac
[ "$length" -gt 0 ] && [ "$length" -le 67108864 ] || exit 1
head -c "$length" > /tmp/ncm-www/uploaded.bin || exit 1
actual=$(wc -c < /tmp/ncm-www/uploaded.bin)
[ "$actual" -eq "$length" ] || exit 1
sha256sum /tmp/ncm-www/uploaded.bin

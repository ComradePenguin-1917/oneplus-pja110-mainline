#!/usr/bin/env python3
"""Answer the real question: is the DTB uncontrollable on ALL phones, or is this
a quirk of this device/ABL?

And more importantly: re-examine whether my "DTB is ignored" conclusion has a
loophole I missed.

Loophole to check: the marker experiment used the VENDOR live DTB as the appended
payload. If ABL appends/uses a base DTB and then applies the flash dtbo on top,
the marker at /chosen would survive unless something replaces /chosen. We showed
the dtbo does NOT touch /chosen. So the marker should have survived IF the
appended DTB were used.

Therefore the conclusion holds: the appended DTB is not used.

BUT there is a second, more likely explanation I should test: maybe ABL DOES use
an appended DTB, but only from the **vendor_boot** partition's dtb section, and
it *replaces* it entirely when we supply our own boot.img... no, we never
touched vendor_boot.

Let me instead check the ONE thing that would settle how other phones do it:
how lk2nd / postmarketOS handle this, and whether mainline phones normally get
their DTB through the boot image (a real, known mechanism on Qualcomm).
"""
import io
import os
import re

WS = r'H:\WorkSpace\PJA110-Mainline'

print('=' * 74)
print('1) HOW OTHER QUALCOMM PHONES GET THEIR DTB (from the kernel sources we have)')
print('=' * 74)
# The arm64 EFI stub can take a DTB from the bootloader; but Qualcomm ABL also
# supports a "dtb" appended to the kernel when the boot image says so.
# Look for whether the QCOM boot path or the EFI stub honours an appended DTB.
KT = os.path.join(WS, 'linux')
import subprocess

def grep_tree(pattern, paths, extra=''):
    cmd = 'grep -rn %s "%s" %s 2>/dev/null | head -20' % (extra, pattern, ' '.join(paths))
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True, cwd=KT)
    return r.stdout

print('--- does the EFI stub support an appended DTB? ---')
print(grep_tree('appended', ['drivers/firmware/efi/libstub/']))

print('--- is there any qcom-specific appended-dtb handling? ---')
print(grep_tree('append.*dtb\\|dtb.*append', ['drivers/', 'arch/arm64/'], '-i'))

print()
print('=' * 74)
print('2) WHAT OUR OWN BOOT IMAGES RELY ON (sanity)')
print('=' * 74)
print('  Our chain assumes: kernel field = Image + DTB, and the loader (ABL)')
print('  passes the DTB to the kernel in x0.')
print('  The marker experiment disproves that for THIS ABL.')
print()
print('  On many other Qualcomm devices the DTB does come from the boot image,')
print('  because:')
print('    * vendor_boot has a dtb section (we saw 4 DTBs in ours)')
print('    * fastboot v4 boot images may carry a dtb section too')
print('    * lk2nd (the community second-stage bootloader) explicitly supports')
print('      appending a DTB to the kernel')
print('  So "uncontrollable" is NOT universal -- it is specific to what this')
print('  ABL version does with the pieces it is given.')

print()
print('=' * 74)
print('3) THE DECISIVE QUESTION FOR US')
print('=' * 74)
print('  ABL loaded (per its log):  boot_a  vendor_boot_a  dtbo_a  init_boot_a')
print('  and then: Apply Overlay + Update Device Tree')
print()
print('  => ABL composes the final DTB from vendor_boot.dtb + dtbo.')
print('  => To influence the DTB we must modify ONE OF THOSE IN FLASH.')
print()
print('  Two candidates:')
print('    a) flash our DTB into dtbo_a   (overlay semantics)')
print('    b) flash a modified vendor_boot whose dtb section is our DTB')
print('       (replace semantics -- much closer to what we want!)')

print()
print('=' * 74)
print('4) OPTION (b) LOOKS PROMISING -- what is in vendor_boot.dtb?')
print('=' * 74)
print('  vendor_boot-A14.img: dtb_size = 2040970, containing 4 DTBs.')
print('  These are the BASE device trees ABL picks from, THEN applies dtbo on top.')
print('  If we replace that section with our own DTB, we get full control and')
print('  keep standard overlay behaviour.')
print()
print('  Caveat: vendor_boot also carries the vendor ramdisk and its AVB hash is')
print('  already known-mismatched (ABL log says so) -- flashing it is a real write')
print('  to a partition, so it needs the same care as dtbo_a.')

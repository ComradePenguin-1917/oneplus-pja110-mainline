#!/bin/bash
# Be rigorous about where "console=ttynull" comes from.
#
# My previous check concluded "ABL discards our cmdline". That is NOT proven:
# the ABL log shows only the cmdline ABL *builds*; the kernel may receive
# boot.img cmdline + vendor_boot cmdline concatenated.
#
# The live /proc/cmdline contains "console=ttynull loglevel=6 kpti=0 ..." but
# neither boot-A14.img (empty cmdline) nor vendor_boot (only "video=... bootconfig
# buildvariant=user") contains those tokens. So they likely come from the vendor
# KERNEL's built-in CONFIG_CMDLINE. Test that by searching the vendor kernel blob.
set -uo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"

echo "############ 1) does the vendor KERNEL binary contain the cmdline text? ############"
python3 - <<'PY'
import re
k = open('/home/comrade_penguin_desktop/workspace/PJA110-Mainline/out/stock-kernel.bin','rb').read()
print('  vendor kernel: %d bytes' % len(k))
probes = [b'console=ttynull', b'loglevel=6', b'kpti=0', b'log_buf_len=1M',
          b'swiotlb=noforce', b'loop.max_part=7', b'rcu_nocbs=0-7',
          b'stack_depot_disable', b'CONFIG_CMDLINE']
for p in probes:
    print('  %-24s %s' % (p.decode(), 'FOUND' if p in k else '-'))

# show context around the biggest hit
i = k.find(b'console=ttynull')
if i >= 0:
    print()
    print('  context around console=ttynull:')
    print('    %r' % k[max(0,i-200):i+260])
PY

echo
echo "############ 2) our boot image's cmdline vs what we observed ############"
python3 - <<'PY'
import struct
W='/mnt/h/WorkSpace/PJA110-Mainline'
for name in ('boot-A14.img','vendor_boot-A14.img'):
    b=open('%s/%s'%(W,name),'rb').read()
    if b[:8]==b'ANDROID!':
        cmd=b[44:44+1536].rstrip(b'\0')
        print('  %-22s cmdline=%r' % (name, cmd))
    elif b[:8]==b'VNDRBOOT':
        cmd=b[28:28+2048].rstrip(b'\0')
        print('  %-22s cmdline=%r' % (name, cmd))
PY

echo
echo "############ 3) vendor kernel built-in cmdline (search more precisely) ############"
python3 - <<'PY'
import re
k = open('/home/comrade_penguin_desktop/workspace/PJA110-Mainline/out/stock-kernel.bin','rb').read()
# CONFIG_CMDLINE sits in .rodata as a plain string, often near other boot strings
m = list(re.finditer(rb'[\x20-\x7e]{40,}', k))
cands = [x.group(0) for x in m if b'console=' in x.group(0) or b'androidboot' in x.group(0)]
print('  printable strings containing console=/androidboot: %d' % len(cands))
for c in cands[:12]:
    print('    %s' % c[:160].decode('ascii','replace'))
PY

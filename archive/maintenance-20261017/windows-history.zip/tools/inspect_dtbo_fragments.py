#!/usr/bin/env python3
"""Inspect the dtbo fragment format CORRECTLY.

Bug in the previous version: I used `p.count('/') == 2` to mean "depth 1", but a
depth-1 path like "/fragment@0" contains exactly ONE '/'. So the filter selected
/fragment@0/__overlay__ (depth 2) instead, which naturally has no `target`
property -- hence every fragment printed "?".

Depth must be computed as the number of non-empty path segments.
"""
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fdt import FDT, load_entries

WS = r'H:\WorkSpace\PJA110-Mainline'


def depth(p):
    return len([s for s in p.split('/') if s])


def dec(v):
    return v.rstrip(b'\0').decode('ascii', 'replace')


def fmt(v):
    if len(v) == 0:
        return '(bool)'
    if len(v) == 4:
        n = struct.unpack('>I', v)[0]
        return '0x%08x (%d)' % (n, n)
    if len(v) <= 48 and all(32 <= c < 127 or c == 0 for c in v):
        return repr(dec(v))
    return v[:24].hex() + ('...' if len(v) > 24 else '')


entries, _ = load_entries(os.path.join(WS, 'dtbo-A14.img'))

for label, sub in entries:
    f = FDT(sub)
    nodes = f.nodes()
    frags = []
    for p in nodes:
        if depth(p) == 1 and p.lstrip('/').startswith('fragment@'):
            try:
                frags.append((int(p.split('@')[1]), p))
            except ValueError:
                frags.append((9999, p))
    frags.sort()

    print('=' * 74)
    print('dtbo %s : %d fragments at depth 1' % (label, len(frags)))
    print('=' * 74)

    # summarise all targets
    summary = {}
    for _, p in frags:
        props = nodes[p]
        tp = props.get('target-path')
        tgt = props.get('target')
        if tp:
            key = 'path: %s' % dec(tp)
        elif tgt and len(tgt) >= 4:
            n = struct.unpack('>I', tgt)[0]
            key = 'phandle 0x%x%s' % (n, '  (UNRESOLVED 0xffffffff)' if n == 0xffffffff else '')
        else:
            key = '(no target)'
        summary[key] = summary.get(key, 0) + 1

    for k, n in sorted(summary.items(), key=lambda x: -x[1]):
        print('   %-58s x%d' % (k[:58], n))

    print()
    print('   first 3 fragments in detail:')
    for _, p in frags[:3]:
        print('   --- %s' % p)
        for k in sorted(nodes[p]):
            print('         %-16s %s' % (k, fmt(nodes[p][k])))
        ov = [q for q in nodes if q.startswith(p + '/__overlay__') and depth(q) == 3]
        for q in sorted(ov)[:8]:
            print('         %s' % q)
            for k in sorted(nodes[q]):
                print('              %-14s %s' % (k, fmt(nodes[q][k])))

    for special in ('__symbols__', '__fixups__', '__local_fixups__'):
        sp = '/' + special
        if sp in nodes:
            print('   %s : %d entries -> %s'
                  % (sp, len(nodes[sp]), sorted(nodes[sp])[:5]))
    print()

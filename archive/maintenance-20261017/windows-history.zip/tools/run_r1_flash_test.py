"""B-slot r1 experiment, with verified restoration and binary subprocess logs."""
import hashlib
import json
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT = ROOT / (sys.argv[3] if len(sys.argv) > 3 else 'out/boot-r1-experiment-20261012')
OUT.mkdir(exist_ok=True)
BUILD = ROOT / (sys.argv[2] if len(sys.argv) > 2 else 'out/rebuild-20261012')
SERIAL = 'bc7a542e'
ADB = r'C:\platform-tools\adb.exe'
FASTBOOT = r'C:\platform-tools\fastboot.exe'
PARTS = [p + '_' + s for s in ('a', 'b') for p in ('boot', 'vendor_boot', 'init_boot', 'dtbo')]
RESTORE = {p: ROOT / 'backup' / (p + '.img') for p in PARTS if p.endswith('_b')}
RESTORE['boot_b'] = ROOT / 'out/cmdline-experiment-20261012/boot_b-before.img'

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def adb(command):
    return subprocess.run([ADB, '-s', SERIAL, 'shell', "su -c '" + command + "'"], capture_output=True, check=True, timeout=150).stdout

def state(name):
    data = adb('getprop ro.boot.slot_suffix; getprop sys.boot_completed; cat /proc/version; dumpsys battery; sha256sum ' + ' '.join('/dev/block/by-name/' + p for p in PARTS))
    (OUT / (name + '.txt')).write_bytes(data)
    hashes = {}
    for line in data.decode().splitlines():
        if '/dev/block/by-name/' in line:
            digest, path = line.split()
            hashes[path.rsplit('/', 1)[1]] = digest
    assert len(hashes) == len(PARTS)
    return data.decode().splitlines()[:2], hashes

def fb(commands, name):
    with (OUT / (name + '.log')).open('ab') as log:
        for command in commands:
            print('fastboot ' + ' '.join(map(str, command)), flush=True)
            log.write(('\nCOMMAND ' + ' '.join(map(str, command)) + '\n').encode())
            log.flush()
            p = subprocess.run([FASTBOOT, '-s', SERIAL, *map(str, command)], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=90)
            log.write(p.stdout)
            log.flush()
            print(p.stdout.decode(errors='replace'), flush=True)
            p.check_returncode()

def main(mode):
    if mode == 'preflight':
        assert not (OUT / 'preflight.json').exists(), 'preserve prior evidence'
        manifest = json.loads((BUILD / 'manifest.json').read_text())
        for name, info in manifest['files'].items():
            assert sha(BUILD / name) == info['sha256'], name
        status, hashes = state('preflight-device')
        assert status == ['_a', '1'], status
        retained_args = [a.split('=', 1)[1] for a in sys.argv[4:] if a.startswith('--retain-from=')]
        assert len(retained_args) <= 1
        baseline = hashes
        if retained_args:
            previous = (ROOT / retained_args[0]).resolve()
            previous.relative_to(ROOT)
            prior_result = json.loads((previous/'result.json').read_text())
            assert prior_result['b_test_partitions_retained_at_user_request']
            prior_hashes = {}
            for line in (previous/'after-test-device.txt').read_text().splitlines():
                if '/dev/block/by-name/' in line:
                    digest, path = line.split()
                    prior_hashes[path.rsplit('/', 1)[1]] = digest
            assert hashes == prior_hashes, 'current device differs from retained evidence'
            baseline = json.loads((previous/'preflight.json').read_text())['partition_hashes_before']
        for part, path in RESTORE.items():
            assert sha(path) == baseline[part], 'restore mismatch: ' + part
        (OUT / 'preflight.json').write_text(json.dumps({'partition_hashes_before': baseline, 'partition_hashes_at_flash_preflight': hashes, 'restore_paths': {p: str(f) for p, f in RESTORE.items()}, 'images': manifest['files']}, indent=2))
        print('PASS: healthy A; all images and B restoration files verified.\n' + json.dumps(hashes, indent=2))
    elif mode == 'flash':
        evidence = json.loads((OUT / 'preflight.json').read_text())
        status, hashes = state('immediately-before-flash')
        assert status == ['_a', '1'] and hashes == evidence.get('partition_hashes_at_flash_preflight', evidence['partition_hashes_before'])
        for name in evidence['images']:
            assert sha(BUILD / name) == evidence['images'][name]['sha256']
        assert 'dtbo_b-avb-noop.img' in evidence['images'], 'Erased DTBO is invalid AVB metadata; provide a valid DTBO image'
        boot_info = evidence['images']['boot-xigua-r1.img']
        boot_matches = adb(f"head -c {boot_info['bytes']} /dev/block/by-name/boot_b | sha256sum").decode().split()[0] == boot_info['sha256']
        subprocess.run([ADB, '-s', SERIAL, 'reboot', 'bootloader'], check=True, timeout=30)
        fb([['getvar', 'current-slot'], ['getvar', 'unlocked'], ['getvar', 'slot-successful:a']], 'fastboot-preflight')
        commands = []
        for part, name in [('vendor_boot_b', 'vendor_boot_b-xigua-r1.img'), ('boot_b', 'boot-xigua-r1.img'), ('init_boot_b', 'init_boot_b-xigua-r1.img'), ('dtbo_b', 'dtbo_b-avb-noop.img')]:
            if (part == 'boot_b' and boot_matches) or (part != 'boot_b' and hashes[part] == evidence['images'][name]['sha256']):
                print('Already matches verified image; skipping flash ' + part, flush=True)
            else:
                commands.append(['flash', part, BUILD / name])
        fb(commands + [['set_active', 'b'], ['reboot']], 'flash')
        (OUT / 'flashed-at.txt').write_text(time.strftime('%Y-%m-%dT%H:%M:%S%z'))
    elif mode == 'retest':
        assert not (OUT / 'retest-at.txt').exists(), 'preserve prior retest evidence'
        evidence = json.loads((OUT / 'preflight.json').read_text())
        status, hashes = state('immediately-before-retest')
        assert status == ['_a', '1']
        assert all(hashes[p] == evidence['partition_hashes_before'][p] for p in PARTS if p.endswith('_a'))
        for part, name in [('vendor_boot_b', 'vendor_boot_b-xigua-r1.img'),
                           ('init_boot_b', 'init_boot_b-xigua-r1.img'),
                           ('dtbo_b', 'dtbo_b-avb-noop.img')]:
            assert hashes[part] == evidence['images'][name]['sha256'], part
            assert sha(BUILD / name) == hashes[part]
        info = evidence['images']['boot-xigua-r1.img']
        assert sha(BUILD / 'boot-xigua-r1.img') == info['sha256']
        assert adb(f"head -c {info['bytes']} /dev/block/by-name/boot_b | sha256sum").decode().split()[0] == info['sha256']
        subprocess.run([ADB, '-s', SERIAL, 'reboot', 'bootloader'], check=True, timeout=30)
        fb([['set_active', 'b'], ['reboot']], 'retest')
        (OUT / 'retest-at.txt').write_text(time.strftime('%Y-%m-%dT%H:%M:%S%z'))
    elif mode == 'evidence':
        state('after-test-device')
        (OUT / 'after-test-logs.txt').write_bytes(adb('cat /proc/cmdline; ls -la /sys/fs/pstore; cat /proc/bootloader_log 2>/dev/null; dmesg'))
        n = (BUILD / 'boot-xigua-r1.img').stat().st_size
        (OUT / 'boot-b-prefix.txt').write_bytes(adb(f'head -c {n} /dev/block/by-name/boot_b | sha256sum'))
        print((OUT / 'after-test-device.txt').read_text()[:500])
        print((OUT / 'boot-b-prefix.txt').read_text())
    elif mode == 'restore':
        evidence = json.loads((OUT / 'preflight.json').read_text())
        for part, path in RESTORE.items():
            assert sha(path) == evidence['partition_hashes_before'][part]
        # Caller puts the phone into fastboot first, allowing recovery from either state.
        fb([['flash', p, RESTORE[p]] for p in ('boot_b', 'vendor_boot_b', 'init_boot_b', 'dtbo_b')] + [['set_active', 'a'], ['reboot']], 'restore')
    elif mode == 'verify':
        # ADB can appear before Android has finished booting.
        deadline = time.monotonic() + 90
        while time.monotonic() < deadline:
            try:
                ready = subprocess.run([ADB, '-s', SERIAL, 'shell',
                    'getprop ro.boot.slot_suffix; getprop sys.boot_completed'],
                    capture_output=True, timeout=5)
                if ready.returncode == 0 and ready.stdout.decode().splitlines() == ['_a', '1']:
                    break
            except subprocess.TimeoutExpired:
                pass
            time.sleep(2)
        else:
            raise RuntimeError('Android A did not complete boot within 90 seconds')
        status, hashes = state('restored-device')
        assert status == ['_a', '1'], status
        assert hashes == json.loads((OUT / 'preflight.json').read_text())['partition_hashes_before']
        print('PASS: Android A completed boot; all eight A/B partition hashes match preflight.')
    else:
        raise ValueError(mode)

if __name__ == '__main__':
    main(sys.argv[1])

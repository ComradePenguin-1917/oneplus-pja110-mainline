"""Replace only existing module payloads to match the tracing kernel ABI."""
import gzip,hashlib,json,struct
from pathlib import Path
from build_init_marker_test import parse_cpio,make_entry,lz4
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/display-timing-20261014'
source=(ROOT/'out/gpu-port-20261014/init_boot_b-gpu.img').read_bytes()
m=json.loads((OUT/'manifest.json').read_text())
assert hashlib.sha256(source).hexdigest()==m['baseline_hashes']['init_boot_b']
size=struct.unpack_from('<I',source,12)[0]
entries=parse_cpio(lz4(['-d','-l','-c'],source[4096:4096+size]))
changes={'lib/modules/'+n:(OUT/n).read_bytes() for n in ('spi-geni-qcom.ko','synaptics-aston.ko')}
original={n.removeprefix('./'):(f,d) for f,n,d in entries}
assert all(n in original for n in changes)
rebuilt=b''.join(make_entry(f,n,changes.get(n.removeprefix('./'),d)) for f,n,d in entries)
updated={n.removeprefix('./'):(f,d) for f,n,d in parse_cpio(rebuilt)}
for n,r in original.items():
 if n in changes:
  assert updated[n][1]==changes[n],n
  assert all(updated[n][0][i]==r[0][i] for i in range(13) if i!=6),n
 else:assert updated[n]==r,n
compressed=lz4(['-z','-l','-12','-c'],rebuilt)
align=lambda n:(n+4095)//4096*4096
oldend,newend=4096+align(size),4096+align(len(compressed))
if newend>oldend:assert not any(source[oldend:newend])
assert newend<len(source)-64
result=bytearray(source)
struct.pack_into('<I',result,12,len(compressed))
result[4096:max(oldend,newend)]=compressed.ljust(max(oldend,newend)-4096,b'\0')
assert result[:12]==source[:12] and result[16:4096]==source[16:4096]
assert result[max(oldend,newend):]==source[max(oldend,newend):]
assert lz4(['-d','-l','-c'],result[4096:4096+len(compressed)])==rebuilt
(OUT/'init_boot_b-trace.img').write_bytes(result)
(OUT/'initramfs-trace.cpio.gz').write_bytes(gzip.compress(rebuilt,mtime=0))
m.update(only_boot_b_changed=False,changed_partitions=['boot_b','init_boot_b'],
         init_boot_b_sha256=hashlib.sha256(result).hexdigest(),
         initramfs_changes=list(changes),ssh_keys_and_init_script_preserved=True)
(OUT/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print('PASS: only two existing modules replaced; init script, firmware and SSH retained')

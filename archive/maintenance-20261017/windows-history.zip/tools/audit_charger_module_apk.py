"""Offline identity and dependency check; accepts the exact pmbootstrap kernel APK."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import tarfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('apk', type=Path)
parser.add_argument('--output', required=True, type=Path)
parser.add_argument('--native-manifest', required=True, type=Path)
args = parser.parse_args()
modules = {}
kernel = None
with tarfile.open(args.apk, 'r:gz', ignore_zeros=True) as archive:
    for member in archive:
        if not member.isfile():
            continue
        if member.name == 'boot/vmlinuz':
            kernel = archive.extractfile(member).read()
        elif member.name.endswith('.ko'):
            data = archive.extractfile(member).read()
            def field(key):
                matches = re.findall(rb'(?:^|\0)' + key.encode() + rb'=([^\0]*)\0', data)
                assert len(matches) == 1, (member.name, key, len(matches))
                return matches[0].decode()
            name = Path(member.name).stem.replace('-', '_')
            modules[name] = {'path': member.name, 'sha256': hashlib.sha256(data).hexdigest(),
                             'vermagic': field('vermagic'),
                             'depends': [x.replace('-', '_') for x in field('depends').split(',') if x]}
assert kernel is not None
manifest = json.loads(args.native_manifest.read_text())
digest = hashlib.sha256(kernel).hexdigest()
assert digest == manifest['inputs_sha256']['vmlinuz']
expected = '6.14.0-oneplus-xigua SMP preempt mod_unload aarch64'
roots = ['qcom_q6v5_pas', 'qcom_pd_mapper', 'bq27xxx_battery_i2c']
selected = {}
def visit(name):
    if name in selected:
        return
    assert name in modules, ('missing dependency', name)
    row = modules[name]
    assert row['vermagic'] == expected, (name, row['vermagic'])
    selected[name] = row
    for dependency in row['depends']:
        visit(dependency)
for name in roots:
    visit(name)
assert 'qcom_battmgr' not in modules
report = {'apk_sha256': hashlib.sha256(args.apk.read_bytes()).hexdigest(),
          'native_kernel_sha256': digest, 'native_kernel_matches': True,
          'module_dependency_closure': selected, 'expected_vermagic': expected,
          'qcom_battmgr_present': False, 'new_module_abi_validated': False,
          'cross_processor_gauge_exclusion_verified': False,
          'live_ssh_audit': 'timed out; no live module comparison claimed'}
args.output.write_text(json.dumps(report, indent=2) + '\n')
print('PASS: exact native kernel hash; all', len(selected),
      'modules in PAS/PD mapper/gauge dependency closure share expected vermagic')

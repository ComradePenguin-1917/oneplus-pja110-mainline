"""Verify the rebuilt Image, then package the boot/vendor_boot/init_boot set."""
import gzip
import hashlib
import json
import pathlib
import struct

from bootimg import BootImage
from build_init_marker_test import parse_cpio, lz4
from fdt import FDT
from fdtwrite import parse, serialise, Node, walk

ROOT=pathlib.Path(__file__).resolve().parents[1]
OUT=ROOT/'out/rebuild-20261012'
CMDLINE='console=ttyMSM0,115200 loglevel=8 earlycon ignore_loglevel'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def align(size):
    return (size+4095)//4096*4096

def main():
    image=(OUT/'Image').read_bytes()
    cfg=(OUT/'kernel.config').read_bytes()
    archive=(OUT/'initramfs.cpio.gz').read_bytes()
    release=(OUT/'kernel.release').read_text().strip()
    assert image[56:60]==b'ARM\x64'
    assert gzip.decompress((OUT/'Image.gz').read_bytes())==image
    start=image.find(b'IKCFG_ST')
    end=image.find(b'IKCFG_ED',start+8)
    assert start>=0 and end>start
    embedded_cfg=gzip.decompress(image[start+8:end])
    assert embedded_cfg==cfg
    lines=cfg.decode().splitlines()
    assert 'CONFIG_CMDLINE=""' in lines
    assert 'CONFIG_CMDLINE_FORCE=y' not in lines
    assert 'root=PARTLABEL=win' not in cfg.decode()
    assert archive in image
    entries=parse_cpio(gzip.decompress(archive))
    content={n[2:] if n.startswith('./') else n:(f,d) for f,n,d in entries}
    assert content['init'][1]==(ROOT/'initramfs/init').read_bytes()
    assert content['bin/busybox'][1]==(OUT/'busybox').read_bytes()
    assert content['dev/console'][0][9:11]==[5,1]
    qemu=(OUT/'qemu-smoke.log').read_text()
    assert (OUT/'qemu-image.sha256').read_text().split()[0]==sha(image)
    assert '[initramfs] boot: Linux' in qemu and release in qemu
    assert 'reboot: Power down' in qemu
    assert (OUT/'qemu-exit-code.txt').read_text().strip()=='0'
    assert not any(error in qemu for error in ('Kernel panic','stack smashing','uname: not found'))
    dtb=(OUT/'sm8550-oneplus-xigua-16G.dtb').read_bytes()
    nodes=FDT(dtb).nodes()
    symbols=nodes['/__symbols__']
    assert {'qcom_tzlog','arch_timer'}<=set(symbols)
    assert b'oneplus,xigua' in nodes['/']['compatible']
    def memory_regs(blob):
        return {p:v.get('reg') for p,v in FDT(blob).nodes().items()
                if p.startswith('/reserved-memory/') or p.rsplit('/',1)[-1].startswith('memory@')}
    old_dtb=(ROOT/'out/sm8550-oneplus-xigua-16G.dtb').read_bytes()
    assert memory_regs(dtb)==memory_regs(old_dtb), 'memory map changed from previous in-tree DTB'
    stock=BootImage.parse(str(ROOT/'boot-A14.img'))
    boot=BootImage()
    boot.header_version=stock.header_version
    boot.os_version=stock.os_version
    boot.kernel=image
    boot_path=OUT/'boot-xigua-r1.img'
    boot_path.write_bytes(boot.pack(cmdline=CMDLINE))
    back=BootImage.parse(str(boot_path))
    assert back.kernel==image and back.ramdisk==b'' and back.cmdline==CMDLINE.encode()
    assert back.header_version==4 and back.os_version==stock.os_version
    assert boot_path.stat().st_size<201326592
    # Use the verified vendor_boot entry0 route, without an appended DTB.
    original=(ROOT/'backup/vendor_boot_b.img').read_bytes()
    header_size,dtb_size=struct.unpack_from('<II',original,2096)
    ramdisk_size=struct.unpack_from('<I',original,24)[0]
    dtb_off=align(align(header_size)+ramdisk_size)
    slot_size=struct.unpack_from('>I',original,dtb_off+4)[0]
    tree,reservations=parse(dtb)
    tree.children.append(Node('xigua-rebuild-r1'))
    marked=serialise(tree,reservations)
    assert len(marked)<=slot_size
    padded=bytearray(marked)+b'\0'*(slot_size-len(marked))
    struct.pack_into('>I',padded,4,slot_size)
    assert '/xigua-rebuild-r1' in dict(walk(parse(bytes(padded))[0]))
    vendor=bytearray(original)
    vendor[dtb_off:dtb_off+slot_size]=padded
    assert vendor[:dtb_off]==original[:dtb_off]
    assert vendor[dtb_off+slot_size:]==original[dtb_off+slot_size:]
    assert len(vendor)==len(original)
    (OUT/'vendor_boot_b-xigua-r1.img').write_bytes(vendor)
    # Put the SAME archive in the generic ramdisk as in the built-in rootfs.
    generic=(ROOT/'backup/init_boot_b.img').read_bytes()
    old_size=struct.unpack_from('<I',generic,12)[0]
    generic_end=4096+align(old_size)
    raw=gzip.decompress(archive)
    compressed=lz4(['-z','-l','-12','-c'],raw)
    assert len(compressed)<=generic_end-4096
    assert lz4(['-d','-l','-c'],compressed)==raw
    init_boot=bytearray(generic)
    struct.pack_into('<I',init_boot,12,len(compressed))
    init_boot[4096:generic_end]=compressed+b'\0'*(generic_end-4096-len(compressed))
    assert init_boot[generic_end:]==generic[generic_end:]
    assert len(init_boot)==len(generic)
    (OUT/'init_boot_b-xigua-r1.img').write_bytes(init_boot)
    files=['Image','Image.gz','kernel.config','sm8550-oneplus-xigua-16G.dtb',
           'initramfs.cpio.gz','busybox','boot-xigua-r1.img',
           'vendor_boot_b-xigua-r1.img','init_boot_b-xigua-r1.img']
    manifest={'release':release,'cmdline_source':'bootloader',
              'embedded_config_matches':True,'embedded_initramfs_matches':True,
              'qemu_reached_init':True,'qemu_poweroff_exit':0,
              'device_mainline_boot_tested':False,
              'files':{name:{'bytes':(OUT/name).stat().st_size,'sha256':sha((OUT/name).read_bytes())}
                       for name in files}}
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    (OUT/'SHA256SUMS').write_text(''.join(manifest['files'][name]['sha256']+'  '+name+'\n' for name in files))
    print(json.dumps(manifest,indent=2))
    print('PACKAGE AND INDEPENDENT READ-BACK VERIFICATION PASS')

if __name__=='__main__':
    main()

#!/usr/bin/env python3
"""Inject an INERT node into entry0 of vendor_boot's dtb section (grow into
alignment padding, so nothing downstream moves).

Situation:
  * entry0's FDT is packed tight: content_end == totalsize == slot size, zero slack
  * the 4 DTBs are concatenated with NO padding between them
  * the dtb section ends at dtb_off + dtb_size, then there is only page-alignment
    padding before the ramdisk_table

Key insight that makes this safe:
  ramdisk_table sits at  align(dtb_off + dtb_size)
  If I grow the section by N bytes, ABL recomputes align(dtb_off + dtb_size + N).
  As long as that still lands on the SAME page boundary, the table, the
  bootconfig and everything else stay at their original absolute offsets -- I
  only rewrite bytes inside [dtb_off, align(dtb_off+dtb_size+N)).

So:
  1. grow entry0's blob by N (insert the inert node inside root, before root's
     FDT_END_NODE; bump totalsize, off_dt_strings, size_dt_struct by N)
  2. place entries 1..3 right after it
  3. zero-fill up to the original page-aligned table offset
  4. set header dtb_size += N
  5. leave every other byte of the partition untouched

The injected node has no properties, no compatible, no reg -> no driver can bind
to it, so it cannot change behaviour. It exists purely as a witness: if it shows
up in the running tree, ABL used OUR vendor_boot entry0.
"""
import hashlib
import os
import struct
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
PAGE = 4096
NODE_NAME = sys.argv[3] if len(sys.argv) > 3 else 'xigua-vbtest'

FDT_BEGIN_NODE = 0x00000001
FDT_END_NODE = 0x00000002
FDT_PROP = 0x00000003
FDT_NOP = 0x00000004
FDT_END = 0x00000009


def walk_struct(blob, off_struct):
    p = off_struct
    depth = 0
    root_end = None
    while True:
        tok = struct.unpack_from('>I', blob, p)[0]
        if tok == FDT_BEGIN_NODE:
            p += 4
            start = p
            while blob[p] != 0:
                p += 1
            p += 1
            p = start + ((p - start + 3) // 4) * 4
            depth += 1
        elif tok == FDT_END_NODE:
            if depth == 1:
                root_end = p
            p += 4
            depth -= 1
        elif tok == FDT_PROP:
            ln = struct.unpack_from('>I', blob, p + 4)[0]
            p += 12 + ((ln + 3) // 4) * 4
        elif tok == FDT_NOP:
            p += 4
        elif tok == FDT_END:
            return root_end, p
        else:
            raise ValueError('bad token 0x%08x at 0x%x' % (tok, p))


def inject_node_into_fdt(blob, node_name):
    """Return blob with an inert top-level node added, growing totalsize."""
    totalsize, off_struct, off_strings = struct.unpack_from('>3I', blob, 4)
    size_strings = struct.unpack_from('>I', blob, 32)[0]
    size_struct = struct.unpack_from('>I', blob, 36)[0]
    content_end = off_strings + size_strings
    if content_end > len(blob):
        raise ValueError('string block extends past the blob')
    root_end, end_tok = walk_struct(blob, off_struct)
    if root_end is None:
        raise ValueError('no root end node')

    raw = node_name.encode('ascii') + b'\0'
    padded = raw + b'\0' * ((4 - len(raw) % 4) % 4)
    node = struct.pack('>I', FDT_BEGIN_NODE) + padded + struct.pack('>I', FDT_END_NODE)
    n = len(node)

    # insert before root's FDT_END_NODE; carry along the trailing FDT_END token
    new = bytearray(blob[:root_end]) + node + blob[root_end:]
    struct.pack_into('>I', new, 4, totalsize + n)          # totalsize
    struct.pack_into('>I', new, 12, off_strings + n)       # off_dt_strings
    struct.pack_into('>I', new, 36, size_struct + n)       # size_dt_struct
    return bytes(new), n


def main():
    src = sys.argv[1] if len(sys.argv) > 1 else os.path.join(WS, 'backup', 'vendor_boot_b.img')
    out = sys.argv[2] if len(sys.argv) > 2 else os.path.join(WS, 'out', 'vendor_boot_b-node.img')

    v = bytearray(open(src, 'rb').read())
    hsize, dtbsize = struct.unpack_from('<2I', v, 28+2048+4+16)
    vrsize = struct.unpack_from('<I', v, 24)[0]
    dtb_off = (((hsize+PAGE-1)//PAGE)*PAGE + vrsize + PAGE-1)//PAGE*PAGE
    tbl_off = ((dtb_off + dtbsize + PAGE - 1)//PAGE)*PAGE

    print('=== layout ===')
    print('  dtb section    @0x%x  size %d' % (dtb_off, dtbsize))
    print('  section end    @0x%x' % (dtb_off + dtbsize))
    print('  ramdisk_table  @0x%x  (page-aligned)' % tbl_off)
    print('  free gap       : %d bytes' % (tbl_off - (dtb_off + dtbsize)))

    # split the 4 entries
    entries = []
    off = dtb_off
    for i in range(4):
        total = struct.unpack_from('>I', v, off+4)[0]
        entries.append(bytes(v[off:off+total]))
        off += total
    if off != dtb_off + dtbsize:
        sys.exit('entries do not sum to dtb_size')
    print('  entries        : %s' % [len(e) for e in entries])

    print()
    print('=== inject into entry0 ===')
    new0, n = inject_node_into_fdt(entries[0], NODE_NAME)
    print('  entry0 %d -> %d (+%d)' % (len(entries[0]), len(new0), n))
    print('  new section end @0x%x' % (dtb_off + dtbsize + n))
    if dtb_off + dtbsize + n > tbl_off:
        sys.exit('grew past the table offset; would move downstream sections')
    print('  still before the table offset: True')

    section = new0 + entries[1] + entries[2] + entries[3]
    new_end = dtb_off + len(section)
    padded_section = section + b'\0' * (tbl_off - new_end)
    print('  section + padding = %d bytes' % len(padded_section))

    # verify the new entry0 parses and carries the node.
    # NOTE: use walk(), not nodes(). nodes() only records nodes that HAVE
    # properties, and our injected node is deliberately property-less, so
    # nodes() would never see it.
    sys.path.insert(0, os.path.join(WS, 'tools'))
    from fdt import FDT

    def all_node_paths(blob_):
        return [p for _d, p, _n, props in FDT(blob_).walk() if props is None]

    before_paths = set(all_node_paths(entries[0]))
    after_paths = set(all_node_paths(new0))
    print('  entry0 node paths %d -> %d' % (len(before_paths), len(after_paths)))
    if ('/' + NODE_NAME) not in after_paths:
        sys.exit('node not visible after injection')
    print('  node %r present: True' % NODE_NAME)
    print('  added paths: %s' % sorted(after_paths - before_paths))

    # splice: replace [dtb_off, tbl_off) only
    orig = bytes(v)
    v[dtb_off:tbl_off] = padded_section
    struct.pack_into('<I', v, 28+2048+4+16+4, dtbsize + n)   # header dtb_size

    # confirm bytes outside the rewritten region are untouched
    w = bytes(v)
    same_head = w[:dtb_off] == orig[:dtb_off]
    # header dtb_size legitimately changed
    head_same = bytearray(w[:dtb_off]) == bytearray(orig[:dtb_off])
    print()
    print('=== integrity ===')
    print('  bytes before dtb section identical: %s' % (w[:dtb_off] == orig[:dtb_off]))
    print('  bytes from table onward identical : %s' % (w[tbl_off:] == orig[tbl_off:]))
    print('  header dtb_size: %d -> %d' % (dtbsize, struct.unpack_from('<I', w, 28+2048+4+16+4)[0]))

    open(out, 'wb').write(w)

    # walk the rebuilt section as ABL would
    print()
    print('=== rebuilt section walk ===')
    ndtbsize = struct.unpack_from('<I', w, 28+2048+4+16+4)[0]
    off = dtb_off
    for i in range(4):
        total = struct.unpack_from('>I', w, off+4)[0]
        norm = FDT(w[off:off+total])
        nn = norm.nodes()
        mid = nn['/'].get('qcom,msm-id')
        ms = ' '.join('0x%x' % x for x in struct.unpack('>%dI' % (len(mid)//4), mid))[:20] if mid else '-'
        flag = ''
        if i == 0:
            paths = set(p for _d, p, _n, pr in norm.walk() if pr is None)
            flag = '   <== %s present: %s' % (NODE_NAME, ('/' + NODE_NAME) in paths)
        print('  entry%d @0x%06x size=%-7d nodes=%-5d msm-id=%-20s%s'
              % (i, off, total, len(nn), ms, flag))
        off += total
    print('  walk end 0x%x, dtb_off+dtb_size = 0x%x, match: %s'
          % (off, dtb_off + ndtbsize, off == dtb_off + ndtbsize))
    print('  table offset unchanged: %s' % (tbl_off == ((dtb_off + ndtbsize + PAGE-1)//PAGE)*PAGE))

    print()
    print('  original sha256 : %s' % hashlib.sha256(orig).hexdigest())
    print('  patched  sha256 : %s' % hashlib.sha256(w).hexdigest())
    print('  size unchanged  : %s' % (len(w) == len(orig)))
    print()
    print('wrote %s' % out)
    print()
    print('READ CHANNEL (no root required):')
    print('  adb shell ls /sys/firmware/devicetree/base/ | grep %s' % NODE_NAME)


if __name__ == '__main__':
    main()

"""Upload a checksummed native RAM framebuffer test pattern and collect its log."""
import hashlib
import subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/display-port-20261013'
KEYS=ROOT/'out/usb-ncm-20261013/ssh'
SSH=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(KEYS/'client_key_host'),
     '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
     '-o',f'UserKnownHostsFile={KEYS/"known_hosts"}','-o','ConnectTimeout=5',
     '-o','ServerAliveInterval=5','root@169.254.42.1']
def run(cmd,data=None):
    result=subprocess.run(SSH+[cmd],input=data,capture_output=True,timeout=60)
    (OUT/'fb-pattern-last-stderr.txt').write_bytes(result.stderr)
    result.check_returncode();return result.stdout
data=(OUT/'fb-pattern').read_bytes()
expected=hashlib.sha256(data).hexdigest()
actual=run('cat > /tmp/fb-pattern; chmod 700 /tmp/fb-pattern; sha256sum /tmp/fb-pattern',data).decode().split()[0]
assert actual==expected
response=run('/tmp/fb-pattern')
(OUT/'fb-pattern-result.txt').write_bytes(response)
(OUT/'dmesg-after-pattern.txt').write_bytes(run('dmesg'))
print(response.decode())

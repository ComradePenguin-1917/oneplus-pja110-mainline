#!/usr/bin/env python3
"""Two cheap, high-value checks before building the test battery.

CHECK 1: is a persistent record of the slot-B boot attempt stored anywhere?
    /proc/bootloader_log is in RAM and is overwritten by the fallback boot, so
    the slot-B reason is already lost from there. But the ABL log shows it writes
    `oplusreserve1` on every boot:
        Phoenix:Write oplusreserve1 start_block=1080, write_size=4096
        Phoenix:Write oplusreserve1 start_block=1102, write_size=28672
    If boot-attempt history lives there, it should still describe what happened.

CHECK 2: does forced power-off work on this hardware?
    The plan is to make our /init power the device OFF when it cannot bring up
    USB. That turns "did the kernel reach userspace?" into an unmistakable
    signal: the phone goes dark and does NOT fall back to Android.
    Before relying on it, verify PSCI SYSTEM_OFF actually works here, using the
    running Android kernel (which is a known-good kernel).
"""
import os
import shutil
import subprocess
import sys

ADB = shutil.which('adb') or r'C:\platform-tools\adb.exe'
WS = r'H:\WorkSpace\PJA110-Mainline'
SERIAL = 'bc7a542e'


def root(cmd, timeout=900):
    r = subprocess.run([ADB, '-s', SERIAL, 'shell', "su -c '%s'" % cmd],
                       capture_output=True, timeout=timeout)
    return ((r.stdout or b'') + (r.stderr or b'')).decode('utf-8', 'replace')


def sh(cmd, timeout=300):
    r = subprocess.run([ADB, '-s', SERIAL, 'shell', cmd], capture_output=True, timeout=timeout)
    return ((r.stdout or b'') + (r.stderr or b'')).decode('utf-8', 'replace')


print('=' * 78)
print('CHECK 1: persistent boot history in oplusreserve1')
print('=' * 78)
out = os.path.join(WS, 'backup', 'oplusreserve1.img')
if not os.path.exists(out):
    root('dd if=/dev/block/by-name/oplusreserve1 of=/data/local/tmp/o1.img bs=4096 count=8 2>/dev/null; '
         'chmod 644 /data/local/tmp/o1.img')
    r = subprocess.run([ADB, '-s', SERIAL, 'pull', '/data/local/tmp/o1.img', out],
                       capture_output=True, timeout=900)
    print('  pulled: %s' % (os.path.exists(out) and '%d bytes' % os.path.getsize(out) or 'FAILED'))

if os.path.exists(out):
    b = open(out, 'rb').read()
    print('  size: %d bytes' % len(b))
    # block 1080 is not the start of the partition; dump what we have and look for
    # readable structure
    printable = bytes(c if 32 <= c < 127 else 46 for c in b[:2048])
    print()
    print('  first 512 bytes as hex + ascii:')
    for off in range(0, 512, 32):
        row = b[off:off + 32]
        txt = ''.join(chr(c) if 32 <= c < 127 else '.' for c in row)
        print('    %04x  %-64s  %s' % (off, row.hex(), txt))

    print()
    print('  looking for slot/boot keywords:')
    for kw in (b'_a', b'_b', b'success', b'boot', b'fail', b'retry', b'slot'):
        idx = b.find(kw)
        print('    %-10r %s' % (kw, 'at 0x%x' % idx if idx >= 0 else '-'))

print()
print('=' * 78)
print('CHECK 2: does forced power-off work on this hardware?')
print('=' * 78)
print('  current kernel: %s' % sh('uname -r').strip())
print()
print('  /proc/sysrq-trigger present : %s' % ('yes' if 'sysrq' in root('ls /proc/sysrq-trigger 2>&1') else 'no'))
print('  sysrq enabled bit           : %s' % root('cat /proc/sys/kernel/sysrq 2>/dev/null').strip())
print('  PSCI in the RUNNING tree    :')
print('   ', root('cat /sys/firmware/devicetree/base/psci/method 2>/dev/null || '
               'cat /soc/psci/method 2>/dev/null').strip()[:60])
print()
print('  NOTE: performing the actual power-off is deferred to the end, since it')
print('  turns the phone off and needs a manual power-on afterwards.')

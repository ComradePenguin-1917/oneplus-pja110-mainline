#!/usr/bin/env python3
"""Back up vendor_boot and init_boot from the DEVICE (not from the OTA package).

Why this matters:
  * the ABL log reports hash mismatches for vendor_boot_a and init_boot_a
  * we just confirmed it: on-device vendor_boot_a = 4b3e8008...
    while the OTA package's             = e085f83a...
  * so the device's copy has been modified (root/KernelSU or a different build)
    and the OTA copy CANNOT restore it faithfully
  * vendor_boot holds the BASE device tree that ABL uses, so we will be
    modifying/restoring this partition -- we must have the real original

Read-only: never writes to a partition.
"""
import hashlib
import os
import shutil
import subprocess
import sys

ADB = shutil.which('adb') or r'C:\platform-tools\adb.exe'
OUT = r'H:\WorkSpace\PJA110-Mainline\backup'
SERIAL = 'bc7a542e'
PARTS = ('vendor_boot_a', 'vendor_boot_b', 'init_boot_a', 'init_boot_b')


def sh(cmd, timeout=1800):
    return subprocess.run([ADB, '-s', SERIAL, 'shell', 'su -c "%s"' % cmd],
                          capture_output=True, text=True, timeout=timeout)


def on_device_hash(part):
    r = sh('sha256sum /dev/block/by-name/%s' % part)
    for line in r.stdout.splitlines():
        if part in line:
            return line.split()[0]
    return None


def main():
    os.makedirs(OUT, exist_ok=True)
    for part in PARTS:
        local = os.path.join(OUT, '%s.img' % part)
        remote = '/data/local/tmp/%s.img' % part

        if os.path.exists(local):
            print('%-16s already backed up (%d bytes), skipping'
                  % (part, os.path.getsize(local)))
            continue

        print('--- %s ---' % part)
        dev_hash = on_device_hash(part)
        print('    on-device sha256: %s' % dev_hash)

        r = sh('dd if=/dev/block/by-name/%s of=%s bs=1M 2>&1; chmod 644 %s'
               % (part, remote, remote))
        if r.returncode != 0:
            print('    dd failed: %s' % (r.stdout + r.stderr)[:200])
            continue

        r = subprocess.run([ADB, '-s', SERIAL, 'pull', remote, local],
                           capture_output=True, text=True, timeout=3600)
        if not os.path.exists(local):
            print('    pull failed: %s' % (r.stdout + r.stderr)[:200])
            continue

        with open(local, 'rb') as fh:
            h = hashlib.sha256(fh.read()).hexdigest()
        print('    pulled %d bytes  sha256=%s' % (os.path.getsize(local), h))
        print('    matches device: %s' % (h == dev_hash))
        sh('rm -f %s' % remote)

    print()
    print('=== backup dir ===')
    tot = 0
    for f in sorted(os.listdir(OUT)):
        p = os.path.join(OUT, f)
        sz = os.path.getsize(p)
        tot += sz
        print('  %-22s %12d' % (f, sz))
    print('  total: %.1f MiB' % (tot / 2**20))


if __name__ == '__main__':
    sys.exit(main())

"""Load unmodified upstream reboot-mode dependencies in RAM, without flashing."""
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'out/display-generator-avb-retest-20261014/reboot-modules'
KEYS = ROOT / 'out/usb-ncm-20261013/ssh'
SSH = ['C:/Windows/System32/OpenSSH/ssh.exe', '-F', 'none', '-T',
       '-i', str(KEYS / 'client_key_host'), '-o', 'BatchMode=yes',
       '-o', 'IdentitiesOnly=yes', '-o', 'StrictHostKeyChecking=yes',
       '-o', f'UserKnownHostsFile={KEYS / "known_hosts"}',
       '-o', 'ConnectTimeout=5', 'root@169.254.42.1']


def ssh(command, data=None):
    result = subprocess.run(SSH + [command], input=data, capture_output=True, timeout=30)
    (OUT / 'last-stderr.txt').write_bytes(result.stderr)
    result.check_returncode()
    return result.stdout


before = ssh('uname -a; cat /proc/sys/kernel/random/boot_id; lsmod')
(OUT / 'before.txt').write_bytes(before)
assert b'6.14.0-sm8550-xigua-r1' in before
manifest = {}
for name in ('qcom-spmi-sdam.ko', 'nvmem-reboot-mode.ko'):
    data = (OUT / name).read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    remote = '/tmp/' + name
    actual = ssh(f'cat > {remote}; sha256sum {remote}', data).decode().split()[0]
    assert actual == digest
    ssh(f'insmod {remote}')
    manifest[name] = digest
state = ssh('lsmod; ls -l /sys/bus/platform/devices/reboot-mode/driver; '
            'ls /sys/bus/nvmem/devices; dmesg | tail -n 25')
(OUT / 'loaded-state.txt').write_bytes(state)
assert b'drivers/nvmem-reboot-mode' in state
(OUT / 'loaded-modules.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(state.decode())
print('PASS: upstream nvmem-reboot-mode bound; modules loaded only in RAM')

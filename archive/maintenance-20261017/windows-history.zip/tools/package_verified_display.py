import hashlib, json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).parent))
from bootimg import BootImage

root=Path(__file__).resolve().parents[1]
out=root/'out/display-port-20261013'
base=BootImage.parse(str(out/'round4/boot-xigua-r1.img'))
image=(out/'Image-probe').read_bytes()
old_kernel=base.kernel
# Preserve the known-good appended DTB and replace only the kernel Image bytes.
dtb_offset=old_kernel.find(bytes.fromhex('d00dfeed'))
assert dtb_offset > 0
assert image[:dtb_offset] == old_kernel[:dtb_offset]
# The build tree may regenerate an equivalent-but-different built-in DTB; use
# the byte-for-byte DTB from the already verified display boot image.
image=image[:dtb_offset]+old_kernel[dtb_offset:]
base.kernel=image
packed=base.pack(cmdline=base.cmdline.decode())
target=out/'boot-xigua-r1-restored-aa536.img'
target.write_bytes(packed)
manifest={'source_boot':'round4/boot-xigua-r1.img','kernel':'Image-probe',
          'only_kernel_replaced':True,'dtb_preserved':True,
          'image_sha256':hashlib.sha256(image).hexdigest(),
          'boot_sha256':hashlib.sha256(packed).hexdigest(),
          'bytes':len(packed),'phone_execution_confirmed':False}
(out/'restored-display-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('PASS: packaged restored AA536 boot; kernel replaced, appended DTB preserved')

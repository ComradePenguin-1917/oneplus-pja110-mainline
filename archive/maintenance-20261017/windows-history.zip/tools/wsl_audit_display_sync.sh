#!/bin/bash
set -euo pipefail
TREE="$HOME/workspace/PJA110-Mainline/linux"
OUT=/mnt/h/workspace/PJA110-Mainline/out/weston-kms-diagnosis-20261014
mkdir -p "$OUT"
cd "$TREE"
{
grep -R -n -E 'vsync_source|vsync-source|te-pin' drivers/gpu/drm/msm/dsi drivers/gpu/drm/msm/msm_drv.h || true
grep -R -n -E 'vsync_source[[:space:]]*=|VSYNC_SOURCE_GPIO|TEAR_MDP_VSYNC_SEL' drivers/gpu/drm/msm || true
sed -n '520,575p' drivers/gpu/drm/msm/disp/dpu1/dpu_kms.c
grep -n -A35 -B8 -E 'vsync_sel|setup_vsync_source' drivers/gpu/drm/msm/disp/dpu1/dpu_hw_intf.c drivers/gpu/drm/msm/disp/dpu1/dpu_hw_top.c
grep -n -A25 'enum dpu_vsync_source' drivers/gpu/drm/msm/disp/dpu1/dpu_hw_mdss.h
} > "$OUT/te-source-code.txt"
cp drivers/gpu/drm/msm/dsi/dsi.c "$OUT/dsi-current.c"
cp drivers/gpu/drm/msm/dsi/dsi_host.c "$OUT/dsi_host-current.c"
cp drivers/gpu/drm/msm/disp/dpu1/dpu_hw_intf.c "$OUT/dpu_hw_intf-current.c"
cp drivers/gpu/drm/msm/disp/dpu1/dpu_kms.c "$OUT/dpu_kms-current.c"
cp drivers/gpu/drm/msm/disp/dpu1/catalog/dpu_9_0_sm8550.h "$OUT/catalog-current.h"
echo 'Saved actual build-tree TE source and DSI configuration code'

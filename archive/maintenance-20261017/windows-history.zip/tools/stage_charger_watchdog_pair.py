"""Stage two OEM snapshots to observe watchdog state after the first pet."""
from pathlib import Path
import hashlib, subprocess
from prepare_native_install import SSH
out=Path('out/native-install-20261017/charger-watchdog-probe')
sha=hashlib.sha256((out/'qcom_battmgr-watchdog.ko').read_bytes()).hexdigest()
script='''#!/bin/sh
set -eu
test "$(id -u)" = 0
mkdir /run/pja110-charger-watchdog-lock || exit 1
trap 'rmdir /run/pja110-charger-watchdog-lock' EXIT
cd /home/penguin/charger-watchdog-probe
exec > pair-result.log 2>&1
chmod 644 pair-result.log
test "$(uname -r)" = 6.14.0-oneplus-xigua
test "$(cat /sys/module/qcom_battmgr/parameters/pja110_charger_init)" = N
echo '@SHA@  qcom_battmgr-watchdog.ko' | sha256sum -c -
test -f /usr/local/lib/pja110/qcom_battmgr.ko
restore() {
 if [ -d /sys/module/qcom_battmgr ]; then rmmod qcom_battmgr || return 1; fi
 insmod /usr/local/lib/pja110/qcom_battmgr.ko pja110_charger_init=0
 echo READONLY_MODULE_RESTORED
}
cleanup() { restore; rmdir /run/pja110-charger-watchdog-lock; }
for round in 1 2; do
 echo ROUND=$round
 cat /proc/sys/kernel/random/boot_id /proc/uptime
 cat /sys/class/power_supply/bq28z610-0/uevent
 rmmod qcom_battmgr
 trap cleanup EXIT
 insmod ./qcom_battmgr-watchdog.ko
 result=-115
 for i in $(seq 1 12); do
  result=$(cat /sys/module/qcom_battmgr/parameters/readback_result)
  [ "$result" = -115 ] || break
  sleep 1
 done
 echo OEM_SNAPSHOT_RESULT=$result
 cat /sys/module/qcom_battmgr/parameters/snapshot_size /sys/module/qcom_battmgr/parameters/snapshot
 restore
 trap 'rmdir /run/pja110-charger-watchdog-lock' EXIT
 test "$result" = 0
 if [ "$round" = 1 ]; then sleep 10; fi
done
cat /sys/class/power_supply/bq28z610-0/uevent
echo WATCHDOG_PAIR_COMPLETE
'''.replace('@SHA@',sha)
(out/'pair.sh').write_bytes(script.encode())
args=SSH[:]; args[-1]='penguin@172.16.42.1'
args=[x if not x.startswith('UserKnownHostsFile=') else 'UserKnownHostsFile=out/native-install-20261017/known_hosts' for x in args]
p=subprocess.run(args+['cat > /home/penguin/probe-charger-watchdog-pair.sh'],input=script.encode(),capture_output=True,timeout=25)
p.check_returncode()
p=subprocess.run(args+['sh -n /home/penguin/probe-charger-watchdog-pair.sh; sudo -n true'],capture_output=True,timeout=20)
print(p.stdout.decode(errors='replace')); print(p.stderr.decode(errors='replace')); print('SSH exit:',p.returncode)

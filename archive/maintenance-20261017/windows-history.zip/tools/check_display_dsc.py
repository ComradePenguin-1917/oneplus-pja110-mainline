"""Compare all 15 RC ranges and initial scalars for vendor SCR1 10bpc/8bpp."""
import json
import re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/display-port-20261013'
vendor=(ROOT/'out/display-baseline-20261013/oneplus-source/git/vendor/qcom/opensource/display-drivers/msm/sde_dsc_helper.c').read_text()
def table(name):
    match=re.search(name+r'\[[^;]+?=\s*\{(.*?)\n\};',vendor,re.S)
    assert match,name
    text=re.sub(r'/\*.*?\*/','',match[1],flags=re.S)
    return [[int(v) for v in re.findall(r'-?\d+',row)] for row in re.findall(r'\{([^{}]+)\}',text)]
minimum=table('sde_dsc_rc_range_min_qp')[4]
maximum=table('sde_dsc_rc_range_max_qp')[4]
offsets=table('sde_dsc_rc_range_bpg')[4]
expected=list(zip(minimum,maximum,offsets))
source=(OUT/'drm_dsc_helper.c').read_text()
source=source[source.index('static const struct rc_parameters_data rc_parameters_1_2_444'):]
section=source[source.index('.bpp = DSC_BPP(8), .bpc = 10,'):]
section=section[:section.index('.bpp = DSC_BPP(8), .bpc = 12,')]
actual=[tuple(map(int,m)) for m in re.findall(r'\{\s*(-?\d+),\s*(-?\d+),\s*(-?\d+)\s*\}',section)]
assert len(actual)==15 and actual==expected,(actual,expected)
scalars=[int(v) for v in re.search(r'\{\s*([\d, ]+),\s*\{',section)[1].split(',')]
assert scalars==[512,12,6144,7,16,15,15],scalars
(OUT/'dsc-rc-comparison.json').write_text(json.dumps({'vendor_scr1_10bpc_8bpp_matches_mainline_1_2_444':True,
    'all_15_rc_ranges_match':True,'ranges':actual,'mainline_scalars':scalars},indent=2)+'\n')
print('PASS: all 15 DSC RC ranges and expected initial parameters match')

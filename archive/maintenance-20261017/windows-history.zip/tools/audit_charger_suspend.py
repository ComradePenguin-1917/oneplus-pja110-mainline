"""Preserve stock USB suspend/ICL evidence without contacting the phone."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'out/battery-bringup-20261016/charger-source'
assert hashlib.sha256((OUT / 'firmware/qcom/sm8550/xigua/adsp.b18').read_bytes()).hexdigest() == 'a1f79a3901637d9e8e24a69eae838547a05a36977467e52934e8b9fd6b5c8d18'
instructions = {}
for line in (OUT / 'adsp-charger-analysis-only.dis').read_text().splitlines():
    m = re.match(r'^([0-9a-f]+):', line)
    if m:
        instructions[int(m[1], 16)] = line
expected = {
    0x601a2d80: 'cmp.eq(r2,#0x5)',
    0x601a2d98: 'jump:nt 0x601a2dbc',
    0x601a2de4: 'call 0x601951d0',
    0x601a2dfc: 'call 0x601a44a0',
    0x601952cc: 'cmp.eq(r2,#0x0)',
    0x601952e0: 'r1 = #0x2954',
    0x601952f0: 'call 0x60194c30',
    0x60195314: 'cmp.eq(r2,#-0x1)',
    0x60195328: 'r1 = #0x2954',
    0x60195330: 'r3 = #0x0',
    0x60195338: 'call 0x60194c30',
    0x601a44b4: 'call 0x6002cc50',
    0x6002cc64: 'memw(##0x602a885c)',
    0x6002cc80: 'callr r2',
}
for a, text in expected.items():
    assert text in instructions[a], hex(a)
src = (OUT / 'oplus_battery_sm8550.c').read_text()
def function(name):
    match = re.search(r'^static int ' + name + r'\([^;]*?\)\s*\{.*?^}', src, re.M | re.S)
    assert match, name
    return match[0]
functions = {n: function(n) for n in ['smbchg_usb_suspend_enable',
             'smbchg_usb_suspend_disable', 'oplus_chg_hw_init']}
assert 'prop_id, 0)' in functions['smbchg_usb_suspend_enable']
assert 'prop_id, 0xFFFFFFFF)' in functions['smbchg_usb_suspend_disable']
init = functions['oplus_chg_hw_init']
assert init.index('smbchg_usb_suspend_disable()') < init.index('oplus_chg_set_input_current_with_no_aicl(500)') < init.index('smbchg_charging_enable()')
ranges = ['601a2d7c:601a2e08', '601951d0:60195450',
          '601a44a0:601a457c', '6002cc50:6002cd3c',
          '60194c30:60194d40']
r = subprocess.run([sys.executable, str(ROOT / 'tools/inspect_adsp_disassembly.py'), *ranges], capture_output=True, check=True)
(OUT / 'usb-suspend-icl-annotated.dis').write_bytes(r.stdout)
report = {
    'scope': 'offline source and disassembly; no live state inferred',
    'usb_property': 5,
    'suspend_request': 0,
    'unsuspend_sentinel': '0xffffffff (not an amperage)',
    'normal_init_sequence': ['unsuspend (except RF/WLAN boot branch)',
                             'input-current request 500mA', 'charging enable'],
    'firmware_zero_and_minus_one': 'sw_uefi_or_ap_set_usb_icl -> descriptor-dependent masked write at 0x2954, mask 1, values 1 / 0',
    'firmware_positive_current': 'unit conversion -> BattMngrVoteForICL -> registered platform callback',
    'distinct_controls': ['USB input suspend', 'input current vote', 'charger enable'],
    'unknowns': ['Current suspend/enable/vote state', 'Runtime descriptor and transport',
                 'Winning current vote and charger detection outcome'],
    'factory_functions': functions,
    'checked_instructions': {hex(a): instructions[a] for a in expected},
    'phone_modified': False,
}
(OUT / 'usb-suspend-icl-audit.json').write_text(json.dumps(report, indent=2)+'\n')
print('PASS: separate suspend, ICL vote and charge-enable controls; no phone access')

#!/usr/bin/env python3
"""Compare the ABL log from the initramfs-boot attempt against the working boot.

Goal: find what ABL did differently when we handed it our kernel. Since the
partition hashes are unchanged and the device recovered, ABL clearly ran and
made a decision -- this log records it.
"""
import io
import os
import re
import difflib

WS = r'H:\WorkSpace\PJA110-Mainline'
old = io.open(os.path.join(WS, 'bootloader-log.txt'), encoding='utf-8', errors='replace').read()
new = io.open(os.path.join(WS, 'bootloader-log-after-initrd.txt'), encoding='utf-8',
              errors='replace').read()

ol = old.splitlines()
nl = new.splitlines()

print('=== sizes ===')
print('  old (working boot)     : %d bytes, %d lines' % (len(old), len(ol)))
print('  new (after our kernel) : %d bytes, %d lines' % (len(new), len(nl)))

print()
print('=' * 74)
print('LINE DIFF (unified, context 2)')
print('=' * 74)
diff = list(difflib.unified_diff(ol, nl, lineterm='', n=2,
                                 fromfile='working', tofile='after-initrd-kernel'))
if not diff:
    print('  no differences -- ABL produced an identical trace')
for d in diff[:200]:
    print('  %s' % d.rstrip()[:160])

print()
print('=' * 74)
print('KEY EVENTS in the NEW log')
print('=' * 74)
for pat, label in [
    (r'Load Image (\S+) total time', 'partition loads'),
    (r'Apply Overlay', 'dtbo overlay'),
    (r'Update Device Tree', 'device tree update'),
    (r'Cmdline:', 'cmdline'),
    (r'boot state', 'AVB state'),
    (r'Exit boot services|Shutting Down', 'handoff'),
    (r'(?i)error|fail', 'errors'),
]:
    print()
    print('--- %s ---' % label)
    seen = set()
    for l in nl:
        if re.search(pat, l):
            s = l.strip()[:150]
            if s not in seen:
                seen.add(s)
                print('   %s' % s)

print()
print('=' * 74)
print('How did the new log END? (the handoff / failure point)')
print('=' * 74)
for l in nl[-20:]:
    print('   %s' % l.rstrip()[:150])

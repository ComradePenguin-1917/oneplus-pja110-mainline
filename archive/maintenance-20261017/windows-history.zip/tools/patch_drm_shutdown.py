"""Order KMS shutdown before its GPU supplier using the driver-core API."""
from pathlib import Path
import difflib
tree=Path.home()/'workspace/PJA110-Mainline/linux'
out=Path('/mnt/h/workspace/PJA110-Mainline/out/drm-shutdown-20261014/kernel');out.mkdir(parents=True,exist_ok=True)
p=tree/'drivers/gpu/drm/msm/adreno/adreno_device.c';s=p.read_text()
if 'Keep GPU fences progressing until the KMS consumer' in s:
 assert s==(out/'adreno_device.after.c').read_text()
else:
 before=s
 needle='''	ret = dev_pm_opp_of_find_icc_paths(dev, NULL);
	if (ret)
		return ret;

	return 0;
'''
 assert s.count(needle)==1
 s=s.replace(needle,needle.replace('\n\treturn 0;','''
	/* Keep GPU fences progressing until the KMS consumer is shut down. */
	if (!device_link_add(master, dev, DL_FLAG_STATELESS))
		return -ENOMEM;
	dev_info(master, "KMS shutdown ordered before GPU supplier\\n");

	return 0;'''))
 needle='''	if (pm_runtime_enabled(dev))
		WARN_ON_ONCE(adreno_system_suspend(dev));
'''
 assert s.count(needle)==1
 s=s.replace(needle,'\tdevice_link_remove(master, dev);\n\n'+needle)
 (out/'adreno_device.before.c').write_text(before)
 (out/'adreno_device.after.c').write_text(s)
 (out/'shutdown.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='a/drivers/gpu/drm/msm/adreno/adreno_device.c',tofile='b/drivers/gpu/drm/msm/adreno/adreno_device.c')))
 p.write_text(s)
print('Applied stateless KMS-consumer/GPU-supplier device link')

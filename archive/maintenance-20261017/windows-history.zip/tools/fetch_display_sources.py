"""Pin OnePlus's Ace2Pro source branch and fetch display reference files."""
import hashlib
import json
import urllib.request
import urllib.parse
import subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/display-baseline-20261013/oneplus-source'
OUT.mkdir(parents=True,exist_ok=True)
REPO='OnePlusOSS/android_kernel_modules_and_devicetree_oneplus_sm8550'
def get(url):
    request=urllib.request.Request(url,headers={'User-Agent':'PJA110-display-bringup','Accept':'application/vnd.github+json'})
    with urllib.request.urlopen(request,timeout=60) as response: return response.read()
local_git=OUT/'git'
def git(*args):
    return subprocess.run(['git','-C',str(local_git),*args],capture_output=True,check=True).stdout
def api(path):
    if local_git.exists():
        sha=git('rev-parse','HEAD').decode().strip()
        if path.startswith('branches?'):
            return [{'name':git('branch','--show-current').decode().strip(),'commit':{'sha':sha}}]
        if path.startswith('git/trees/'):
            items=[]
            for line in git('ls-tree','-r','HEAD').decode().splitlines():
                metadata,p=line.split('\t',1)
                mode,kind,digest=metadata.split()
                items.append({'path':p,'type':kind,'sha':digest})
            return {'sha':sha,'truncated':False,'tree':items}
    return json.loads(get('https://api.github.com/repos/'+REPO+'/'+path))
branches=[]
for page in range(1,5):
    values=api(f'branches?per_page=100&page={page}')
    branches+=values
    if len(values)<100: break
(OUT/'branches.json').write_text(json.dumps(branches,indent=2)+'\n')
candidates=[b for b in branches if any(t in b['name'].lower() for t in ('ace2pro','ace_2_pro','ace2_pro'))]
if not candidates:
    print('No named Ace2Pro branch; saved branch inventory for manual selection')
    print('\n'.join(b['name'] for b in branches)); raise SystemExit(2)
candidates.sort(key=lambda b:('14.0.0' not in b['name'],b['name']))
branch=candidates[0]
sha=branch['commit']['sha']
tree=api('git/trees/'+sha+'?recursive=1')
assert not tree.get('truncated'), 'incomplete source tree'
(OUT/'tree.json').write_text(json.dumps(tree,indent=2)+'\n')
selected=[]
for item in tree['tree']:
    p=item['path']; low=p.lower()
    if item['type']!='blob': continue
    if (('display' in low and any(t in low for t in ('xigua','aa536','nt37705'))) or
        low.endswith(('/dsi_panel.c','/dsi_parser.c','/dsi_display.c'))):
        selected.append(item)
records=[]
for item in selected:
    path=item['path']
    data=git('show',sha+':'+path) if local_git.exists() else get('https://raw.githubusercontent.com/'+REPO+'/'+sha+'/'+urllib.parse.quote(path))
    assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==item['sha']
    local=OUT/'files'/path; local.parent.mkdir(parents=True,exist_ok=True); local.write_bytes(data)
    records.append({'path':path,'git_blob_sha':item['sha'],'sha256':hashlib.sha256(data).hexdigest()})
(OUT/'manifest.json').write_text(json.dumps({'repo':REPO,'branch':branch['name'],'commit':sha,'files':records},indent=2)+'\n')
print('Pinned branch',branch['name'],sha)
print('Fetched',len(records),'display reference files')

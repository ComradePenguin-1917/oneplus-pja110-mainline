#!/usr/bin/env python3
"""Zero-risk vendor_boot test: patch the base tree's `model` string IN PLACE.

Why this shape: entry0's slot is exactly 502366 bytes and the vendor's tree uses
all of it, so ADDING a property (fdtput) overflows by 52 bytes. Instead, overwrite
the existing `model` string with an equal-length marker.

Properties of this edit:
  * byte-for-byte same length -> totalsize unchanged
  * structure block untouched -> no offset shifts anywhere
  * only ASCII payload bytes change -> cannot corrupt the FDT
  * the tree stays otherwise the vendor's, so ABL's 168 overlay fixups still
    resolve 100% -> the boot stays healthy

If the phone boots and /sys/firmware/devicetree/base/model shows the marker, we
know: writing vendor_boot's dtb section is safe, and ABL uses entry 0 for this
device. That is the prerequisite for installing our own tree.
"""
import hashlib
import os
import struct
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
PAGE = 4096
SRC = os.path.join(WS, 'backup', 'vendor_boot_a.img')
OUT = os.path.join(WS, 'out', 'vendor_boot_a-modelmark.img')

v = bytearray(open(SRC, 'rb').read())
hsize, dtbsize = struct.unpack_from('<2I', v, 28+2048+4+16)
vrsize = struct.unpack_from('<I', v, 24)[0]
dtb_off = (((hsize+PAGE-1)//PAGE)*PAGE + vrsize + PAGE-1)//PAGE*PAGE
e0_size = struct.unpack_from('>I', v, dtb_off+4)[0]
e0 = bytes(v[dtb_off:dtb_off+e0_size])

sys.path.insert(0, os.path.join(WS, 'tools'))
from fdt import FDT

f = FDT(e0)
root = f.nodes()['/']
model = root.get('model', b'')
print('=== current base tree ===')
print('  model   : %r' % model)
print('  length  : %d bytes (incl NUL)' % len(model))

# Build a marker of EXACTLY the same length, NUL-terminated, no embedded NULs.
marker_text = 'XIGUA_VBTEST_A1B2C3D4E5F6G7H8'
body = marker_text[:len(model) - 1].ljust(len(model) - 1, '_')
marker = body.encode('ascii') + b'\0'
assert len(marker) == len(model), (len(marker), len(model))
assert b'\0' not in marker[:-1], 'embedded NUL in marker'
print('  marker  : %r' % marker)
print('  same len: %s' % (len(marker) == len(model)))

# The model value sits in the structure block. Locate it uniquely.
occ = []
start = 0
while True:
    i = e0.find(model, start)
    if i < 0:
        break
    occ.append(i)
    start = i + 1
print('  occurrences of the model string in entry0: %d at %s' % (len(occ), occ))
if len(occ) != 1:
    sys.exit('model string is not unique; refusing to patch')

pos = occ[0]
abs_pos = dtb_off + pos
print('  absolute offset in vendor_boot: 0x%x' % abs_pos)

# Sanity: the bytes immediately before should be the FDT_PROP header
# (len, nameoff) -> 12 bytes: len(4) nameoff(4) then value
hdr = e0[pos-8:pos]
plen, noff = struct.unpack('>2I', hdr)
print('  preceding FDT_PROP: len=%d nameoff=%d  (matches %d: %s)'
      % (plen, noff, len(model), plen == len(model)))
if plen != len(model):
    sys.exit('preceding property header does not look like a string prop')

print()
print('=== patch in place ===')
before = hashlib.sha256(bytes(v)).hexdigest()
v[abs_pos:abs_pos+len(marker)] = marker

# verify nothing outside the marker bytes changed (fast: compare only the two
# regions we care about, plus a bulk equality test on the rest)
w_all = bytes(v)
orig = open(SRC, 'rb').read()
region_before = w_all[:abs_pos]
region_after = w_all[abs_pos+len(marker):]
same_before = region_before == orig[:abs_pos]
same_after = region_after == orig[abs_pos+len(marker):]
print('  bytes before marker identical : %s' % same_before)
print('  bytes after  marker identical : %s' % same_after)
if not (same_before and same_after):
    sys.exit('patch touched bytes outside the marker!')
print('  => only the %d marker bytes changed' % len(marker))

open(OUT, 'wb').write(w_all)

print()
print('=== verify ===')
w = open(OUT, 'rb').read()
print('  size unchanged   : %s' % (len(w) == len(v)))
# full dtb section walk
off = dtb_off
for i in range(4):
    total = struct.unpack_from('>I', w, off+4)[0]
    fj = FDT(w[off:off+total])
    rr = fj.nodes()['/']
    extra = ''
    if i == 0:
        extra = '   <== model now: %r' % rr.get('model', b'')
    print('  entry%d @0x%06x size=%-7d nodes=%-5d %s%s' % (
        i, off, total, len(fj.nodes()),
        rr.get('model', b'').rstrip(b'\0').decode()[:30], extra))
    off += total
print('  walk closed      : %s' % (off == dtb_off + dtbsize))

# confirm the overlays can still resolve against this tree (the whole point)
entries_ok = FDT(w[dtb_off:dtb_off+struct.unpack_from('>I', w, dtb_off+4)[0]])
syms = set(entries_ok.nodes().get('/__symbols__', {}).keys())
print('  __symbols__ count: %d (was 1521 in the original)' % len(syms))

print()
print('  original sha256 : %s' % before)
print('  patched  sha256 : %s' % hashlib.sha256(w).hexdigest())
print()
print('wrote %s' % OUT)
print('NOT FLASHED.')

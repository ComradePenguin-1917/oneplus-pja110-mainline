"""Validate archived live GPT geometry against the native-install inventory."""
import json
from pathlib import Path
import struct
import uuid

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'out/native-install-20261016'
GPT = ROOT/'out/boot-success-20261014/native-after-charge'


def main():
    current = json.loads((GPT/'gpt.json').read_text())
    previous = json.loads((GPT.parent/'native-install-before/gpt.json').read_text())
    inventory = json.loads((OUT/'partitions.json').read_text())
    backups = json.loads((OUT/'backup-verification.json').read_text())
    checked = []
    targets = {}
    renumbered = {}
    def disk_guid(directory, device):
        raw = (directory/f'{device}-primary-header.bin').read_bytes()
        return str(uuid.UUID(bytes_le=raw[56:72]))
    old_by_guid = {disk_guid(GPT.parent/'native-install-before', d['device']):d
                   for d in previous}
    for disk in current:
        primary, secondary = disk['copies']
        assert primary['side']=='primary' and secondary['side']=='backup'
        for c in disk['copies']:
            assert c['signature_valid'] and c['header_crc_valid'] and c['table_crc_valid']
            assert c['current_lba']==c['physical_header_lba']
        assert primary['entries']==secondary['entries']
        assert primary['alternate_lba']==secondary['current_lba']
        assert secondary['alternate_lba']==primary['current_lba']
        header = (GPT/f"{disk['device']}-primary-header.bin").read_bytes()
        first, last = struct.unpack_from('<QQ', header, 40)
        entries = sorted(primary['entries'], key=lambda e:e['start'])
        for i,e in enumerate(entries):
            assert first<=e['start']<=e['end']<=last, e['name']
            if i:
                assert entries[i-1]['end']<e['start'], e['name']
            if e['name'] in inventory:
                n=e['name']
                assert n not in targets, n
                size=(e['end']-e['start']+1)*disk['block_size']
                assert size==inventory[n]['bytes'], n
                assert inventory[n]['device']==disk['device']+str(e['index']+1), n
                targets[n]={'device':inventory[n]['device'], 'bytes':size,
                            'gib':round(size/1024**3, 3), 'start_lba':e['start'],
                            'end_lba':e['end']}
        old = old_by_guid[disk_guid(GPT, disk['device'])]
        assert {k:v for k,v in old.items() if k!='device'}=={k:v for k,v in disk.items() if k!='device'}, f"GPT changed: {disk['device']}"
        if old['device']!=disk['device']:
            renumbered[old['device']]=disk['device']
        checked.append(disk['device'])
    assert targets.keys()==inventory.keys()
    assert len(backups)==20 and all(p['verified'] for p in backups.values())
    result={'gpt_snapshot':str(GPT.relative_to(ROOT)), 'verified_luns':checked,
            'both_gpt_copies_crc_valid_and_entries_identical':True,
            'all_partition_boundaries_valid_no_overlaps':True,
            'gpt_unchanged_since_before_interrupted_reboot':True,
            'device_renumbering_old_to_current':renumbered,
            'inventory_matches_gpt_sizes_and_partition_numbers':True,
            'verified_backup_count':len(backups), 'targets':targets,
            'intended_roles':{'a':'normal postmarketOS', 'b':'standalone rescue'},
            'currently_active_slot':'b', 'phone_partitions_written':False,
            'native_distro_boot_verified':False,
            'interrupted_reboot_timing_test_passed':False}
    (OUT/'partition-audit-result.json').write_text(json.dumps(result,indent=2)+'\n')
    print('PASS: six LUNs, main/backup GPT consistency, boundaries and inventory')
    print('PASS: GPT unchanged; all 20 partition backups verified')
    for name in ['userdata','super','boot_a','init_boot_a','vendor_boot_a','dtbo_a']:
        print(name,targets[name]['device'],targets[name]['gib'],'GiB')


if __name__=='__main__':
    main()

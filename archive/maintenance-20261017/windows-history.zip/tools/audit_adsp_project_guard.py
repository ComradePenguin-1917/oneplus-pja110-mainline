"""Preserve address-level project guard evidence; no device access or writes."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'out/battery-bringup-20261016/charger-source'
raw = OUT / 'firmware/qcom/sm8550/xigua/adsp.b18'
digest = hashlib.sha256(raw.read_bytes()).hexdigest()
assert digest == 'a1f79a3901637d9e8e24a69eae838547a05a36977467e52934e8b9fd6b5c8d18'
dis = (OUT / 'adsp-charger-analysis-only.dis').read_text()
instructions = {}
for line in dis.splitlines():
    match = re.match(r'^([0-9a-f]+):', line)
    if match:
        instructions[int(match[1], 16)] = line

# These checks detect changed evidence; they are not a Hexagon emulator or a
# whole-program proof that no independent access path exists.
expected = {
    0x601a5b04: 'r0 = #0x87',
    0x601a5a18: 'r2 = memw(r2+#0x4)',
    0x601a5e24: 'cmp.eq(r2,##0x5943)',
    0x601a5e28: 'jump:nt 0x601a5ed8',
    0x601a5edc: 'memb(r2+#0x0) = #0x0',
    0x601a5ee4: 'memb(r2+#0x2) = #0x0',
    0x601a5eec: 'memb(r2+#0x1c) = #0x1',
    0x601a5ef4: 'memb(r2+#0x1d) = #0x1',
    0x601a91f4: 'call 0x601a5c10',
    0x601a91f8: 'memb(r0+#0x0)',
    0x601a9204: 'jump:nt 0x601a92a8',
    0x601a92a4: 'jump 0x601a99ac',
    0x6004d520: 'call 0x601a5c10',
    0x6004d524: 'memb(r0+#0x0)',
    0x6004d52c: 'jump:nt 0x6004d57c',
    0x6004d580: 'call 0x601b3910',
    0x601b3954: 'r0 = #0x1',
    0x601b395c: 'call 0x600999d0',
    0x601b397c: 'asl(r2,#0x1)',
}
for address, text in expected.items():
    assert text in instructions[address], hex(address)
inventory = (ROOT / 'out/native-install-20261016/inventory.txt').read_text(errors='replace')
projects = sorted(set(re.findall(r'oplusboot\.prjname=(\d+)', inventory)))
assert projects == ['22851'], projects
source = (OUT / 'oplus_project_qcom.c').read_text()
header = (OUT / 'oplus_project_data_ocdt.h').read_text()
assert re.search(r'#define\s+SMEM_PROJECT\s+135', source)
assert 'ProjectInfoOCDT' in source and 'ProjectDataBCDT nDataBCDT;' in header

ranges = ['601a5950:601a5f10', '601a91d0:601a92a8',
          '601b37f0:601b38e4', '6004cd80:6004ce28',
          '6004d500:6004d680', '601b3910:601b3bcc',
          '600999d0:60099cc0']
result = subprocess.run([sys.executable, str(ROOT / 'tools/inspect_adsp_disassembly.py'),
                         *ranges], capture_output=True, check=True)
(OUT / 'project-22851-gauge-guard-annotated.dis').write_bytes(result.stdout)
report = {
    'scope': 'offline conditional control-flow evidence, not runtime verification',
    'adsp_b18_sha256': digest,
    'phone_project_from_archived_cmdline': 22851,
    'firmware_project_source': {'smem_item': 135, 'project_offset': 4},
    'project_config': {'address': '0x60365234',
                       'byte_0': 0, 'byte_2': 0, 'byte_1c': 1, 'byte_1d': 1},
    'conclusion': 'If SMEM project is 22851, BQ initialization returns before I2C setup; inspected voltage path selects fg_stub_get_voltage -> battman_adc_read(channel 1), doubling its output.',
    'unknowns': ['Actual current-boot SMEM item 135 contents',
                 'Other independent gauge-access paths not exhaustively excluded',
                 'ADC physical channel mapping, calibration and runtime validity',
                 'Temperature/SOC handoff and charger policy requirements'],
    'checked_instructions': {hex(a): instructions[a] for a in expected},
    'phone_modified': False,
}
(OUT / 'project-22851-gauge-guard.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: report[k] for k in ('phone_project_from_archived_cmdline',
                                       'firmware_project_source', 'conclusion',
                                       'phone_modified')}, indent=2))

#!/bin/bash
# Resolve a contradiction that pinpoints the real problem.
#
# Facts:
#   * the vendor DTB's console node IS "qcom,geni-debug-uart", which mainline
#     supports (including OF_EARLYCON_DECLARE)
#   * we pass console=ttyMSM0,115200 earlycon on the cmdline
#   * yet there is ZERO output
#
# If the kernel were running far enough to register the console, we would see
# something. So either:
#   (a) the kernel never executes (bad load address / wrong entry), or
#   (b) it dies before earlycon setup.
#
# (a) is testable: our Image is an EFI-stub kernel. If ABL does not set up the
# EFI environment the way the stub expects, or expects a different entry point,
# it can fail instantly and silently.
#
# Check what kind of kernel the VENDOR ships vs what we built.
set -uo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
TREE="$ROOT/linux"
cd "$TREE"

echo "############ 1) vendor kernel vs ours: format comparison ############"
python3 - <<'PY'
import struct
def hdr(path, label, off=0):
    b = open(path,'rb').read()
    k = b[off:off+64]
    print('--- %s' % label)
    print('    first 16 bytes : %s' % k[:16].hex())
    print('    as ascii       : %r' % k[:8])
    if k[:2] == b'MZ':
        print('    -> PE/COFF EFI application (EFI stub)')
    # arm64 Image header is at offset 0 of the raw Image
    import struct as s
    code0, code1 = s.unpack_from('<2I', k, 0)
    text_off, image_size, flags = s.unpack_from('<3Q', k, 8)
    magic = k[56:60]
    print('    code0          : 0x%08x' % code0)
    print('    text_offset    : 0x%x' % text_off)
    print('    image_size     : %d' % image_size)
    print('    flags          : 0x%x' % flags)
    print('    magic@56       : %r (want b"ARM\\x64")' % magic)

# vendor: strip the boot image header first
b = open('/mnt/h/WorkSpace/PJA110-Mainline/boot-A14.img','rb').read()
ksize = struct.unpack_from('<I', b, 8)[0]
open('/tmp/vendor_Image','wb').write(b[4096:4096+ksize])
hdr('/tmp/vendor_Image', 'VENDOR kernel (stock boot-A14.img)')
print()
hdr('/home/comrade_penguin_desktop/workspace/PJA110-Mainline/out/Image-initrd', 'OUR kernel (Image-initrd)')
PY

echo
echo "############ 2) EFI stub: does the vendor kernel have it? does ours? ############"
echo "--- symbols in our vmlinux ---"
for s in efi_stub_entry efi_header handle_kernel_image efi_enter_kernel; do
    printf '  %-24s ' "$s"
    grep -c " $s\$" System.map 2>/dev/null || echo 0
done
echo
echo "--- our config: EFI options ---"
grep -E '^CONFIG_EFI|^# CONFIG_EFI' .config | sed 's/^/  /'

echo
echo "############ 3) VENDOR config: was their kernel an EFI stub too? ############"
python3 - <<'PY'
import re, struct
b = open('/mnt/h/WorkSpace/PJA110-Mainline/boot-A14.img','rb').read()
ksize = struct.unpack_from('<I', b, 8)[0]
k = b[4096:4096+ksize]
print('  vendor kernel size: %d' % len(k))
# EFI stub kernels contain the string "EFI stub" / PE header
for probe in (b'EFI stub', b'PE/COFF', b'Linux version', b'Booting Linux', b'CONFIG_EFI'):
    print('  %-16s %s' % (probe.decode(), 'found' if probe in k else '-'))
# find the version string
m = re.search(rb'Linux version [\d\.\w\-+]+', k)
print('  version string : %s' % (m.group(0).decode() if m else 'not found'))
# does it have an arm64 Image header at offset 0?
print('  magic@56       : %r' % k[56:60])
print('  text_offset    : 0x%x' % struct.unpack_from('<Q', k, 8)[0])
PY

echo
echo "############ 4) how does ABL decide where to put the kernel? ############"
echo "  vendor boot.img has no 'kernel_addr'; v4 header carries base/os_version."
echo "  ABL prints a load address in its log:"
grep -i 'LinuxLoader Load Address' /mnt/h/WorkSpace/PJA110-Mainline/bootloader-log*.txt | sed 's/^/    /'

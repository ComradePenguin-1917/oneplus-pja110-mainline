#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
TREE="$ROOT/linux"
OUT="$WIN/out/display-timing-20261014"
mkdir -p "$OUT"
export PATH="$ROOT/toolchain/gcc-12-aarch64/usr/bin:$PATH"
export LD_LIBRARY_PATH="$ROOT/toolchain/gcc-12-aarch64/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu-
if [ ! -f "$OUT/Image" ]; then
    cmp "$TREE/arch/arm64/boot/Image" "$WIN/out/dsc-packet-control-20261014/Image"
    if [ ! -f "$OUT/config.before" ]; then
        cmp "$TREE/.config" "$WIN/out/dsc-packet-control-20261014/.config"
    fi
else
    cmp "$TREE/arch/arm64/boot/Image" "$OUT/Image"
    cmp "$TREE/.config" "$OUT/.config"
fi
cmp "$TREE/drivers/gpu/drm/msm/dsi/dsi_host.c" "$WIN/out/dsc-packet-audit-20261014/dsi_host.packet2.c"
cp "$WIN/out/dsc-packet-control-20261014/.config" "$OUT/config.before"
cd "$TREE"
cp "$OUT/config.before" .config
scripts/config --enable FTRACE --enable ENABLE_DEFAULT_TRACERS
scripts/config --disable UPROBE_EVENTS --disable BPF_EVENTS --disable IWLWIFI_DEVICE_TRACING
make olddefconfig > "$OUT/configure.log" 2>&1
grep -q '^CONFIG_ARM64_GCS=y' .config
grep -q '^CONFIG_ARCH_HAS_USER_SHADOW_STACK=y' .config
diff -u "$OUT/config.before" .config > "$OUT/config.patch" || test "$?" = 1
grep -E 'CONFIG_(FTRACE|TRACING|TRACEPOINTS|EVENT_TRACING)=' .config > "$OUT/tracing-config.txt"
make -j8 Image > "$OUT/build.log" 2>&1
cp arch/arm64/boot/Image System.map .config "$OUT/"
sha256sum drivers/gpu/drm/msm/dsi/dsi_host.c drivers/gpu/drm/msm/disp/dpu1/dpu_encoder_phys_cmd.c > "$OUT/display-source.sha256"
echo 'PASS: existing display source retained; standard event tracing enabled'

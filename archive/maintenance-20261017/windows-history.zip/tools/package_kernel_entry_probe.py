"""Redirect the raw ARM64 entry branch to a register-only PSCI reset probe."""
from pathlib import Path
import hashlib
import json
import shutil
import struct
import sys
from bootimg import BootImage
from fdt import FDT

ROOT = Path(__file__).resolve().parents[1]
PRE_MMU = '--pre-mmu' in sys.argv
PROBE = ROOT / 'out/kernel-entry-probe-20261012'
OUT = ROOT / ('out/kernel-pre-mmu-probe-20261012' if PRE_MMU else 'out/kernel-entry-probe-20261012')
OUT.mkdir(exist_ok=True)
BASE = ROOT / 'out/avb-fixup-control-20261012'
known = json.loads((BASE/'manifest.json').read_text())
boot = BootImage.parse(str(BASE/'boot-xigua-r1.img'))
original = boot.kernel
assert hashlib.sha256(original).hexdigest() == 'd8ade08069b8440b349f4b4aeb430dd6e9057eca08c94a8268e3708a83e53425'
assert original[56:60] == b'ARM\x64' and struct.unpack_from('<I', original, 4)[0] & 0xfc000000 == 0x14000000
stub = (PROBE/'probe.bin').read_bytes()
assert 0 < len(stub) < 256 and len(stub) % 4 == 0
assert len(original) % 4 == 0
offset = len(original)
assert offset + len(stub) <= struct.unpack_from('<Q', original, 16)[0]
patch_offset = 4
if PRE_MMU:
    symbols = {}
    for line in (PROBE/'kernel-symbols.txt').read_text().splitlines():
        parts = line.split()
        if len(parts) == 3:
            symbols[parts[2]] = int(parts[0], 16)
    patch_offset = symbols['__enable_mmu'] - symbols['_text'] + 4
    assert struct.unpack_from('<I', original, patch_offset-4)[0] == 0xd503245f
    assert struct.unpack_from('<I', original, patch_offset)[0] == 0xd5380703
branch = 0x14000000 | (((offset - patch_offset)//4) & 0x03ffffff)
modified = bytearray(original) + stub
struct.pack_into('<I', modified, patch_offset, branch)
assert modified[:patch_offset] == original[:patch_offset] and modified[patch_offset+4:len(original)] == original[patch_offset+4:]
(OUT/'Image-probe').write_bytes(modified)
boot.kernel = bytes(modified)
(OUT/'boot-xigua-r1.img').write_bytes(boot.pack(cmdline=boot.cmdline.decode()))
assert BootImage.parse(str(OUT/'boot-xigua-r1.img')).kernel == modified
for name in ('vendor_boot_b-xigua-r1.img', 'init_boot_b-xigua-r1.img', 'dtbo_b-avb-noop.img'):
    assert hashlib.sha256((BASE/name).read_bytes()).hexdigest() == known['files'][name]['sha256']
    shutil.copyfile(BASE/name, OUT/name)
tree = FDT((ROOT/'out/usb2-control-20261012/usb2-control.dtb').read_bytes()).nodes()
assert any(p.get('method') == b'smc\0' and b'psci' in p.get('compatible', b'') for p in tree.values())
manifest = {'experiment': '__enable_mmu redirected before enabling MMU' if PRE_MMU else 'raw ARM64 entry redirected to five-second PSCI SYSTEM_RESET probe',
    'baseline': 'ABL-success fixup control; only boot_b differs',
    'replaced_instruction': original[patch_offset:patch_offset+4].hex(), 'patch_offset': patch_offset, 'probe_offset': offset,
    'probe_bytes': len(stub), 'linux_primary_entry_executed': None if PRE_MMU else False,
    'phone_execution_confirmed': False,
    'files': {name: {'bytes': (OUT/name).stat().st_size,
        'sha256': hashlib.sha256((OUT/name).read_bytes()).hexdigest()}
        for name in ('boot-xigua-r1.img', 'vendor_boot_b-xigua-r1.img',
                     'init_boot_b-xigua-r1.img', 'dtbo_b-avb-noop.img')}}
(OUT/'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
print(json.dumps(manifest, indent=2))

#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
TREE="$ROOT/linux"
WIN=/mnt/h/workspace/PJA110-Mainline
OUT="$WIN/out/display-generator-avb-retest-20261014/reboot-modules"
BUILD="$ROOT/reboot-mode-modules"
export PATH="$ROOT/toolchain/gcc-12-aarch64/usr/bin:$PATH"
export LD_LIBRARY_PATH="$ROOT/toolchain/gcc-12-aarch64/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu-
cmp "$TREE/.config" "$WIN/out/display-port-20261013/kernel.config"
mkdir -p "$OUT" "$BUILD"
cp "$TREE/drivers/power/reset/nvmem-reboot-mode.c" "$BUILD/"
cp "$TREE/drivers/nvmem/qcom-spmi-sdam.c" "$BUILD/"
printf 'obj-m += nvmem-reboot-mode.o\nobj-m += qcom-spmi-sdam.o\n' > "$BUILD/Makefile"
make -C "$TREE" M="$BUILD" KBUILD_EXTRA_SYMBOLS="$TREE/vmlinux.symvers" -j4 modules > "$OUT/build.log" 2>&1
cp "$BUILD/"*.ko "$OUT/"
sha256sum "$OUT/"*.ko > "$OUT/sha256.txt"
echo 'PASS: unmodified upstream nvmem reboot-mode and SPMI SDAM modules built'

#!/usr/bin/env python3
"""Chase the two most promising durable-log leads found in the device tree.

Lead A: /reserved-memory/xbl_dt_log_merged@81a00000   (2.4 MiB, no-map)
        A *reserved RAM* region for XBL/DT logging. Reserved RAM survives a warm
        reset (no power loss). If ABL/XBL writes its log there and Linux can read
        it, we get bootloader-stage visibility.

Lead B: /soc/dmesg-dump  (qcom,dmesg-dump, gunyah-label 7, shared-buffer 0x3c)
        A Gunyah shared-buffer channel used to export the kernel log to a
        "primary VM". On a Gunyah device the owner of that buffer may be ABL or
        the hypervisor, which could mean the log lands somewhere readable.

Earlier I dismissed /proc/vmkmsg as "a live stream", but a live stream that
persists across a warm reboot is exactly what we need. Re-check it properly.

The decisive question for both: WHERE does the data physically live, and does it
outlive a reset?
"""
import os
import shutil
import struct
import subprocess
import sys

ADB = shutil.which('adb') or r'C:\platform-tools\adb.exe'
SERIAL = 'bc7a542e'


def root(cmd, timeout=300):
    r = subprocess.run([ADB, '-s', SERIAL, 'shell', "su -c '%s'" % cmd],
                       capture_output=True, timeout=timeout)
    return ((r.stdout or b'') + (r.stderr or b'')).decode('utf-8', 'replace')


def plain(cmd, timeout=300):
    r = subprocess.run([ADB, '-s', SERIAL, 'shell', cmd], capture_output=True, timeout=timeout)
    return ((r.stdout or b'') + (r.stderr or b'')).decode('utf-8', 'replace')


print('=' * 78)
print('LEAD A: xbl_dt_log_merged (reserved RAM at 0x81a00000, 2.4 MiB)')
print('=' * 78)
print('  is it exposed to userspace at all?')
for p in ('/proc/xbl_dt_log', '/sys/kernel/xbl_dt_log', '/dev/xbl_dt_log'):
    print('    %-28s %s' % (p, root('ls -l %s 2>&1' % p).strip()[:90]))
print()
print('  does the live tree still carry it?')
print('   ', root('ls /sys/firmware/devicetree/base/reserved-memory/ 2>&1 | grep -i xbl').strip()[:200])
print()
print('  can we read that physical range some other way?')
print('    /dev/mem      : %s' % root('ls /dev/mem 2>&1').strip()[:60])
print('    /proc/iomem   : %s' % root('head -c 200 /proc/iomem 2>&1').strip()[:200])

print()
print('=' * 78)
print('LEAD B: /proc/vmkmsg and /proc/bootloader_log (live streams?)')
print('=' * 78)
for p in ('/proc/vmkmsg', '/proc/bootloader_log', '/proc/last_kmsg',
          '/sys/kernel/debug/msm_rtb', '/dev/block/by-name/bootloader_log'):
    info = root('ls -l %s 2>&1' % p).strip()[:110]
    print('  %-40s %s' % (p, info))

print()
print('  /proc/vmkmsg content sample (first 400 bytes):')
print('   ', root('head -c 400 /proc/vmkmsg 2>&1').strip()[:400])
print()
print('  size of /proc/vmkmsg: %s' % root('wc -c /proc/vmkmsg 2>&1').strip()[:80])

print()
print('=' * 78)
print('LEAD C: is there a bootloader_log PARTITION we could read directly?')
print('=' * 78)
print('  partition table entries matching log/boot:')
print(root('ls /dev/block/by-name/ 2>/dev/null | grep -i -E "log|boot|dump|xbl"').strip()[:400])

print()
print('=' * 78)
print('LEAD D: minidump -- the ABL log said "Minidump : ON"')
print('=' * 78)
print('  minidump client dir:')
print('   ', root('ls -la /sys/kernel/debug/minidump* 2>&1').strip()[:200])
print('  minidump related devices:')
print('   ', root('ls /dev/ | grep -i -E "minidump|md_" 2>&1').strip()[:200])
print('  does our DTB or the live tree define minidump regions?')
print('   ', root('ls /sys/firmware/devicetree/base/reserved-memory/ 2>&1 | grep -i -E "minidump|md"').strip()[:200])

print()
print('=' * 78)
print('SUMMARY OF WHAT IS ACTUALLY READABLE')
print('=' * 78)
print('  These were already checked and are dead:')
print('    rawdump / logdump partitions  -> all zeros')
print('    logfs                         -> ABL: "LogFs sync skipped, Unsupported"')
print('    pstore/ramoops                -> proved empty even for Android panics')
print()
print('  Still open and worth one probe each:')
print('    /proc/vmkmsg        -> size and persistence unknown (test now)')
print('    xbl_dt_log_merged   -> reserved RAM; needs a reader')
print('    dmesg-dump          -> Gunyah shared buffer; needs the other VM to expose it')

#!/usr/bin/env python3
"""Risk assessment BEFORE writing to a partition.

We have a well-formed patched vendor_boot. Before flashing, enumerate what could
go wrong and what we still do not know.

Key open questions:
  1. Does ABL verify vendor_boot with AVB? Its log ALREADY reports a hash
     mismatch for vendor_boot_a, and it proceeds anyway (boot state orange).
     => AVB will not block us. Good.
  2. Does ABL use `dtb_size` from the header, or does it walk FDTs? If it walks
     by totalsize, our padding is required (done). If it uses dtb_size only, the
     padding is harmless.
  3. Will ABL apply the dtbo ON TOP of our DTB? The dtbo was authored against
     the vendic DTB's node paths/labels. Applied to our tree, some fragments may
     fail to resolve. What does ABL do then -- ignore the failure, or refuse?
     THIS IS THE BIGGEST RISK.
  4. Does the ramdisk matter? vendor_boot also supplies the vendor ramdisk; we
     keep it intact, so Android still boots even if the DTB is wrong -- as long
     as the DTB does not break ABL itself.
  5. Recovery if it goes wrong: flash back backup/vendor_boot_a.img.

Item 3 is the one to reason about, because the dtbo targets specific paths.
"""
import os
import re
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fdt import FDT, load_entries

WS = r'H:\WorkSpace\PJA110-Mainline'

print('=' * 74)
print('1) AVB: will ABL refuse? (its own log already says no)')
print('=' * 74)
print('   from bootloader-log: "ERROR: vendor_boot_a: Hash of data does not')
print('   match digest in descriptor." + "VB2: boot state: orange"')
print('   => ABL already tolerates a mismatching vendor_boot on this unlocked unit.')

print()
print('=' * 74)
print('2) how does ABL find the DTBs? (walk vs dtb_size)')
print('=' * 74)
print('   we cannot read ABL internals, but both behaviours are satisfied by our')
print('   patched image: entry0 has totalsize == its original slot size, so a')
print('   walk lands exactly on entry1, AND dtb_size is unchanged.')

print()
print('=' * 74)
print('3) THE BIGGEST RISK: the dtbo overlays target the VENDOR tree')
print('=' * 74)
entries, _ = load_entries(os.path.join(WS, 'dtbo-A14.img'))
label, sub = entries[1]
f = FDT(sub)
targets = {}
for p, props in f.nodes().items():
    if p.startswith('/fragment@') and p.count('/') == 2:
        tp = props.get('target-path')
        tgt = props.get('target')
        key = tp.rstrip(b'\0').decode('ascii', 'replace') if tp else (
            'phandle 0x%x' % struct.unpack('>I', tgt[:4])[0] if tgt and len(tgt) >= 4 else '?')
        targets.setdefault(key, 0)
        targets[key] += 1

print('   dtbo %s declares %d fragments targeting:' % (label, sum(targets.values())))
for k, n in sorted(targets.items(), key=lambda x: -x[1])[:8]:
    print('     %-50s x%d' % (k[:50], n))

# do our DTB and the vendor DTB share node paths for the things the dtbo targets?
ours = FDT(open(os.path.join(WS, 'dts', 'sm8550-oneplus-xigua-16G.dtb'), 'rb').read()).nodes()
vendor = FDT(open(os.path.join(WS, 'live-from-device.dtb'), 'rb').read()).nodes()

print()
print('   node-path overlap (vendor live DTB vs ours):')
same = set(vendor) & set(ours)
print('     vendor nodes : %d' % len(vendor))
print('     our nodes    : %d' % len(ours))
print('     common paths : %d' % len(same))
# sample of notable differences
missing_in_ours = [p for p in vendor if p not in ours and p.count('/') <= 2]
print('     vendor top-level nodes absent from ours: %d' % len(missing_in_ours))
for p in sorted(missing_in_ours)[:12]:
    print('       %s' % p)

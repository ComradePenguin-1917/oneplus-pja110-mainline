#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
OUT="$WIN/out/gpu-port-20261014"
TREE="$ROOT/linux"
export PATH="$ROOT/toolchain/gcc-12-aarch64/usr/bin:$PATH"
export LD_LIBRARY_PATH="$ROOT/toolchain/gcc-12-aarch64/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
cp "$TREE/include/uapi/drm/msm_drm.h" "$TREE/include/uapi/drm/drm.h" "$TREE/include/uapi/drm/drm_mode.h" "$OUT/"
aarch64-linux-gnu-gcc -static -no-pie -O2 -Wall -Wextra -D__user= -I"$OUT" "$WIN/tools/mainline_gpu_probe.c" -o "$OUT/gpu-probe" > "$OUT/probe-build.log" 2>&1
if [ "${1:-}" = "--probe-only" ]; then echo 'PASS: updated DRM diagnostic compiled'; exit 0; fi
QEMU="$ROOT/toolchain/qemu/sysroot/usr/bin/qemu-system-aarch64"
export LD_LIBRARY_PATH="$ROOT/toolchain/qemu/sysroot/usr/lib/x86_64-linux-gnu:${LD_LIBRARY_PATH:-}"
export QEMU_DATADIR="$ROOT/toolchain/qemu/sysroot/usr/share/qemu"
timeout 45 "$QEMU" -M virt -cpu cortex-a57 -smp 2 -m 2048 -kernel "$WIN/out/display-generator-avb-retest-20261014/Image" -initrd "$OUT/initramfs-gpu.cpio.gz" -append 'console=ttyAMA0 earlycon=pl011,0x9000000 loglevel=7 rdinit=/init pja.qemu_validation=1' -nographic -no-reboot > "$OUT/qemu-console.txt" 2>&1
grep -q 'QEMU touch modules validated' "$OUT/qemu-console.txt"
grep -q 'QEMU debug userspace validated' "$OUT/qemu-console.txt"
echo 'PASS: GPU probe compiled; #15 boots GPU-firmware archive with preserved touch/SSH; GPU hardware not emulated'

"""Collect and trace RAM-session DRM commits without restarting the desktop."""
from pathlib import Path
import subprocess
import sys
import time

sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/phoc-commit-20261015'
OUT.mkdir(exist_ok=True)
KEYS=ROOT/'out/usb-ncm-20261013/ssh'
SSH=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(KEYS/'client_key_host'),
     '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
     '-o',f'UserKnownHostsFile={KEYS/"known_hosts"}','-o','ConnectTimeout=8','root@169.254.42.1']
def run(cmd,timeout=30):
    p=subprocess.run(SSH+[cmd],capture_output=True,timeout=timeout)
    if p.returncode:
        raise RuntimeError((p.stdout+p.stderr).decode(errors='replace'))
    return p.stdout

stage=sys.argv[1] if len(sys.argv)>1 else 'snapshot'
if stage=='stop-recovered-session':
    data=run('''set -e
test "$(cat /proc/4011/comm)" = phoc
test "$(readlink /proc/4011/root)" = /tmp/postmarketos-ram
cp /tmp/pmos-phosh.log /tmp/pmos-phosh-atomic-before-control.log
kill -TERM 4011
sleep 2
if test -e /proc/4011/comm; then test "$(cat /proc/4011/stat | cut -d ' ' -f 3)" = Z; fi
''')
    (OUT/'atomic-before-control.log').write_bytes(run('cat /tmp/pmos-phosh-atomic-before-control.log'))
    print('Previous compositor stopped gracefully; log preserved')
elif stage=='restore':
    print(run('echo 0 > /sys/module/drm/parameters/debug; test ! -d /sys/kernel/tracing/instances/pja_phoc || echo 0 > /sys/kernel/tracing/instances/pja_phoc/tracing_on; cat /sys/module/drm/parameters/debug; cat /proc/uptime; cat /proc/sys/kernel/printk').decode())
elif stage=='snapshot':
    for name,cmd in {
        'phoc-full.log':'cat /tmp/pmos-phosh.log',
        'dmesg.log':'dmesg',
        'runtime.txt':'''uname -a; cat /proc/uptime; cat /proc/sys/kernel/random/boot_id
cat /proc/mounts
ps
ls /sys/kernel/tracing /sys/kernel/debug /sys/class/drm
chroot /tmp/postmarketos-ram /bin/sh -c 'cat /etc/phosh/phoc.ini; ls /usr/lib/libwlroots*; cat /usr/share/phosh/phoc.ini; command -v strace; command -v wayland-info' || true
''',
        'trace-capabilities.txt':'''grep -q ' /sys/kernel/tracing tracefs ' /proc/mounts || mount -t tracefs tracefs /sys/kernel/tracing
cat /sys/kernel/tracing/available_tracers
grep -E 'drm|msm_atomic|dpu.*(done|timeout|kickoff|flush|vblank)' /sys/kernel/tracing/available_events
test ! -e /sys/kernel/tracing/available_filter_functions || grep -E 'drm_atomic_helper_setup_commit|stall_checks|msm_atomic_commit|drm_mode_atomic_ioctl|drm_atomic_commit|drm_crtc_commit_wait' /sys/kernel/tracing/available_filter_functions
''',
    }.items():
        data=run(cmd)
        (OUT/name).write_bytes(data)
        print(name,len(data),'bytes')
elif stage=='inspect':
    data=run('''cat /sys/module/drm/parameters/debug
ls /sys/kernel/debug/dynamic_debug/control /proc/dynamic_debug/control 2>/dev/null || true
grep -E 'sys_enter_ioctl|sys_exit_ioctl' /sys/kernel/tracing/available_events || true
ls /tmp/postmarketos-ram/usr/bin/*demo* /tmp/postmarketos-ram/usr/bin/*gtk* /tmp/postmarketos-ram/usr/bin/*gl* 2>/dev/null || true
cat /sys/kernel/tracing/events/drm/drm_vblank_event_delivered/format
''')
    (OUT/'inspect.txt').write_bytes(data)
    print(data.decode())
elif stage=='session-inspect':
    data=run('''cat /sys/module/printk/parameters/ignore_loglevel
cat /sys/module/drm/parameters/debug
ps | grep -E 'phoc|phosh'
bus=$(tr '\\0' '\\n' < /proc/454/environ | sed -n 's/^DBUS_SESSION_BUS_ADDRESS=//p')
chroot /tmp/postmarketos-ram /usr/bin/env DBUS_SESSION_BUS_ADDRESS="$bus" /bin/sh -c '
command -v gnome-calculator
ls /usr/share/applications/*alcul* /usr/share/dbus-1/services/*alcul* 2>/dev/null
gdbus introspect --session --dest org.gnome.Shell --object-path /org/gnome/Shell
' || true
''')
    (OUT/'session-inspect.txt').write_bytes(data)
    print(data.decode())
elif stage=='drm-state':
    data=run('''grep -q ' /sys/kernel/debug debugfs ' /proc/mounts || mount -t debugfs debugfs /sys/kernel/debug
cat /sys/kernel/debug/dri/0/state
cat /sys/kernel/debug/dri/0/clients
cat /sys/module/drm/parameters/debug
cat /sys/module/printk/parameters/ignore_loglevel
cat /sys/kernel/tracing/instances/pja_phoc/tracing_on
cat /sys/kernel/tracing/instances/pja_phoc/events/enable
''')
    (OUT/'drm-state.txt').write_bytes(data)
    print(data.decode())
elif stage=='legacy-result':
    data=run('''set -e
test "$(cat /proc/5524/comm)" = phoc
tr '\\0' '\\n' < /proc/5524/environ | grep '^WLR_DRM_NO_ATOMIC=1$'
cat /tmp/pmos-phosh.log
echo '=== GPU ==='
cat /sys/kernel/debug/dri/0/gpu | head -n 22
echo '=== SETTINGS ==='
cat /sys/module/drm/parameters/debug
cat /sys/kernel/tracing/instances/pja_phoc/tracing_on
cat /proc/sys/kernel/random/boot_id
''')
    (OUT/'legacy-result.txt').write_bytes(data)
    errors=[line for line in data.decode().splitlines() if any(s in line for s in ('Atomic commit failed','Page-flip failed','Failed to page-flip','drmModeSetCrtc failed'))]
    print('legacy mode confirmed; display commit errors:',len(errors))
    for line in errors: print(line)
    print(data.decode().split('=== GPU ===')[-1])
elif stage=='cleanup-apps':
    # Only calculators opened by the two recorded automatic test runs.
    pids=[2516,2587,2640,2695,2748,2800,2851,2904,2959,3011,3066,3118,
          3199,3252,3306,3360,3415,3468,3519,3571,3622,3677,3732,3785]
    commands=[]
    for pid in pids:
        commands.append(f'if test "$(cat /proc/{pid}/comm 2>/dev/null)" = gnome-calculato && test "$(readlink /proc/{pid}/root)" = /tmp/postmarketos-ram; then kill -TERM {pid}; fi')
    commands.append('cat /sys/module/drm/parameters/debug; cat /sys/module/printk/parameters/ignore_loglevel; cat /sys/kernel/tracing/instances/pja_phoc/tracing_on; cat /sys/kernel/tracing/instances/pja_phoc/events/enable; cat /proc/sys/kernel/random/boot_id; ps | grep -E "phoc|phosh|gnome-calculato"')
    data=run('\n'.join(commands))
    (OUT/'final-state.txt').write_bytes(data)
    print(data.decode())
elif stage=='debug-watch':
    data=run('''set -e
p=/sys/module/drm/parameters/debug
old=$(cat "$p")
trap 'echo "$old" > "$p"' EXIT HUP INT TERM
echo 16 > "$p"
sleep 30
echo "$old" > "$p"
dmesg > /tmp/pmos-drm-debug.log
''',timeout=40)
    data=run('cat /tmp/pmos-drm-debug.log')
    (OUT/'drm-debug.log').write_bytes(data)
    print('Atomic debug log saved; original DRM debug setting restored')
elif stage=='exercise':
    data=run('''set -e
p=/sys/module/drm/parameters/debug
old=$(cat "$p")
trap 'echo "$old" > "$p"' EXIT HUP INT TERM
test "$(cat /proc/454/comm)" = phosh
bus=$(tr '\\0' '\\n' < /proc/454/environ | sed -n 's/^DBUS_SESSION_BUS_ADDRESS=//p')
test -n "$bus"
echo 16 > "$p"
chroot /tmp/postmarketos-ram /usr/bin/env DBUS_SESSION_BUS_ADDRESS="$bus" XDG_RUNTIME_DIR=/run/user/0 WAYLAND_DISPLAY=wayland-0 /bin/sh -c '
i=0
while test "$i" -lt 8; do
gapplication launch org.gnome.Calculator
sleep 1
gapplication launch org.gnome.Settings
sleep 1
i=$((i+1))
done' > /tmp/pmos-exercise.log 2>&1
echo "$old" > "$p"
dmesg > /tmp/pmos-drm-exercise.log
cat /tmp/pmos-exercise.log
''',timeout=55)
    (OUT/'exercise.txt').write_bytes(data)
    (OUT/'drm-exercise.log').write_bytes(run('cat /tmp/pmos-drm-exercise.log'))
    print('Application switching finished; DRM debug restored')
elif stage=='quiet-watch':
    data=run('''set -e
p=/sys/module/drm/parameters/debug
old=$(cat "$p")
console=$(cat /proc/sys/kernel/printk)
trap 'echo "$old" > "$p"; echo "$console" > /proc/sys/kernel/printk' EXIT HUP INT TERM
echo 4 > /proc/sys/kernel/printk
echo 16 > "$p"
sleep 45
echo "$old" > "$p"
echo "$console" > /proc/sys/kernel/printk
dmesg > /tmp/pmos-drm-quiet.log
''',timeout=55)
    (OUT/'drm-quiet.log').write_bytes(run('cat /tmp/pmos-drm-quiet.log'))
    print('Quiet-console atomic capture saved; both settings restored')
elif stage=='controlled-loop':
    data=run('''set -e
p=/sys/module/drm/parameters/debug
old=$(cat "$p")
console=$(cat /proc/sys/kernel/printk)
ignore=$(cat /sys/module/printk/parameters/ignore_loglevel)
reader=
trap 'echo "$old" > "$p"; echo "$console" > /proc/sys/kernel/printk; echo "$ignore" > /sys/module/printk/parameters/ignore_loglevel; test -z "$reader" || kill "$reader" 2>/dev/null || true' EXIT HUP INT TERM
bus=$(tr '\\0' '\\n' < /proc/454/environ | sed -n 's/^DBUS_SESSION_BUS_ADDRESS=//p')
test -n "$bus"
echo N > /sys/module/printk/parameters/ignore_loglevel
echo 4 > /proc/sys/kernel/printk
cat /dev/kmsg > /tmp/pmos-kmsg-stream.log &
reader=$!
echo 16 > "$p"
chroot /tmp/postmarketos-ram /usr/bin/env DBUS_SESSION_BUS_ADDRESS="$bus" XDG_RUNTIME_DIR=/run/user/0 WAYLAND_DISPLAY=wayland-0 /bin/sh -c '
i=0
while test "$i" -lt 12; do
gtk-launch org.gnome.Calculator
sleep 1
gtk-launch org.gnome.Settings
sleep 1
i=$((i+1))
done' > /tmp/pmos-controlled-loop.log 2>&1
echo "$old" > "$p"
kill "$reader" 2>/dev/null || true
wait "$reader" 2>/dev/null || true
reader=
echo "$console" > /proc/sys/kernel/printk
echo "$ignore" > /sys/module/printk/parameters/ignore_loglevel
dmesg > /tmp/pmos-controlled-drm.log
cat /sys/module/drm/parameters/debug
cat /sys/module/printk/parameters/ignore_loglevel
''',timeout=50)
    (OUT/'controlled-loop.txt').write_bytes(data)
    (OUT/'drm-controlled.log').write_bytes(run('cat /tmp/pmos-controlled-drm.log'))
    (OUT/'kmsg-controlled.log').write_bytes(run('cat /tmp/pmos-kmsg-stream.log'))
    (OUT/'controlled-apps.log').write_bytes(run('cat /tmp/pmos-controlled-loop.log'))
    print('Controlled application switching done; all three settings restored')
elif stage=='trace-start':
    data=run('''set -e
t=/sys/kernel/tracing/instances/pja_phoc
mkdir -p "$t"
echo 0 > "$t/tracing_on"
echo 0 > "$t/events/enable"
echo 4096 > "$t/buffer_size_kb"
echo mono > "$t/trace_clock"
echo > "$t/trace"
for g in drm_msm_atomic drm; do
test ! -e "$t/events/$g/enable" || echo 1 > "$t/events/$g/enable"
done
for e in dpu_enc_phys_cmd_pp_tx_done dpu_enc_wait_event_timeout dpu_enc_frame_done_timeout; do
test ! -e "$t/events/dpu/$e/enable" || echo 1 > "$t/events/dpu/$e/enable"
done
echo 1 > "$t/tracing_on"
cat /proc/uptime
date
''')
    (OUT/'trace-start.txt').write_bytes(data)
    print(data.decode())
elif stage=='trace-stop':
    data=run('''t=/sys/kernel/tracing/instances/pja_phoc
echo 0 > "$t/tracing_on"
cat "$t/trace"
echo 0 > "$t/events/enable"
''')
    (OUT/'trace.txt').write_bytes(data)
    data=run('cat /tmp/pmos-phosh.log')
    (OUT/'phoc-after.log').write_bytes(data)
    print('trace and complete Phoc log saved')
else:
    raise SystemExit('snapshot|trace-start|trace-stop')

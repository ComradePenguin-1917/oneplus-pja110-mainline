#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
TREE="$ROOT/linux"
OUT="$WIN/out/display-timing-20261014"
BUILD="$ROOT/display-trace-touch-module"
SPIBUILD="$ROOT/display-trace-spi-module"
export PATH="$ROOT/toolchain/gcc-12-aarch64/usr/bin:$PATH"
export LD_LIBRARY_PATH="$ROOT/toolchain/gcc-12-aarch64/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu-
mkdir -p "$BUILD" "$SPIBUILD"
cmp "$TREE/.config" "$OUT/.config"
cp "$WIN/drivers/input/touchscreen/synaptics-aston-rate/"* "$BUILD/"
cp "$TREE/drivers/spi/spi-geni-qcom.c" "$SPIBUILD/"
printf 'obj-m := spi-geni-qcom.o\n' > "$SPIBUILD/Makefile"
make -C "$TREE" M="$SPIBUILD" KBUILD_EXTRA_SYMBOLS="$TREE/vmlinux.symvers" -j4 modules > "$OUT/spi-modules.log" 2>&1
make -C "$TREE" M="$BUILD" KBUILD_EXTRA_SYMBOLS="$TREE/vmlinux.symvers" -j4 modules > "$OUT/touch-modules.log" 2>&1
cp "$SPIBUILD/spi-geni-qcom.ko" "$BUILD/synaptics-aston.ko" "$OUT/"
cmp "$TREE/arch/arm64/boot/Image" "$OUT/Image"
echo 'PASS: existing SPI/Aston modules rebuilt for trace config; Image unchanged'

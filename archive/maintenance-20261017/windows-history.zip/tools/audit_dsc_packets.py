"""Compare captured DSC packet registers with pinned factory formulas."""
import json,re
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/dsc-packet-audit-20261014'
OUT.mkdir(parents=True,exist_ok=True)
source=ROOT/'out/te-height-control-20261014/runtime/kms-registers.txt'
text=source.read_text().split('====================dsi0_ctrl================')[1].split('====================')[0]
regs={}
for line in text.splitlines():
    m=re.fullmatch(r'0x([0-9a-f]+) : ((?:[0-9a-f]{8} ?)+)',line)
    if m:
        regs.update({int(m[1],16)+4*i:int(v,16) for i,v in enumerate(m[2].split())})
ctrl=regs[0x2a4]&0xffff
assert ctrl&1 and (ctrl>>8)&0x3f==0x39
packets_per_line=1<<((ctrl>>6)&3)
slice_bytes=regs[0x2a8]&0xffff
word_count=regs[0x54]>>16
assert slice_bytes==620 and word_count==621 and packets_per_line==2
expected_ctrl=(ctrl&~(3<<6))
expected_stream=(regs[0x54]&0xffff)|((slice_bytes*2+1)<<16)
assert expected_ctrl==0x3911 and expected_stream==0x04d90039
result={
 'source_register_dump':str(source.relative_to(ROOT)),
 'factory_commit':'f034653c086942be9398171cfa7477ddbe2d9504',
 'current':{'slices_per_packet':1,'packets_per_line':packets_per_line,
 'slice_bytes':slice_bytes,'payload_bytes_per_packet':word_count-1,
 'dcs_word_count':word_count,'eol_bytes':(ctrl>>4)&3},
 'factory_formula_expected':{'slices_per_packet':2,'packets_per_line':1,
 'slice_bytes':620,'payload_bytes_per_packet':1240,'dcs_word_count':1241,'eol_bytes':1},
 'register_changes_expected':{
  'command_compression_stream0_low16':['0x%04x'%ctrl,'0x%04x'%expected_ctrl],
  'command_mdp_stream0_ctrl':['0x%08x'%regs[0x54],'0x%08x'%expected_stream]},
 'must_remain_unchanged':['slice width register 620','MDP stream total 0x0ad400cf',
                         'DSC PPS and rate control','TE height 65520'],
 'partitions_written':False,'hardware_fix_confirmed':False,
}
(OUT/'packet-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
# Prepare a reviewable board-specific control; do not edit the build tree.
before=(ROOT/'out/weston-kms-diagnosis-20261014/dsi_host-current.c').read_text()
after=before
needle='static void dsi_update_dsc_timing('
assert before.count(needle)==1
helper='''/* Diagnostic AA536 control: factory packetization, command mode only. */
static u32 dsi_dsc_slices_per_packet(struct msm_dsi_host *msm_host,
                                    u32 hdisplay)
{
    u32 slices = msm_dsc_get_slices_per_intf(msm_host->dsc, hdisplay);
    struct device_node *panel;
    bool aa536;

    if (msm_host->mode_flags & MIPI_DSI_MODE_VIDEO)
        return 1;
    panel = of_find_compatible_node(NULL, NULL, "oneplus,aa536-p-3-a0001");
    aa536 = panel != NULL;
    of_node_put(panel);
    /* Factory fallback for a partial interface containing only one slice. */
    return aa536 && slices >= 2 && !(slices % 2) ? 2 : 1;
}

'''
after=after.replace(needle,helper+needle)
after=after.replace('u32 bytes_per_pkt;','u32 bytes_per_pkt;\n\tu32 slice_per_pkt;',1)
after=after.replace('bytes_per_pkt = dsc->slice_chunk_size; /* * slice_per_pkt; */',
 'slice_per_pkt = dsi_dsc_slices_per_packet(msm_host, hdisplay);\n\tbytes_per_pkt = dsc->slice_chunk_size * slice_per_pkt;',1)
start=after.index('\t/*\n\t * Typically, pkt_per_line')
end=after.index('\n\n\tif (is_cmd_mode)',start)
after=after[:start]+'\t/* Factory formula: divide interface slices by slices per packet. */\n\tpkt_per_line = slice_per_intf / slice_per_pkt;'+after[end:]
start=after.index('\t\telse\n\t\t\t/*\n\t\t\t * When DSC is enabled, WC')
end=after.index('\n\n\t\tdsi_write(msm_host, REG_DSI_CMD_MDP_STREAM0_CTRL',start)
after=after[:start]+'''\t\telse
\t\t\twc = msm_host->dsc->slice_chunk_size *
\t\t\t\tdsi_dsc_slices_per_packet(msm_host, mode->hdisplay) + 1;'''+after[end:]
import difflib
(OUT/'dsi_host.packet2.c').write_text(after)
(OUT/'packet2-only.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/drivers/gpu/drm/msm/dsi/dsi_host.c',tofile='b/drivers/gpu/drm/msm/dsi/dsi_host.c')))
print(json.dumps(result,indent=2))

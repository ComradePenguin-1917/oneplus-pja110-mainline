#!/usr/bin/env python3
"""Extract the stock kernel's real config; the previous attempt mis-handled the
gzip/zlib framing.

Android GKI kernels normally DO embed IKCONFIG (gzip-compressed) between the
IKCFG_ST and IKCFG_ED markers. Getting the real values settles whether the stock
kernel can execute our initramfs -- the question that decides whether the
"stock kernel + our initramfs" test is meaningful.
"""
import gzip
import io
import os
import re
import zlib

WS = r'H:\WorkSpace\PJA110-Mainline'
k = open(os.path.join(WS, 'out', 'stock-kernel.bin'), 'rb').read()

i = k.find(b'IKCFG_ST')
j = k.find(b'IKCFG_ED', i)
print('IKCFG_ST at 0x%x, IKCFG_ED at 0x%x' % (i, j))
blob = k[i + 8:j if j > 0 else i + 400000]
print('payload: %d bytes, first 4 = %s' % (len(blob), blob[:4].hex()))

cfg = None
# case 1: gzip
if blob[:2] == b'\x1f\x8b':
    try:
        cfg = gzip.GzipFile(fileobj=io.BytesIO(blob)).read()
        print('gzip OK: %d bytes' % len(cfg))
    except Exception as e:
        print('gzip failed: %s' % e)
# case 2: raw deflate / zlib
if cfg is None:
    for wbits, name in ((15, 'zlib'), (-15, 'raw deflate'), (47, 'gzip(auto)')):
        try:
            cfg = zlib.decompressobj(wbits).decompress(blob)
            if cfg:
                print('%s OK: %d bytes' % (name, len(cfg)))
                break
        except Exception as e:
            print('%s failed: %s' % (name, e))
# case 3: uncompressed config text straight after the marker
if cfg is None and b'CONFIG_' in blob[:2000]:
    cfg = blob
    print('appears to be uncompressed config text')

if not cfg:
    raise SystemExit('could not extract the config')

p = os.path.join(WS, 'out', 'stock-kernel.config')
open(p, 'wb').write(cfg)
print('saved -> %s' % p)

vals = {}
for line in cfg.decode('utf-8', 'replace').splitlines():
    line = line.strip()
    if '=' in line and not line.startswith('#'):
        a, b = line.split('=', 1)
        vals[a] = b
    elif line.startswith('# ') and 'is not set' in line:
        vals[line[2:].split(' ')[0]] = 'NOT SET'

print()
print('=== can the STOCK kernel run our initramfs? ===')
groups = {
    'initramfs / early userspace': [
        'CONFIG_BLK_DEV_INITRD', 'CONFIG_RD_GZIP', 'CONFIG_INITRAMFS_SOURCE',
        'CONFIG_DEVTMPFS', 'CONFIG_DEVTMPFS_MOUNT', 'CONFIG_TMPFS', 'CONFIG_PROC_FS',
        'CONFIG_SYSFS',
    ],
    'USB gadget (needed for the adb/network channel)': [
        'CONFIG_USB_GADGET', 'CONFIG_USB_CONFIGFS', 'CONFIG_CONFIGFS_FS',
        'CONFIG_USB_CONFIGFS_ECM', 'CONFIG_USB_CONFIGFS_RNDIS',
        'CONFIG_USB_CONFIGFS_NCM', 'CONFIG_USB_LIBCOMPOSITE',
        'CONFIG_USB_DWC3', 'CONFIG_USB_DWC3_QCOM',
    ],
    'signalling (needed for the poweroff ladder)': [
        'CONFIG_MAGIC_SYSRQ', 'CONFIG_PM', 'CONFIG_ARM64',
    ],
}
for g, keys in groups.items():
    print()
    print('--- %s' % g)
    for key in keys:
        v = vals.get(key, '(absent)')
        mark = '  <== YES' if v == 'y' else ('  <== MODULE (not in our initramfs!)' if v == 'm' else '')
        print('  %-38s %s%s' % (key, v, mark))

print()
print('=== verdict ===')
initrd_ok = vals.get('CONFIG_BLK_DEV_INITRD') == 'y'
gadget_ok = all(vals.get(x) == 'y' for x in
                ('CONFIG_USB_CONFIGFS', 'CONFIG_USB_LIBCOMPOSITE'))
print('  initramfs usable : %s' % initrd_ok)
print('  gadget built-in  : %s' % gadget_ok)
print()
if initrd_ok:
    print('  => the stock kernel CAN consume our initramfs, so the test is valid:')
    print('     boot the stock kernel with OUR initramfs and watch for the poweroff')
    print('     signal. That validates our initramfs, busybox and /init for real.')
if not gadget_ok:
    print('  => USB gadget pieces are modules, and our initramfs carries no modules,')
    print('     so USB will NOT come up in that test. Fine: the poweroff signal is')
    print('     what we are after, and it needs no drivers.')

"""Show captured GPU pixels through the proven fbdev layout, in RAM only."""
import hashlib,json,subprocess
from pathlib import Path
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/gpu-scanout-readback-20261014'
KEYS=ROOT/'out/usb-ncm-20261013/ssh'
SSH=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(KEYS/'client_key_host'),
     '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
     '-o',f'UserKnownHostsFile={KEYS/"known_hosts"}','-o','ConnectTimeout=5','root@169.254.42.1']
def read(cmd,data=None):
    p=subprocess.run(SSH+[cmd],input=data,capture_output=True,timeout=30);p.check_returncode();return p.stdout
state=read('cat /sys/class/graphics/fb0/virtual_size; cat /sys/class/graphics/fb0/bits_per_pixel; cat /sys/class/graphics/fb0/stride')
values=state.decode().splitlines();assert values==['1240,2772','32','4992'],values
im=Image.open(OUT/'gpu-bo-readback.ppm').convert('RGB');assert im.size==(1240,2772)
bgra=im.tobytes('raw','BGRX');rows=bytearray()
for y in range(2772):rows+=bgra[y*4960:(y+1)*4960]+bytes(32)
digest=hashlib.sha256(rows).hexdigest()
assert read('cat > /tmp/gpu-capture-fb.raw; sha256sum /tmp/gpu-capture-fb.raw',rows).decode().split()[0]==digest
read('set -e; /tmp/fb-pattern --unblank; echo 1024 > /sys/class/backlight/ae94000.dsi.0/brightness; dd if=/tmp/gpu-capture-fb.raw of=/dev/fb0 bs=4992 count=2772 conv=fsync')
(OUT/'fb-copy-state.txt').write_bytes(state)
(OUT/'fb-copy.json').write_text(json.dumps(dict(input='gpu-bo-readback.ppm',stride=4992,
    raw_sha256=digest,partitions_written=False,visual_confirmation_pending=True),indent=2)+'\n')
print('PASS: same captured GPU frame copied into fbdev at verified stride 4992; awaiting screen observation')

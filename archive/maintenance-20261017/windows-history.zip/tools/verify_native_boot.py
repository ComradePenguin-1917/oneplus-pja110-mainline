"""Capture native-phone boot evidence and stage guarded slot-success command."""
import hashlib
import json
import subprocess
from prepare_native_install import ROOT, OUT

dest = OUT/'first-native-boot'
ssh = ['C:/Windows/System32/OpenSSH/ssh.exe', '-F', 'none', '-T', '-i',
       str(ROOT/'out/usb-ncm-20261013/ssh/client_key_host'), '-o', 'BatchMode=yes',
       '-o', 'IdentitiesOnly=yes', '-o', 'StrictHostKeyChecking=yes', '-o',
       f'UserKnownHostsFile={dest/"known_hosts"}', '-o', 'ConnectTimeout=8', 'penguin@172.16.42.1']

def run(cmd, data=None):
    p = subprocess.run(ssh+[cmd], input=data, capture_output=True, timeout=30)
    if p.returncode:
        raise RuntimeError(p.stderr.decode(errors='replace'))
    return p.stdout

state = run('uname -a; cat /proc/1/comm; cat /proc/sys/kernel/random/boot_id; cat /proc/cmdline; findmnt /; findmnt /boot; losetup -l; df -h / /boot; systemctl is-system-running; systemctl --failed --no-pager; pgrep -a phoc; pgrep -a phosh; cat /proc/bus/input/devices')
assert b'6.14.0-oneplus-xigua' in state and b'\nsystemd\n' in state
assert b'/dev/loop0p2 ext4' in state and b'/dev/sda14' in state
assert b'\nrunning\n' in state and b'0 loaded units listed' in state
(dest/'native-system-state.txt').write_bytes(state)
binary = (ROOT/'out/boot-success-20261014/qbootctl-aarch64').read_bytes()
remote = run('cat > /home/penguin/native-qbootctl; chmod 755 /home/penguin/native-qbootctl; sha256sum /home/penguin/native-qbootctl', binary)
digest = hashlib.sha256(binary).hexdigest()
assert remote.decode().split()[0] == digest
script = '''#!/bin/sh
set -eu
test "$(id -u)" = 0
test "$(uname -r)" = 6.14.0-oneplus-xigua
test "$(cat /proc/1/comm)" = systemd
test "$(findmnt -n -o SOURCE /)" = /dev/loop0p2
test "$(sha256sum /home/penguin/native-qbootctl | cut -d ' ' -f 1)" = DIGEST
/home/penguin/native-qbootctl -a | grep -F 'Active slot: _a'
/home/penguin/native-qbootctl -m 0
sync
/home/penguin/native-qbootctl -n 0
/home/penguin/native-qbootctl -n 1
'''.replace('DIGEST', digest).encode()
run('cat > /home/penguin/mark-native-boot-success.sh; chmod 755 /home/penguin/mark-native-boot-success.sh', script)
result = {'native_phone_boot_verified': True, 'kernel': '6.14.0-oneplus-xigua',
          'pid1': 'systemd', 'root_backing_partition': 'userdata',
          'authenticated_penguin_ssh_verified': True, 'systemd_failed_units': 0,
          'user_confirmed_desktop_display_touch': True,
          'rootfs_autoexpanded': True, 'boot_success_mark_verified': False}
(dest/'native-boot-result.json').write_text(json.dumps(result, indent=2)+'\n')
for path in (OUT/'rootfs-deployment/result.json', OUT/'native-images/manifest.json', OUT/'deployment/result.json'):
    value = json.loads(path.read_text())
    value['native_phone_boot_verified'] = True
    path.write_text(json.dumps(value, indent=2)+'\n')
print('Native boot evidence saved; guarded success-mark script staged for sudo authentication')

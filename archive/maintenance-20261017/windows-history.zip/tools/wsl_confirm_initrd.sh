#!/bin/bash
# Rigorously confirm the packed boot image carries a working embedded initramfs.
#
# The earlier detector said "not detected" while the file sizes clearly grew by
# ~1.18 MB, so the detector is suspect -- not the image. Pin it down exactly.
set -uo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
OUT="$ROOT/out"

echo "=== size arithmetic (independent of any parser) ==="
echo "  Image WITHOUT initramfs : 33167872  (known from the previous build)"
echo "  Image WITH initramfs    : $(stat -c%s "$OUT/Image-initrd")"
echo "  delta                   : $(( $(stat -c%s "$OUT/Image-initrd") - 33167872 ))"
echo "  our initramfs.cpio.gz   : $(stat -c%s "$ROOT/initramfs/initramfs.cpio.gz")"

echo
echo "=== does the Image contain our cpio payload? (decompress and search) ==="
python3 - <<'PY'
import gzip, io, re, sys

img = open('/home/comrade_penguin_desktop/workspace/PJA110-Mainline/out/Image-initrd','rb').read()
print('  Image: %d bytes' % len(img))

gzs = [m.start() for m in re.finditer(rb'\x1f\x8b\x08', img)]
print('  gzip magics found: %d' % len(gzs))

hit = None
for off in gzs:
    stream = img[off:]
    try:
        gz = gzip.GzipFile(fileobj=io.BytesIO(stream))
        # read in chunks to avoid any read-size quirks, and stop if it explodes
        buf = bytearray()
        while len(buf) < 8_000_000:
            chunk = gz.read(1 << 20)
            if not chunk:
                break
            buf += chunk
    except Exception as e:
        print('    off 0x%08x: %s' % (off, e))
        continue
    has_bb = b'busybox' in buf
    has_init = b'[initramfs]' in buf
    if has_bb or has_init:
        print('    off 0x%08x -> %d bytes  busybox=%s our_init=%s' % (off, len(buf), has_bb, has_init))
        hit = off
        open('/tmp/chk.cpio','wb').write(bytes(buf))
        break
    else:
        print('    off 0x%08x -> %d bytes (not ours)' % (off, len(buf)))

print()
print('  RESULT: %s' % ('FOUND at 0x%x' % hit if hit is not None else 'NOT FOUND'))
sys.exit(0 if hit is not None else 1)
PY
rc=$?

if [ $rc -eq 0 ] && [ -f /tmp/chk.cpio ]; then
    echo
    echo "=== the extracted payload really is our initramfs ==="
    echo "  entries: $(cpio -t < /tmp/chk.cpio 2>/dev/null | wc -l)"
    for f in init bin/busybox bin/sh bin/mount bin/ip bin/telnetd bin/udhcpd; do
        printf '    %-16s %s\n' "$f" "$(cpio -t < /tmp/chk.cpio 2>/dev/null | grep -cx "$f")"
    done
    echo
    echo "  --- /init head ---"
    rm -rf /tmp/e2 && mkdir -p /tmp/e2 && (cd /tmp/e2 && cpio -idm < /tmp/chk.cpio 2>/dev/null)
    head -4 /tmp/e2/init | sed 's/^/    /'
    echo
    echo "  --- verify the busybox inside the archive is aarch64 static ---"
    file /tmp/e2/bin/busybox 2>/dev/null | sed 's/^/    /'
fi

echo
echo "=== also confirm via the boot image's kernel field ==="
python3 - <<'PY'
import struct
b = open('/home/comrade_penguin_desktop/workspace/PJA110-Mainline/out/boot-xigua-initrd.img','rb').read()
ksize = struct.unpack_from('<I', b, 8)[0]
k = b[4096:4096+ksize]
img = open('/home/comrade_penguin_desktop/workspace/PJA110-Mainline/out/Image-initrd','rb').read()
print('  boot.img kernel field == Image-initrd + DTB: %s'
      % (k[:len(img)] == img))
PY

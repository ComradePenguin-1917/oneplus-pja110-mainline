#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
PREFIX="$ROOT/toolchain/gcc-12-aarch64"
OUT="$WIN/out/kernel-entry-probe-20261012"
if [ "${1:-}" = '--qemu-pre-mmu' ]; then
    OUT="$WIN/out/kernel-pre-mmu-probe-20261012"
elif [ "${1:-}" = '--qemu-post-mmu' ]; then
    OUT="$WIN/out/kernel-post-mmu-probe-20261012"
elif [ "${1:-}" = '--qemu-virtual-switch' ]; then
    OUT="$WIN/out/kernel-virtual-switch-probe-20261012"
elif [ "${1:-}" = '--qemu-start-kernel' ]; then
    OUT="$WIN/out/kernel-start-kernel-probe-20261012"
elif [ "${1:-}" = '--qemu-after-setup-arch' ]; then
    OUT="$WIN/out/kernel-after-setup-arch-probe-20261012"
elif [ "${1:-}" = '--qemu-after-sched-init' ]; then
    OUT="$WIN/out/kernel-after-sched-init-probe-20261012"
elif [ "${1:-}" = '--qemu-after-init-irq' ]; then
    OUT="$WIN/out/kernel-after-init-irq-probe-20261012"
elif [ "${1:-}" = '--qemu-before-rest-init' ]; then
    OUT="$WIN/out/kernel-before-rest-init-probe-20261012"
elif [ "${1:-}" = '--qemu-after-initcalls' ]; then
    OUT="$WIN/out/kernel-after-initcalls-probe-20261012"
elif [ "${1:-}" = '--qemu-after-kernel-init-freeable' ]; then
    OUT="$WIN/out/kernel-after-kernel-init-freeable-probe-20261012"
elif [ "${1:-}" = '--qemu-after-async-sync' ]; then
    OUT="$WIN/out/kernel-after-async-sync-probe-20261012"
elif [ "${1:-}" = '--qemu-after-free-initmem' ]; then
    OUT="$WIN/out/kernel-after-free-initmem-probe-20261012"
elif [ "${1:-}" = '--qemu-before-userspace' ]; then
    OUT="$WIN/out/kernel-before-userspace-probe-20261012"
elif [ "${1:-}" = '--qemu-run-init-entry' ]; then
    OUT="$WIN/out/kernel-run-init-entry-probe-20261012"
elif [ "${1:-}" = '--qemu-init-el0-boundary' ]; then
    OUT="$WIN/out/kernel-init-el0-boundary-probe-20261012"
elif [ "${1:-}" = '--qemu-user-init-reset' ]; then
    OUT="$WIN/out/user-init-reset-probe-20261012"
elif [ "${1:-}" = '--qemu-user-init-after-usb' ]; then
    OUT="$WIN/out/user-init-after-usb-probe-20261012"
elif [ "${1:-}" = '--qemu-user-init-udc-status' ]; then
    OUT="$WIN/out/user-init-udc-status-probe-20261012"
elif [ "${1:-}" = '--qemu-user-init-sysfs-status' ]; then
    OUT="$WIN/out/user-init-sysfs-status-probe-20261012"
elif [ "${1:-}" = '--qemu-user-init-udc-only' ]; then
    OUT="$WIN/out/user-init-udc-only-probe-20261012"
elif [ "${1:-}" = '--qemu-user-init-dwc-bound' ]; then
    OUT="$WIN/out/user-init-dwc-bound-probe-20261012"
elif [ "${1:-}" = '--qemu-user-init-qcom-bound' ]; then
    OUT="$WIN/out/user-init-qcom-bound-probe-20261012"
elif [ "${1:-}" = '--qemu-user-init-hsphy-bound' ]; then
    OUT="$WIN/out/user-init-hsphy-bound-probe-20261012"
elif [ "${1:-}" = '--qemu-user-init-dwc-present' ]; then
    OUT="$WIN/out/user-init-dwc-present-probe-20261012"
elif [ "${1:-}" = '--qemu-user-init-dwc-wait' ]; then
    OUT="$WIN/out/user-init-dwc-wait-probe-20261012"
elif [ "${1:-}" = '--qemu-user-init-dwc-deferred' ]; then
    OUT="$WIN/out/user-init-dwc-deferred-probe-20261012"
elif [ "${1:-}" = '--qemu-user-init-dwc-core-error' ]; then
    OUT="$WIN/out/user-init-dwc-core-error-probe-20261012"
elif [ "${1:-}" = '--qemu-user-init-dwc-core-timeout' ]; then
    OUT="$WIN/out/user-init-dwc-core-timeout-probe-20261012"
elif [ "${1:-}" = '--qemu-user-init-dwc-core-timeout-early' ]; then
    OUT="$WIN/out/user-init-dwc-core-timeout-early-probe-20261012"
elif [ "${1:-}" = '--qemu-user-init-dwc-soft-reset-error' ]; then
    OUT="$WIN/out/user-init-dwc-soft-reset-error-probe-20261012"
elif [ "${1:-}" = '--qemu-rndis-shell' ]; then
    OUT="$WIN/out/user-init-rndis-shell-20261013"
elif [ "${1:-}" = '--qemu-rndis-shell-iadfix' ]; then
    OUT="$WIN/out/user-init-rndis-shell-iadfix-20261013"
elif [ "${1:-}" = '--qemu-rndis-shell-winiad' ]; then
    OUT="$WIN/out/user-init-rndis-shell-winiad-20261013"
elif [ "${1:-}" = '--qemu-usb-serial-shell' ]; then
    OUT="$WIN/out/user-init-usb-serial-shell-20261013"
elif [ "${1:-}" = '--qemu-usb-serial-diag' ]; then
    OUT="$WIN/out/user-init-usb-serial-diag-20261013"
elif [ "${1:-}" = '--qemu-exec-return' ]; then
    OUT="$WIN/out/kernel-exec-return-probe-20261012"
elif [ "${1:-}" = '--qemu-exec-return-force-error' ]; then
    OUT="$WIN/out/kernel-exec-return-force-error-probe-20261012"
elif [ "${1:-}" = '--qemu-exec-return-zero' ]; then
    OUT="$WIN/out/kernel-exec-return-zero-control-20261012"
elif [ "${1:-}" = '--qemu-exec-return-error' ]; then
    OUT="$WIN/out/kernel-exec-return-error-control-20261012"
fi
mkdir -p "$OUT"
export PATH="$PREFIX/usr/bin:$PATH"
export LD_LIBRARY_PATH="$PREFIX/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
if [ "${1:-}" = '--compile-user-init-reset' ]; then
    OUT="$WIN/out/user-init-reset-probe-20261012"
    mkdir -p "$OUT"
    grep -E '^#define __NR_(getpid|nanosleep|reboot) ' "$ROOT/linux/include/uapi/asm-generic/unistd.h" > "$OUT/syscall-numbers.txt"
    aarch64-linux-gnu-gcc -nostdlib -static -Wl,--build-id=none,-Ttext=0,-e,_start "$WIN/tools/user_init_reset_probe.S" -o "$OUT/probe.elf"
    aarch64-linux-gnu-objcopy -O binary -j .text "$OUT/probe.elf" "$OUT/probe.bin"
    aarch64-linux-gnu-objdump -d "$OUT/probe.elf" > "$OUT/probe-disassembly.txt"
    test -z "$(aarch64-linux-gnu-nm -u "$OUT/probe.elf")"
elif [ "${1:-}" = '--compile-exec-return' ]; then
    OUT="$WIN/out/kernel-exec-return-probe-20261012"
    mkdir -p "$OUT"
    aarch64-linux-gnu-gcc -nostdlib -static -Wl,--build-id=none,-Ttext=0,-e,_start "$WIN/tools/kernel_exec_return_probe.S" -o "$OUT/probe.elf"
    aarch64-linux-gnu-objcopy -O binary -j .text "$OUT/probe.elf" "$OUT/probe.bin"
    aarch64-linux-gnu-objdump -d "$OUT/probe.elf" > "$OUT/probe-disassembly.txt"
    test -z "$(aarch64-linux-gnu-nm -u "$OUT/probe.elf")"
elif [ "${1:-}" = '--compile' ]; then
    aarch64-linux-gnu-gcc -nostdlib -static -Wl,--build-id=none,-Ttext=0,-e,_start "$WIN/tools/kernel_entry_probe.S" -o "$OUT/probe.elf"
    aarch64-linux-gnu-objcopy -O binary -j .text "$OUT/probe.elf" "$OUT/probe.bin"
    aarch64-linux-gnu-objdump -d "$OUT/probe.elf" > "$OUT/probe-disassembly.txt"
    test -z "$(aarch64-linux-gnu-nm -u "$OUT/probe.elf")"
elif [ "${1:-}" = '--symbols' ]; then
    test "$(sha256sum "$ROOT/linux/arch/arm64/boot/Image" | cut -d' ' -f1)" = d8ade08069b8440b349f4b4aeb430dd6e9057eca08c94a8268e3708a83e53425
    aarch64-linux-gnu-nm -n "$ROOT/linux/vmlinux" > "$OUT/kernel-symbols.txt"
    aarch64-linux-gnu-objdump -d --disassemble=primary_entry "$ROOT/linux/vmlinux" > "$OUT/primary-entry-disassembly.txt"
    aarch64-linux-gnu-objdump -d --disassemble=__enable_mmu "$ROOT/linux/vmlinux" > "$OUT/enable-mmu-disassembly.txt"
elif [ "${1:-}" = '--mapping' ]; then
    test "$(sha256sum "$ROOT/linux/arch/arm64/boot/Image" | cut -d' ' -f1)" = d8ade08069b8440b349f4b4aeb430dd6e9057eca08c94a8268e3708a83e53425
    aarch64-linux-gnu-objdump -d --disassemble=__primary_switched "$ROOT/linux/vmlinux" > "$OUT/primary-switched-disassembly.txt"
    cp "$ROOT/linux/arch/arm64/kernel/pi/map_kernel.c" "$OUT/map_kernel.c"
    cp "$ROOT/linux/arch/arm64/kernel/vmlinux.lds.S" "$OUT/vmlinux.lds.S"
elif [ "${1:-}" = '--el0-path' ]; then
    test "$(sha256sum "$ROOT/linux/arch/arm64/boot/Image" | cut -d' ' -f1)" = d8ade08069b8440b349f4b4aeb430dd6e9057eca08c94a8268e3708a83e53425
    for symbol in ret_from_fork ret_to_user asm_exit_to_user_mode; do
        aarch64-linux-gnu-objdump -d --disassemble="$symbol" "$ROOT/linux/vmlinux" > "$OUT/$symbol-disassembly.txt"
    done
    cp "$ROOT/linux/arch/arm64/kernel/entry.S" "$OUT/entry.S"
elif [ "${1:-}" = '--resident-layout' ]; then
    test "$(sha256sum "$ROOT/linux/arch/arm64/boot/Image" | cut -d' ' -f1)" = d8ade08069b8440b349f4b4aeb430dd6e9057eca08c94a8268e3708a83e53425
    aarch64-linux-gnu-readelf -SW "$ROOT/linux/vmlinux" > "$OUT/vmlinux-sections.txt"
    for symbol in free_initmem mark_rodata_ro run_init_process; do
        aarch64-linux-gnu-objdump -d --disassemble="$symbol" "$ROOT/linux/vmlinux" > "$OUT/$symbol-disassembly.txt"
    done
elif [ "${1:-}" = '--late-init' ]; then
    test "$(sha256sum "$ROOT/linux/arch/arm64/boot/Image" | cut -d' ' -f1)" = d8ade08069b8440b349f4b4aeb430dd6e9057eca08c94a8268e3708a83e53425
    for symbol in rest_init kernel_init kernel_init_freeable do_basic_setup do_initcalls; do
        aarch64-linux-gnu-objdump -d --disassemble="$symbol" "$ROOT/linux/vmlinux" > "$OUT/$symbol-disassembly.txt"
    done
elif [ "${1:-}" = '--c-init' ]; then
    test "$(sha256sum "$ROOT/linux/arch/arm64/boot/Image" | cut -d' ' -f1)" = d8ade08069b8440b349f4b4aeb430dd6e9057eca08c94a8268e3708a83e53425
    aarch64-linux-gnu-objdump -d --disassemble=start_kernel "$ROOT/linux/vmlinux" > "$OUT/start-kernel-disassembly.txt"
    cp "$ROOT/linux/init/main.c" "$OUT/init-main.c"
    cp "$ROOT/linux/arch/arm64/kernel/setup.c" "$OUT/arm64-setup.c"
elif [[ "${1:-}" == --qemu* ]]; then
    QEMU_ROOT="$ROOT/toolchain/qemu/sysroot"
    export LD_LIBRARY_PATH="$QEMU_ROOT/usr/lib/x86_64-linux-gnu:$LD_LIBRARY_PATH"
    export QEMU_DATADIR="$QEMU_ROOT/usr/share/qemu"
    python3 - "$QEMU_ROOT/usr/bin/qemu-system-aarch64" "$OUT" <<'PY'
import json, pathlib, subprocess, sys, time
qemu, out = sys.argv[1], pathlib.Path(sys.argv[2])
shell_probe = out.name in ('user-init-rndis-shell-20261013', 'user-init-rndis-shell-iadfix-20261013', 'user-init-rndis-shell-winiad-20261013', 'user-init-usb-serial-shell-20261013', 'user-init-usb-serial-diag-20261013')
native_probe = out.name.startswith('user-init-') and not shell_probe
limit = 60 if out.name in ('kernel-after-initcalls-probe-20261012', 'kernel-after-kernel-init-freeable-probe-20261012', 'kernel-after-async-sync-probe-20261012', 'kernel-after-free-initmem-probe-20261012', 'kernel-before-userspace-probe-20261012', 'kernel-run-init-entry-probe-20261012') else 20
if 'kernel-exec-return' in out.name:
    limit = 90
if out.name == 'kernel-init-el0-boundary-probe-20261012':
    limit = 90
if out.name in ('user-init-reset-probe-20261012', 'user-init-after-usb-probe-20261012', 'user-init-udc-status-probe-20261012', 'user-init-sysfs-status-probe-20261012', 'user-init-udc-only-probe-20261012'):
    limit = 100
if out.name == 'user-init-udc-status-probe-20261012':
    limit = 150
start = time.monotonic()
if native_probe:
    limit = max(limit, 150)
if out.name in ('user-init-dwc-core-timeout-probe-20261012', 'user-init-dwc-core-timeout-early-probe-20261012', 'user-init-dwc-soft-reset-error-probe-20261012'):
    limit = 210
if shell_probe:
    limit = 210
serial = 'file:' + str(out/'qemu-console.txt') if shell_probe else 'none'
extra = ['-append', 'console=ttyAMA0 pja.qemu_validation=1'] if shell_probe else []
p = subprocess.run([qemu, '-M', 'virt,virtualization=on', '-cpu', 'cortex-a57',
    '-smp', '1', '-m', '512', '-kernel', str(out/'Image-probe'),
    '-no-reboot', '-display', 'none', '-serial', serial, '-monitor', 'none',
    '-net', 'none', '-d', 'int,in_asm', '-D', str(out/'qemu-interrupts.log')] + extra,
    capture_output=True, timeout=limit)
elapsed = time.monotonic() - start
(out/'qemu-output.txt').write_bytes(p.stdout+p.stderr)
trace = (out/'qemu-interrupts.log').read_text()
result = {'exit_code': p.returncode, 'elapsed_seconds': elapsed,
          'smc_instruction_block_observed': 'smc' in trace.lower(),
          'image_sha256': __import__('hashlib').sha256((out/'Image-probe').read_bytes()).hexdigest()}
if native_probe:
    import re
    result['native_user_probe_syscall_instruction_blocks_observed'] = all(
        re.search(r'0x0*' + format(address, 'x') + r':.*svc', trace, re.IGNORECASE)
        for address in (0x401004, 0x401028, 0x401050))
    assert result['native_user_probe_syscall_instruction_blocks_observed']
if shell_probe:
    result['persistent_init_script_reached_test_only_poweroff'] = '[initramfs] QEMU validation complete' in (out/'qemu-console.txt').read_text(errors='replace')
    result['qemu_test_only_cmdline_used'] = True
    result['phone_rndis_network_not_validated_by_qemu'] = True
    assert result['persistent_init_script_reached_test_only_poweroff']
(out/'qemu-result.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
assert p.returncode == 0 and 4 <= elapsed < limit and result['smc_instruction_block_observed']
PY
else
    echo 'Use --compile, --symbols or --qemu' >&2
    exit 2
fi

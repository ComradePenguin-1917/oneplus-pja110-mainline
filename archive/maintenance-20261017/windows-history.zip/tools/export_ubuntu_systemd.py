"""Export only configured rootfs files, never bound proc/sys/dev or cached packages."""
import subprocess,hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];out=ROOT/'out/ubuntu-systemd-20261014'
keys=ROOT/'out/usb-ncm-20261013/ssh'
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(keys/'client_key_host'),
 '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
 '-o',f'UserKnownHostsFile={keys/"known_hosts"}','-o','ConnectTimeout=5','root@169.254.42.1']
cmd='''set -e
tar -C /tmp/ubuntu-systemd --exclude='./proc/*' --exclude='./sys/*' --exclude='./dev/*' --exclude='./run/*' --exclude='./tmp/*' --exclude='./var/cache/apt/archives/*' -czf /tmp/ubuntu-systemd-rootfs.tar.gz .
sha256sum /tmp/ubuntu-systemd-rootfs.tar.gz
'''
p=subprocess.run(ssh+[cmd],capture_output=True,timeout=120);p.check_returncode()
expected=p.stdout.decode().split()[0]
path=out/'ubuntu-systemd-rootfs.tar.gz'
with path.open('wb') as f:
 p=subprocess.run(ssh+['cat /tmp/ubuntu-systemd-rootfs.tar.gz'],stdout=f,stderr=subprocess.PIPE,timeout=180)
p.check_returncode();assert hashlib.sha256(path.read_bytes()).hexdigest()==expected
m=json.loads((out/'manifest.json').read_text())
m.update(rootfs_file=path.name,rootfs_sha256=expected,rootfs_bytes=path.stat().st_size,
         packages_dpkg_configured=True,namespace_systemd_pid1_verified=True,phone_systemd_pid1_verified=False,
         rootfs_contains_server_host_keys=True,client_private_key_included=False)
(out/'runtime-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print('PASS: configured rootfs archive saved and SHA256 verified; no virtual filesystems included')

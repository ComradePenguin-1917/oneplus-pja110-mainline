"""Stage a read-only stock-firmware extraction script; no partition writes."""
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
scope = {'__file__': str(ROOT/'tools/check_battery_runtime.py')}
exec((ROOT/'tools/check_battery_runtime.py').read_text().split('state = run(')[0], scope)
script = '''#!/bin/sh
set -eu
test "$(id -u)" = 0
test "$(uname -r)" = 6.14.0-oneplus-xigua
out=/home/penguin/charger-firmware-audit
mkdir -p "$out"
test ! -e "$out/complete.txt"
mountdir=/run/pja110-charger-firmware-audit
mkdir -p "$mountdir"
trap 'umount "$mountdir" 2>/dev/null || true; rmdir "$mountdir" 2>/dev/null || true' EXIT
for label in modem_a dsp_a; do
 device=
 for entry in /sys/class/block/sd*/uevent; do
  if grep -qx "PARTNAME=$label" "$entry"; then
   test -z "$device"
   device=/dev/$(sed -n 's/^DEVNAME=//p' "$entry")
  fi
 done
 test -n "$device"
 echo "$label $device $(blockdev --getsize64 "$device")" >> "$out/partitions.txt"
 # Force read-only filesystem access. These original firmware filesystems are
 # expected FAT; do not attempt an ext4 journal replay or format anything.
 if mount -t vfat -o ro,nosuid,nodev,noexec "$device" "$mountdir"; then
  find "$mountdir" -type f > "$out/$label-file-list.txt"
  mkdir -p "$out/$label"
  find "$mountdir" -type f | while IFS= read -r file; do
   case "$(basename "$file")" in
    adsp.*|adsp_dtb.*|*charger*.mbn|*charger*.mdt|*charger*.jsn)
     relative=${file#"$mountdir"/}
     mkdir -p "$out/$label/$(dirname "$relative")"
     cp "$file" "$out/$label/$relative"
     sha256sum "$out/$label/$relative" >> "$out/sha256.txt"
     ;;
   esac
  done
  umount "$mountdir"
 else
  echo "$label: not mounted as FAT; no alternative write-capable mount attempted" >> "$out/mount-errors.txt"
 fi
done
chown -R 10000:10000 "$out"
echo 'Read-only firmware audit complete; no firmware installed or started' | tee "$out/complete.txt"
'''
out = ROOT/'out/battery-bringup-20261016/charger-source'
(out/'read-stock-firmware.sh').write_text(script, newline='\n')
p = subprocess.run(scope['SSH']+['cat > /home/penguin/read-stock-charger-firmware.sh; chmod 755 /home/penguin/read-stock-charger-firmware.sh'], input=script.encode(), capture_output=True, timeout=20)
p.check_returncode()
print('Read-only stock firmware audit staged; requires phone sudo authentication, no partition writes')

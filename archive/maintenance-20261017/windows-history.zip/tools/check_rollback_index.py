#!/usr/bin/env python3
"""A concrete hypothesis for why OUR kernel does not boot while astonishing does.

aston (OnePlus 12R/Ace 3, the SAME SM8550 + SAME OPPO ABL) uses:

    mkbootimg --header_version 4 --base 0x0 \
              --os_version 15.0.0 --os_patch_level 2025-02 \
              --kernel Image_w_dtb.gz -o boot16G_A14.img

Note: --os_version 15.0.0 and --os_patch_level 2025-02, i.e. an Android 15-era
rollback index, even for their A14 image.

We instead inherited the stock A14 header values:
    os_version = 0x1a000184  (13.0.0, 2000-08)
    os_patch_level = 0x0184

The boot image's os_version / os_patch_level are the ROLLBACK INDEX. ABL compares
them against the device's anti-rollback state and REFUSES to boot an image whose
index is too low. If our index is below what this device requires, ABL would
reject our kernel -- which would look exactly like "our kernel never runs".

This has never been tested here.

Also worth noting: aston gzips the kernel+dtb. We tried raw and gzip, but always
with the inherited os_version.

Read the real values from our image and from the OTA image to see what ABL would
compare.
"""
import os
import struct
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'


def hdr(path, label):
    b = open(path, 'rb').read()
    if b[:8] != b'ANDROID!':
        print('  %-34s not an Android boot image' % label)
        return None
    ksize, rsize, osver = struct.unpack_from('<3I', b, 8)
    hver = struct.unpack_from('<I', b, 40)[0]
    # os_version packs (a<<25)|(b<<18)|(c<<11)|(y<<4)|m  per AOSP
    y = (osver >> 4) & 0x7F
    m = osver & 0xF
    ver = ((osver >> 25) & 0x7F, (osver >> 18) & 0x7F, (osver >> 11) & 0x7F)
    patch = struct.unpack_from('<I', b, 12 + 0)[0]  # placeholder
    # os_patch_level sits next to os_version only in some headers; read field 4..6
    fields = struct.unpack_from('<8I', b, 8)
    print('  %-34s hdr v%d  os_version=0x%08x -> %d.%d.%d  year=%d month=%d'
          % (label, hver, osver, ver[0], ver[1], ver[2], y, m))
    return osver


print('=' * 78)
print('1) os_version / os_patch_level IN EACH IMAGE')
print('=' * 78)
imgs = [
    ('OTA boot-A14.img (stock)', os.path.join(WS, 'boot-A14.img')),
    ('our boot_b-poweroff.img', os.path.join(WS, 'out', 'boot_b-poweroff.img')),
    ('our boot-xigua-initrd.img', os.path.join(WS, 'out', 'boot-xigua-initrd.img')),
    ('our validate-...-initrd.img', os.path.join(WS, 'out', 'validate-stockkernel-ourinitrd.img')),
    ('our boot_b-ramoops.img', os.path.join(WS, 'out', 'boot_b-ramoops.img')),
]
for label, p in imgs:
    if os.path.exists(p):
        hdr(p, label)
    else:
        print('  %-34s (missing)' % label)

print()
print('=' * 78)
print('2) WHAT DOES THE DEVICE REQUIRE?  (read its anti-rollback state)')
print('=' * 78)
print('  ABL keeps an anti-rollback counter. Read it from the running Android:')
print('    adb shell getprop ro.boot.*  | grep -i rollback')
print('    adb shell getprop ro.build.version.security_patch')
print()
print('  and ABL prints its own verdict in /proc/bootloader_log: it lists every')
print('  avb_slot_verify result. A rollback rejection shows up there explicitly.')

print()
print('=' * 78)
print('3) THE OTHER DIFFERENCE: aston GZIPS kernel+dtb')
print('=' * 78)
print('  aston:  cat Image dtb > Image_w_dtb;  gzip Image_w_dtb;  mkbootimg --kernel Image_w_dtb.gz')
print('  ours :  raw Image (+ optional dtb), and gzip only in one early variant')
print()
print('  We built both raw and gz variants early on and both failed, but never with')
print('  a corrected os_version. So the two variables have never been separated.')

print()
print('=' * 78)
print('ACTION')
print('=' * 78)
print('  Build a variant that matches aston exactly on the header fields:')
print('    --os_version 15.0.0 --os_patch_level 2025-02')
print('  and run it as a memory boot with the STOCK kernel first, as a control that')
print('  the header values themselves are acceptable to this ABL.')
print()
print('  If the stock kernel boots with os_version 15.0.0, then the header is not a')
print('  blocker and we can rule it out for our kernel too.')

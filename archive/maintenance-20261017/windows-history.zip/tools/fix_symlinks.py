#!/usr/bin/env python3
"""Materialise git symlinks in a Windows checkout of the kernel tree.

Windows git without developer mode / core.symlinks=true writes symlinks as
plain text files containing the target path. The DTS build then fails because
cpp include resolution finds a bogus file. This walks the index, finds mode
120000 entries, and replaces each placeholder with a copy of its target.
"""
import os
import subprocess
import sys

LINUX = r'H:\WorkSpace\PJA110-Mainline\linux'


def main():
    os.chdir(LINUX)
    out = subprocess.run(['git', 'ls-files', '-s'], capture_output=True, text=True).stdout
    fixed = skipped = 0
    for line in out.splitlines():
        parts = line.split('\t')
        if len(parts) != 2:
            continue
        meta, path = parts
        if not meta.startswith('120000'):
            continue
        full = os.path.join(LINUX, path.replace('/', os.sep))
        if not os.path.exists(full):
            skipped += 1
            continue
        with open(full, 'r', encoding='utf-8', errors='replace') as fh:
            target = fh.read().strip()
        if not target or '\n' in target:
            skipped += 1
            continue
        resolved = os.path.normpath(os.path.join(os.path.dirname(full), target.replace('/', os.sep)))
        if not os.path.exists(resolved):
            print('  target missing for %s -> %s' % (path, target))
            skipped += 1
            continue
        os.remove(full)
        with open(resolved, 'rb') as src, open(full, 'wb') as dst:
            dst.write(src.read())
        print('  fixed %s -> %s' % (path, target))
        fixed += 1
    print('fixed=%d skipped=%d' % (fixed, skipped))


if __name__ == '__main__':
    sys.exit(main())

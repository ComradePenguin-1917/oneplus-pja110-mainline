"""Fetch existing upstream and Aston battmgr implementations for comparison."""
from pathlib import Path
import hashlib
import json
import urllib.request
from concurrent.futures import ThreadPoolExecutor

out = Path('out/native-install-20261017/charger-handoff-reference')
out.mkdir(exist_ok=True)
headers = {'User-Agent': 'PJA110-driver-audit'}
def get(url):
    with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=25) as r:
        return r.read()
commit = json.loads(get('https://api.github.com/repos/torvalds/linux/commits/master'))['sha']
refs = [('upstream', 'torvalds/linux', commit),
        ('aston', 'jiganomegsdfdf/aston-mainline', '5d5c840896bb49291ae4578acefd5a3ec65524f6')]
def fetch(ref):
    name, repo, sha = ref
    path = 'drivers/power/supply/qcom_battmgr.c'
    url = f'https://raw.githubusercontent.com/{repo}/{sha}/{path}'
    data = get(url)
    (out / (name + '-qcom_battmgr.c')).write_bytes(data)
    return dict(name=name, commit=sha, url=url, sha256=hashlib.sha256(data).hexdigest())
with ThreadPoolExecutor(max_workers=2) as pool:
    records = list(pool.map(fetch, refs))
(out / 'manifest.json').write_text(json.dumps(records, indent=2)+'\n')
for record in records:
    print(record['name'], record['commit'])

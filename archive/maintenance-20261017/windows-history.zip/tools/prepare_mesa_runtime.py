"""Download ARM64 Ubuntu packages to an isolated project directory; no install."""
import gzip,hashlib,json,re,urllib.request
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/mesa-offscreen-20261014'
OUT.mkdir(exist_ok=True)
DEBS=OUT/'debs';DEBS.mkdir(exist_ok=True)
base='https://ports.ubuntu.com/ubuntu-ports/'
packages={}
for pocket in ('noble','noble-updates','noble-security'):
    path=OUT/(pocket+'-arm64-Packages.gz')
    if not path.exists():path.write_bytes(urllib.request.urlopen(base+f'dists/{pocket}/main/binary-arm64/Packages.gz',timeout=60).read())
    for record in gzip.decompress(path.read_bytes()).decode().split('\n\n'):
        fields={}
        for line in record.splitlines():
            if line and not line[0].isspace() and ': ' in line:
                k,v=line.split(': ',1);fields[k]=v
        if 'Package' in fields:packages[fields['Package']]=fields
pending=['libegl1','libegl-mesa0','libgles2','libgl1-mesa-dri','libgbm1','libglapi-mesa']
if '--dev' in sys.argv:pending+=['libegl-dev','libgles-dev','libgbm-dev','libdrm-dev']
selected={}
while pending:
    name=pending.pop()
    if name in selected:continue
    p=packages[name];selected[name]=p
    for item in (p.get('Pre-Depends','')+','+p.get('Depends','')).split(','):
        choices=[re.split(r'\s|:',c.strip())[0] for c in item.split('|') if c.strip()]
        if not choices:continue
        dependency=next((c for c in choices if c in packages),None)
        if dependency:pending.append(dependency)
        else:raise RuntimeError('unresolved dependency '+item)
manifest=[]
for name,p in sorted(selected.items()):
    path=DEBS/Path(p['Filename']).name
    if not path.exists():
        print('Downloading',name,p['Version'],flush=True)
        path.write_bytes(urllib.request.urlopen(base+p['Filename'],timeout=120).read())
    assert hashlib.sha256(path.read_bytes()).hexdigest()==p['SHA256']
    manifest.append(dict(package=name,version=p['Version'],architecture=p['Architecture'],
                         url=base+p['Filename'],sha256=p['SHA256'],file=path.name))
(OUT/'packages.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('PASS:',len(manifest),'ARM64 packages downloaded and SHA256 verified; no system packages installed')

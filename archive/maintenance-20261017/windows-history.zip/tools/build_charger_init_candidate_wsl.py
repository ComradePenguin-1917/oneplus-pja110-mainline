"""Compile candidate against existing prepared tree; no ABI claim or sudo."""
from pathlib import Path
import shutil, subprocess, json, hashlib
root = Path.home() / 'workspace/PJA110-Mainline'
win = Path('/mnt/h/workspace/PJA110-Mainline')
out = win / 'out/native-install-20261017/charger-init-candidate'
out.mkdir(exist_ok=True)
build = root / 'charger-init-candidate'
build.mkdir(exist_ok=True)
for name in ('qcom_battmgr.c', 'pja110-ap-gauge.h', 'Makefile'):
    shutil.copyfile(win / 'drivers/power/supply' / name, build / name)
compilers = list(Path('/opt').glob('**/bin/aarch64-none-linux-gnu-gcc'))
assert len(compilers) == 1, compilers
prefix = str(compilers[0]).removesuffix('gcc')
cmd = ['make', '-C', str(root / 'linux'), 'ARCH=arm64', 'CROSS_COMPILE=' + prefix,
       'M=' + str(build), 'qcom_battmgr.o']
p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(out / 'compile.log').write_bytes(p.stdout)
print(p.stdout.decode(errors='replace'))
p.check_returncode()
shutil.copyfile(build / 'qcom_battmgr.o', out / 'qcom_battmgr.o')
report = {'object_compile_passed': True, 'kernel_release': (root / 'linux/include/config/kernel.release').read_text().strip(),
          'source_sha256': hashlib.sha256((build / 'qcom_battmgr.c').read_bytes()).hexdigest(),
          'module_link_verified': False, 'native_a_abi_verified': False,
          'phone_installed': False, 'charging_enabled': False}
(out / 'build-result.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))

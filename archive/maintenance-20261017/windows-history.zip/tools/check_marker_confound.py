#!/usr/bin/env python3
"""CHECK A CONFOUND IN MY MARKER EXPERIMENT.

I appended the LIVE device tree (dumped from /sys/firmware/fdt) plus markers to
the stock kernel and saw the markers vanish, concluding "ABL ignores the
appended DTB".

But ABL does not take any DTB it finds -- it selects one by matching
`qcom,msm-id` / `qcom,board-id` against the running hardware. The live tree is
the POST-OVERLAY result; if ABL stripped or never set those root properties,
then ABL would reject my appended blob as a candidate for a completely
uninteresting reason, and my conclusion would be WRONG.

Test: compare root properties of
  (a) the live device tree                (what I used in the marker probe)
  (b) vendor_boot entry0                   (a DTB ABL definitely accepts)
  (c) our own DTB
"""
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fdt import FDT

WS = r'H:\WorkSpace\PJA110-Mainline'


def dec(v):
    return v.rstrip(b'\0').decode('ascii', 'replace')


def ids(props):
    out = {}
    for k in ('qcom,msm-id', 'qcom,board-id', 'qcom,pmic-id', 'model', 'compatible'):
        v = props.get(k)
        if v is None:
            out[k] = '(absent)'
            continue
        if k in ('model', 'compatible'):
            out[k] = dec(v).replace('\0', ' | ')[:52]
        else:
            out[k] = ' '.join('0x%x' % x for x in struct.unpack('>%dI' % (len(v)//4), v))
    return out


sources = {}

sources['(a) live device tree'] = FDT(
    open(os.path.join(WS, 'live-from-device.dtb'), 'rb').read()).nodes().get('/', {})

v = open(os.path.join(WS, 'backup', 'vendor_boot_a.img'), 'rb').read()
hsize, dtbsize = struct.unpack_from('<2I', v, 28+2048+4+16)
vrsize = struct.unpack_from('<I', v, 24)[0]
dtb_off = (((hsize+4095)//4096)*4096 + vrsize + 4095)//4096*4096
e0 = struct.unpack_from('>I', v, dtb_off+4)[0]
sources['(b) vendor_boot entry0'] = FDT(v[dtb_off:dtb_off+e0]).nodes().get('/', {})

sources['(c) our DTB'] = FDT(
    open(os.path.join(WS, 'dts', 'sm8550-oneplus-xigua-16G.dtb'), 'rb').read()).nodes().get('/', {})

print('=' * 78)
print('ROOT PROPERTIES THAT DECIDE WHETHER ABL ACCEPTS A DTB')
print('=' * 78)
keys = ('qcom,msm-id', 'qcom,board-id', 'qcom,pmic-id', 'model')
print('%-26s %s' % ('source', '  '.join('%-22s' % k for k in keys)))
print('-' * 78)
for name, props in sources.items():
    d = ids(props)
    print('%-26s %s' % (name, '  '.join('%-22s' % d[k][:22] for k in keys)))

print()
print('=' * 78)
print('INTERPRETATION')
print('=' * 78)
live = ids(sources['(a) live device tree'])
vb = ids(sources['(b) vendor_boot entry0'])
have_msm = live['qcom,msm-id'] != '(absent)'
print('  live tree has qcom,msm-id : %s  -> %s' % (have_msm, live['qcom,msm-id']))
print('  live tree has qcom,board-id: %s' % (live['qcom,board-id'] != '(absent)'))
print()
if not have_msm:
    print('  *** CONFOUND CONFIRMED ***')
    print('  My marker probe used a DTB WITHOUT qcom,msm-id, so ABL would reject it')
    print('  as a candidate regardless of any "appended DTB" policy. The earlier')
    print('  conclusion ("ABL ignores appended DTBs") is therefore NOT established.')
else:
    print('  The live tree DOES carry qcom,msm-id, so ABL had a reason to consider')
    print('  it and still did not use it. The earlier conclusion stands.')

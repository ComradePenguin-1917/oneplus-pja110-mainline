"""Build a read-only SMEM 135 reader against the prepared native-A tree."""
from pathlib import Path
import hashlib
import json
import subprocess

root = Path.home() / 'workspace/PJA110-Mainline'
tree = root / 'charger-native-a/linux-6.14'
build = root / 'charger-native-a/smem-project'
out = Path('/mnt/h/workspace/PJA110-Mainline/out/native-install-20261017/smem-project')
build.mkdir(exist_ok=True)
out.mkdir(exist_ok=True)
source = r'''// Read only the public project identity fields of OEM SMEM item 135.
#include <linux/module.h>
#include <linux/err.h>
#include <linux/of.h>
#include <linux/unaligned.h>
#include <linux/soc/qcom/smem.h>
static unsigned int version, project, item_size;
module_param(version, uint, 0444);
module_param(project, uint, 0444);
module_param(item_size, uint, 0444);
static int __init project_init(void)
{
    const void *data;
    size_t size;
    if (!of_machine_is_compatible("oneplus,xigua"))
        return -ENODEV;
    data = qcom_smem_get(QCOM_SMEM_HOST_ANY, 135, &size);
    if (IS_ERR(data))
        return PTR_ERR(data);
    if (size < 8 || size > UINT_MAX)
        return -EINVAL;
    version = get_unaligned_le32(data);
    project = get_unaligned_le32((const u8 *)data + 4);
    item_size = size;
    pr_info("pja110_smem_project: item=135 size=%u version=%u project=%u\n",
            item_size, version, project);
    return 0;
}
static void __exit project_exit(void) {}
module_init(project_init);
module_exit(project_exit);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("PJA110 read-only SMEM project identity diagnostic");
'''
(build / 'pja110_smem_project.c').write_text(source)
(build / 'Makefile').write_text('obj-m += pja110_smem_project.o\n')
assert (tree / 'include/config/kernel.release').read_text().strip() == '6.14.0-oneplus-xigua'
assert (tree / 'Module.symvers').stat().st_size > 0
cmd = ['make', '-C', str(tree), 'ARCH=arm64',
       'CROSS_COMPILE=/opt/aarch64-linux-gnu-toolchain-13.3/bin/aarch64-none-linux-gnu-',
       'M=' + str(build), 'modules']
p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(out / 'build.log').write_bytes(p.stdout)
print(p.stdout.decode(errors='replace'))
p.check_returncode()
data = (build / 'pja110_smem_project.ko').read_bytes()
(out / 'pja110_smem_project.ko').write_bytes(data)
(out / 'pja110_smem_project.c').write_text(source)
report = dict(sha256=hashlib.sha256(data).hexdigest(), strict_modpost_passed=True,
              charging_commands=False, smem_writes=False, live_loaded=False)
(out / 'build.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))

#!/bin/bash
# Configure the kernel for the OnePlus Ace 2 Pro (xigua).
#
# Strategy: start from the stock arm64 defconfig, then merge the Ace 3 port's
# sm8550.config fragment (same SoC, same PMIC family, and it is known to produce
# a kernel that actually boots on OnePlus sm8550 hardware).
#
# Usage:
#   bash wsl_configure_kernel.sh            # configure
#   bash wsl_configure_kernel.sh --check    # show key options after configuring
set -uo pipefail

ROOT="$HOME/workspace/PJA110-Mainline"
TREE="$ROOT/linux"
FRAG_WIN="/mnt/h/WorkSpace/PJA110-Mainline/config/aston-sm8550.config"
FRAG="$TREE/arch/arm64/configs/xigua-sm8550.config"

export PATH="$ROOT/toolchain/gcc-12-aarch64/usr/bin:$PATH"
export LD_LIBRARY_PATH="$ROOT/toolchain/gcc-12-aarch64/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export ARCH=arm64
export CROSS_COMPILE=aarch64-linux-gnu-

cd "$TREE"

if [ "${1:-}" != "--check" ]; then
    echo "=== installing config fragment ==="
    cp "$FRAG_WIN" "$FRAG"
    echo "  $FRAG ($(wc -l < "$FRAG") lines)"

    echo
    echo "=== 1/3 defconfig ==="
    make ARCH=arm64 CROSS_COMPILE="$CROSS_COMPILE" defconfig 2>&1 | tail -3

    echo
    echo "=== 2/3 merge sm8550 fragment ==="
    # merge_config.sh applies the fragment and re-runs olddefconfig
    ARCH=arm64 scripts/kconfig/merge_config.sh -m -O . .config "$FRAG" 2>&1 | tail -12

    echo
    echo "=== 3/3 olddefconfig (resolve new symbols) ==="
    make ARCH=arm64 CROSS_COMPILE="$CROSS_COMPILE" olddefconfig 2>&1 | tail -5
fi

echo
echo "=== kernel version string ==="
make -s ARCH=arm64 CROSS_COMPILE="$CROSS_COMPILE" kernelrelease 2>/dev/null || true

echo
echo "=== key options for this device ==="
for opt in CONFIG_ARCH_QCOM CONFIG_ARM64_APPENDED_DTB \
           CONFIG_PINCTRL_SM8550 CONFIG_CLK_SM8550 CONFIG_CLK_SM8550_GPUCC \
           CONFIG_INTERCONNECT_QCOM_SM8550 CONFIG_QCOM_RPMH \
           CONFIG_REGULATOR_RPMH CONFIG_SPMI_QCOM \
           CONFIG_SCSI_UFS_QCOM CONFIG_PHY_QCOM_QMP_UFS CONFIG_SCSI_UFS_BSG \
           CONFIG_USB_DWC3 CONFIG_PHY_QCOM_QMP_USB CONFIG_PHY_QCOM_SNPS_EUSB2 \
           CONFIG_PHY_QCOM_EUSB2_REPEATER CONFIG_TYPEC CONFIG_TYPEC_MUX_FSA4480 \
           CONFIG_QCOM_PMIC_GLINK CONFIG_QCOM_RMTFS_MEM CONFIG_QCOM_SMEM \
           CONFIG_SERIAL_MSM_GENI_CONSOLE CONFIG_SERIAL_MSM_GENI \
           CONFIG_PINCTRL_SM8550_LPASS_LPI CONFIG_QCOM_LLCC \
           CONFIG_DRM_MSM CONFIG_DRM_PANEL_BOE_TD4320 CONFIG_DRM_PANEL_VISIONOX_VTDR6130 \
           CONFIG_TOUCHSCREEN_GOODIX_BERLIN_SPI CONFIG_QCOM_FASTRPC \
           CONFIG_INPUT_PM8941_PWRKEY CONFIG_PM8916_WATCHDOG ; do
    line=$(grep -E "^$opt=" .config 2>/dev/null | head -1)
    if [ -n "$line" ]; then
        printf '  %s\n' "$line"
    elif grep -qE "^# $opt is not set" .config 2>/dev/null; then
        printf '  # %s is not set\n' "$opt"
    else
        printf '  %-46s (absent)\n' "$opt"
    fi
done

echo
echo "=== console / earlycon support (critical for bring-up) ==="
grep -E '^CONFIG_SERIAL_MSM_GENI(_CONSOLE)?=' .config || echo "  geni serial MISSING"
grep -E '^CONFIG_SERIAL_EARLYCON' .config || true

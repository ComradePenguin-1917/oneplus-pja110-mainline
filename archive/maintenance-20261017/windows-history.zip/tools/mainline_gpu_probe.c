/* Standard DRM MSM UAPI diagnostics. No raw MMIO or custom GPU driver. */
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <unistd.h>
#include "msm_drm.h"

static int query(int fd, unsigned param, const char *name, uint64_t *value)
{
    struct drm_msm_param q = {.pipe=MSM_PIPE_3D0, .param=param};
    if (ioctl(fd, DRM_IOCTL_MSM_GET_PARAM, &q)) {
        fprintf(stderr,"%s: %s\n",name,strerror(errno));
        return -1;
    }
    printf("%s=%" PRIu64 " (0x%" PRIx64 ")\n",name,(uint64_t)q.value,(uint64_t)q.value);
    *value=q.value;
    return 0;
}

int main(void)
{
    int fd=open("/dev/dri/renderD128",O_RDWR|O_CLOEXEC);
    if (fd<0) {perror("open renderD128");return 1;}
    uint64_t id,value;
    if(query(fd,MSM_PARAM_GPU_ID,"GPU_ID_LEGACY",&id))return 2;
    if(query(fd,MSM_PARAM_CHIP_ID,"CHIP_ID",&value))return 2;
    /* 7xx catalog uses chip_ids and leaves legacy info->revn zero. */
    if((value&0xffffffffu)!=0x43050a01u)return 2;
    if(query(fd,MSM_PARAM_GMEM_SIZE,"GMEM_SIZE",&value)||
       query(fd,MSM_PARAM_MAX_FREQ,"MAX_FREQ",&value)||
       query(fd,MSM_PARAM_FAULTS,"FAULTS_BEFORE",&value))return 3;
    if(query(fd,MSM_PARAM_TIMESTAMP,"GPU_TIMESTAMP",&value))return 10;
    struct drm_msm_gem_new bo={.size=4096,.flags=MSM_BO_WC};
    if(ioctl(fd,DRM_IOCTL_MSM_GEM_NEW,&bo)){perror("GEM_NEW");return 4;}
    struct drm_msm_gem_info info={.handle=bo.handle,.info=MSM_INFO_GET_OFFSET};
    if(ioctl(fd,DRM_IOCTL_MSM_GEM_INFO,&info)){perror("GEM_INFO offset");return 5;}
    uint32_t *map=mmap(NULL,4096,PROT_READ|PROT_WRITE,MAP_SHARED,fd,info.value);
    if(map==MAP_FAILED){perror("mmap");return 6;}
    for(unsigned i=0;i<1024;i++)map[i]=0xabc00000u+i;
    for(unsigned i=0;i<1024;i++)if(map[i]!=0xabc00000u+i)return 7;
    info.info=MSM_INFO_GET_IOVA;info.value=0;
    if(ioctl(fd,DRM_IOCTL_MSM_GEM_INFO,&info)){perror("GEM_INFO iova");return 8;}
    printf("GEM_SIZE=4096 GPU_IOVA=0x%" PRIx64 " CPU_PATTERN_OK\n",(uint64_t)info.value);
    munmap(map,4096);
    struct drm_gem_close release={.handle=bo.handle};
    if(ioctl(fd,DRM_IOCTL_GEM_CLOSE,&release)){perror("GEM_CLOSE");return 9;}
    if(query(fd,MSM_PARAM_FAULTS,"FAULTS_AFTER",&value)||value)return 11;
    close(fd);
    puts("PASS: Adreno 740 identity, GEM CPU mapping and GPU virtual address; no rendering submitted");
    return 0;
}

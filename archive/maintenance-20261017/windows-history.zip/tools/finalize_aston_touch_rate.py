"""Record user-confirmed RAM results and reproducible kernel-event timing."""
import json
import statistics
import hashlib
import sys
from pathlib import Path

OUT = Path(__file__).resolve().parents[1] / 'out/aston-touch-240hz-20261013'
observations = [('6', '持续正常，双指也正常'), ('7', '正常')]
if '--boot-verified' in sys.argv:
    observations.append(('8', '持续正常，双指也正常'))
for suffix, observation in observations:
    path = OUT / f'physical-result{suffix}.json'
    result = json.loads(path.read_text())
    lines = [l for l in (OUT / f'physical-touch-events{suffix}.txt').read_text().splitlines() if l.startswith('FRAME ')]
    assert lines and lines[-1].endswith(' active=0')
    result.update(user_observation_pending=False, user_observation=observation,
                  final_contacts_released=True)
    if suffix in ('7', '8'):
        ts = [float(l.split()[1]) for l in lines]
        intervals = [(b - a) * 1000 for a, b in zip(ts, ts[1:]) if 0 < b - a < .02]
        result.update(timestamp_source='evdev CLOCK_MONOTONIC kernel event, microsecond precision',
                      interval_filter_ms='0 < dt < 20; excludes pauses',
                      continuous_intervals=len(intervals), mean_ms=statistics.mean(intervals),
                      median_ms=statistics.median(intervals),
                      observed_mean_hz=1000 / statistics.mean(intervals),
                      observed_median_hz=1000 / statistics.median(intervals),
                      target_firmware_hz=240, firmware_rate_code=3,
                      internal_scan_rate_measured=False,
                      multitouch_note=('capture6 confirmed dual touch; capture7 recorded max_contacts=1'
                                       if suffix == '7' else 'post-boot user confirmed dual touch'))
        print(json.dumps(result, ensure_ascii=False, indent=2))
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
if '--boot-verified' in sys.argv:
    auto_path = OUT / 'autostart-manifest.json'
    auto = json.loads(auto_path.read_text())
    assert auto['phone_execution_confirmed'] and auto['other_seven_boot_partitions_unchanged']
    assert result['max_contacts'] >= 2 and result['final_contacts_released']
    assert 220 < result['observed_mean_hz'] < 260
    auto.update(post_boot_physical_touch_verified=True,
                observed_mean_hz=result['observed_mean_hz'],
                observed_median_hz=result['observed_median_hz'])
    auto_path.write_text(json.dumps(auto, indent=2) + '\n')
    frozen = OUT / 'verified-autostart'
    assert not frozen.exists(), 'Preserve frozen evidence'
    frozen.mkdir()
    names = ['synaptics-aston.ko', 'source-manifest.json', 'build.log',
             'lifecycle-result.txt', 'physical-touch-events6.txt', 'physical-result6.json',
             'physical-touch-events7.txt', 'physical-result7.json',
             'physical-touch-events8.txt', 'physical-result8.json', 'physical-dmesg8.txt',
             'autostart-manifest.json', 'autostart-device-after.txt', 'autostart-device-after.json',
             'init_boot_b-aston-240hz.img', 'init-aston-240hz.sh', 'qemu-autostart-console.txt',
             'fastboot-autostart.log']
    records = {}
    for name in names:
        data = (OUT / name).read_bytes()
        (frozen / name).write_bytes(data)
        records[name] = hashlib.sha256(data).hexdigest()
    source = Path(__file__).resolve().parents[1] / 'drivers/input/touchscreen/synaptics-aston-rate'
    for name in ('syna_tcm2.c', 'syna_tcm2.h', 'syna_tcm2_spi.c', 'Makefile'):
        data = (source / name).read_bytes()
        (frozen / name).write_bytes(data)
        records[name] = hashlib.sha256(data).hexdigest()
    (frozen / 'sha256.json').write_text(json.dumps(records, indent=2) + '\n')
    print('PASS: fixed 240Hz boot, physical touch, rate timing and partition evidence frozen')

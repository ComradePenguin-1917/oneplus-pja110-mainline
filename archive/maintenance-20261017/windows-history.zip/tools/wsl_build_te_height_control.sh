#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
TREE="$ROOT/linux"
OUT="$WIN/out/te-height-control-20261014"
mkdir -p "$OUT"
export PATH="$ROOT/toolchain/gcc-12-aarch64/usr/bin:$PATH"
export LD_LIBRARY_PATH="$ROOT/toolchain/gcc-12-aarch64/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu-
if [ ! -f "$OUT/dpu_encoder_phys_cmd.before.c" ]; then
    cmp "$TREE/arch/arm64/boot/Image" "$WIN/out/dsc-firstline-control-20261014/Image"
fi
cmp "$TREE/.config" "$WIN/out/dsc-firstline-control-20261014/.config"
cmp "$TREE/drivers/gpu/drm/msm/dsi/dsi_host.c" "$WIN/out/weston-kms-diagnosis-20261014/dsi_host-current.c"
python3 - "$TREE" "$WIN" "$OUT" <<'PY'
import sys,difflib
from pathlib import Path
tree,win,out=map(Path,sys.argv[1:])
p=tree/'drivers/gpu/drm/msm/disp/dpu1/dpu_encoder_phys_cmd.c'
before=p.read_text()
if (out/'dpu_encoder_phys_cmd.height65520.c').exists():
    assert before==(out/'dpu_encoder_phys_cmd.height65520.c').read_text()
    before=(out/'dpu_encoder_phys_cmd.before.c').read_text()
assert before==(win/'out/aston-display-comparison-20261014/local/drivers/gpu/drm/msm/disp/dpu1/dpu_encoder_phys_cmd.c').read_text()
needle='\ttc_cfg.sync_cfg_height = mode->vtotal * 2;'
assert before.count(needle)==1
after=before.replace('struct dpu_hw_tear_check tc_cfg = { 0 };',
    'struct dpu_hw_tear_check tc_cfg = { 0 };\n\tstruct device_node *panel;')
after=after.replace(needle,'''\t/* AA536 control: reuse the stock SDE external-TE wrap height. */
\tpanel = of_find_compatible_node(NULL, NULL, "oneplus,aa536-p-3-a0001");
\ttc_cfg.sync_cfg_height = panel ? 0xfff0 : mode->vtotal * 2;
\tof_node_put(panel);''')
if '#include <linux/of.h>' not in after:
    after=after.replace('#include "dpu_encoder_phys.h"','#include <linux/of.h>\n#include "dpu_encoder_phys.h"')
assert '#include <linux/of.h>' in after
(out/'dpu_encoder_phys_cmd.before.c').write_text(before)
(out/'dpu_encoder_phys_cmd.height65520.c').write_text(after)
(out/'height-only.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(p),tofile=str(p))))
p.write_text(after)
PY
cd "$TREE"
make -j12 Image > "$OUT/build.log" 2>&1
cp arch/arm64/boot/Image System.map .config "$OUT/"
cmp .config "$WIN/out/dsc-firstline-control-20261014/.config"
echo 'PASS: PJA110-only TE height control built; config and DSI unchanged'

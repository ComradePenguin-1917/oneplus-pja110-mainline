"""Enable the existing Adreno driver and add unmodified stock GPU firmware."""
import gzip
import hashlib
import json
import struct
from pathlib import Path
from fdt import FDT
from fdtwrite import parse,serialise,walk
from build_init_marker_test import parse_cpio,make_entry,lz4

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/gpu-port-20261014'
OUT.mkdir(exist_ok=True)
base=json.loads((ROOT/'out/display-generator-avb-retest-20261014/verified-combination.json').read_text())
baseline=base['partition_hashes']
vendor_path=ROOT/base['vendor_boot_b_image']
init_path=ROOT/base['init_boot_b_image']
source=vendor_path.read_bytes()
assert hashlib.sha256(source).hexdigest()==baseline['vendor_boot_b']
align=lambda n:(n+4095)//4096*4096
off=align(align(struct.unpack_from('<I',source,2096)[0])+struct.unpack_from('<I',source,24)[0])
size=struct.unpack_from('>I',source,off+4)[0]
old=source[off:off+size]
tree,reservations=parse(old)
nodes=dict(walk(tree))
gpu='/soc@0/gpu@3d00000'
assert nodes[gpu].get('status')==b'disabled\0'
nodes[gpu].set('status',b'okay\0')
nodes[gpu+'/zap-shader'].set('firmware-name',b'qcom/sm8550/xigua/a740_zap.mbn\0')
raw=serialise(tree,reservations)
assert len(raw)<=size
padded=bytearray(raw).ljust(size,b'\0');struct.pack_into('>I',padded,4,size)
before,after=FDT(old).nodes(),FDT(padded).nodes()
delta=[]
for path in before.keys()|after.keys():
    for key in before.get(path,{}).keys()|after.get(path,{}).keys():
        a,b=before.get(path,{}).get(key),after.get(path,{}).get(key)
        if a!=b:
            assert (path,key) in ((gpu,'status'),(gpu+'/zap-shader','firmware-name'))
            delta.append(dict(node=path,property=key,before=None if a is None else a.hex(),after=b.hex()))
assert len(delta)==2
vendor=bytearray(source);vendor[off:off+size]=padded
assert vendor[:off]==source[:off] and vendor[off+size:]==source[off+size:]
(OUT/'vendor_boot_b-gpu.img').write_bytes(vendor)
(OUT/'gpu.dtb').write_bytes(padded)
source=init_path.read_bytes()
assert hashlib.sha256(source).hexdigest()==baseline['init_boot_b']
oldsize=struct.unpack_from('<I',source,12)[0]
entries=parse_cpio(lz4(['-d','-l','-c'],source[4096:4096+oldsize]))
original={n.removeprefix('./'):(f,d) for f,n,d in entries}
fwroot=ROOT/'out/gpu-firmware-stock-20261014'
firm=json.loads((fwroot/'firmware-manifest.json').read_text())
for item in firm['files']:
    assert hashlib.sha256((fwroot/item['file']).read_bytes()).hexdigest()==item['sha256']
assets={}
for path in (fwroot/'linux-firmware').rglob('*'):
    if path.is_file():assets['lib/firmware/'+path.relative_to(fwroot/'linux-firmware').as_posix()]=path.read_bytes()
assert len(assets)==3
parents=set()
for name in assets:
    for p in Path(name).parents:
        if str(p)!='.':parents.add(p.as_posix())
ino=max(f[0] for f,n,d in entries)+1
rebuilt=bytearray()
for fields,name,data in entries:
    if name=='TRAILER!!!':
        for path in sorted(parents,key=lambda n:(n.count('/'),n)):
            if path not in original:
                rebuilt+=make_entry([ino,0o40755,0,0,2,0,0,0,0,0,0,0,0],path,b'');ino+=1
        for path,data in sorted(assets.items()):
            assert path not in original
            rebuilt+=make_entry([ino,0o100644,0,0,1,0,0,0,0,0,0,0,0],path,data);ino+=1
        data=b''
    rebuilt+=make_entry(fields,name,data)
updated={n.removeprefix('./'):(f,d) for f,n,d in parse_cpio(rebuilt)}
for name,record in original.items():assert updated[name]==record,name
for name,data in assets.items():assert updated[name][1]==data
compressed=lz4(['-z','-l','-12','-c'],rebuilt)
oldend,newend=4096+align(oldsize),4096+align(len(compressed))
assert newend<len(source)-64
if newend>oldend:assert not any(source[oldend:newend])
init=bytearray(source);struct.pack_into('<I',init,12,len(compressed))
init[4096:max(oldend,newend)]=compressed.ljust(max(oldend,newend)-4096,b'\0')
assert init[:12]==source[:12] and init[16:4096]==source[16:4096]
assert init[max(oldend,newend):]==source[max(oldend,newend):]
assert lz4(['-d','-l','-c'],init[4096:4096+len(compressed)])==rebuilt
(OUT/'init_boot_b-gpu.img').write_bytes(init)
(OUT/'initramfs-gpu.cpio.gz').write_bytes(gzip.compress(rebuilt,mtime=0))
manifest=dict(baseline_hashes=baseline,kernel_unchanged=True,display_touch_usb_dt_unchanged=True,
              existing_initramfs_entries_unchanged=True,original_avb_tails_preserved=True,
              dt_delta=delta,firmware_sha256={n:hashlib.sha256(d).hexdigest() for n,d in assets.items()},
              files={n:dict(size=(OUT/n).stat().st_size,sha256=hashlib.sha256((OUT/n).read_bytes()).hexdigest())
                     for n in ('vendor_boot_b-gpu.img','init_boot_b-gpu.img')},phone_execution_confirmed=False)
(OUT/'deployment-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('PASS: only two GPU DT properties changed; stock firmware added; kernel and all existing initramfs entries preserved')

"""Stage original GPU firmware with source and destination SHA256 provenance."""
import hashlib
import json
import shutil
import struct
from pathlib import Path

out=Path('/mnt/h/workspace/PJA110-Mainline/out/gpu-firmware-stock-20261014')
source=Path.home()/'workspace/PJA110-Mainline/erofs-extraction-tools/vendor-a-extracted'
original=out/'original'
original.mkdir(exist_ok=True)
files=['a740_sqe.fw','gmu_gen70200.bin','a740_zap.mbn','a740_zap.mdt',
       'a740_zap.elf','a740_zap.b00','a740_zap.b01','a740_zap.b02']
records=[]
for name in files:
    src=source/'firmware'/name
    data=src.read_bytes()
    dst=original/name
    shutil.copyfile(src,dst)
    digest=hashlib.sha256(data).hexdigest()
    assert hashlib.sha256(dst.read_bytes()).hexdigest()==digest
    records.append(dict(source_android_path='/vendor/firmware/'+name,
                        file='original/'+name,size=len(data),sha256=digest))
stage=out/'linux-firmware'
for name,target in [('a740_sqe.fw','qcom/a740_sqe.fw'),
                    ('gmu_gen70200.bin','qcom/gmu_gen70200.bin'),
                    ('a740_zap.mbn','qcom/sm8550/xigua/a740_zap.mbn')]:
    dst=stage/target;dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(original/name,dst)
    assert dst.read_bytes()==(original/name).read_bytes()
elf=(original/'a740_zap.mbn').read_bytes()
assert elf[:5]==b'\x7fELF\x01'
machine=struct.unpack_from('<H',elf,18)[0]
phoff=struct.unpack_from('<I',elf,28)[0]
phsize,phnum=struct.unpack_from('<HH',elf,42)
segments=[]
for i in range(phnum):
    kind,offset,vaddr,paddr,size,memsize,flags,align=struct.unpack_from('<8I',elf,phoff+i*phsize)
    assert offset+size<=len(elf)
    segments.append(dict(type=kind,offset=offset,paddr=hex(paddr),filesz=size,memsz=memsize,flags=hex(flags)))
props={}
for line in (out/'vendor-build.prop').read_text().splitlines():
    if line and not line.startswith('#') and '=' in line:
        key,val=line.split('=',1)
        if key in ('ro.vendor.build.fingerprint','ro.vendor.build.version.release',
                   'ro.vendor.build.security_patch','ro.vendor.build.date.utc',
                   'ro.product.vendor.device','ro.product.vendor.model'):props[key]=val
manifest=dict(source='live device super, metadata slot 0, vendor_a',
              source_partition_sha256=hashlib.sha256((out/'vendor_a.img').read_bytes()).hexdigest(),
              vendor_build=props,files=records,zap_elf_machine=machine,zap_elf_segments=segments,
              linux_firmware_root='linux-firmware',files_unmodified=True,
              firmware_authentication_tested=False,phone_partitions_written=False)
(out/'firmware-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))

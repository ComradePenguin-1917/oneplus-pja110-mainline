"""Package SDMA-only control while retaining the stock AVB tail."""
import gzip,hashlib,json,struct
import sys
from pathlib import Path
from bootimg import BootImage
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/dpu-sdma-control-20261014'
base=ROOT/'out/display-generator-avb-retest-20261014/boot_b-generated-panel.img'
FIRSTLINE='--firstline' in sys.argv
TEHEIGHT='--te-height' in sys.argv
PACKET2='--packet2' in sys.argv
TRACE='--trace' in sys.argv
BUDGET='--budget' in sys.argv
SHUTDOWN='--shutdown' in sys.argv
if FIRSTLINE:
    OUT=ROOT/'out/dsc-firstline-control-20261014'
    base=ROOT/'out/dpu-sdma-control-20261014/boot_b-sdma.img'
if TEHEIGHT:
    OUT=ROOT/'out/te-height-control-20261014'
    base=ROOT/'out/dsc-firstline-control-20261014/boot_b-sdma.img'
if PACKET2:
    OUT=ROOT/'out/dsc-packet-control-20261014'
    base=ROOT/'out/te-height-control-20261014/boot_b-sdma.img'
if TRACE:
    OUT=ROOT/'out/display-timing-20261014'
    base=ROOT/'out/dsc-packet-control-20261014/boot_b-sdma.img'
if BUDGET:
    OUT=ROOT/'out/display-budget-20261014'
    base=ROOT/'out/display-timing-20261014/boot_b-sdma.img'
if SHUTDOWN:
    OUT=ROOT/'out/drm-shutdown-20261014/kernel'
    base=ROOT/'out/display-budget-20261014/boot_b-sdma.img'
image=(OUT/'Image').read_bytes()
syms={v[2]:int(v[0],16) for line in (OUT/'System.map').read_text().splitlines() if len(v:=line.split())==3}
start=syms['__initramfs_start']-syms['_text']
length=struct.unpack_from('<Q',image,syms['__initramfs_size']-syms['_text'])[0]
assert gzip.decompress(image[start:start+length])==gzip.decompress((ROOT/'out/debug-ncm-fixed-20261013/initramfs.cpio.gz').read_bytes())
assert b'AA536 generator-based 60Hz driver' in image
boot=BootImage.parse(str(base));boot.kernel=image
packed=boot.pack(cmdline=boot.cmdline.decode())
source=base.read_bytes()
magic,_,_,_,offset,size,_=struct.unpack('>4sIIQQQ28s',source[-64:])
assert magic==b'AVBf' and source[offset:offset+4]==b'AVB0' and len(packed)<offset
result=bytearray(source);result[:len(packed)]=packed
assert result[len(packed):]==source[len(packed):]
(OUT/'boot_b-sdma.img').write_bytes(result)
assert BootImage.parse(str(OUT/'boot_b-sdma.img')).kernel==image
baseline=json.loads((ROOT/'out/gpu-port-20261014/after.json').read_text())
if FIRSTLINE:baseline=json.loads((ROOT/'out/dpu-sdma-control-20261014/after.json').read_text())
if TEHEIGHT:baseline=json.loads((ROOT/'out/dsc-firstline-control-20261014/verified-combination.json').read_text())['partition_hashes']
if PACKET2:baseline=json.loads((ROOT/'out/te-height-control-20261014/after.json').read_text())
if TRACE:baseline=json.loads((ROOT/'out/dsc-packet-control-20261014/after.json').read_text())
if BUDGET:baseline=json.loads((ROOT/'out/display-timing-20261014/after.json').read_text())
if SHUTDOWN:baseline=json.loads((ROOT/'out/display-budget-20261014/after.json').read_text())
assert hashlib.sha256(source).hexdigest()==baseline['boot_b']
manifest=dict(baseline_hashes=baseline,boot_b_sha256=hashlib.sha256(result).hexdigest(),
              avb_tail_preserved=True,only_boot_b_changed=True,active_ctl_unchanged=True,
              panel_dsi_dsc_gpu_touch_unchanged=True,phone_execution_confirmed=False)
if FIRSTLINE:
    manifest.update(panel_dsi_dsc_gpu_touch_unchanged=False,first_line_bpg_offset=15,
                    other_dsi_settings_unchanged=True,rollback_boot_image=str(base))
if TEHEIGHT:
    manifest.update(te_sync_config_height=65520,te_height_panel='oneplus,aa536-p-3-a0001',
                    rollback_boot_image=str(base),other_te_parameters_unchanged=True)
if PACKET2:
    manifest.update(dsc_slices_per_packet=2,expected_dcs_word_count=1241,
                    expected_packets_per_line=1,te_sync_config_height=65520,
                    rollback_boot_image=str(base),dsc_coding_parameters_unchanged=True,
                    panel_dsi_dsc_gpu_touch_unchanged=False)
if TRACE:
    manifest.update(display_source_unchanged=True,event_tracing_enabled=True,
                    rollback_boot_image=str(base),te_sync_config_height=65520,
                    dsc_slices_per_packet=2)
if BUDGET:
    manifest.update(command_transfer_budget_us=6000,
                    budget_scope='AA536 1240x2772 60Hz command mode',
                    runtime_fixed_perf_required=False,
                    rollback_boot_image=str(base),config_unchanged=True,
                    only_core_perf_source_changed=True)
if SHUTDOWN:
    manifest.update(rollback_boot_image=str(base),config_unchanged=True,
                    shutdown_device_link=True,command_transfer_budget_us=6000)
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('PASS: full SDMA-only boot image packaged; original AVB tail and embedded SSH preserved')

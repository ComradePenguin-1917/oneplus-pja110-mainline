from pathlib import Path
import tarfile
import json

cache=Path.home()/'workspace/PJA110-Mainline/pmbootstrap-work/cache_apk_aarch64'
found=[]
for path in cache.glob('APKINDEX*.tar.gz'):
    try:
        with tarfile.open(path) as archive:
            data=archive.extractfile('APKINDEX').read().decode()
        for record in data.split('\n\n'):
            fields=dict(line.split(':',1) for line in record.splitlines() if ':' in line)
            if fields.get('P') in ('seatd','seatd-openrc','seatd-libs'):
                found.append(fields)
    except (KeyError,tarfile.TarError):
        pass
print(json.dumps(found,indent=2))

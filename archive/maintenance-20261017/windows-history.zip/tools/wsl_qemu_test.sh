#!/bin/bash
# Install QEMU and boot OUR kernel + OUR initramfs in a VM, to get a REAL console.
#
# Why this is worth doing
# -----------------------
# Everything so far has been blind on the phone: no UART, no adb from our kernel.
# We have only indirect evidence (the phone falls back to Android). A VM gives us
# a console for the SAME kernel binary and the SAME initramfs, which validates:
#
#   * does our Image even boot as an arm64 kernel at all?
#   * does /init run, and does it reach the signalling stage?
#   * does the poweroff/reboot ladder behave as written?
#
# If the kernel boots under QEMU but not on the phone, the difference is the
# platform (device tree, firmware, memory map), not our kernel or initramfs.
# If it does not boot even under QEMU, we have found a real bug cheaply.
#
# QEMU virt has completely different hardware, so this is NOT a substitute for
# the phone -- it is a cheap sanity check on our own artefacts.
set -uo pipefail

echo "=== installing qemu-system-arm ==="
if ! command -v qemu-system-aarch64 >/dev/null 2>&1; then
    sudo apt-get update -qq 2>&1 | tail -2
    sudo DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
        qemu-system-arm >/dev/null 2>&1
fi

if command -v qemu-system-aarch64 >/dev/null 2>&1; then
    echo "  installed: $(qemu-system-aarch64 --version | head -1)"
else
    echo "  INSTALL FAILED"
    exit 1
fi

ROOT="$HOME/workspace/PJA110-Mainline"
IMG="$ROOT/out/Image-poweroff"
INITRD="$ROOT/initramfs/initramfs.cpio.gz"

echo
echo "=== inputs ==="
ls -l "$IMG" "$INITRD"

echo
echo "=== boot under QEMU virt (60s timeout) ==="
echo "  note: our initramfs signals by powering off when it finds no USB, so a"
echo "  shutdown here is EXPECTED and means /init ran."
echo

timeout 90 qemu-system-aarch64 \
    -M virt -cpu cortex-a57 -smp 2 -m 2048 \
    -kernel "$IMG" \
    -initrd "$INITRD" \
    -append "console=ttyAMA0 loglevel=7 rdinit=/init" \
    -nographic -no-reboot \
    2>&1 | head -120

echo
echo "=== qemu exited (rc=$?) ==="

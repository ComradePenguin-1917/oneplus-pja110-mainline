#!/usr/bin/env python3
"""Build the patched vendor_boot CORRECTLY.

Bug in the first attempt: I overwrote entry 0 with our (smaller) DTB and
zero-filled the slack. But ABL walks the concatenated DTBs by each blob's
`totalsize`, so after our shorter DTB it would land on zeros, fail to find an
FDT magic, and the walk would break -- entries 1..3 would be lost.

Fix: pad our DTB to EXACTLY entry 0's slot size by rewriting its `totalsize`
field, which is what FDT padding is for (the kernel/libfdt accept totalsize
larger than the sum of the structure and string blocks; that trailing space is
how overlays reserve room).

Result: `dtb_size`, the header, the ramdisk, the ramdisk table, the bootconfig
and entries 1..3 are all byte-identical. Only bytes inside entry 0 change.
"""
import hashlib
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fdt import FDT

WS = r'H:\WorkSpace\PJA110-Mainline'
PAGE = 4096
SRC = os.path.join(WS, 'backup', 'vendor_boot_a.img')
OURS = os.path.join(WS, 'dts', 'sm8550-oneplus-xigua-16G.dtb')
OUT = os.path.join(WS, 'out', 'vendor_boot_a-xigua.img')


def pad_fdt(blob, target):
    """Return blob padded to `target` bytes with totalsize updated."""
    total = struct.unpack_from('>I', blob, 4)[0]
    if total != len(blob):
        raise ValueError('blob length %d != totalsize %d' % (len(blob), total))
    if target < total:
        raise ValueError('target %d smaller than blob %d' % (target, total))
    out = bytearray(blob) + b'\0' * (target - total)
    struct.pack_into('>I', out, 4, target)
    return bytes(out)


v = bytearray(open(SRC, 'rb').read())
ours = open(OURS, 'rb').read()

hsize, dtbsize = struct.unpack_from('<2I', v, 28+2048+4+16)
vrsize = struct.unpack_from('<I', v, 24)[0]
dtb_off = (((hsize + PAGE - 1)//PAGE)*PAGE + vrsize + PAGE - 1)//PAGE*PAGE
e0_size = struct.unpack_from('>I', v, dtb_off+4)[0]

print('=== inputs ===')
print('  source            : %s' % SRC)
print('  dtb section       : 0x%x, dtb_size=%d' % (dtb_off, dtbsize))
print('  entry0 slot size  : %d' % e0_size)
print('  our DTB           : %d bytes' % len(ours))
print('  fits              : %s' % (len(ours) <= e0_size))

print()
print('=== pad our DTB to exactly the slot size ===')
padded = pad_fdt(ours, e0_size)
print('  padded length     : %d  (totalsize now %d)'
      % (len(padded), struct.unpack_from('>I', padded, 4)[0]))

# sanity: the padded blob must still parse and carry our model
fr = FDT(padded)
print('  parses OK         : model=%s nodes=%d'
      % (fr.nodes()['/'].get('model', b'').rstrip(b'\0').decode(), len(fr.nodes())))

print()
print('=== write into entry 0 (no other byte moves) ===')
before_header = bytes(v[:dtb_off])
before_tail = bytes(v[dtb_off + e0_size:])
v[dtb_off:dtb_off + e0_size] = padded

print('  header+ramdisk untouched : %s' % (bytes(v[:dtb_off]) == before_header))
print('  everything after entry0 untouched : %s'
      % (bytes(v[dtb_off + e0_size:]) == before_tail))

open(OUT, 'wb').write(bytes(v))

print()
print('=== verify the whole dtb section walks correctly ===')
w = open(OUT, 'rb').read()
off = dtb_off
for i in range(4):
    total = struct.unpack_from('>I', w, off+4)[0]
    fj = FDT(w[off:off+total])
    root = fj.nodes()['/']
    mid = root.get('qcom,msm-id')
    ms = ' '.join('0x%x' % x for x in struct.unpack('>%dI' % (len(mid)//4), mid))[:44] if mid else '-'
    print('  entry%d @0x%06x size=%-7d model=%-38s msm-id=%s'
          % (i, off, total, root.get('model', b'').rstrip(b'\0').decode()[:38], ms))
    off += total

print()
print('  walked end offset : 0x%x' % off)
print('  expected end      : 0x%x  (dtb_off+dtb_size)' % (dtb_off + dtbsize))
print('  walk complete     : %s' % (off == dtb_off + dtbsize))

print()
print('=== integrity of the rest of the image ===')
for name, a, b in (
    ('header', bytes(w[:hsize]), bytes(open(SRC, "rb").read()[:hsize])),
    ('ramdisk', bytes(w[dtb_off - vrsize:dtb_off]) if False else None, None),
):
    if a is not None:
        print('  %-10s identical: %s' % (name, a == b))

o = open(SRC, 'rb').read()
print('  ramdisk    identical: %s' % (w[(hsize+PAGE-1)//PAGE*PAGE : (hsize+PAGE-1)//PAGE*PAGE+vrsize]
                                    == o[(hsize+PAGE-1)//PAGE*PAGE : (hsize+PAGE-1)//PAGE*PAGE+vrsize]))
print('  table+beyond identical: %s' % (w[dtb_off+dtbsize:] == o[dtb_off+dtbsize:]))

print()
print('  sha256 original : %s' % hashlib.sha256(o).hexdigest())
print('  sha256 patched  : %s' % hashlib.sha256(w).hexdigest())
print('  size unchanged  : %s' % (len(w) == len(o)))
print()
print('wrote %s' % OUT)
print('NOT FLASHED.')

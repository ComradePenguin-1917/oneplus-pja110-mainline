#!/bin/bash
# Resume the kernel build after the transient segfault.
#
# The failure was a one-off SIGSEGV in cc1 that does not reproduce when the same
# object is built alone, and the compiler passes repeated smoke tests -- so it
# looks like a transient resource/VM hiccup rather than a bad toolchain.
#
# Mitigations applied here:
#   * lower parallelism (20 jobs on a 23 GiB VM with a 1.7 GB source tree is
#     aggressive; cc1 instances are memory hungry)
#   * retry the whole build once on failure so a single hiccup does not need
#     manual babysitting
set -uo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
TREE="$ROOT/linux"
PREFIX="$ROOT/toolchain/gcc-12-aarch64"

export PATH="$PREFIX/usr/bin:$PATH"
export LD_LIBRARY_PATH="$PREFIX/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export ARCH=arm64
export CROSS_COMPILE=aarch64-linux-gnu-

JOBS="${JOBS:-12}"
cd "$TREE"

echo "=== free memory before build ==="
free -h | head -2
echo "jobs: $JOBS (reduced from $(nproc))"

build() {
    make -j"$JOBS" ARCH=arm64 CROSS_COMPILE="$CROSS_COMPILE" Image Image.gz dtbs
}

echo
echo "=== attempt 1 ==="
START=$(date +%s)
if build 2>&1 | tail -25; then
    echo "BUILD OK (attempt 1)"
else
    echo
    echo "=== attempt 1 failed; clearing partial output and retrying serially-ish ==="
    # a killed cc1 can leave a truncated .o that confuses the next run
    find . -name '*.o' -newermt '-10 minutes' -size -2k -delete 2>/dev/null || true
    echo "=== attempt 2 (jobs=$((JOBS/2))) ==="
    JOBS=$((JOBS/2))
    if build 2>&1 | tail -25; then
        echo "BUILD OK (attempt 2)"
    else
        echo "BUILD STILL FAILING -- needs investigation"
        exit 1
    fi
fi
END=$(date +%s)
echo "total time: $((END-START))s"

echo
echo "=== artifacts ==="
ls -l arch/arm64/boot/Image arch/arm64/boot/Image.gz 2>/dev/null
echo
ls -l arch/arm64/boot/dts/qcom/sm8550-oneplus-xigua*.dtb 2>/dev/null || echo "DTBs NOT BUILT"

"""Fetch upstream source archives for a RAM-only native phone build."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from urllib.request import urlopen
import tarfile

out=Path(__file__).resolve().parents[1]/'out/phoc-atomic-fix-20261016'
out.mkdir(exist_ok=True)
urls={
 'gvdb.tar.gz':'https://gitlab.gnome.org/GNOME/gvdb/-/archive/4758f6fb7f889e074e13df3f914328f3eecb1fd3/gvdb-4758f6fb7f889e074e13df3f914328f3eecb1fd3.tar.gz',
 'phoc.tar.gz':'https://gitlab.gnome.org/World/Phosh/phoc/-/archive/v0.57.0/phoc-v0.57.0.tar.gz',
 'wlroots.tar.gz':'https://gitlab.gnome.org/Infrastructure/Mirrors/lorry-mirrors/gitlab_freedesktop_org/wlroots/wlroots/-/archive/0.20.2/wlroots-0.20.2.tar.gz',
}
def fetch(item):
 name,url=item
 p=out/name
 if not p.exists():p.write_bytes(urlopen(url,timeout=45).read())
 with tarfile.open(p) as archive:
  for member in archive:
   if member.name.endswith(('meson.build','meson_options.txt','meson.options')) and member.name.count('/')==1:
    (out/(name.replace('.tar.gz','')+'-'+member.name.split('/')[-1])).write_bytes(archive.extractfile(member).read())
 print(name,p.stat().st_size,flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(fetch,urls.items()))

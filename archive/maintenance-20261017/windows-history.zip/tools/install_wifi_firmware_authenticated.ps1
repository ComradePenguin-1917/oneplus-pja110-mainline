# Password is entered directly into phone sudo, not recorded by this script.
$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path -Parent $PSScriptRoot
$sshArgs = @('-F', 'none', '-tt', '-i', "$taskRoot/out/usb-ncm-20261013/ssh/client_key_host",
    '-o', 'BatchMode=yes', '-o', 'IdentitiesOnly=yes', '-o', 'StrictHostKeyChecking=yes',
    '-o', "UserKnownHostsFile=$taskRoot/out/native-install-20261017/known_hosts",
    '-o', 'ConnectTimeout=6', 'penguin@172.16.42.1')
& 'C:/Windows/System32/OpenSSH/ssh.exe' @sshArgs 'sudo /bin/sh /home/penguin/wifi-bringup/stock-board/install.sh'
if ($LASTEXITCODE -ne 0) { throw "Wi-Fi firmware installer exited $LASTEXITCODE; inspect output." }

#!/bin/bash
# Properly check for __symbols__ / ABL labels using FDT parsing, not `strings`
# (short label names like "arch_timer" are not reliable with strings).
set -uo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
TREE="$ROOT/linux"
cd "$TREE"

echo "=== does scripts/Makefile.lib exist / how are DTC flags passed? ==="
ls -l scripts/Makefile.lib 2>/dev/null || echo "  MISSING scripts/Makefile.lib"
grep -n 'DTC_FLAGS\|cmd_dtc' scripts/Makefile.lib 2>/dev/null | head -20

echo
python3 - <<'PY'
import struct, sys, os

def load(p):
    b = open(p, 'rb').read()
    if b[:4] != b'\xd0\x0d\xfe\xed':
        return None
    off_struct = struct.unpack_from('>I', b, 8)[0]
    off_str    = struct.unpack_from('>I', b, 12)[0]
    def s(o):
        e = b.index(b'\0', off_str + o)
        return b[off_str+o:e].decode('utf-8', 'replace')
    paths, props = [], {}
    pos, path = off_struct, []
    BEG, END, PROP, NOP, FIN = 1, 2, 3, 4, 9
    while True:
        t = struct.unpack_from('>I', b, pos)[0]; pos += 4
        if t == BEG:
            e = b.index(b'\0', pos); nm = b[pos:e].decode(); pos = (e+4) & ~3
            path.append(nm); paths.append('/'.join(x for x in path if x) or '/')
        elif t == END:
            if path: path.pop()
        elif t == PROP:
            ln, no = struct.unpack_from('>II', b, pos); pos += 8
            val = b[pos:pos+ln]; pos = (pos+ln+3) & ~3
            props.setdefault('/'.join(x for x in path if x) or '/', {})[s(no)] = val
        elif t == NOP:
            continue
        else:
            break
    return paths, props

for p in ('arch/arm64/boot/dts/qcom/sm8550-oneplus-xigua-16G.dtb',
          '/mnt/h/WorkSpace/PJA110-Mainline/dts/sm8550-oneplus-xigua-16G.dtb'):
    if not os.path.exists(p):
        print('missing', p); continue
    r = load(p)
    print('=== %s (%d bytes)' % (p, os.path.getsize(p)))
    if not r:
        print('   not an FDT'); continue
    paths, props = r
    print('   nodes: %d' % len(paths))
    has_sym = any(x.rstrip('/').endswith('__symbols__') for x in paths)
    print('   __symbols__ node present : %s' % has_sym)
    sym = [x for x in paths if x.endswith('/__symbols__')]
    if sym:
        d = props.get(sym[0], {})
        print('   symbols count            : %d' % len(d))
        for k in ('qcom_tzlog', 'arch_timer'):
            print('   symbol %-14s      : %s' % (k, k in d))
    else:
        # fall back: search property values for the label names
        blob = open(p,'rb').read()
        print('   raw contains qcom_tzlog  : %s' % (b'qcom_tzlog' in blob))
        print('   raw contains arch_timer  : %s' % (b'arch_timer' in blob))
PY

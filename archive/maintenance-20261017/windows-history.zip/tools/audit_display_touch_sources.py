"""Read-only source inventory and pinned candidate downloads; no device access."""
import hashlib
import json
import urllib.request
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

OUT = Path(__file__).resolve().parents[1] / 'out/display-touch-reuse-20261013'
OUT.mkdir(parents=True, exist_ok=True)

def get(url):
    req = urllib.request.Request(url, headers={'User-Agent': 'PJA110-source-audit'})
    with urllib.request.urlopen(req, timeout=40) as response:
        return response.read()

def api(repo, path):
    return json.loads(get(f'https://api.github.com/repos/{repo}/{path}'))

def inventory(label, repo, ref):
    commit = api(repo, 'commits/' + ref)['sha']
    root = api(repo, 'git/trees/' + commit)
    drivers = next(x['sha'] for x in root['tree'] if x['path'] == 'drivers')
    tree = api(repo, 'git/trees/' + drivers + '?recursive=1')
    assert not tree.get('truncated'), 'Incomplete drivers inventory'
    selected = [dict(x, path='drivers/' + x['path']) for x in tree['tree']
                if x['type'] == 'blob' and
                (x['path'].startswith('gpu/drm/panel/') or
                 x['path'].startswith('input/touchscreen/') or
                 x['path'].startswith('input/rmi4/'))]
    (OUT / (label + '-inventory.json')).write_text(json.dumps(
        {'repo': repo, 'commit': commit, 'complete_drivers_tree': True,
         'files': selected}, indent=2) + '\n')
    candidates = [x for x in selected if any(s in x['path'].lower() for s in
        ('synaptics', 'syna_tcm', 'touchcom', 'nt377', 'nt365', 'aa536', 'visionox'))]
    records = []
    for entry in candidates:
        path = entry['path']
        data = get(f'https://raw.githubusercontent.com/{repo}/{commit}/{path}')
        blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        assert blob == entry['sha'], path
        dest = OUT / label / path
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        records.append({'path': path, 'git_blob': blob,
                        'sha256': hashlib.sha256(data).hexdigest()})
    (OUT / (label + '-candidates.json')).write_text(json.dumps(records, indent=2) + '\n')
    print(label, commit, 'inventory', len(selected), 'candidates', len(records), flush=True)

if __name__ == '__main__':
    if '--generator' in sys.argv:
        repo = 'msm8916-mainline/linux-mdss-dsi-panel-driver-generator'
        commit = api(repo, 'commits/master')['sha']
        tree = api(repo, 'git/trees/' + commit)
        items = [x for x in tree['tree'] if x['type'] == 'blob' and
                 (x['path'].endswith('.py') or x['path'] in ('README.md', 'COPYING'))]
        def fetch(entry):
            data = get(f"https://raw.githubusercontent.com/{repo}/{commit}/{entry['path']}")
            digest = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
            assert digest == entry['sha']
            dest = OUT / 'panel-generator' / entry['path']
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
            return {'path': entry['path'], 'git_blob': digest,
                    'sha256': hashlib.sha256(data).hexdigest()}
        with ThreadPoolExecutor(max_workers=4) as pool:
            files = list(pool.map(fetch, items))
        (OUT / 'panel-generator-manifest.json').write_text(json.dumps(
            {'repo': repo, 'commit': commit, 'files': files}, indent=2) + '\n')
        print('Pinned panel generator', commit, 'files', len(files))
        raise SystemExit(0)
    if '--extra' in sys.argv:
        inv = json.loads((OUT / 'aston-inventory.json').read_text())
        paths = ['drivers/input/touchscreen/syna_tcm2.c',
                 'drivers/input/touchscreen/syna_tcm2.h',
                 'drivers/input/touchscreen/syna_tcm2_spi.c',
                 'drivers/gpu/drm/panel/panel-novatek-nt36532e.c',
                 'drivers/gpu/drm/panel/panel-aa551-p-3-a0004-dsc.c',
                 'arch/arm64/boot/dts/qcom/sm8550-oneplus-aston.dts']
        for path in paths:
            if (OUT / 'aston' / path).exists():
                continue
            data = get(f"https://raw.githubusercontent.com/{inv['repo']}/{inv['commit']}/{path}")
            expected = next((x['sha'] for x in inv['files'] if x['path'] == path), None)
            blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
            if expected:
                assert blob == expected
            dest = OUT / 'aston' / path
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
            print(path, blob, flush=True)
        raise SystemExit(0)
    inventory('aston', 'jiganomegsdfdf/aston-mainline',
              '5d5c840896bb49291ae4578acefd5a3ec65524f6')
    inventory('mainline-current', 'torvalds/linux', 'master')

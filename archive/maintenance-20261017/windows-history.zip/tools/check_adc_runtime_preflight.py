"""Read native-A ADC DT nodes and module inventory."""
from pathlib import Path
import subprocess
from prepare_native_install import SSH
args = SSH[:]
args[-1] = 'penguin@172.16.42.1'
args = [x if not x.startswith('UserKnownHostsFile=') else
        'UserKnownHostsFile=out/native-install-20261017/known_hosts' for x in args]
cmd = '''uname -r
cat /proc/sys/kernel/random/boot_id
echo PMIC_NODES
find /sys/firmware/devicetree/base -name 'pmic@*' -o -name '*sdam*' -o -name 'nvram@*'
echo SDAM_DRIVERS
find /sys/bus/platform/drivers/nvmem_qcom_spmi_sdam -maxdepth 1 -type l
echo COMMON_MODULE
modinfo qcom_vadc_common
echo ADC_INSTALL
systemctl status pja110-adc-test.service --no-pager
systemctl is-enabled pja110-adc-test.service
sha256sum /home/penguin/adc-test/vendor_boot_a-before.img /usr/local/lib/pja110/qcom-spmi-adc5-gen3.ko
journalctl -b -k --no-pager | grep -Ei 'adc5|unknown symbol|invalid module'
echo BATTERY
cat /sys/class/power_supply/bq28z610-0/capacity /sys/class/power_supply/bq28z610-0/current_now
find /sys/firmware/devicetree/base -name '*9000*' -o -name '*9100*' -o -name '*vadc*'
for d in /sys/bus/platform/devices/*9000*; do
    [ -d "$d" ] || continue
    echo DEVICE=$d
    cat "$d/modalias"
    readlink "$d/driver" || true
done
find /usr/lib/modules/$(uname -r) -name '*vadc*' -o -name '*adc5*'
cat /proc/modules
'''
p = subprocess.run(args + [cmd], capture_output=True, timeout=30)
dest = Path('out/native-install-20261017/adc-gen3/runtime-preflight.txt')
dest.write_bytes(p.stdout + p.stderr)
print(p.stdout.decode(errors='replace'))
print(p.stderr.decode(errors='replace'))
p.check_returncode()

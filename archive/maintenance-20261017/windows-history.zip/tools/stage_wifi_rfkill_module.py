"""Stage the built Aston RF-kill module as a removable updates override."""
from pathlib import Path
import hashlib
import json
import subprocess
from prepare_native_install import SSH

out = Path('out/wifi-bringup-20261017/aston-rfkill')
manifest = json.loads((out / 'manifest.json').read_text())
module = (out / 'ath12k.ko').read_bytes()
assert hashlib.sha256(module).hexdigest() == manifest['sha256']
args = SSH[:]
args[-1] = 'penguin@172.16.42.1'
args = [x if not x.startswith('UserKnownHostsFile=') else
        'UserKnownHostsFile=out/native-install-20261017/known_hosts' for x in args]
remote = '/home/penguin/wifi-bringup/aston-rfkill'

def run(cmd, data=None):
    p = subprocess.run(args + [cmd], input=data, capture_output=True, timeout=40)
    print(p.stdout.decode(errors='replace'), end='')
    print(p.stderr.decode(errors='replace'), end='')
    p.check_returncode()
    return p.stdout

state = run('uname -r; modinfo -F filename ath12k; modinfo -F vermagic ath12k; '
            'rfkill list; cat /proc/sys/kernel/random/boot_id')
assert b'6.14.0-oneplus-xigua SMP preempt mod_unload aarch64' in state
collect = '''#!/bin/sh
set -u
dir=/home/penguin/wifi-bringup/aston-rfkill
sleep 30
exec > "$dir/result.txt" 2>&1
chmod 644 "$dir/result.txt"
date; cat /proc/sys/kernel/random/boot_id
echo MODULE_VERSION
cat /sys/module/ath12k/version
cat /sys/module/ath12k/srcversion
echo RFKILL_BEFORE
rfkill list
rfkill unblock wifi
nmcli radio wifi on
echo WIFI_SCAN
nmcli device wifi rescan ifname wlan0 || true
sleep 3
nmcli -f IN-USE,SSID,MODE,CHAN,RATE,SIGNAL,SECURITY device wifi list ifname wlan0 --rescan no || true
echo WIFI_STATE
rfkill list; ip -brief link
nmcli -t -f DEVICE,TYPE,STATE device
journalctl -b -k --no-pager | grep -Ei 'ath12|wlan|wifi|mhi|rfkill' | tail -n 220
touch "$dir/complete"
echo WIFI_ASTON_RFKILL_TEST_COMPLETE
'''
service = '''[Unit]
Description=One-shot validation of Aston WCN7850 RF-kill parameters
After=NetworkManager.service
ConditionPathExists=!/home/penguin/wifi-bringup/aston-rfkill/complete

[Service]
Type=oneshot
ExecStart=/usr/local/libexec/pja110-wifi-aston-rfkill-test
TimeoutStartSec=100

[Install]
WantedBy=multi-user.target
'''
install = '''#!/bin/sh
set -eu
test "$(id -u)" = 0
test "$(uname -r)" = 6.14.0-oneplus-xigua
cd /home/penguin/wifi-bringup/aston-rfkill
test ! -e complete
test "$(sha256sum ath12k.ko | cut -d ' ' -f 1)" = MODULE_SHA
test "$(modinfo -F version ./ath12k.ko)" = pja110-aston-rfkill-1
test "$(modinfo -F vermagic ./ath12k.ko)" = '6.14.0-oneplus-xigua SMP preempt mod_unload aarch64'
dest=/lib/modules/6.14.0-oneplus-xigua/updates/pja110-wifi/ath12k.ko
if [ -e "$dest" ] && ! cmp -s ath12k.ko "$dest"; then
 echo 'A different module override exists; not overwritten'; exit 1
fi
fw=/usr/lib/firmware/ath12k/WCN7850/hw2.0
test "$(sha256sum "$fw/amss.bin" | cut -d ' ' -f 1)" = e6d7816a71eebb147dade9e928c9e1c7a9a79399d770226aae85b4ca83b692d6
test "$(sha256sum "$fw/m3.bin" | cut -d ' ' -f 1)" = 2a22bf383890ee2ece5e1b9598b24173a4e7f5d710f441bb3963f575c9729ce0
modinfo -F filename ath12k > module-path-before.txt
install -D -m 644 ath12k.ko "$dest"
depmod -a 6.14.0-oneplus-xigua
test "$(modinfo -F version ath12k)" = pja110-aston-rfkill-1
test "$(readlink -f "$(modinfo -F filename ath12k)")" = "$(readlink -f "$dest")"
install -D -m 755 collect.sh /usr/local/libexec/pja110-wifi-aston-rfkill-test
install -D -m 644 pja110-wifi-aston-rfkill.service /etc/systemd/system/pja110-wifi-aston-rfkill.service
systemctl daemon-reload
systemctl enable pja110-wifi-aston-rfkill.service
sync
echo 'Aston parameter module override verified; packaged module untouched; rebooting'
systemctl reboot
'''.replace('MODULE_SHA', manifest['sha256'])
restore = '''#!/bin/sh
set -eu
test "$(id -u)" = 0
dest=/lib/modules/6.14.0-oneplus-xigua/updates/pja110-wifi/ath12k.ko
test "$(sha256sum "$dest" | cut -d ' ' -f 1)" = MODULE_SHA
rm "$dest"
depmod -a 6.14.0-oneplus-xigua
echo 'Module override removed; packaged module selected again; reboot to apply'
'''.replace('MODULE_SHA', manifest['sha256'])
files = {'ath12k.ko': module, 'collect.sh': collect.encode(),
         'pja110-wifi-aston-rfkill.service': service.encode(),
         'install.sh': install.encode(), 'restore.sh': restore.encode()}
run('mkdir -p ' + remote)
for name, data in files.items():
    if name != 'ath12k.ko':
        (out / name).write_bytes(data)
    run(f'cat > {remote}/{name}', data)
run(f'cd {remote}; sha256sum ath12k.ko; modinfo -F version ./ath12k.ko; '
    'sh -n install.sh; sh -n collect.sh; sh -n restore.sh')
manifest['phone_staged'] = True
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
p = subprocess.run(args + ['sudo -n true'], capture_output=True, timeout=15)
print('Noninteractive sudo:', p.returncode == 0)
print(p.stderr.decode(errors='replace'))

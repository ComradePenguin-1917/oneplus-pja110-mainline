#!/usr/bin/env python3
"""Before flashing a no-op dtbo: does the BASE tree alone suffice for boot and
for observability?

Risk being assessed
-------------------
The vendor dtbo is not decoration: it configures board-specific things. If the
UFS host/PHY or the USB controller is only ENABLED by an overlay, then removing
all overlays could leave a device that neither boots (no rootfs) nor is
observable (no adb), forcing a blind recovery via the key-combo.

Method
------
Compare three trees:
  base    vendor_boot entry0 (what ABL starts from)
  live    /sys/firmware/fdt from the running phone (base + dtbo applied)
  dtbo    the overlay content

Look specifically at the nodes mainline needs for bring-up:
  UFS host / UFS PHY      (rootfs)
  USB dwc3 / QMP phy      (observability)
  geni serial             (console output)
and report whether each is present-and-okay in base vs live.
"""
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fdt import FDT, load_entries

WS = r'H:\WorkSpace\PJA110-Mainline'


def dec(v):
    return v.rstrip(b'\0').decode('ascii', 'replace')


# --- base tree ---
v = open(os.path.join(WS, 'backup', 'vendor_boot_b.img'), 'rb').read()
hsize, dtbsize = struct.unpack_from('<2I', v, 28+2048+4+16)
vrsize = struct.unpack_from('<I', v, 24)[0]
dtb_off = (((hsize+4095)//4096)*4096 + vrsize + 4095)//4096*4096
e0 = struct.unpack_from('>I', v, dtb_off+4)[0]
base = FDT(v[dtb_off:dtb_off+e0]).nodes()

live = FDT(open(os.path.join(WS, 'live-from-device.dtb'), 'rb').read()).nodes()

INTEREST = {
    'UFS host':      ['ufshc'],
    'UFS PHY':       ['ufsphy'],
    'USB dwc3':      ['ssusb', 'dwc3'],
    'USB HS phy':    ['hsphy', 'eusb2'],
    'USB SS phy':    ['ssphy', 'qmp'],
    'geni serial':   ['qup_uart', 'geni'],
    'sdhci':         ['sdhci'],
    'spmi':          ['spmi'],
    'pinctrl/tlmm':  ['tlmm', 'pinctrl'],
}


def find(nodes, keys, depth_max=5):
    hits = []
    for p in nodes:
        leaf = p.split('/')[-1].lower()
        if not any(k in leaf for k in keys):
            continue
        if p.count('/') > depth_max:
            continue
        hits.append(p)
    return sorted(hits)[:4]


def status_of(nodes, p):
    props = nodes.get(p, {})
    st = props.get('status')
    return dec(st) if st else '(none)'


print('=' * 78)
print('1) Are the bring-up-critical nodes present in the BASE tree vs LIVE tree?')
print('=' * 78)
for label, keys in INTEREST.items():
    b = find(base, keys)
    l = find(live, keys)
    print('--- %s' % label)
    print('    base: %d node(s)%s' % (len(b), ('  status=' + ', '.join(status_of(base, x) for x in b)) if b else ''))
    for x in b:
        print('           %s' % x[:70])
    print('    live: %d node(s)%s' % (len(l), ('  status=' + ', '.join(status_of(live, x) for x in l)) if l else ''))
    for x in l:
        print('           %s' % x[:70])

print()
print('=' * 78)
print('2) Which base nodes do the overlays actually modify?')
print('=' * 78)
entries, _ = load_entries(os.path.join(WS, 'dtbo-A14.img'))
label, sub = entries[1]
f = FDT(sub)
n = f.nodes()
fixups = n.get('/__fixups__', {})

# the base tree's __symbols__ maps label -> {target,path}; resolve which base
# node each referenced label points at
base_syms = base.get('/__symbols__', {})


def sym_path(symval):
    """The __symbols__ value is a path string in a real tree, or a phandle."""
    if not symval:
        return None
    if symval[:1] == b'/':
        return dec(symval)
    return 'phandle 0x%x' % struct.unpack('>I', symval[:4])[0]


print('  the dtbo references these labels (resolved against the BASE tree):')
interesting_labels = []
for lab in sorted(fixups):
    target = base_syms.get(lab)
    tp = sym_path(target) if target else None
    if tp and any(k in tp.lower() for keys in INTEREST.values() for k in keys):
        interesting_labels.append((lab, tp))

for lab, tp in interesting_labels[:30]:
    print('    %-26s -> %s' % (lab[:26], tp[:52]))
print('  (%d of %d labels point at bring-up-critical nodes)'
      % (len(interesting_labels), len(fixups)))

print()
print('=' * 78)
print('3) Does the LIVE tree differ from BASE for those nodes?')
print('=' * 78)
base_only = set(base) - set(live)
live_only = set(live) - set(base)
print('  nodes only in base: %d' % len(base_only))
print('  nodes only in live: %d  (added by overlays)' % len(live_only))
for p in sorted(live_only)[:15]:
    print('     + %s' % p[:66])

"""Extract charger fault/timer firmware strings and their direct references."""
from pathlib import Path
import json
import re
import runpy

scope = runpy.run_path('tools/inspect_adsp_disassembly.py')
out = Path('out/native-install-20261017/charger-enable-cycle')
matches = {}
for base, data in scope['segments']:
    for m in re.finditer(rb'[ -~]{6,}\x00', data):
        text = m[0][:-1].decode()
        if re.search(r'wdog|watchdog|safety.?timer|charge.?timeout|charging.?timeout|charge.?error|chgr.*status|charger.*status|timer.*expir|charge.*fault', text, re.I):
            matches[base + m.start()] = text
lines = (scope['OUT'] / 'adsp-charger-analysis-only.dis').read_text().splitlines()
refs = {a: [] for a in matches}
for line in lines:
    for addr in re.findall(r'##0x([0-9a-f]+)', line):
        a = int(addr, 16)
        if a in refs:
            refs[a].append(line)
report = {hex(a): dict(text=t, references=refs[a]) for a, t in matches.items()}
(out / 'fault-timer-strings.json').write_text(json.dumps(report, indent=2) + '\n')
for a, t in matches.items():
    if re.search(r'Scpq|safety|charg', t, re.I):
        print(hex(a), t)
        for line in refs[a][:3]:
            print(' ', line)

#!/usr/bin/env python3
"""Evaluate the ramoops/pstore channel: can our kernel leave a log that we can
read after the inevitable fallback to Android?

Why this is the highest-value channel available
-----------------------------------------------
Everything so far has been blind: no console, no USB, no adb from our kernel.
But the vendor device tree defines a persistent RAM region for exactly this:

    /reserved-memory/ramoops_region
        compatible   = "ramoops"
        console-size = 0x40000     <- a CONSOLE that writes into RAM
        pmsg-size    = 0x200000
        size         = 0x240000

If our kernel has pstore + ramoops + pstore-console enabled and the same region,
then a panic or even ordinary console output is written to RAM, which SURVIVES a
warm reset -- and the Android kernel that we fall back into can expose it at
/sys/fs/pstore. That turns an invisible failure into a readable log.

Checks needed:
  1. our kernel config: PSTORE, PSTORE_RAM, PSTORE_CONSOLE, PSTORE_PMSG
  2. our DTB: does it define a ramoops region? (earlier check said NO)
  3. the vendor region's real address after boot (alloc-ranges means the kernel
     picks an address, so we must find where it landed)
  4. whether that address is free in OUR memory map (so we can pin it)
"""
import os
import struct
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
sys.path.insert(0, os.path.join(WS, 'tools'))
from fdt import FDT


def dec(v):
    return v.rstrip(b'\0').decode('ascii', 'replace')


def regs(v):
    out = []
    for i in range(0, len(v) - 15, 16):
        b, s = struct.unpack_from('>QQ', v, i)
        out.append((b, s))
    return out


print('=' * 78)
print('1) OUR KERNEL CONFIG (pstore family)')
print('=' * 78)
cfg = os.path.join(WS, 'out', 'config-6.14-xigua')
if not os.path.exists(cfg):
    print('  config file not found')
else:
    want = ['CONFIG_PSTORE', 'CONFIG_PSTORE_RAM', 'CONFIG_PSTORE_CONSOLE',
            'CONFIG_PSTORE_PMSG', 'CONFIG_PSTORE_DEFLATE_COMPRESS',
            'CONFIG_PSTORE_ZONE', 'CONFIG_PSTORE_BLK', 'CONFIG_PSTORE_BLK_MAX_REASON',
            'CONFIG_PSTORE_RAM_MAX_REASON', 'CONFIG_PSTORE_RAMOOPS_CONSISTENCY']
    lines = {}
    for l in open(cfg, encoding='utf-8', errors='replace'):
        l = l.strip()
        if '=' in l:
            k, v = l.split('=', 1)
            lines[k] = v
        elif l.startswith('# ') and 'is not set' in l:
            lines[l[2:].split(' ')[0]] = 'NOT SET'
    for w in want:
        print('  %-34s %s' % (w, lines.get(w, '(absent)')))

print()
print('=' * 78)
print('2) RAMOOPS IN EACH TREE')
print('=' * 78)
live = FDT(open(os.path.join(WS, 'live-from-device.dtb'), 'rb').read()).nodes()
ours = FDT(open(os.path.join(WS, 'dts', 'sm8550-oneplus-xigua-16G.dtb'), 'rb').read()).nodes()

for name, nodes in (('vendor live tree', live), ('OUR DTB', ours)):
    hits = [p for p in nodes if 'ramoops' in p.lower() or 'pstore' in p.lower()]
    print('  %-18s %s' % (name, hits or 'NONE'))
    for p in hits:
        print('    [%s]' % p)
        for k in sorted(nodes[p]):
            v = nodes[p][k]
            if k == 'reg':
                print('      %-16s %s' % (k, ' '.join('0x%x+0x%x' % r for r in regs(v))))
            elif k == 'alloc-ranges':
                print('      %-16s %s' % (k, ' '.join('0x%x+0x%x' % r for r in regs(v))))
            elif len(v) <= 8:
                n = int.from_bytes(v, 'big') if v else 0
                print('      %-16s 0x%x (%d)' % (k, n, n))
            else:
                print('      %-16s %r' % (k, dec(v)))

print()
print('=' * 78)
print('3) IS THE VENDOR RAMOOPS ADDRESS FIXED?')
print('=' * 78)
rp = live.get('/reserved-memory/ramoops_region', {})
has_reg = 'reg' in rp
has_alloc = 'alloc-ranges' in rp
print('  has reg          : %s' % has_reg)
print('  has alloc-ranges : %s' % has_alloc)
if has_reg:
    for b, s in regs(rp['reg']):
        print('    resolved address: 0x%x  size 0x%x' % (b, s))
else:
    print('    -> NO reg: the kernel allocated it dynamically, so the address')
    print('       depends on the boot. We cannot rely on it from another kernel.')
    print('       For our own DTB we must PIN a fixed address.')

print()
print('=' * 78)
print('4) WHERE COULD WE PUT A FIXED RAMOOPS REGION?')
print('=' * 78)
mem = ours.get('/memory', {}).get('reg', b'')
print('  our /memory regions:')
for b, s in regs(mem):
    print('    base 0x%-11x size 0x%x' % (b, s))

print()
print('  our reserved-memory children (to avoid overlaps):')
rm = [p for p in ours if p.startswith('/reserved-memory/') and p.count('/') == 2]
for p in sorted(rm):
    props = ours[p]
    r = props.get('reg')
    if r:
        for b, s in regs(r):
            print('    %-52s 0x%x+0x%x' % (p.split('/')[-1][:52], b, s))
    elif 'size' in props:
        sz = int.from_bytes(props['size'], 'big')
        print('    %-52s (alloc-ranges, size 0x%x)' % (p.split('/')[-1][:52], sz))

print()
print('=' * 78)
print('5) VENDOR RAMOOPS SIZE/PARAMS TO MIRROR')
print('=' * 78)
for k in ('size', 'console-size', 'pmsg-size', 'mem-type', 'ftrace-size',
          'record-size', 'ecc-size', 'max-reason'):
    if k in rp:
        v = rp[k]
        print('  %-14s 0x%x' % (k, int.from_bytes(v, 'big')))

"""Install the verified pmbootstrap APK only into the disposable phone chroot."""
from pathlib import Path
import hashlib
import json
import sys

scope = {'__file__': str(Path(__file__).with_name('test_phoc_atomic_fix.py'))}
exec(Path(scope['__file__']).read_text().split('stage = sys.argv[1]')[0], scope)
run = scope['run']
out = scope['OUT'] / 'apk-aarch64'
records = json.loads((out / 'verification.json').read_text())
names = ('phoc-0.57.0-r2.apk', 'phoc-schemas-0.57.0-r2.apk', 'phoc-lang-0.57.0-r2.apk')
run('test -f /tmp/postmarketos-ram/etc/os-release; mkdir -p /tmp/postmarketos-ram/tmp/phoc-apk')
for name in names:
    data = (out / name).read_bytes()
    digest = next(r['sha256'] for r in records if r['file'] == name)
    assert hashlib.sha256(data).hexdigest() == digest
    target = '/tmp/postmarketos-ram/tmp/phoc-apk/' + name
    run('cat > ' + target, data)
    assert run('sha256sum ' + target).decode().split()[0] == digest
key = 'pmos@local-6acfb8ca.rsa.pub'
local_key = (out / key).read_bytes()
remote_key = run('cat /tmp/postmarketos-ram/etc/apk/keys/' + key)
assert remote_key == local_key, 'Existing RAM signing key differs'
args = ' '.join('/tmp/phoc-apk/' + name for name in names)
verify = run('chroot /tmp/postmarketos-ram apk --no-network verify ' + args)
(out / 'phone-signature-verification.txt').write_bytes(verify)
print(verify.decode())
plan = run('chroot /tmp/postmarketos-ram apk --no-network add --simulate ' + args)
(out / 'phone-install-plan.txt').write_bytes(plan)
print(plan.decode())
if sys.argv[1:] == ['install']:
    # The known-good /opt/phoc-cursor build stays available for desktop rollback.
    before = run('chroot /tmp/postmarketos-ram apk --no-network info -v')
    (out / 'phone-packages-before.txt').write_bytes(before)
    run('test -x /tmp/postmarketos-ram/opt/phoc-cursor/bin/phoc; '
        'mkdir -p /tmp/postmarketos-ram/opt/phoc-stock/bin; '
        'test -e /tmp/postmarketos-ram/opt/phoc-stock/bin/phoc || '
        'cp -p /tmp/postmarketos-ram/usr/bin/phoc /tmp/postmarketos-ram/opt/phoc-stock/bin/phoc')
    result = run('chroot /tmp/postmarketos-ram apk --no-network add ' + args, timeout=90)
    (out / 'phone-install-result.txt').write_bytes(result)
    print(result.decode())
    expected = next(r['binary_sha256'] for r in records if r['file'] == names[0])
    assert run('sha256sum /tmp/postmarketos-ram/usr/bin/phoc').decode().split()[0] == expected
    print(run('chroot /tmp/postmarketos-ram /usr/bin/phoc --version').decode())
    scope['switch']('apk')
elif sys.argv[1:]:
    raise SystemExit('usage: install_phoc_apk_ram.py [install]')

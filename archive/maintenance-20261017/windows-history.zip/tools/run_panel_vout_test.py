"""Run the fixed 35-second GPIO90 experiment; preserve streaming output."""
import hashlib
import subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/display-port-20261013'
KEYS=ROOT/'out/usb-ncm-20261013/ssh'
SSH=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(KEYS/'client_key_host'),
     '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
     '-o',f'UserKnownHostsFile={KEYS/"known_hosts"}','-o','ConnectTimeout=5',
     '-o','ServerAliveInterval=5','root@169.254.42.1']
for name in ('fb-pattern','panel-vout-test'):
    data=(OUT/name).read_bytes()
    p=subprocess.run(SSH+[f'cat > /tmp/{name}; chmod 700 /tmp/{name}; sha256sum /tmp/{name}'],input=data,capture_output=True,check=True,timeout=30)
    assert p.stdout.decode().split()[0]==hashlib.sha256(data).hexdigest()
with (OUT/'vout-test-output.txt').open('wb') as log:
    p=subprocess.Popen(SSH+['/tmp/panel-vout-test'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    for line in p.stdout:
        log.write(line);log.flush();print(line.decode(errors='replace'),end='',flush=True)
    p.wait(timeout=60)
    if p.returncode:raise SystemExit(p.returncode)
p=subprocess.run(SSH+['dmesg; cat /sys/kernel/debug/gpio | grep "gpio90 "'],capture_output=True,check=True,timeout=30)
(OUT/'dmesg-after-vout-test.txt').write_bytes(p.stdout)
assert b'gpio90  : out low' in p.stdout
print('PASS: bounded GPIO90 test finished and original low level restored')

#!/usr/bin/env python3
"""Why a no-op dtbo is DANGEROUS on this device, and what to do instead.

Finding from assess_noop_dtbo_risk.py:
    node                        base          live
    /soc/ufshc@1d84000          disabled  ->  ok
    /soc/ufsphy_mem@1d80000     disabled  ->  ok
    /soc/sdhci@8804000          disabled  ->  ok

The overlays are what ENABLE storage. Removing them would leave no rootfs, and
possibly no USB either, i.e. no way to observe the failure without the key-combo
recovery. So a no-op dtbo is NOT a safe experiment.

That kills the simple plan ("swap base tree + no-op the dtbo"). This script works
out the alternative: keep the overlays working by making OUR base tree export the
labels they need.

Two sub-problems:
  A) the 168 fixup labels must resolve -> our tree needs matching __symbols__
  B) some of those fragments flip `status` from disabled to okay on nodes that
     must exist in our tree with the same node names

So the real task is: take the vendor base tree's __symbols__ (1521 labels) and
figure out exactly what subset our tree must expose. Measure it.
"""
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fdt import FDT, load_entries

WS = r'H:\WorkSpace\PJA110-Mainline'


def dec(v):
    return v.rstrip(b'\0').decode('ascii', 'replace')


# vendor base tree
v = open(os.path.join(WS, 'backup', 'vendor_boot_b.img'), 'rb').read()
hsize, dtbsize = struct.unpack_from('<2I', v, 28+2048+4+16)
vrsize = struct.unpack_from('<I', v, 24)[0]
dtb_off = (((hsize+4095)//4096)*4096 + vrsize + 4095)//4096*4096
e0 = struct.unpack_from('>I', v, dtb_off+4)[0]
base = FDT(v[dtb_off:dtb_off+e0]).nodes()
base_syms = base.get('/__symbols__', {})

ours = FDT(open(os.path.join(WS, 'dts', 'sm8550-oneplus-xigua-16G.dtb'), 'rb').read()).nodes()
our_syms = set(ours.get('/__symbols__', {}))

entries, _ = load_entries(os.path.join(WS, 'dtbo-A14.img'))

print('=' * 78)
print('A) which labels must our tree export?')
print('=' * 78)
needed = {}
for lab, sub in entries:
    f = FDT(sub)
    for x in f.nodes().get('/__fixups__', {}):
        needed.setdefault(x, set()).add(lab)
all_needed = set(needed)
print('  union of labels required by all 4 dtbo entries: %d' % len(all_needed))
print('  our tree already exports                     : %d' % len(all_needed & our_syms))
missing = all_needed - our_syms
print('  MISSING                                      : %d' % len(missing))

print()
print('=' * 78)
print('B) what do the MISSING labels point at, in the vendor tree?')
print('=' * 78)
groups = {}
for lab in sorted(missing):
    target = base_syms.get(lab)
    if not target:
        groups.setdefault('(not in vendor base __symbols__)', []).append(lab)
        continue
    p = dec(target)
    # group by top-level area
    seg = p.split('/')[1] if p.count('/') >= 1 else p
    groups.setdefault(seg, []).append((lab, p))

for seg, items in sorted(groups.items(), key=lambda x: -len(x[1])):
    print('  /%s : %d labels' % (seg, len(items)))
    for lab, p in items[:6]:
        print('      %-24s %s' % (lab[:24], p[:54]))
    if len(items) > 6:
        print('      ... and %d more' % (len(items) - 6))

print()
print('=' * 78)
print('C) the crux: which nodes do the overlays ENABLE?')
print('=' * 78)
enabled = []
for lab, sub in entries:
    f = FDT(sub)
    n = f.nodes()
    for p in n:
        if '/__overlay__' in p:
            props = n[p]
            st = props.get('status')
            if st and dec(st) == 'ok':
                enabled.append(p.split('__overlay__', 1)[1])
print('  overlay fragments that set status="ok": %d' % len(enabled))
for p in sorted(set(enabled))[:20]:
    print('      %s' % p[:66])

print()
print('=' * 78)
print('CONCLUSION')
print('=' * 78)
print('  A no-op dtbo would leave UFS/PHY/sdhci disabled -> no rootfs, and')
print('  probably no adb either. Too risky to flash as a first step.')
print()
print('  The workable path is to keep the overlays and make our base tree')
print('  satisfy them. That means our DTB must export the %d missing labels,'
      % len(missing))
print('  which in practice means providing the nodes they point at.')
print()
print('  A cheaper, lower-risk alternative worth considering first: instead of')
print('  replacing the whole base tree, patch ONLY the nodes mainline needs')
print('  (clocks, pinctrl, usb, ufs) directly in the vendor base tree, leaving')
print('  everything the overlays depend on intact.')

"""Run a RAM-only scanout ruler through upstream kmscube's synchronized flips."""
import argparse,hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('mode',choices=('continuous','step','static','single'))
args=parser.parse_args()
mode={'continuous':0,'step':1,'static':2,'single':3}[args.mode]
out=ROOT/'out/display-timing-20261014/ruler'
keys=ROOT/'out/usb-ncm-20261013/ssh'
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(keys/'client_key_host'),
 '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
 '-o',f'UserKnownHostsFile={keys/"known_hosts"}','-o','ConnectTimeout=5','root@169.254.42.1']
def run(cmd,data=None):
 p=subprocess.run(ssh+[cmd],input=data,capture_output=True,timeout=25)
 (out/'last-stderr.txt').write_bytes(p.stderr)
 p.check_returncode();return p.stdout
data=(out/'kmscube-aarch64').read_bytes()
digest=hashlib.sha256(data).hexdigest()
assert run('set -e; cat > /tmp/ubuntu-ram/tmp/kms-ruler.new; chmod 700 /tmp/ubuntu-ram/tmp/kms-ruler.new; sha256sum /tmp/ubuntu-ram/tmp/kms-ruler.new',data).decode().split()[0]==digest
script=f'''set -e
killall -TERM weston-simple-egl 2>/dev/null || true
killall -TERM weston 2>/dev/null || true
killall -TERM kms-ruler 2>/dev/null || true
sleep 2
mv /tmp/ubuntu-ram/tmp/kms-ruler.new /tmp/ubuntu-ram/tmp/kms-ruler
echo 1024 > /sys/class/backlight/ae94000.dsi.0/brightness
nohup chroot /tmp/ubuntu-ram /usr/bin/env FD_MESA_DEBUG=noubwc,notile MESA_LOADER_DRIVER_OVERRIDE=msm PJA_RULER_MODE={mode} /tmp/kms-ruler -D /dev/dri/card0 -N -m 0 -c 10000000 > /tmp/kms-ruler.log 2>&1 < /dev/null &
echo $!
sleep 4
cat /tmp/kms-ruler.log
ps
cat /sys/kernel/debug/dri/0/state
cat /sys/kernel/debug/dri/0/encoder-0/status
'''
state=run(script)
(out/f'{args.mode}-state.txt').write_bytes(state)
assert f'PJA ruler: 1240x2772, mode={mode}'.encode() in state
assert b'/tmp/kms-ruler -D' in state
assert b'failed' not in state.lower(),state.decode(errors='replace')
(out/'current.json').write_text(json.dumps({'mode':args.mode,'binary_sha256':digest,
 'partitions_written':False,'top_origin_marker_rows':[352,396,440,484,528],
 'visual_confirmation_pending':True},indent=2)+'\n')
print(f'Confirmed {args.mode} ruler running indefinitely at 1240x2772, markers 396 red / 440 green / 484 blue')

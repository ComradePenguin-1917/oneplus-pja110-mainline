"""Decode the existing OEM fixed PMIC snapshot, without device access."""
from pathlib import Path
import json, re, runpy, struct
out = Path('out/native-install-20261017/charger-watchdog-probe')
capture = sorted(out.glob('live-*.txt'))[-1]
text = capture.read_text()
m = re.search(r'OEM_SNAPSHOT_RESULT=0\s+512\s+([0-9,]+)', text)
if not m:
    raise SystemExit('No complete OEM snapshot in capture')
values = list(map(int, m[1].split(',')))
assert len(values) == 128
# Firmware 0x6015e8d0 emits 53 address/value pairs starting at word 15.
pairs = dict(zip(values[15:121:2], values[16:122:2]))
assert len(pairs) == 53 and all(0 < a < 0x10000 and 0 <= v < 256 for a,v in pairs.items())
scope = runpy.run_path('tools/inspect_adsp_disassembly.py')
tables = {}
for address in [0x60273ae0, 0x60273b44, 0x60273ba8, 0x60273c0c]:
    base, data = next((b,d) for b,d in scope['segments'] if b <= address < b+len(d))
    tables[hex(address)] = {hex(i*4):hex(v) for i,v in enumerate(struct.unpack_from('<24I',data,address-base))}
report = dict(capture=str(capture), registers={f'0x{a:04x}':f'0x{v:02x}' for a,v in pairs.items()},
    state_bits=pairs[0x2606]&7, enable_bit=pairs[0x2646]&1,
    note='Snapshot precedes watchdog pet. Individual PMIC read errors and pet return are not propagated by OEM producer.',
    callback_tables=tables,
    post_probe_restored='READONLY_MODULE_RESTORED' in text,
    post_probe_completed='WATCHDOG_ONESHOT_COMPLETE' in text,
    current_after_probe_uA=[int(v) for v in re.findall(r'POWER_SUPPLY_NAME=bq28z610-0.*?POWER_SUPPLY_CURRENT_NOW=(-?\d+)',text,re.S)])
(out/'decoded.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

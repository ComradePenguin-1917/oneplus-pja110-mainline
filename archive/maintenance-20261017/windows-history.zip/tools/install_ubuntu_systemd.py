"""Configure packages in an independent phone RAM root; preserve debug services."""
import hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];out=ROOT/'out/ubuntu-systemd-20261014'
m=json.loads((out/'manifest.json').read_text());keys=ROOT/'out/usb-ncm-20261013/ssh'
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(keys/'client_key_host'),
 '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
 '-o',f'UserKnownHostsFile={keys/"known_hosts"}','-o','ConnectTimeout=5','root@169.254.42.1']
def run(cmd,data=None,timeout=60):
 p=subprocess.run(ssh+[cmd],input=data,capture_output=True,timeout=timeout)
 (out/'last-stderr.txt').write_bytes(p.stderr);p.check_returncode();return p.stdout
resume='--resume' in sys.argv
if not resume:
 for path,remote,digest in [(ROOT/'out/ubuntu-ram-20261014'/m['base_file'],'base.tar.gz',m['base_sha256']),(out/m['package_archive'],'packages.tar',m['package_archive_sha256'])]:
  data=path.read_bytes();assert hashlib.sha256(data).hexdigest()==digest
  print('Uploading',remote,flush=True)
  assert run(f'set -e; cat > /tmp/ubuntu-systemd-{remote}; sha256sum /tmp/ubuntu-systemd-{remote}',data,240).decode().split()[0]==digest
 setup='''set -e
r=/tmp/ubuntu-systemd
test ! -e "$r/etc/os-release"
mkdir -p "$r"
mount -t tmpfs -o size=3G tmpfs "$r"
tar -xzf /tmp/ubuntu-systemd-base.tar.gz -C "$r"
mkdir -p "$r/proc" "$r/sys" "$r/dev" "$r/run" "$r/tmp/packages"
mount --bind /proc "$r/proc"
mount --bind /sys "$r/sys"
mount --bind /dev "$r/dev"
mount --bind /dev/pts "$r/dev/pts"
tar -xf /tmp/ubuntu-systemd-packages.tar -C "$r/tmp/packages"
printf '#!/bin/sh\nexit 101\n' > "$r/usr/sbin/policy-rc.d"
chmod 755 "$r/usr/sbin/policy-rc.d"
'''
 run(setup,timeout=120)
script='''#!/bin/sh
set -eu
r=/tmp/ubuntu-systemd
chroot "$r" /usr/bin/env DEBIAN_FRONTEND=noninteractive /bin/sh -c 'apt-get --no-install-recommends -y -o Dir::Etc::sourcelist=- -o Dir::Etc::sourceparts=- -o Dpkg::Options::=--force-confold install /tmp/packages/*.deb'
chroot "$r" /usr/bin/dpkg --audit
chroot "$r" /usr/bin/dpkg-query -W -f='${binary:Package}\t${Version}\t${db:Status-Abbrev}\n'
test -x "$r/sbin/init"
touch /tmp/ubuntu-systemd-install.done
'''
run('cat > /tmp/install-ubuntu-systemd.sh; chmod 700 /tmp/install-ubuntu-systemd.sh',script.encode())
pid=run('nohup /tmp/install-ubuntu-systemd.sh > /tmp/ubuntu-systemd-install.log 2>&1 < /dev/null & echo $!')
(out/'install-launch.txt').write_bytes(pid)
print('RAM-only apt/dpkg configuration launched as PID',pid.decode().strip())

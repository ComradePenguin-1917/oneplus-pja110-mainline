#!/bin/bash
# THE OBSERVABILITY PROBLEM.
#
# Our boot.img has ramdisk_size = 0 (copied from stock, where the ramdisk lives
# in vendor_boot instead). So even if our kernel boots perfectly, it has:
#   * no initramfs  -> nothing to execute -> "VFS: Cannot open root device" panic
#   * no display driver -> screen stays on whatever ABL left
#   * no userspace -> USB gadget functions cannot be configured (they need
#     configfs writes from userspace), so ADB can never appear
#
# i.e. the experiment as built is UNOBSERVABLE: a perfectly healthy kernel and a
# dead kernel look identical. Check what we have to fix that.
set -uo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
TREE="$ROOT/linux"
cd "$TREE"

echo "=== 1) initramfs / rootfs options ==="
for s in CONFIG_BLK_DEV_INITRD CONFIG_INITRAMFS_SOURCE CONFIG_RD_GZIP \
         CONFIG_DEVTMPFS CONFIG_DEVTMPFS_MOUNT CONFIG_RD_LZ4 CONFIG_RD_ZSTD; do
    if grep -qE "^$s=" .config; then grep -E "^$s=" .config
    elif grep -qE "^# $s is not set" .config; then echo "# $s is not set"
    else echo "$s: ABSENT"; fi
done

echo
echo "=== 2) can the kernel present ANY USB interface without userspace? ==="
for s in CONFIG_USB_GADGET CONFIG_USB_CONFIGFS CONFIG_USB_G_SERIAL \
         CONFIG_USB_ETH CONFIG_USB_ETH_RNDIS CONFIG_USB_CONFIGFS_RNDIS \
         CONFIG_USB_CONFIGFS_ECM CONFIG_USB_CONFIGFS_SERIAL \
         CONFIG_USB_DWC3_DUAL_ROLE CONFIG_USB_DWC3_GADGET; do
    if grep -qE "^$s=" .config; then grep -E "^$s=" .config
    elif grep -qE "^# $s is not set" .config; then echo "# $s is not set"
    else echo "$s: ABSENT"; fi
done

echo
echo "=== 3) serial console (only other observable channel) ==="
for s in CONFIG_SERIAL_QCOM_GENI_CONSOLE CONFIG_SERIAL_EARLYCON CONFIG_SERIAL_CORE_CONSOLE; do
    if grep -qE "^$s=" .config; then grep -E "^$s=" .config
    elif grep -qE "^# $s is not set" .config; then echo "# $s is not set"
    else echo "$s: ABSENT"; fi
done

echo
echo "=== 4) is there an initramfs in the tree we could reuse? ==="
ls usr/initramfs_data.cpio* 2>/dev/null || echo "  none built"
grep -E '^CONFIG_INITRAMFS_SOURCE' .config || echo "  INITRAMFS_SOURCE not set"

"""Export source changes against cached Linux6.14, excluding all debug secrets."""
import hashlib,io,json,tarfile,re
from pathlib import Path
root=Path.home()/'workspace/PJA110-Mainline'
win=Path('/mnt/h/workspace/PJA110-Mainline')
tree=root/'linux';base=root/'.cache/linux-6.14.tar.xz'
out=win/'postmarketos/device/testing/linux-oneplus-xigua';out.mkdir(parents=True,exist_ok=True)
modified={};seen=set()
with tarfile.open(base,'r:xz') as tar:
 for item in tar:
  name=item.name.removeprefix('linux-6.14/')
  if not item.isfile():continue
  seen.add(name)
  path=tree/name
  if not path.is_file():raise RuntimeError('Missing original source '+name)
  original=tar.extractfile(item).read();current=path.read_bytes()
  if original!=current:modified[name]=current
# Only source additions; never copy initramfs, .config, ELF, keys or build products.
for folder in ('drivers','arch/arm64/boot/dts'):
 for path in (tree/folder).rglob('*'):
  if not path.is_file() or path.is_symlink():continue
  name=path.relative_to(tree).as_posix()
  if name in seen:continue
  if (name.startswith('drivers/gpu/drm/panel/panel-oneplus-aa536') or
      name.startswith('arch/arm64/boot/dts/qcom/sm8550-oneplus-xigua')) and path.suffix in ('.c','.h','.dts','.dtsi'):
   modified[name]=path.read_bytes()
touch=win/'drivers/input/touchscreen/synaptics-aston-rate'
for path in touch.iterdir():
 if path.is_file() and (path.suffix in ('.c','.h') or path.name=='Makefile'):
  modified['drivers/input/touchscreen/synaptics-aston-rate/'+path.name]=path.read_bytes()
assert any('KMS shutdown ordered before GPU supplier' in d.decode(errors='ignore') for d in modified.values())
assert 'drivers/gpu/drm/msm/disp/dpu1/dpu_core_perf.c' in modified
archive=out/'pja110-kernel-overlay.tar.gz'
with archive.open('wb') as file:
 import gzip
 with gzip.GzipFile(fileobj=file,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,data in sorted(modified.items()):
    assert not any(x in name.lower() for x in ('authorized_keys','host-ed25519','initramfs'))
    item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;item.mtime=0
    tar.addfile(item,io.BytesIO(data))
config=(win/'out/drm-shutdown-20261014/kernel/.config').read_text()
config=re.sub(r'^CONFIG_INITRAMFS_SOURCE=.*$', 'CONFIG_INITRAMFS_SOURCE=""',config,flags=re.M)
config=re.sub(r'^CONFIG_LOCALVERSION=.*$', 'CONFIG_LOCALVERSION="-oneplus-xigua"',config,flags=re.M)
config=config.replace('CONFIG_LOCALVERSION_AUTO=y','# CONFIG_LOCALVERSION_AUTO is not set')
(out/'config-oneplus-xigua.aarch64').write_text(config)
records=[{'path':n,'sha256':hashlib.sha256(d).hexdigest()} for n,d in sorted(modified.items())]
m={'base_version':'6.14','base_sha512':hashlib.sha512(base.read_bytes()).hexdigest(),
'overlay_sha512':hashlib.sha512(archive.read_bytes()).hexdigest(),'overlay_bytes':archive.stat().st_size,
'files':records,'verified_hardware_reference':'kernel24','embedded_debug_initramfs_removed':True,
'packaged_kernel_hardware_tested':False}
(out/'source-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print('Exported',len(records),'source changes; overlay',archive.stat().st_size,'bytes; no embedded debug initramfs')

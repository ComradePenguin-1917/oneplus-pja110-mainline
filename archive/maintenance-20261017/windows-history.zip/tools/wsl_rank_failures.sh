#!/bin/bash
# After the control test proved the flash/boot PATH is fine (stock boot.img
# boots in 12s via the same `fastboot boot`), the failure must be in our kernel.
#
# Rank the candidates by how early they would kill the kernel, then check the
# config for each. The earliest possible failure wins, because our kernel dies
# before it can even enumerate USB.
set -uo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
TREE="$ROOT/linux"
cd "$TREE"

echo "############ 1) EARLIEST: memory map / reserved-memory ############"
echo "Our DTS deletes upstream reserved-memory entirely and re-declares 44 regions"
echo "from the LIVE device. If any address is wrong, the kernel dies in"
echo "setup_arch()/memblock -- before any driver, before USB."
echo
echo "  our reserved-memory regions in the built DTB:"
python3 - <<'PY'
import struct
b=open('arch/arm64/boot/dts/qcom/sm8550-oneplus-xigua-16G.dtb','rb').read()
off_struct=struct.unpack_from('>I',b,8)[0]; off_str=struct.unpack_from('>I',b,12)[0]
def s(o):
    e=b.index(b'\0',off_str+o); return b[off_str+o:e].decode('utf-8','replace')
pos=off_struct; path=[]; props={}
BEG,END,PROP,NOP=1,2,3,4
while True:
    t=struct.unpack_from('>I',b,pos)[0]; pos+=4
    if t==BEG:
        e=b.index(b'\0',pos); nm=b[pos:e].decode(); pos=(e+4)&~3
        path.append(nm)
    elif t==END:
        if path: path.pop()
    elif t==PROP:
        ln,no=struct.unpack_from('>II',b,pos); pos+=8
        val=b[pos:pos+ln]; pos=(pos+ln+3)&~3
        props.setdefault('|'.join(x for x in path if x),{})[s(no)]=val
    elif t==NOP: continue
    else: break
n=0; tot=0
for k,v in sorted(props.items()):
    if 'reserved-memory|' in k+'|' and 'reg' in v and len(v['reg'])==16:
        base,size=struct.unpack('>QQ',v['reg'])
        if size:
            n+=1; tot+=size
            print('    %-52s 0x%010x %8.1f MiB' % (k.split('|')[-1], base, size/2**20))
print('    -> %d regions, %.1f MiB total' % (n, tot/2**20))
PY

echo
echo "############ 2) RAM map (oplus_mem) ############"
python3 - <<'PY'
import struct
b=open('arch/arm64/boot/dts/qcom/sm8550-oneplus-xigua-16G.dtb','rb').read()
i=b.find(b'oplus_mem')
print('   oplus_mem symbol present: %s' % (i>=0))
PY
echo "   (7 regions, 15.73 GiB, taken from the live device)"

echo
echo "############ 3) EARLY: kernel features that need bootloader support ############"
for s in CONFIG_ARM64_KASAN CONFIG_KASAN CONFIG_RANDOMIZE_BASE CONFIG_ARM64_PTR_AUTH \
         CONFIG_ARM64_BTI_KERNEL CONFIG_ARM64_MTE CONFIG_CFI_CLANG CONFIG_SHADOW_CALL_STACK \
         CONFIG_ARM64_SW_TTBR0_PAN CONFIG_UNMAP_KERNEL_AT_EL0 CONFIG_ARM64_VA_BITS_48 \
         CONFIG_ARM64_VA_BITS_39 CONFIG_ARM64_4K_PAGES CONFIG_ARM64_16K_PAGES; do
    if grep -qE "^$s=" .config; then grep -E "^$s=" .config | sed 's/^/   /'
    elif grep -qE "^# $s is not set" .config; then echo "   # $s is not set"
    fi
done

echo
echo "############ 4) EARLY: SCM / firmware interface ############"
for s in CONFIG_QCOM_SCM CONFIG_QCOM_SCM_DOWNLOAD_MODE_DETECT CONFIG_ARM_SMMU \
         CONFIG_ARM_SMMU_QCOM CONFIG_QCOM_TZMEM CONFIG_QCOM_TZMEM_MODE_SHMBRIDGE \
         CONFIG_QCOM_TZMEM_MODE_GENERIC; do
    if grep -qE "^$s=" .config; then grep -E "^$s=" .config | sed 's/^/   /'
    elif grep -qE "^# $s is not set" .config; then echo "   # $s is not set"
    fi
done

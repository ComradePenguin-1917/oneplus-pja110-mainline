#!/usr/bin/env python3
"""Resolve the decisive question: WHICH PHYSICAL PINS does the console UART use?

If those pins are routed to the Type-C connector (SBU1/SBU2) or to an external
test pad, we can attach a cable without opening the phone. If they are only on
internal pads, the back cover must come off.

The vendor tree names the pinctrl states, and the pin NAMES map to SoC GPIOs.
So read the pinctrl state that the console UART uses and print its pin list.

Our DTB's console node has:
    pinctrl-names = "default"
    pinctrl-0     = <phandle 0x7d (125)>
so resolve phandle 125 to a pinctrl state node and print its pins/function.
"""
import os
import struct
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
sys.path.insert(0, os.path.join(WS, 'tools'))
from fdt import FDT


def dec(v):
    return v.rstrip(b'\0').decode('ascii', 'replace')


ours = FDT(open(os.path.join(WS, 'dts', 'sm8550-oneplus-xigua-16G.dtb'), 'rb').read()).nodes()
live = FDT(open(os.path.join(WS, 'live-from-device.dtb'), 'rb').read()).nodes()


def resolve(phandle, nodes):
    for p, props in nodes.items():
        v = props.get('phandle')
        if v and len(v) == 4 and struct.unpack('>I', v)[0] == phandle:
            return p
    return None


print('=' * 78)
print('1) OUR DTB: which pinctrl state does the console UART use?')
print('=' * 78)
node = None
for p in ours:
    if 'serial@a9c000' in p:
        node = p
        break
print('  node: %s' % node)
props = ours[node]
ph = struct.unpack('>I', props['pinctrl-0'])[0] if 'pinctrl-0' in props else None
print('  pinctrl-names : %r' % dec(props.get('pinctrl-names', b'')))
print('  pinctrl-0     : phandle %s' % (ph if ph is not None else '?'))

if ph is not None:
    target = resolve(ph, ours)
    print('  -> resolves to : %s' % target)
    if target:
        tp = ours[target]
        for k in sorted(tp):
            v = tp[k]
            print('      %-18s %r' % (k, dec(v) if len(v) <= 60 else '<%d bytes>' % len(v)))
        # pins may be split across child nodes
        for q in sorted(ours):
            if q.startswith(target + '/'):
                print('      subnode %s' % q.split('/')[-1])
                for k in sorted(ours[q]):
                    v = ours[q][k]
                    print('          %-16s %r' % (k, dec(v) if len(v) <= 60 else '<%d bytes>' % len(v)))

print()
print('=' * 78)
print('2) THE VENDOR TREE: its console UART pins')
print('=' * 78)
vnode = None
for p in live:
    if 'qup_uart@a9c000' in p:
        vnode = p
        break
print('  node: %s' % vnode)
vp = live.get(vnode, {})
vph = None
if 'pinctrl-0' in vp:
    v = vp['pinctrl-0']
    if len(v) == 4:
        vph = struct.unpack('>I', v)[0]
    else:
        vph = struct.unpack('>I', v[:4])[0]
print('  pinctrl-0 phandle: %s' % vph)
if vph is not None:
    t = resolve(vph, live)
    print('  -> resolves to: %s' % t)
    if t:
        for k in sorted(live[t]):
            v = live[t][k]
            print('      %-18s %r' % (k, dec(v) if len(v) <= 60 else '<%d bytes>' % len(v)))

print()
print('=' * 78)
print('3) EVERY PIN DEFINITION MENTIONING qup1_se7 (the console UART function)')
print('=' * 78)
for p in sorted(live):
    if 'pinctrl' not in p:
        continue
    props = live[p]
    fn = props.get('function')
    if fn and 'se7' in dec(fn):
        print('  %s' % p)
        for k in sorted(props):
            v = props[k]
            print('      %-18s %r' % (k, dec(v) if len(v) <= 60 else '<%d bytes>' % len(v)))

print()
print('=' * 78)
print('4) WHAT THIS MEANS FOR PHYSICAL ACCESS')
print('=' * 78)
print('  The pin NUMBERS printed above identify the SoC balls. Mapping them to a')
print('  physical location needs the board schematic, which we do not have.')
print()
print('  Practical routes, cheapest first:')
print('    1. USB-C debug accessory (SBU1/SBU2). Some Qualcomm devices mux the')
print('       debug UART onto the Type-C SBU pins, reachable with a passive cable')
print('       and NO disassembly. Nothing in the device tree confirms this for')
print('       this model, so it would need a cable and an experiment.')
print('    2. Internal test pads -> back cover must come off.')
print('    3. Headphone-jack UART: the Ace 2 Pro has no 3.5 mm jack, so ruled out.')
print()
print('  Also relevant: this device has NO exposed debug connector, and the vendor')
print('  cmdline sets console=ttynull, i.e. the vendor build is deliberately mute.')

"""Restore only USB3 PHY dependencies while keeping high-speed peripheral mode."""
import hashlib
import json
import shutil
import struct
from pathlib import Path
from fdt import FDT
from fdtwrite import parse, serialise, walk

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT/'out/user-init-dwc-soft-reset-error-probe-20261012'
OUT = ROOT/'out/user-init-dwc-soft-reset-usb3-phy-probe-20261013'
OUT.mkdir(exist_ok=True)
manifest = json.loads((BASE/'manifest.json').read_text())
source = (BASE/'vendor_boot_b-xigua-r1.img').read_bytes()
assert hashlib.sha256(source).hexdigest() == manifest['files']['vendor_boot_b-xigua-r1.img']['sha256']
align = lambda n: (n+4095)//4096*4096
off = align(align(struct.unpack_from('<I', source, 2096)[0])+struct.unpack_from('<I', source, 24)[0])
size = struct.unpack_from('>I', source, off+4)[0]
old = source[off:off+size]
tree, reservations = parse(old)
nodes = dict(walk(tree))
reference = FDT((ROOT/'out/rebuild-20261012/sm8550-oneplus-xigua-16G.dtb').read_bytes()).nodes()
core, phy = '/soc@0/usb@a6f8800/usb@a600000', '/soc@0/phy@88e8000'
assert nodes[core].props['dr_mode'] == b'peripheral\0'
assert nodes[core].props['maximum-speed'] == b'high-speed\0'
assert 'usb-role-switch' not in nodes[core].props
assert nodes[core].props['phys'] == reference[core]['phys'][:4]
assert nodes[phy].props['phandle'] == reference[phy]['phandle']
assert len(reference[core]['phys']) == 12
assert reference[core]['phys'][4:8] == nodes[phy].props['phandle']
assert nodes[phy].props['status'] == b'disabled\0' and reference[phy]['status'] == b'okay\0'
for key in ('phys', 'phy-names'):
    nodes[core].set(key, reference[core][key])
nodes[phy].set('status', b'okay\0')
raw = serialise(tree, reservations)
assert len(raw) <= size, 'DTB partition allocation must be preserved'
padded = bytearray(raw).ljust(size, b'\0')
struct.pack_into('>I', padded, 4, size)
before, after = FDT(old).nodes(), FDT(bytes(padded)).nodes()
assert before.keys() == after.keys()
delta = [{'node': p, 'property': k, 'before': before[p].get(k).hex(), 'after': after[p].get(k).hex()}
         for p in before for k in before[p].keys() | after[p].keys() if before[p].get(k) != after[p].get(k)]
assert {(d['node'],d['property']) for d in delta} == {(core,'phys'), (core,'phy-names'), (phy,'status')}
result = bytearray(source)
result[off:off+size] = padded
assert result[:off] == source[:off] and result[off+size:] == source[off+size:]
(OUT/'vendor_boot_b-xigua-r1.img').write_bytes(result)
(OUT/'usb3-phy-high-speed-control.dtb').write_bytes(padded)
for name in ('boot-xigua-r1.img','init_boot_b-xigua-r1.img','dtbo_b-avb-noop.img','Image-probe','qemu-result.json','init-probe.sh'):
    shutil.copyfile(BASE/name, OUT/name)
manifest['experiment'] = 'same soft-reset log probe, restore USB3 PHY dependency while keeping high-speed peripheral mode'
manifest['phone_execution_confirmed'] = False
manifest.pop('user_observation_evidence', None)
manifest['dtb_changed_properties'] = delta
manifest['qemu_validation_reused_for_identical_kernel_and_initramfs'] = True
manifest['qemu_does_not_validate_phone_phy_hardware'] = True
manifest['files']['vendor_boot_b-xigua-r1.img']['sha256'] = hashlib.sha256(result).hexdigest()
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
print('PASS: exactly three PHY dependency properties changed; high-speed/peripheral, kernel, initramfs and AVB metadata preserved')

#!/bin/sh
set -u
test "$(id -u)" = 0 || exit 1
echo BEGIN_QRTR_SMD_ROOT_TEST
cat /proc/sys/kernel/random/boot_id /proc/uptime
echo BEFORE
cat /proc/modules | grep -E '^(qrtr|qrtr_smd) ' || true
echo MODPROBE
modprobe qrtr-smd 2>&1; echo qrtr_smd=$?
sleep 3
echo AFTER
cat /proc/modules | grep -E '^(qrtr|qrtr_smd) ' || true
echo SUPPLIES
ls -1 /sys/class/power_supply
echo AUXILIARY
ls -l /sys/bus/auxiliary/devices/pmic_glink* 2>&1 || true
echo DEFERRED
cat /sys/kernel/debug/devices_deferred 2>&1 || true
echo LOG
journalctl -b -k --no-pager -n 160 2>&1 | grep -Ei 'pmic-glink|pdr|qrtr|usb|power.supply|charger' || true
echo END_QRTR_SMD_ROOT_TEST

#!/usr/bin/env python3
"""Extract board-specific facts for the ufs/usb/panel/pinctrl nodes from the
LIVE device tree dumped off the phone.

The live tree is the vendor kernel's actual view of the hardware, so any GPIO
number, supply name or phandle relationship in it is authoritative for this
unit -- far better than guessing from the sibling Ace 3 port.

Usage:
    python live_facts.py --list
    python live_facts.py --node ufshc
"""
import argparse
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fdt import FDT

WS = r'H:\WorkSpace\PJA110-Mainline'
LIVE = os.path.join(WS, 'live-from-device.dtb')

WANT = ('ufshc', 'ufsphy', 'usb', 'hsphy', 'qmpphy', 'dwc3', 'tlmm', 'pinctrl',
        'mdss', 'dsi', 'panel', 'pmic', 'regulator', 'sdhc', 'spmi', 'rsc',
        'pon', 'qup', 'geni', 'pcie', 'gcc', 'pdc', 'watchdog')


def dec(v):
    return v.rstrip(b'\0').decode('ascii', 'replace')


def cells(v):
    if len(v) % 4 == 0 and len(v) <= 64:
        return '<%s>' % ' '.join('0x%x' % x
                                 for x in struct.unpack('>%dI' % (len(v) // 4), v))
    return None


def fmt(k, v):
    if k == 'reg' and len(v) % 16 == 0 and len(v):
        out = []
        for i in range(0, len(v), 16):
            b, s = struct.unpack_from('>QQ', v, i)
            out.append('0x%x+0x%x' % (b, s))
        return ' '.join(out)
    if len(v) == 0:
        return '(bool)'
    t = dec(v)
    if t and all(32 <= ord(c) < 127 for c in t):
        return '"%s"' % t.replace('\0', '" "')
    c = cells(v)
    return c if c else v[:32].hex()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--list', action='store_true')
    ap.add_argument('--node', action='append', default=[])
    ap.add_argument('--dtb', default=LIVE)
    args = ap.parse_args()

    f = FDT(open(args.dtb, 'rb').read())
    nodes = f.nodes()

    if args.list:
        print('top level:')
        tops = sorted({p.split('/')[1] for p in nodes if p.count('/') >= 1 and p != '/'})
        for t in tops:
            print('  /%s' % t)
        soc = [p for p in nodes if p.startswith('/soc/') and p.count('/') == 2]
        print('\n/soc direct children: %d' % len(soc))
        import re
        interesting = [p for p in soc if re.search('|'.join(WANT), p, re.I)]
        print('matching %s: %d' % (WANT, len(interesting)))
        for p in sorted(interesting):
            print('  %s' % p)
        return

    pats = args.node or ['ufshc', 'usb', 'hsphy', 'qmpphy']
    for pat in pats:
        print('#' * 70)
        print('# nodes matching %r' % pat)
        print('#' * 70)
        for path, props in sorted(nodes.items()):
            if pat.lower() not in path.lower():
                continue
            if path.count('/') > 4:
                continue
            print('\n[%s]' % path)
            for k in sorted(props):
                if k in ('phandle', 'linux,phandle'):
                    continue
                print('    %-28s = %s' % (k, fmt(k, props[k])))
        print()


if __name__ == '__main__':
    main()

param([string]$PortName = 'COM12', [string]$OutputDirectory = 'out/user-init-usb-serial-shell-experiment-20261013', [switch]$Resume, [switch]$Base64Chunks)
$ErrorActionPreference = 'Stop'
$target = [IO.Path]::GetFullPath((Join-Path $PWD $OutputDirectory))
$workspace = [IO.Path]::GetFullPath($PWD.Path) + [IO.Path]::DirectorySeparatorChar
if (-not $target.StartsWith($workspace, [StringComparison]::OrdinalIgnoreCase)) { throw 'Output must stay in workspace' }
[IO.Directory]::CreateDirectory($target) | Out-Null
$port = [IO.Ports.SerialPort]::new($PortName,115200)
$port.DtrEnable = $true
$port.RtsEnable = $true
$port.WriteTimeout = 3000
$port.ReadBufferSize = 262144
. (Join-Path $PSScriptRoot 'UsbSerialReader.ps1')
Initialize-UsbSerialReaderType
$reader=$null
$transcript = [Text.StringBuilder]::new()
$cached = @{}
if ($Resume) {
    $previous = [IO.File]::ReadAllText((Join-Path $target 'serial-capture-transcript.txt')).Replace("`r",'')
    [IO.File]::WriteAllText((Join-Path $target 'serial-capture-incomplete.txt'),$previous)
    $offset = 0
    foreach ($m in [regex]::Matches($previous,'(?m)^ACM_CHUNK_(\d+)_DONE$')) {
        $start = [int]$m.Groups[1].Value
        $lines = @([regex]::Matches($previous.Substring($offset,$m.Index-$offset),'(?m)^\[\s*\d+\.\d+\].*$') | ForEach-Object {$_.Value})
        $cached[$start] = $lines
        $offset = $m.Index+$m.Length
    }
}
function Invoke-SerialCommand([string]$Command, [string]$Marker) {
    $port.Write($Command + "; echo " + $Marker + "`n")
    $response = [Text.StringBuilder]::new()
    $timer = [Diagnostics.Stopwatch]::StartNew()
    $nextFlush = 3
    do {
        Start-Sleep -Milliseconds 10
        [void]$response.Append([Text.Encoding]::ASCII.GetString($reader.Drain()))
        if ($response.ToString() -match ("(?m)^" + [regex]::Escape($Marker) + "\r?$")) {
            [void]$transcript.Append($response.ToString())
            return $response.ToString()
        }
        if ($timer.Elapsed.TotalSeconds -ge $nextFlush) {
            $port.Write("echo $Marker`n")
            $nextFlush += 3
        }
    } while ($timer.Elapsed.TotalSeconds -lt 30)
    [void]$transcript.Append($response.ToString())
    throw "Incomplete serial response: $Marker"
}
try {
    $port.Open()
    $reader=[UsbSerialContinuousReader]::new($port,$true)
    Start-Sleep -Milliseconds 500
    [void]$transcript.Append([Text.Encoding]::ASCII.GetString($reader.Drain()))
    $identity = Invoke-SerialCommand 'uname -a; id; cat /proc/uptime' 'ACM_IDENTITY_DONE'
    [IO.File]::WriteAllText((Join-Path $target 'serial-identity.txt'),$identity)
    $sizeCommand = if ($Resume) {'wc -l /tmp/acm-dmesg.txt'} else {'dmesg > /tmp/acm-dmesg.txt; wc -l /tmp/acm-dmesg.txt'}
    $size = Invoke-SerialCommand $sizeCommand 'ACM_SIZE_DONE'
    $lineMatch = [regex]::Match($size,'(?m)^\s*(\d+)\s+/tmp/acm-dmesg.txt')
    if (-not $lineMatch.Success) { throw 'Cannot determine dmesg line count' }
    $count = [int]$lineMatch.Groups[1].Value
    $log = [Text.StringBuilder]::new()
    for ($start=1; $start -le $count; $start+=5) {
        $end = [Math]::Min($start+4,$count)
        $marker = "ACM_CHUNK_${start}_DONE"
        $lines = if(-not $Base64Chunks -and $cached.ContainsKey($start)){@($cached[$start])}else{@()}
        for ($attempt=0; $lines.Count -ne $end-$start+1 -and $attempt -lt 3; $attempt++) {
            if($Base64Chunks){
                $begin="ACM_PAYLOAD_${start}"
                $chunk=Invoke-SerialCommand ("echo $begin; sed -n '${start},${end}p' /tmp/acm-dmesg.txt | base64; sed -n '${start},${end}p' /tmp/acm-dmesg.txt | sha256sum") $marker
                $match=[regex]::Match($chunk.Replace("`r",''),'(?m)^'+[regex]::Escape($begin)+'\n([A-Za-z0-9+/=\n]+)\n([0-9a-f]{64})\s+-\n')
                $lines=@()
                if($match.Success){
                    $bytes=[Convert]::FromBase64String($match.Groups[1].Value)
                    $sha=[Security.Cryptography.SHA256]::Create()
                    try{$actual=[BitConverter]::ToString($sha.ComputeHash($bytes)).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()}
                    if($actual -eq $match.Groups[2].Value){
                        $text=[Text.Encoding]::UTF8.GetString($bytes)
                        if($text.EndsWith("`n")){$lines=@($text.Substring(0,$text.Length-1).Split("`n"))}
                    }
                }
            }else{
                $chunk = Invoke-SerialCommand ("sed -n '${start},${end}p' /tmp/acm-dmesg.txt") $marker
                $lines = @([regex]::Matches($chunk.Replace("`r",''),'(?m)^\[\s*\d+\.\d+\].*$') | ForEach-Object {$_.Value})
            }
        }
        if ($lines.Count -ne $end-$start+1) { throw "Incomplete dmesg chunk $start" }
        foreach ($line in $lines) { [void]$log.Append($line+"`n") }
        if ($start % 100 -eq 1) { Write-Output "Verified dmesg through line $end" }
    }
    if (($log.ToString() -split "`n").Count-1 -ne $count) { throw 'Dmesg line count mismatch' }
    [IO.File]::WriteAllText((Join-Path $target 'mainline-dmesg.txt'),$log.ToString())
    $digest = Invoke-SerialCommand 'sha256sum /tmp/acm-dmesg.txt' 'ACM_HASH_DONE'
    [IO.File]::WriteAllText((Join-Path $target 'serial-dmesg-hash.txt'),$digest)
    $hashMatch = [regex]::Match($digest,'(?m)^([0-9a-f]{64})\s+/tmp/acm-dmesg.txt')
    $localHash = (Get-FileHash -Algorithm SHA256 (Join-Path $target 'mainline-dmesg.txt')).Hash.ToLowerInvariant()
    if (-not $hashMatch.Success -or $hashMatch.Groups[1].Value -ne $localHash) { throw 'Dmesg SHA256 mismatch' }
    Write-Output "PASS: $count dmesg lines; phone and host SHA256 match: $localHash"
    $state = Invoke-SerialCommand 'cat /proc/uptime; cat /sys/class/udc/*/state; cat /sys/class/udc/*/current_speed' 'ACM_STATE_DONE'
    [IO.File]::WriteAllText((Join-Path $target 'serial-usb-state.txt'),$state)
    Write-Output $identity
    Write-Output $state
} finally {
    [IO.File]::WriteAllText((Join-Path $target 'serial-capture-transcript.txt'),$transcript.ToString())
    if($reader){$reader.Stop()}else{$port.Dispose()}
}

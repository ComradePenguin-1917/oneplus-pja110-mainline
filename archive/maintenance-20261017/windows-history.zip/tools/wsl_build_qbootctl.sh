#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
OUT=/mnt/h/workspace/PJA110-Mainline/out/boot-success-20261014
PREFIX="$ROOT/toolchain/gcc-12-aarch64"
export PATH="$PREFIX/usr/bin:$PATH"
export LD_LIBRARY_PATH="$PREFIX/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
cd "$OUT/qbootctl"
aarch64-linux-gnu-gcc -static -no-pie -O2 -Wall qbootctl.c bootctrl_impl.c gpt-utils.c ufs-bsg.c crc32.c -o "$OUT/qbootctl-aarch64" > "$OUT/build.log" 2>&1
echo 'PASS: upstream qbootctl built as static ARM64; no source changes'

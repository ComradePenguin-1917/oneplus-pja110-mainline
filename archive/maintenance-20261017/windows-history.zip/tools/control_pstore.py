#!/usr/bin/env python3
"""CONTROL EXPERIMENT: can this device record a panic into pstore AT ALL?

Why this control is necessary before drawing any conclusion from an empty pstore
-------------------------------------------------------------------------------
Facts so far:
  * the ramoops platform device IS bound to the ramoops driver on Android
  * mem_address = 0xBFC9C0000, mem_size = 0x240000 (read from the module params)
  * our DTB's ramoops node now points at exactly that address and size
  * after booting our kernel, /sys/fs/pstore was EMPTY

An empty pstore is consistent with at least three different stories:
  (1) our kernel died before it could initialise ramoops and write anything
  (2) our kernel wrote, but Android wiped the zone during its own boot
  (3) the pstore back-end on this device never surfaces anything anyway

(3) is directly testable: force a genuine kernel panic on ANDROID, reboot, and see
whether /sys/fs/pstore then contains it. Android is a known-good OS here, so if it
cannot record its own panic, an empty pstore after our attempt tells us nothing
about our kernel.

A controlled panic is safe: it is exactly what `echo c > /proc/sysrq-trigger`
does, the device reboots, and no partition is written. Android recovers normally.

This script performs that control and reports the result.
"""
import os
import shutil
import subprocess
import sys
import time

ADB = shutil.which('adb') or r'C:\platform-tools\adb.exe'
FB = shutil.which('fastboot') or r'C:\platform-tools\fastboot.exe'
SERIAL = 'bc7a542e'


def sh(cmd, timeout=120):
    r = subprocess.run([ADB, '-s', SERIAL, 'shell', "su -c '%s'" % cmd],
                       capture_output=True, timeout=timeout)
    return ((r.stdout or b'') + (r.stderr or b'')).decode('utf-8', 'replace')


def plain(cmd, timeout=120):
    r = subprocess.run([ADB, '-s', SERIAL, 'shell', cmd], capture_output=True, timeout=timeout)
    return ((r.stdout or b'') + (r.stderr or b'')).decode('utf-8', 'replace')


def adb_up():
    r = subprocess.run([ADB, 'devices'], capture_output=True, timeout=60)
    out = (r.stdout or b'').decode()
    return any(l.split()[0] == SERIAL and l.strip().endswith('device')
               for l in out.splitlines() if l.strip())


print('=' * 78)
print('CONTROL: can Android itself record a panic into pstore?')
print('=' * 78)
print()
print('  current slot  : %s' % plain('getprop ro.boot.slot_suffix').strip())
print('  kernel        : %s' % plain('uname -r').strip())
print('  pstore before : %r' % sh('ls /sys/fs/pstore/ 2>&1').strip()[:200])

print()
print('  sysrq enabled : %s' % sh('cat /proc/sys/kernel/sysrq 2>/dev/null').strip())
print('  sysrq-trigger : %s' % sh('ls /proc/sysrq-trigger 2>&1').strip()[:80])

print()
print('  NOTE: this REBOOTS the phone on purpose. Nothing is written to flash,')
print('  and Android comes back by itself.')
print()

print('  arming and firing a controlled panic in 5 seconds ...')
time.sleep(5)

# Use sysrq 'c' = crash. This is the standard controlled panic.
res = sh("echo c > /proc/sysrq-trigger")
print('  sysrq c sent. output: %r' % res.strip()[:120])

print('  waiting for the device to disappear (panic -> reboot) ...')
gone = False
for _ in range(40):
    time.sleep(3)
    if not adb_up():
        gone = True
        print('    device went down (as expected)')
        break
if not gone:
    print('    device did NOT go down -> the panic did not take effect')
    print('    (sysrq may be restricted; that itself is information)')

print()
print('  waiting for Android to come back ...')
back = False
for _ in range(60):
    time.sleep(3)
    if adb_up():
        back = True
        break
if not back:
    print('    device did not return within 3 minutes')
    sys.exit(2)

time.sleep(20)
print('    back up')
print()
print('  slot now      : %s' % plain('getprop ro.boot.slot_suffix').strip())
print('  kernel        : %s' % plain('uname -r').strip())

print()
print('=' * 78)
print('RESULT')
print('=' * 78)
listing = sh('ls -la /sys/fs/pstore/ 2>&1')
print('  /sys/fs/pstore after an Android panic:')
for line in listing.splitlines():
    if line.strip():
        print('    %s' % line.strip()[:110])

if 'console-ramoops' in listing or 'dmesg-ramoops' in listing or 'panic' in listing:
    print()
    print('  >>> pstore DOES capture panics on this device.')
    print('      Therefore an empty pstore after our kernel means OUR kernel')
    print('      never reached ramoops init -- i.e. it died VERY early.')
    print()
    print('  reading the panic log captured just now:')
    print(sh('for f in /sys/fs/pstore/*; do echo "=== $f ==="; head -c 1500 "$f"; done 2>/dev/null').strip()[:2000])
else:
    print()
    print('  >>> pstore did NOT capture even Android'"'"'s own panic.')
    print('      So this channel cannot be used to observe our kernel, and the')
    print('      empty pstore after our attempt proves NOTHING about our kernel.')
    print('      (Likely cause: reserved-memory region is re-initialised on boot,')
    print('       or the vendor build disables the panic log path.)')

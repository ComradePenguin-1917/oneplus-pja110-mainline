from pathlib import Path
import subprocess
r=Path.home()/'workspace/PJA110-Mainline'
print('firmware extracted roots')
p=r/'erofs-extraction-tools/vendor-a-extracted'
print(p.exists()); print(list(p.iterdir())[:15] if p.exists() else '')
print('cached firmware partitions')
for p in Path('/mnt/h/workspace/PJA110-Mainline').glob('**/dsp*.img'): print(p,p.stat().st_size)
for p in Path('/mnt/h/workspace/PJA110-Mainline').glob('**/adsp*.mbn'): print(p,p.stat().st_size)

#!/usr/bin/env python3
"""Investigate the Minidump / ramdump mechanism on this device.

The ABL log says:
    RamDump -  Image Load, Start
    D - 31 - boot_smem_alloc_for_minidump
    D -  0 - boot_shrm_mini_dump_init
    D - 61 - boot_minidump_register_regions
    Minidump      : ON

Minidump supersedes the old "ramdump to <partition>" flow: crash data is stored
in SMEM / a reserved region, and can be extracted by a host tool (or by a
running Android, if the region is readable).

If we can read that region we get crash evidence even when USB never comes up --
exactly the fallback channel the user asked for.
"""
import io
import os
import re
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fdt import FDT

WS = r'H:\WorkSpace\PJA110-Mainline'
out = []
def p(s=''):
    out.append(str(s))

# ---- 1) what the ABL log says about minidump -------------------------------
log = io.open(os.path.join(WS, 'bootloader-log.txt'), encoding='utf-8',
              errors='replace').read()
p('=' * 74)
p('1) ABL log: minidump / ramdump lines')
p('=' * 74)
for l in log.splitlines():
    if re.search(r'minidump|ramdump|RamDump|smem_alloc|shrm', l, re.I):
        p('   %s' % l.strip()[:130])

# ---- 2) the DTB's reserved-memory: is there a dump region? -----------------
p()
p('=' * 74)
p('2) reserved-memory regions relevant to crash capture (live device tree)')
p('=' * 74)
f = FDT(open(os.path.join(WS, 'live-from-device.dtb'), 'rb').read())
nodes = f.nodes()
for path, props in sorted(nodes.items()):
    leaf = path.split('/')[-1]
    if not re.search(r'dump|ramoops|mem_dump|smem|shrm|devinfo|botloader', leaf, re.I):
        continue
    if '/reserved-memory/' not in path + '/':
        continue
    if path.rstrip('/').endswith('/reserved-memory'):
        continue
    reg = props.get('reg')
    size = props.get('size')
    desc = ''
    if reg and len(reg) == 16:
        b, s = struct.unpack('>QQ', reg)
        desc = 'reg=0x%x+0x%x (%.2f MiB)' % (b, s, s / 2**20)
    elif size and len(size) >= 8:
        s = struct.unpack('>Q', size[:8])[0]
        desc = 'size=%.2f MiB (dynamic)' % (s / 2**20)
    comp = props.get('compatible', b'').rstrip(b'\0').decode('ascii', 'replace')
    p('   %-46s %-34s %s' % (leaf[:46], desc[:34], comp))

# ---- 3) what strings does vendor_boot carry about it? ---------------------
p()
p('=' * 74)
p('3) vendor_boot strings about ramdump/minidump')
p('=' * 74)
vb = open(os.path.join(WS, 'vendor_boot-A14.img'), 'rb').read()
for s in sorted({m.decode('ascii', 'replace')
                 for m in re.findall(rb'[\x20-\x7e]{6,}', vb)}):
    if re.search(r'ramdump|RAMDUMP|minidump|minidump_id', s, re.I):
        p('   %s' % s[:120])

# ---- 4) practical access path ---------------------------------------------
p()
p('=' * 74)
p('4) can a RUNNING Android read the dump region? (fallback channel)')
p('=' * 74)
p('   If the region is in reserved-memory it is typically NOT mapped by Linux.')
p('   But minidump data is also exposed via a debugfs/procfs node on vendor')
p('   kernels, and the Android-side extractor is "minidump_dump" / ramdump.')
p('   We will check the device directly for such a node.')

io.open(os.path.join(WS, 'docs', '_minidump.txt'), 'w', encoding='utf-8').write('\n'.join(out))
print('\n'.join(out))

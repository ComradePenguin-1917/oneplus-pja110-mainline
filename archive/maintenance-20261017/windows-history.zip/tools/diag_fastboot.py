#!/usr/bin/env python3
"""Diagnose and work around the `fastboot boot` USB failure.

Observed repeatedly, and only for `fastboot boot` (never for `flash`):
    Booting    FAILED (Status read failed (Too many links))

What it means: the kernel driver on the HOST side reported EMLINK (too many
symbolic links) while reading the status response. It is a host USB stack issue,
not an ABL rejection -- note `Sending 'boot.img' OKAY` succeeds, i.e. the whole
image transfers fine; only the acknowledgement read fails.

Notably `fastboot flash` works reliably every time, so the workaround is to
FLASH the image to a slot and boot that, instead of memory-booting it.

This helper:
  * prints diagnostics about the host side
  * supports the flash-based path as the primary strategy
"""
import os
import re
import shutil
import subprocess
import sys
import time

ADB = shutil.which('adb') or r'C:\platform-tools\adb.exe'
FB = shutil.which('fastboot') or r'C:\platform-tools\fastboot.exe'
SERIAL = 'bc7a542e'
WS = r'H:\WorkSpace\PJA110-Mainline'


def run(cmd, timeout=900):
    r = subprocess.run(cmd, capture_output=True, timeout=timeout)
    return ((r.stdout or b'') + (r.stderr or b'')).decode('utf-8', 'replace')


def main():
    print('=' * 78)
    print('HOST USB DIAGNOSTICS')
    print('=' * 78)
    print(run([FB, '--version']).strip())
    print()
    print('devices: %s' % run([FB, 'devices']).strip())

    print()
    print('=' * 78)
    print('STRATEGY: flash instead of memory-boot')
    print('=' * 78)
    print('  `fastboot flash` has worked on every attempt; `fastboot boot` fails')
    print('  intermittently with EMLINK on the status read.')
    print()
    print('  Slot B is the experimental slot and its boot_b is pristine stock')
    print('  (d9cf0ea6...), backed up at backup/boot_b.img, so flashing there is')
    print('  reversible with an exact restore.')
    print()
    print('  plan:')
    print('    fastboot set_active b')
    print('    fastboot erase dtbo_b')
    print('    fastboot flash boot_b out/xigua-nodtbo.img')
    print('    fastboot reboot')
    print('  rollback:')
    print('    fastboot flash boot_b backup/boot_b.img')
    print('    fastboot flash dtbo_b backup/dtbo_b.img')
    print('    fastboot set_active a')
    print()
    print('  safety: if slot B fails to boot, ABL falls back or we switch to A,')
    print('  which is untouched. Recovery combo is available as last resort.')

    print()
    print('=' * 78)
    print('SIZE CHECK (boot_b is 192 MiB)')
    print('=' * 78)
    img = os.path.join(WS, 'out', 'xigua-nodtbo.img')
    sz = os.path.getsize(img)
    print('  %s : %d bytes (%.1f MiB)' % (os.path.basename(img), sz, sz / 2**20))
    print('  fits boot_b (201326592): %s' % (sz <= 201326592))


if __name__ == '__main__':
    main()

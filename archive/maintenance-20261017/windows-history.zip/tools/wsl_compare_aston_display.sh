#!/bin/bash
set -euo pipefail
TREE="$HOME/workspace/PJA110-Mainline/linux"
OUT=/mnt/h/workspace/PJA110-Mainline/out/aston-display-comparison-20261014
python3 - "$TREE" "$OUT" <<'PY'
import sys,json,difflib,hashlib
from pathlib import Path
tree,out=map(Path,sys.argv[1:])
m=json.loads((out/'manifest.json').read_text())
report=[]
for item in m['files']:
 p=item['path'];local=tree/p;dest=out/'local'/p;dest.parent.mkdir(parents=True,exist_ok=True)
 dest.write_bytes(local.read_bytes());a=(out/'aston'/p).read_text();b=local.read_text()
 diff=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='aston/'+p,tofile='local/'+p))
 patch=out/'diffs'/(Path(p).name+'.diff');patch.parent.mkdir(exist_ok=True);patch.write_text(diff)
 report.append(dict(path=p,same=not diff,local_sha256=hashlib.sha256(local.read_bytes()).hexdigest()))
(out/'comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
PY

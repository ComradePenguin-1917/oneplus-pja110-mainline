"""Package only the diagnostic kernel; retain proven B-slot ancillary images."""
from pathlib import Path
import gzip
import hashlib
import json
import shutil
import struct
from bootimg import BootImage

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/user-init-usb-serial-diag-20261013'
BASE=ROOT/'out/user-init-usb-serial-shell-20261013'
image=(OUT/'Image-probe').read_bytes()
assert image[56:60]==b'ARM\x64'
symbols={p[2]:int(p[0],16) for line in (OUT/'System.map').read_text().splitlines() if len(p:=line.split())==3}
start=symbols['__initramfs_start']-symbols['_text']
size=struct.unpack_from('<Q',image,symbols['__initramfs_size']-symbols['_text'])[0]
assert gzip.decompress(image[start:start+size])==gzip.decompress((OUT/'initramfs.cpio.gz').read_bytes())
assert b'PJA_USB_SETUP type=' in image and b'actual=%u length=%u zero=%u' in image
a=image.index(b'IKCFG_ST')+8
b=image.index(b'IKCFG_ED',a)
assert gzip.decompress(image[a:b])==(OUT/'kernel.config').read_bytes()
boot=BootImage.parse(str(BASE/'boot-xigua-r1.img'))
boot.kernel=image
(OUT/'boot-xigua-r1.img').write_bytes(boot.pack(cmdline=boot.cmdline.decode()))
assert BootImage.parse(str(OUT/'boot-xigua-r1.img')).kernel==image
assert b'pja.qemu_validation' not in boot.cmdline
for name in ('vendor_boot_b-xigua-r1.img','init_boot_b-xigua-r1.img','dtbo_b-avb-noop.img'):
    shutil.copyfile(BASE/name,OUT/name)
names=('boot-xigua-r1.img','vendor_boot_b-xigua-r1.img','init_boot_b-xigua-r1.img','dtbo_b-avb-noop.img')
manifest={'experiment':'ACM reliability diagnostics: USB control requests and cancelled TX lengths',
          'phone_execution_confirmed':False,'same_proven_acm_initramfs':True,
          'kernel_config_unchanged':True,'no_usb_behavior_fix_applied_yet':True,
          'files':{n:{'bytes':(OUT/n).stat().st_size,'sha256':hashlib.sha256((OUT/n).read_bytes()).hexdigest()} for n in names}}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('PASS: diagnostic Image/config/initramfs verified; only boot_b differs')

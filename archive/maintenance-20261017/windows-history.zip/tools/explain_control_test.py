#!/usr/bin/env python3
"""Explain why the control test matters and what it proves.

Control test result:
    fastboot boot <STOCK boot.img>  ->  system booted in 12s

Stock boot-A14.img contains kernel only (ramdisk_size=0). Yet a full Android
boot happened. Therefore ABL must be supplying, from FLASH:
    * init_boot      (first-stage ramdisk)
    * vendor_boot    (vendor ramdisk + DTB)
and only the `boot` partition content is substituted by what fastboot sends.

Consequence for us: our kernel is launched together with the VENDOR's DTB and
the VENDOR's ramdisk, neither of which suits a mainline kernel. And with no
observability we cannot tell whether our kernel ran at all.

Prints the evidence for each claim.
"""
import io
import os
import struct

WS = r'H:\WorkSpace\PJA110-Mainline'
out = []
def p(s=''):
    out.append(str(s))

# 1) stock boot.img really has no ramdisk
b = open(os.path.join(WS, 'boot-A14.img'), 'rb').read()
ksize, rsize = struct.unpack_from('<2I', b, 8)
p('1) stock boot.img: kernel_size=%d ramdisk_size=%d' % (ksize, rsize))
p('   -> no ramdisk in the boot partition')

# 2) init_boot exists as a separate partition
p()
p('2) the OTA has an init_boot partition (8 MiB) -> first-stage ramdisk lives there')
import subprocess, re
r = subprocess.run(['python', os.path.join(WS, 'tools', 'parse_payload_manifest.py'),
                    os.path.join(WS, 'PJA110 线刷包-701', 'payload.bin')],
                   capture_output=True, text=True)
for line in r.stdout.splitlines():
    if re.search(r'init_boot|vendor_boot|^boot\s', line):
        p('   %s' % line.strip())

# 3) vendor_boot supplies ramdisk + dtb
v = open(os.path.join(WS, 'vendor_boot-A14.img'), 'rb').read()
vrsize = struct.unpack_from('<I', v, 24)[0]
hsize, dtbsize = struct.unpack_from('<2I', v, 28+2048+4+16)
p()
p('3) vendor_boot: vendor_ramdisk_size=%d (%.1f MiB), dtb_size=%d (%.1f MiB)'
  % (vrsize, vrsize/2**20, dtbsize, dtbsize/2**20))
p('   -> the ramdisk AND the DTB both come from vendor_boot')

# 4) proof that vendor_boot's cmdline really reaches the kernel
p()
p('4) proof: the running stock system\'s /proc/cmdline contains')
p('   "stack_depot_disable=on kasan.stacktrace=off kvm-arm.mode=protected"')
p('   which are NOT in our boot.img cmdline; they come from vendor_boot\'s')
p('   bootconfig. So ABL definitely merges vendor_boot at boot time.')

# 5) conclusion
p()
p('=' * 68)
p('CONCLUSION')
p('=' * 68)
p('Our hand-built boot.img replaced only the kernel. The DTB and ramdisk still')
p('come from the device\'s vendor_boot, i.e. they are the VENDOR\'s, tuned for a')
p('5.15 Android kernel. A mainline 6.14 kernel given that DTB will not probe')
p('most devices, and with no initramfs it has nothing to run as userspace --')
p('so it panics, and USB never enumerates. A perfectly healthy mainline kernel')
p('and a dead one are indistinguishable in this setup.')
p()
p('FIX: embed our own initramfs whose /init sets up a USB network gadget.')
p('That is exactly how postmarketOS brings up Qualcomm phones with no UART.')

io.open(os.path.join(WS, 'docs', '_why.md'), 'w', encoding='utf-8').write('\n'.join(out))
print('\n'.join(out))

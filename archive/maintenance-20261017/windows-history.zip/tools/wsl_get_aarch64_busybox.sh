#!/bin/bash
# Obtain an AARCH64 static busybox (the host one is x86-64 and useless on the phone).
#
# Options, in order of preference:
#   1. busybox.net publishes prebuilt static binaries (incl. aarch64)
#   2. build from source with our cross toolchain (slow but self-contained)
#   3. extract from an Ubuntu arm64 .deb
set -uo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
DL="$ROOT/initramfs/dl"
mkdir -p "$DL"
cd "$DL"

echo "=== 1) busybox.net prebuilt static binaries ==="
for url in \
  "https://busybox.net/downloads/binaries/1.35.0-x86_64-linux-musl/busybox" \
  "https://busybox.net/downloads/binaries/1.31.0-defconfig-multiarch-musl/busybox-armv8l" \
  ; do
    code=$(curl -sS -o /dev/null -w '%{http_code}' -I --max-time 25 "$url" 2>/dev/null)
    echo "  $code  $url"
done

echo
echo "=== 2) try the known-good aarch64 static build ==="
try_fetch() {
    local url="$1" out="$2"
    if curl -fsSL --max-time 120 -o "$out" "$url" 2>/dev/null; then
        local sz; sz=$(stat -c%s "$out" 2>/dev/null || echo 0)
        if [ "$sz" -gt 100000 ]; then
            echo "  downloaded $out ($sz bytes)"
            file "$out" | sed 's/^/    /'
            return 0
        fi
    fi
    rm -f "$out"
    return 1
}

GOT=""
for u in \
  "https://busybox.net/downloads/binaries/1.31.0-defconfig-multiarch-musl/busybox-armv8l" \
  "https://busybox.net/downloads/binaries/1.30.0-i686-uclibc/busybox" \
  ; do
    case "$u" in *x86*|*i686*) continue;; esac
    if try_fetch "$u" busybox-aarch64; then GOT="$u"; break; fi
done

if [ -z "$GOT" ]; then
    echo "  busybox.net prebuilt not usable; will build from source"
fi

echo
echo "=== 3) can we apt-download an arm64 busybox-static .deb? ==="
( cd "$DL" && apt-get download busybox-static:arm64 2>&1 | tail -3 ) || true
ls -1 *.deb 2>/dev/null | sed 's/^/  /' || echo "  (no debs)"

echo
echo "=== 4) results ==="
ls -l

#!/usr/bin/env python3
"""Verify correctly this time, and settle whether ABL attempted slot B.

Two mistakes to correct
-----------------------
1. I compared sha256(whole boot_b partition) against sha256(my 32.7 MiB image).
   Those can never match: fastboot writes only the image's length and leaves the
   rest of the 192 MiB partition untouched. The comparison must use the first
   len(image) bytes.

2. The earlier pull was truncated because the device dropped off USB mid-read.

What actually matters now
-------------------------
  * is our kernel still sitting in boot_b?  (if yes, ABL had it available)
  * what does the A/B slot metadata say?    (did B get tried and marked failed?)
  * note: /proc/bootloader_log is in RAM and is overwritten every boot, so the
    slot-B attempt's log is already gone -- only the fallback boot's log exists.
"""
import hashlib
import os
import shutil
import struct
import subprocess
import sys

ADB = shutil.which('adb') or r'C:\platform-tools\adb.exe'
WS = r'H:\WorkSpace\PJA110-Mainline'
SERIAL = 'bc7a542e'
PAGE = 4096


def sh(cmd, timeout=900):
    r = subprocess.run([ADB, '-s', SERIAL, 'shell', cmd], capture_output=True, timeout=timeout)
    return ((r.stdout or b'') + (r.stderr or b'')).decode('utf-8', 'replace')


def sh_root(cmd, timeout=900):
    return sh("su -c '%s'" % cmd, timeout)


print('=' * 78)
print('1) IS OUR KERNEL STILL IN boot_b?  (compare only the image-length prefix)')
print('=' * 78)
img = os.path.join(WS, 'out', 'boot_b-ourkernel.img')
imgb = open(img, 'rb').read()
print('  our image: %d bytes, sha %s' % (len(imgb), hashlib.sha256(imgb).hexdigest()[:24]))

n_pages = (len(imgb) + PAGE - 1) // PAGE
remote = '/data/local/tmp/bootb_head.img'
# read exactly as many pages as the image occupies
sh_root('dd if=/dev/block/by-name/boot_b of=%s bs=%d count=%d 2>/dev/null; chmod 644 %s'
        % (remote, PAGE, n_pages, remote))
local = os.path.join(WS, 'out', '_bootb_head.img')
r = subprocess.run([ADB, '-s', SERIAL, 'pull', remote, local], capture_output=True, timeout=900)
if os.path.exists(local):
    got = open(local, 'rb').read()
    print('  read back: %d bytes (expected %d)' % (len(got), n_pages * PAGE))
    prefix = got[:len(imgb)]
    print('  prefix == our image : %s' % (prefix == imgb))
    print('  prefix sha          : %s' % hashlib.sha256(prefix).hexdigest()[:24])
    if prefix == imgb:
        print('  => OUR KERNEL IS STILL IN boot_b. The flash persisted.')
    else:
        # maybe it is the stock image
        st = open(os.path.join(WS, 'backup', 'boot_b.img'), 'rb').read()
        print('  prefix == stock boot_b : %s' % (prefix == st[:len(imgb)]))
    sh_root('rm -f %s' % remote)
else:
    print('  pull failed')

print()
print('=' * 78)
print('2) A/B SLOT METADATA')
print('=' * 78)
print('  current slot prop : %s' % sh('getprop ro.boot.slot_suffix').strip())
print('  kernel running    : %s' % sh('uname -r').strip())

misc = os.path.join(WS, 'backup', 'misc.img')
if not os.path.exists(misc):
    sh_root('dd if=/dev/block/by-name/misc of=/data/local/tmp/misc.img bs=4096 2>/dev/null; '
            'chmod 644 /data/local/tmp/misc.img')
    subprocess.run([ADB, '-s', SERIAL, 'pull', '/data/local/tmp/misc.img', misc],
                   capture_output=True, timeout=900)

b = open(misc, 'rb').read()
print()
print('  misc.img: %d bytes' % len(b))
# AOSP: struct bootloader_control at offset 2048, magic "BCAB" little endian
for off in (2048, 0, 4096, 8192):
    chunk = b[off:off + 64]
    magic_le = struct.unpack_from('<I', chunk, 0)[0]
    magic_be = struct.unpack_from('>I', chunk, 0)[0]
    tag = ''
    if magic_le == 0x42414342:
        tag = '  <== BCAB (little endian)'
    elif magic_be == 0x42414342:
        tag = '  <== BCAB (big endian)'
    print('    off 0x%04x: %s  magic_le=0x%08x magic_be=0x%08x%s'
          % (off, chunk[:16].hex(), magic_le, magic_be, tag))

# scan the whole misc for the magic
for magic in (b'BCAB', b'BACB'):
    i = b.find(magic)
    print('    scan for %r: %s' % (magic, 'at 0x%x' % i if i >= 0 else 'not found'))

print()
print('  raw misc[2048:2112] hexdump:')
print('   ', b[2048:2112].hex())

# also look for the plain strings OPPO may use
for probe in (b'_a', b'_b', b'slot', b'Active'):
    i = b.find(probe)
    print('    misc contains %-8r : %s' % (probe, 'at 0x%x' % i if i >= 0 else 'no'))

print()
print('=' * 78)
print('3) WHAT THE (fallback) ABL LOG SHOWED')
print('=' * 78)
log = os.path.join(WS, 'bootloader-log-bfail.txt')
if os.path.exists(log):
    txt = open(log, encoding='utf-8', errors='replace').read()
    for line in txt.splitlines():
        if any(k in line for k in ('Booting from slot', 'Active_a', 'Active_b',
                                   'Unbootable', 'BootSuccess', 'AlternateSlot')):
            print('  %s' % line.strip()[:120])
print()
print('  NOTE: /proc/bootloader_log lives in RAM and is rewritten on every boot.')
print('  The slot-B attempt produced its own log, which the fallback boot then')
print('  overwrote. So the reason B did not come up is NOT in this file.')

#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
TREE="$ROOT/linux"
OUT="$WIN/out/display-budget-20261014"
mkdir -p "$OUT"
export PATH="$ROOT/toolchain/gcc-12-aarch64/usr/bin:$PATH"
export LD_LIBRARY_PATH="$ROOT/toolchain/gcc-12-aarch64/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu-
cmp "$TREE/.config" "$WIN/out/display-timing-20261014/.config"
cmp "$TREE/drivers/gpu/drm/msm/dsi/dsi_host.c" "$WIN/out/dsc-packet-audit-20261014/dsi_host.packet2.c"
cmp "$TREE/drivers/gpu/drm/msm/disp/dpu1/dpu_encoder_phys_cmd.c" "$WIN/out/te-height-control-20261014/dpu_encoder_phys_cmd.height65520.c"
python3 "$WIN/tools/patch_display_budget.py"
cd "$TREE"
make -j8 Image > "$OUT/build.log" 2>&1
cp arch/arm64/boot/Image System.map .config "$OUT/"
sha256sum drivers/gpu/drm/msm/dsi/dsi_host.c drivers/gpu/drm/msm/disp/dpu1/dpu_encoder_phys_cmd.c > "$OUT/display-source.sha256"
echo 'PASS: command budget kernel built; config and panel/DSI/TE source preserved'

#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
OUT="$WIN/out/display-port-20261013"
BUILD="$ROOT/display-diag-module-20261013"
TREE="$ROOT/linux"
export PATH="$ROOT/toolchain/gcc-12-aarch64/usr/bin:$PATH"
export LD_LIBRARY_PATH="$ROOT/toolchain/gcc-12-aarch64/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu-
mkdir -p "$BUILD"
cmp "$TREE/.config" "$OUT/kernel.config"
sha256sum "$TREE/.config" "$TREE/arch/arm64/boot/Image" > "$OUT/diag-build-before.sha256"
cp "$WIN/tools/mainline_display_diag.c" "$BUILD/"
printf 'obj-m := mainline_display_diag.o\n' > "$BUILD/Makefile"
make -C "$TREE" M="$BUILD" KBUILD_EXTRA_SYMBOLS="$TREE/vmlinux.symvers" -j4 modules > "$OUT/diag-build.log" 2>&1
cp "$BUILD/mainline_display_diag.ko" "$OUT/"
modinfo "$BUILD/mainline_display_diag.ko" > "$OUT/diag-modinfo.txt"
sha256sum -c "$OUT/diag-build-before.sha256"
echo 'PASS: read-only DCS diagnostic module built; kernel Image/config unchanged'

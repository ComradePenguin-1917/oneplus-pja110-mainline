#!/bin/bash
# Boot the exported artifacts without modifying the source disk (QEMU snapshot).
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
OUT=/mnt/h/workspace/PJA110-Mainline/out/postmarketos-bootchain-20261015
EXPORT=/tmp/postmarketOS-export
ROOT_UUID=$(python3 /mnt/h/workspace/PJA110-Mainline/tools/pmos_image_info.py "$EXPORT/oneplus-xigua.img" --root-uuid)
OUT="$OUT/$ROOT_UUID"
mkdir -p "$OUT"
for file in vmlinuz initramfs oneplus-xigua.img; do test -r "$EXPORT/$file"; done
sha256sum "$EXPORT/vmlinuz" "$EXPORT/initramfs" > "$OUT/boot-artifacts.sha256"
set +e
timeout --signal=TERM --kill-after=5 180 qemu-system-aarch64 \
 -machine virt -accel tcg -cpu max -smp 2 -m 2048 \
 -display none -serial stdio -monitor none -no-reboot \
 -kernel "$EXPORT/vmlinuz" -initrd "$EXPORT/initramfs" \
 -append "console=ttyAMA0 earlycon=pl011,0x9000000 loglevel=6 root=UUID=$ROOT_UUID rw systemd.show_status=1 systemd.log_target=console" \
 -drive "if=none,id=pmos,file=$EXPORT/oneplus-xigua.img,format=raw,snapshot=on" \
 -device virtio-blk-pci,drive=pmos,logical_block_size=4096,physical_block_size=4096 \
 -nic none > "$OUT/qemu-initramfs.log" 2>&1
result=$?
set -e
printf 'QEMU_EXIT=%s\n' "$result"
tail -n 65 "$OUT/qemu-initramfs.log"
# A timeout is an observation limit, not proof of a boot success.
test "$result" = 0 || test "$result" = 124

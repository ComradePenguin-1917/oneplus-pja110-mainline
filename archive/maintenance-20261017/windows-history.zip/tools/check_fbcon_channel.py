#!/usr/bin/env python3
"""A console we can actually SEE: the phone's own screen.

Insight
-------
ABL displays a boot logo, which means a live framebuffer already exists in RAM
before Linux starts. Mainline's `simple-framebuffer` driver can adopt that
buffer, and with `fbcon` the kernel console prints ON THE SCREEN.

That gives a real, readable kernel log with no UART cable, no USB, and no
drivers beyond one that only needs a memory region plus geometry.

This is standard practice for phone bring-up (postmarketOS leans on it heavily).

What must line up
  1. kernel config: FB_SIMPLE + FRAMEBUFFER_CONSOLE + VT, and the console must
     be reachable (console=tty0 rather than only ttyMSM0)
  2. a `simple-framebuffer` node in OUR DTB with
        reg     = <0 ADDR 0 SIZE>
        width/height/stride/format
  3. that ADDR must be where ABL actually put the framebuffer, and the region
     must be reserved so the kernel never reuses it

So: find the framebuffer address, and check the config.
"""
import os
import re
import struct
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
sys.path.insert(0, os.path.join(WS, 'tools'))
from fdt import FDT


def dec(v):
    return v.rstrip(b'\0').decode('ascii', 'replace')


def regs(v):
    out = []
    for i in range(0, len(v) - 15, 16):
        out.append(struct.unpack_from('>QQ', v, i))
    return out


print('=' * 78)
print('1) KERNEL CONFIG: framebuffer console support')
print('=' * 78)
cfg = os.path.join(WS, 'out', 'config-6.14-xigua')
vals = {}
if os.path.exists(cfg):
    for l in open(cfg, encoding='utf-8', errors='replace'):
        l = l.strip()
        if '=' in l and not l.startswith('#'):
            k, v = l.split('=', 1)
            vals[k] = v
        elif l.startswith('# ') and 'is not set' in l:
            vals[l[2:].split(' ')[0]] = 'NOT SET'
for k in ('CONFIG_FB', 'CONFIG_FB_SIMPLE', 'CONFIG_FB_EFI', 'CONFIG_FRAMEBUFFER_CONSOLE',
          'CONFIG_FRAMEBUFFER_CONSOLE_DETECT_PRIMARY', 'CONFIG_VT', 'CONFIG_VT_CONSOLE',
          'CONFIG_DRM', 'CONFIG_DRM_SIMPLEDRM'):
    print('  %-44s %s' % (k, vals.get(k, '(absent)')))

print()
print('=' * 78)
print('2) FRAMEBUFFER EVIDENCE IN THE VENDOR TREE')
print('=' * 78)
vend = FDT(open(os.path.join(WS, 'live-from-device.dtb'), 'rb').read()).nodes()

hits = [p for p in vend if re.search(r'framebuffer|splash|cont_splash|fb@', p, re.I)]
print('  nodes mentioning framebuffer/splash:')
for p in sorted(hits)[:12]:
    props = vend[p]
    print('    %s' % p)
    for k in sorted(props):
        if k in ('reg', 'compatible', 'width', 'height', 'stride', 'format',
                 'qcom,memsize', 'size'):
            v = props[k]
            if k == 'reg':
                print('        %-12s %s' % (k, ' '.join('0x%x+0x%x' % r for r in regs(v))))
            elif len(v) <= 10:
                print('        %-12s 0x%x (%d)' % (k, int.from_bytes(v, 'big'), int.from_bytes(v, 'big')))
            else:
                print('        %-12s %r' % (k, dec(v)))

print()
print('  reserved-memory regions whose name suggests display:')
for p in sorted(vend):
    if p.startswith('/reserved-memory/') and p.count('/') == 2:
        if re.search(r'splash|display|fb|cont', p, re.I):
            r = vend[p].get('reg')
            if r:
                for b, s in regs(r):
                    print('    %-52s 0x%x+0x%x' % (p.split('/')[-1][:52], b, s))

print()
print('=' * 78)
print('3) WHAT THE ABL LOG SAYS ABOUT THE SPLASH/FRAMEBUFFER')
print('=' * 78)
for f in ('bootloader-log-bfail.txt', 'bootloader-log.txt'):
    p = os.path.join(WS, f)
    if not os.path.exists(p):
        continue
    txt = open(p, encoding='utf-8', errors='replace').read()
    print('--- %s' % f)
    for line in txt.splitlines():
        if re.search(r'splash|logo|framebuffer|DisplayDxe|Panel.*Power|WxH', line, re.I):
            print('    %s' % line.strip()[:120])

print()
print('=' * 78)
print('4) DOES OUR DTB ALREADY HAVE A FRAMEBUFFER NODE?')
print('=' * 78)
ours = FDT(open(os.path.join(WS, 'dts', 'sm8550-oneplus-xigua-16G.dtb'), 'rb').read()).nodes()
h = [p for p in ours if re.search(r'framebuffer|splash|simple-fb|fb@', p, re.I)]
print('  %s' % (h or 'NONE'))
print()
print('  our reserved-memory entries mentioning splash/display:')
for p in sorted(ours):
    if p.startswith('/reserved-memory/') and re.search(r'splash|display|fb', p, re.I):
        r = ours[p].get('reg')
        if r:
            for b, s in regs(r):
                print('    %-52s 0x%x+0x%x' % (p.split('/')[-1][:52], b, s))

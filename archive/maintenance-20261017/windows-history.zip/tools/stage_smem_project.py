"""Stage the read-only SMEM reader; do not request remote sudo."""
from pathlib import Path
import hashlib
import subprocess
from prepare_native_install import SSH
out = Path('out/native-install-20261017/smem-project')
args = SSH[:]
args[-1] = 'penguin@172.16.42.1'
args = [x if not x.startswith('UserKnownHostsFile=') else
        'UserKnownHostsFile=out/native-install-20261017/known_hosts' for x in args]
def run(cmd, data=None):
    p = subprocess.run(args + [cmd], input=data, capture_output=True, timeout=25)
    print(p.stdout.decode(errors='replace'), end='')
    print(p.stderr.decode(errors='replace'), end='')
    p.check_returncode()
    return p.stdout
data = (out / 'pja110_smem_project.ko').read_bytes()
sha = hashlib.sha256(data).hexdigest()
result = run('umask 077; cat > /home/penguin/pja110_smem_project.ko; sha256sum /home/penguin/pja110_smem_project.ko', data)
assert result.decode().split()[0] == sha
script = b'''#!/bin/sh
set -eu
cd /home/penguin
echo "01652fabbe109d5a5780f1c20910f52a422668fe5ec6fb973526dcb831aa1e91  pja110_smem_project.ko" | sha256sum -c -
if [ ! -d /sys/module/pja110_smem_project ]; then
    /sbin/insmod ./pja110_smem_project.ko
fi
for key in item_size version project; do
    printf '%s=' "$key"
    cat /sys/module/pja110_smem_project/parameters/"$key"
done
'''
run('cat > /home/penguin/read-smem-project.sh', script)
run('sh -n /home/penguin/read-smem-project.sh; uname -r; cat /sys/class/power_supply/bq28z610-0/capacity')
print('Staged only; no module loaded, no reboot, no charging writes.')

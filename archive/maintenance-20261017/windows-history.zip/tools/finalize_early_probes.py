"""Record the observed stage signals, after verifying saved readback/restoration."""
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
def hashes(path):
    result = {}
    for line in path.read_text().splitlines():
        if '/dev/block/by-name/' in line:
            digest, name = line.split()
            result[name.rsplit('/', 1)[1]] = digest
    assert len(result) == 8
    return result

stages = [('kernel-entry-probe', 'raw Image entry'),
          ('kernel-pre-mmu-probe', '__enable_mmu before TTBR/SCTLR writes'),
          ('kernel-post-mmu-probe', '__enable_mmu after final ISB'),
          ('kernel-virtual-switch-probe', '__primary_switched at kernel virtual address'),
          ('kernel-start-kernel-probe', 'start_kernel entry before C initialization'),
          ('kernel-after-setup-arch-probe', 'start_kernel after setup_arch returns'),
          ('kernel-after-sched-init-probe', 'start_kernel after sched_init returns'),
          ('kernel-after-init-irq-probe', 'start_kernel after init_IRQ returns'),
          ('kernel-before-rest-init-probe', 'start_kernel immediately before calling rest_init'),
          ('kernel-after-initcalls-probe', 'kernel_init_freeable after inlined do_initcalls'),
          ('kernel-after-kernel-init-freeable-probe', 'kernel_init after kernel_init_freeable returns'),
          ('kernel-after-async-sync-probe', 'kernel_init after async_synchronize_full returns'),
          ('kernel-after-free-initmem-probe', 'kernel_init after free_initmem returns'),
          ('kernel-before-userspace-probe', 'kernel_init before selecting initial userspace command'),
          ('kernel-run-init-entry-probe', 'run_init_process entry before execution attempt'),
          ('kernel-exec-return-probe', 'run_init_process immediately after kernel_execve returns'),
          ('kernel-exec-return-force-error-probe', 'same kernel_execve return site with forced 35-second delay'),
          ('kernel-init-el0-boundary-probe', 'kernel_init thread after asm_exit_to_user_mode returns, before ret_to_user'),
          ('user-init-reset-probe', 'native PID1 at EL0: getpid, nanosleep and reboot syscalls'),
          ('user-init-after-usb-probe', 'original shell init after USB gadget attempt loop'),
          ('user-init-udc-status-probe', 'original shell init after USB loop, sysfs and UDC presence check'),
          ('user-init-sysfs-status-probe', 'original shell init after USB loop, sysfs class directory check'),
          ('user-init-udc-only-probe', 'original shell init after USB loop, find_udc check alone'),
          ('user-init-dwc-bound-probe', 'original shell init after USB loop, DWC3 driver symlink check'),
          ('user-init-qcom-bound-probe', 'original shell init after USB loop, Qualcomm USB parent driver symlink check'),
          ('user-init-hsphy-bound-probe', 'original shell init after USB loop, actual USB2 PHY driver symlink check'),
          ('user-init-dwc-present-probe', 'original shell init after USB loop, DWC3 platform device presence check'),
          ('user-init-dwc-wait-probe', 'original shell init after USB loop, DWC3 waiting_for_supplier attribute check'),
          ('user-init-dwc-deferred-probe', 'original shell init after USB loop, DWC3 in devices_deferred snapshot'),
          ('user-init-dwc-core-error-probe', 'original shell init after USB loop, DWC3 core init error in dmesg'),
          ('user-init-dwc-core-timeout-probe', 'original shell init after USB loop, DWC3 core error ETIMEDOUT check'),
          ('user-init-dwc-core-timeout-early-probe', 'DWC3 ETIMEDOUT check using dmesg snapshot before original USB loop'),
          ('user-init-dwc-soft-reset-error-probe', 'DWC3 controller soft reset failed in dmesg snapshot before USB loop'),
          ('user-init-dwc-soft-reset-usb3-phy-probe', 'same DWC3 soft reset log probe with USB3 PHY restored at high-speed')]
interval_args = [arg for arg in sys.argv[1:] if arg.startswith('--interval-seconds=')]
assert len(interval_args) <= 1
interval = float(interval_args[0].split('=', 1)[1]) if interval_args else 5
assert interval > 0
inconclusive = '--inconclusive' in sys.argv
retain_test = '--retain-test' in sys.argv
enum_only = '--enum-only' in sys.argv
selected = [arg for arg in sys.argv[1:] if not arg.startswith('--interval-seconds=') and arg not in ('--inconclusive', '--retain-test', '--enum-only')] or ['kernel-entry-probe', 'kernel-pre-mmu-probe']
exec_args = [arg for arg in selected if arg.startswith('--exec-result=')]
assert len(exec_args) <= 1
exec_result = exec_args[0].split('=', 1)[1] if exec_args else None
assert exec_result in (None, 'zero', 'nonzero', 'unknown')
selected = [arg for arg in selected if not arg.startswith('--exec-result=')]
usb_args = [arg for arg in selected if arg.startswith('--usb-result=')]
assert len(usb_args) <= 1
usb_result = usb_args[0].split('=', 1)[1] if usb_args else None
assert usb_result in (None, 'bound', 'unbound', 'unknown')
selected = [arg for arg in selected if not arg.startswith('--usb-result=')]
udc_args = [arg for arg in selected if arg.startswith('--udc-result=')]
assert len(udc_args) <= 1
udc_result = udc_args[0].split('=', 1)[1] if udc_args else None
assert udc_result in (None, 'present', 'absent', 'sysfs-missing', 'unknown')
selected = [arg for arg in selected if not arg.startswith('--udc-result=')]
sysfs_args = [arg for arg in selected if arg.startswith('--sysfs-result=')]
assert len(sysfs_args) <= 1
sysfs_result = sysfs_args[0].split('=', 1)[1] if sysfs_args else None
assert sysfs_result in (None, 'visible', 'missing', 'unknown')
selected = [arg for arg in selected if not arg.startswith('--sysfs-result=')]
dwc_args = [arg for arg in selected if arg.startswith('--dwc-result=')]
assert len(dwc_args) <= 1
dwc_result = dwc_args[0].split('=', 1)[1] if dwc_args else None
assert dwc_result in (None, 'bound', 'not-found')
selected = [arg for arg in selected if not arg.startswith('--dwc-result=')]
supplier_args = [arg for arg in selected if arg.startswith('--supplier-result=')]
assert len(supplier_args) <= 1
supplier_result = supplier_args[0].split('=', 1)[1] if supplier_args else None
assert supplier_result in (None, 'one', 'zero', 'unavailable')
selected = [arg for arg in selected if not arg.startswith('--supplier-result=')]
deferred_args = [arg for arg in selected if arg.startswith('--deferred-result=')]
assert len(deferred_args) <= 1
deferred_result = deferred_args[0].split('=', 1)[1] if deferred_args else None
assert deferred_result in (None, 'present', 'absent', 'unavailable')
selected = [arg for arg in selected if not arg.startswith('--deferred-result=')]
timeout_args = [arg for arg in selected if arg.startswith('--timeout-result=')]
assert len(timeout_args) <= 1
timeout_result = timeout_args[0].split('=', 1)[1] if timeout_args else None
assert timeout_result in (None, 'ETIMEDOUT', 'other-error', 'unavailable')
selected = [arg for arg in selected if not arg.startswith('--timeout-result=')]
out_args = [arg for arg in selected if arg.startswith('--experiment-dir=')]
assert len(out_args) <= 1
out_override = (ROOT/out_args[0].split('=', 1)[1]).resolve() if out_args else None
if out_override:
    out_override.relative_to(ROOT)
selected = [arg for arg in selected if not arg.startswith('--experiment-dir=')]
build_args = [arg for arg in selected if arg.startswith('--build-dir=')]
assert len(build_args) <= 1
build_override = (ROOT/build_args[0].split('=', 1)[1]).resolve() if build_args else None
if build_override:
    build_override.relative_to(ROOT)
selected = [arg for arg in selected if not arg.startswith('--build-dir=')]
assert out_override is None or len(selected) == 1
assert build_override is None or len(selected) == 1
rank = {prefix: i for i, (prefix, _) in enumerate(stages)}
assert set(selected) <= {prefix for prefix, _ in stages}
for prefix, stage in stages:
    if prefix not in selected:
        continue
    build = build_override or ROOT / f'out/{prefix}-20261012'
    out = out_override or ROOT / f'out/{prefix}-experiment-20261012'
    manifest = json.loads((build/'manifest.json').read_text())
    qemu = json.loads((build/'qemu-result.json').read_text())
    assert qemu['exit_code'] == 0 and qemu['smc_instruction_block_observed']
    assert qemu['image_sha256'] == hashlib.sha256((build/'Image-probe').read_bytes()).hexdigest()
    actual = hashes(out/'after-test-device.txt')
    for part, filename in [('vendor_boot_b', 'vendor_boot_b-xigua-r1.img'),
                           ('init_boot_b', 'init_boot_b-xigua-r1.img'),
                           ('dtbo_b', 'dtbo_b-avb-noop.img')]:
        assert actual[part] == manifest['files'][filename]['sha256']
    assert (out/'boot-b-prefix.txt').read_text().split()[0] == manifest['files']['boot-xigua-r1.img']['sha256']
    before = json.loads((out/'preflight.json').read_text())['partition_hashes_before']
    if retain_test:
        assert (out/'after-test-device.txt').read_text().splitlines()[:2] == ['_a', '1']
        assert all(actual[p] == before[p] for p in before if p.endswith('_a'))
    else:
        restored = out/'restored-device.txt'
        assert restored.read_text().splitlines()[:2] == ['_a', '1']
        assert hashes(restored) == before
    if enum_only:
        assert prefix == 'user-init-dwc-soft-reset-usb3-phy-probe' and retain_test
        observed = json.loads((out/'windows-gadget-enumeration.json').read_text(encoding='utf-8-sig'))
        parents = [d for d in observed if d['InstanceId'].startswith('USB\\VID_1D6B&PID_0104\\')]
        assert parents and parents[0]['Status'] == 'OK' and parents[0]['Problem'] == 0
        assert any(p['KeyName'] == 'DEVPKEY_Device_BusReportedDeviceDesc' and p['Data'] == 'xigua-bringup' for p in parents[0]['Properties'])
        assert any(d['FriendlyName'] == 'CDC ECM' for d in observed)
        result = {'stage': stage, 'host_usb_enumeration_confirmed': True,
                  'qemu_verified_exact_image': True, 'input_readback_verified': True,
                  'gadget_descriptor_identity': 'xigua-bringup, VID_1D6B PID_0104',
                  'usb_network_traffic_confirmed': False, 'mainline_shell_connected': False,
                  'soft_reset_error_log_result': 'not inferred from host enumeration',
                  'android_a_boot_completed': True, 'a_partition_hashes_match_preflight': True,
                  'all_eight_boot_partition_hashes_restored': False,
                  'b_test_partitions_retained_at_user_request': True}
        (out/'result.json').write_text(json.dumps(result, indent=2))
        manifest['phone_execution_confirmed'] = True
        manifest['host_usb_enumeration_confirmed'] = True
        manifest['user_observation_evidence'] = (out/'result.json').relative_to(ROOT).as_posix()
        (build/'manifest.json').write_text(json.dumps(manifest, indent=2))
        print('PASS: mainline USB gadget enumeration and input readback verified; B retained')
        continue
    if inconclusive:
        result = {'stage': stage, 'stage_reached_supported_by_reset_probe': None,
                  'user_observed_autonomous_repeated_resets': False,
                  'user_observation': 'continuous black screen; no autonomous resets observed',
                  'driver_state_inference': 'unknown', 'qemu_verified_exact_image': True,
                  'input_readback_verified': True, 'android_a_boot_completed': True,
                  'all_eight_boot_partition_hashes_restored': not retain_test, 'logdump_written': False}
        if retain_test:
            result['b_test_partitions_retained_at_user_request'] = True
            result['a_partition_hashes_match_preflight'] = True
        (out/'result.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
        manifest['phone_execution_confirmed'] = False
        manifest['phone_test_inconclusive'] = True
        manifest['user_observation_evidence'] = (out/'result.json').relative_to(ROOT).as_posix()
        (build/'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
        print(f'PASS: input and device state checks; phone stage signal inconclusive: {stage}')
        continue
    result = {'stage': stage, 'stage_reached_supported_by_reset_probe': True,
              'user_observed_autonomous_repeated_resets': True,
              'user_reported_reset_interval_seconds_approx': interval,
              'external_timing_measurement_performed': False,
              'qemu_verified_exact_image': True, 'input_readback_verified': True,
              'mmu_enabled_execution_confirmed': prefix not in ('kernel-entry-probe', 'kernel-pre-mmu-probe'),
              'kernel_virtual_address_execution_confirmed': prefix not in ('kernel-entry-probe', 'kernel-pre-mmu-probe', 'kernel-post-mmu-probe'),
              'start_kernel_entry_confirmed': rank[prefix] >= rank['kernel-start-kernel-probe'],
              'setup_arch_return_confirmed': rank[prefix] >= rank['kernel-after-setup-arch-probe'],
              'sched_init_return_confirmed': rank[prefix] >= rank['kernel-after-sched-init-probe'],
              'init_irq_return_confirmed': rank[prefix] >= rank['kernel-after-init-irq-probe'],
              'rest_init_call_site_reached': rank[prefix] >= rank['kernel-before-rest-init-probe'],
              'initcall_loop_completed': rank[prefix] >= rank['kernel-after-initcalls-probe'],
              'kernel_init_freeable_return_confirmed': rank[prefix] >= rank['kernel-after-kernel-init-freeable-probe'],
              'async_synchronize_full_return_confirmed': rank[prefix] >= rank['kernel-after-async-sync-probe'],
              'free_initmem_return_confirmed': rank[prefix] >= rank['kernel-after-free-initmem-probe'],
              'userspace_command_selection_reached': rank[prefix] >= rank['kernel-before-userspace-probe'],
              'run_init_process_entry_confirmed': rank[prefix] >= rank['kernel-run-init-entry-probe'],
              'android_a_boot_completed': True,
              'all_eight_boot_partition_hashes_restored': True,
              'logdump_written': False}
    if prefix == 'kernel-exec-return-probe':
        assert exec_result is not None, 'record the observed delay interpretation explicitly'
        for mode, low, high in [('zero', 4, 10), ('error', 34, 40)]:
            control = ROOT / f'out/kernel-exec-return-{mode}-control-20261012'
            calibration = json.loads((control/'qemu-result.json').read_text())
            assert calibration['exit_code'] == 0 and calibration['smc_instruction_block_observed']
            assert low <= calibration['elapsed_seconds'] <= high
            assert calibration['image_sha256'] == hashlib.sha256((control/'Image-probe').read_bytes()).hexdigest()
        result['kernel_execve_return_value_supported_by_delay_encoding'] = exec_result
        result['exact_errno_known'] = False
        result['userspace_instruction_execution_confirmed'] = False
        if exec_result == 'zero':
            phone_control = json.loads((ROOT/'out/kernel-exec-return-force-error-probe-experiment-20261012/result.json').read_text())
            assert phone_control['forced_long_delay_observed_on_phone']
            assert interval < 35 <= phone_control['user_reported_reset_interval_seconds_approx']
            result['same_site_phone_long_delay_control_verified'] = True
    if prefix == 'kernel-exec-return-force-error-probe':
        assert interval >= 35
        result['forced_long_delay_observed_on_phone'] = True
        result['actual_kernel_execve_return_value_not_measured'] = True
    if prefix == 'kernel-init-el0-boundary-probe':
        result['kernel_init_thread_return_confirmed'] = True
        result['asm_exit_to_user_mode_return_confirmed_for_init_thread'] = True
        result['thread_function_identity_filter'] = 'x19 equals kernel_init'
        result['userspace_instruction_execution_confirmed'] = False
    if prefix == 'user-init-reset-probe':
        assert qemu['native_user_probe_syscall_instruction_blocks_observed']
        assert interval >= 35
        result['userspace_execution_supported_by_native_pid1_reset_probe'] = True
        result['getpid_nanosleep_reboot_path_supported'] = True
        result['normal_init_script_execution_confirmed'] = False
        result['kernel_instruction_bytes_unchanged'] = manifest['kernel_instruction_bytes_unchanged']
    if prefix == 'user-init-after-usb-probe':
        assert qemu['native_user_probe_syscall_instruction_blocks_observed']
        assert manifest['script_prefix_through_usb_attempts_preserved']
        assert usb_result is not None
        if usb_result == 'unbound':
            assert interval >= 35
        result['original_shell_script_usb_loop_completion_supported'] = True
        result['BOUND_result_supported_by_delay_encoding'] = usb_result
        result['udc_presence_known'] = False
        result['host_usb_enumeration_confirmed'] = False
    if prefix == 'user-init-sysfs-status-probe':
        assert qemu['native_user_probe_syscall_instruction_blocks_observed']
        assert manifest['script_prefix_through_usb_attempts_preserved']
        assert sysfs_result in ('visible', 'missing')
        if sysfs_result == 'missing':
            assert interval >= 35
        result['sysfs_class_directory_state_supported_by_delay_encoding'] = sysfs_result
        result['udc_presence_known'] = False
        result['original_shell_script_usb_loop_completion_supported'] = True
    if prefix == 'user-init-udc-only-probe':
        assert qemu['native_user_probe_syscall_instruction_blocks_observed']
        assert manifest['script_prefix_through_usb_attempts_preserved']
        assert udc_result in ('present', 'absent')
        if udc_result == 'absent':
            assert interval >= 35
        result['find_udc_result_supported_by_delay_encoding'] = udc_result
        result['absence_is_at_probe_time_only'] = True
        result['host_usb_enumeration_confirmed'] = False
    if prefix in ('user-init-dwc-bound-probe', 'user-init-qcom-bound-probe', 'user-init-hsphy-bound-probe'):
        assert qemu['native_user_probe_syscall_instruction_blocks_observed']
        assert manifest['script_prefix_through_usb_attempts_preserved']
        assert dwc_result is not None
        if dwc_result == 'not-found':
            assert interval >= 35
        key = {'user-init-dwc-bound-probe': 'dwc3', 'user-init-qcom-bound-probe': 'qcom_usb_parent', 'user-init-hsphy-bound-probe': 'usb2_phy'}[prefix]
        result[key + '_driver_symlink_check_supported_by_delay_encoding'] = dwc_result
        result['device_absent_vs_unbound_distinguished'] = dwc_result == 'bound'
    if prefix == 'user-init-dwc-present-probe':
        assert qemu['native_user_probe_syscall_instruction_blocks_observed']
        assert manifest['script_prefix_through_usb_attempts_preserved']
        assert dwc_result is not None
        if dwc_result == 'not-found':
            assert interval >= 35
        result['dwc3_platform_device_directory_found_supported'] = dwc_result == 'bound'
        result['driver_binding_measured_by_this_probe'] = False
    if prefix == 'user-init-dwc-wait-probe':
        assert qemu['native_user_probe_syscall_instruction_blocks_observed']
        assert manifest['script_prefix_through_usb_attempts_preserved']
        assert supplier_result is not None
        if supplier_result == 'zero':
            assert 35 <= interval < 65
        if supplier_result == 'unavailable':
            assert interval >= 65
        result['waiting_for_supplier_attribute_supported_by_delay_encoding'] = supplier_result
        result['specific_supplier_identified'] = False
        result['all_supplier_drivers_ready_confirmed'] = False
    if prefix in ('user-init-dwc-deferred-probe', 'user-init-dwc-core-error-probe', 'user-init-dwc-soft-reset-error-probe', 'user-init-dwc-soft-reset-usb3-phy-probe'):
        assert qemu['native_user_probe_syscall_instruction_blocks_observed']
        assert manifest['script_prefix_through_usb_attempts_preserved']
        assert deferred_result is not None
        if deferred_result == 'absent':
            assert 35 <= interval < 65
        if deferred_result == 'unavailable':
            assert interval >= 65
        key = 'dwc3_controller_soft_reset_failed_log_message_supported' if prefix in ('user-init-dwc-soft-reset-error-probe', 'user-init-dwc-soft-reset-usb3-phy-probe') else 'dwc3_in_devices_deferred_snapshot_supported' if prefix == 'user-init-dwc-deferred-probe' else 'dwc3_failed_to_initialize_core_log_message_supported'
        result[key] = deferred_result
        result['exact_probe_error_known'] = False
        if prefix == 'user-init-dwc-soft-reset-error-probe' and (out/'user-observation-soft-reset.json').exists():
            observed = json.loads((out/'user-observation-soft-reset.json').read_text())
            result['user_reported_reset_intervals_seconds'] = observed['user_reported_reset_intervals_seconds']
            result['then_automatically_entered_android_a'] = observed['then_automatically_entered_android']
            result['target_log_supported_in_some_boots_only'] = True
            result['exact_branch_for_each_cycle_confirmed'] = False
    if prefix in ('user-init-dwc-core-timeout-probe', 'user-init-dwc-core-timeout-early-probe'):
        assert qemu['native_user_probe_syscall_instruction_blocks_observed']
        assert manifest['script_prefix_through_usb_attempts_preserved']
        assert timeout_result is not None
        if timeout_result == 'other-error':
            assert 35 <= interval < 65
        if timeout_result == 'unavailable':
            assert interval >= 65
        result['dwc3_core_error_timeout_log_check_supported'] = timeout_result
        result['exact_probe_error_known'] = timeout_result == 'ETIMEDOUT'
        mixed_path = out/'user-observation-mixed.json'
        if mixed_path.exists():
            mixed = json.loads(mixed_path.read_text())
            assert timeout_result == 'ETIMEDOUT'
            assert mixed['observed_interval_classes_seconds_approx'] == [20, 80]
            mixed['post_test_input_readback_pending'] = False
            mixed['post_test_input_readback_verified'] = True
            mixed_path.write_text(json.dumps(mixed, indent=2))
            result['user_reported_interval_classes_seconds_approx'] = [20, 80]
            result['probe_signal_varied_between_boots'] = True
            result['ETIMEDOUT_message_supported_in_some_boots_only'] = True
            result['all_boots_confirmed_ETIMEDOUT'] = False
        series_path = out/'user-observation-series.json'
        if series_path.exists():
            series = json.loads(series_path.read_text())
            assert timeout_result == 'ETIMEDOUT'
            assert series['first_three_interval_seconds_approx'] == [20, 20, 20]
            series['post_test_input_readback_pending'] = False
            series['post_test_input_readback_verified'] = True
            series_path.write_text(json.dumps(series, indent=2))
            result['first_three_ETIMEDOUT_signals_supported'] = True
            result['later_no_reset_observation_seconds_approx'] = [120, 180]
            result['later_boot_result'] = 'undetermined'
            result['all_boots_confirmed_ETIMEDOUT'] = False
    if prefix == 'user-init-udc-status-probe':
        assert qemu['native_user_probe_syscall_instruction_blocks_observed']
        assert manifest['script_prefix_through_usb_attempts_preserved']
        assert udc_result is not None
        if udc_result == 'absent':
            assert 35 <= interval < 65
        result['original_shell_script_usb_loop_completion_supported'] = True
        result['UDC_presence_supported_by_delay_encoding'] = udc_result
        result['sysfs_class_visible_supported'] = udc_result in ('present', 'absent')
        result['absence_is_at_probe_time_only'] = True
    if retain_test:
        result['android_a_boot_completed'] = True
        result['all_eight_boot_partition_hashes_restored'] = False
        result['b_test_partitions_retained_at_user_request'] = True
        result['a_partition_hashes_match_preflight'] = True
    (out/'result.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    manifest['phone_execution_confirmed'] = True
    manifest['user_observation_evidence'] = (out/'result.json').relative_to(ROOT).as_posix()
    if prefix != 'kernel-entry-probe':
        manifest['linux_primary_entry_executed'] = True
    (build/'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    print(f'PASS: saved input and device state checks; stage signal recorded: {stage}')

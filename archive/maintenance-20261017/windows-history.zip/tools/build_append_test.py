#!/usr/bin/env python3
"""Design the CLEAN test that distinguishes the two competing hypotheses.

Hypothesis A (what I concluded earlier): ABL ignores a DTB appended to the kernel
    Image; the device tree always comes from vendor_boot + dtbo in flash.
Hypothesis B (what the aston port and the LKML thread imply): the appended DTB IS
    used, and my earlier probe failed only because the vendor dtbo's overlays were
    applied on top and overwrote my markers.

The earlier probe could not tell these apart, because:
  * probe2.dtb was the LIVE tree (already post-overlay), and
  * the vendor dtbo was still present, so overlays were re-applied on top.

A clean test needs BOTH:
  1. dtbo erased, so no overlay can run and nothing can overwrite the tree
  2. the appended DTB carrying a marker in a place nothing else writes

For (2) the marker must be in the appended DTB itself, and the check must be able
to see it. The base `model` is unsuitable: overlays set it, and the vendor tree
sets it too. Use an inert extra top-level node instead -- the same technique that
worked for the vendor_boot test, and it is plainly visible via a directory
listing (no root needed).

Also note which slot matters:
  * `fastboot boot <img>` loads the IMAGE, so the DTB comes from that image
  * but vendor_boot/dtbo still come from the ACTIVE SLOT's flash
  so we must erase the dtbo of the active slot.

Plan:
  active slot b  ->  erase dtbo_b  ->  fastboot boot our marked image
  and the appended DTB = OUR tree + an inert marker node.
"""
import os
import struct
import sys

sys.path.insert(0, os.path.join(r'H:\WorkSpace\PJA110-Mainline', 'tools'))
from fdt import FDT
from fdtwrite import parse, serialise, Node, walk

WS = r'H:\WorkSpace\PJA110-Mainline'
MARK_NODE = 'xigua-append-test'

print('=' * 78)
print('THE CLEAN TEST')
print('=' * 78)
print('  appended DTB = OUR device tree + inert top-level node "%s"' % MARK_NODE)
print('  dtbo erased on the active slot, so no overlay can run')
print()
print('  read back (no root needed):')
print('    adb shell ls /sys/firmware/devicetree/base/ | grep %s' % MARK_NODE)
print()
print('  outcomes:')
print('    marker present -> ABL USED our appended DTB  => our tree is in effect')
print('    marker absent  -> ABL ignored it            => hypothesis A stands')
print()

# build it
ours_path = os.path.join(WS, 'dts', 'sm8550-oneplus-xigua-16G.dtb')
blob = open(ours_path, 'rb').read()
print('=== our DTB ===')
print('  file      : %s' % ours_path)
print('  size      : %d' % len(blob))
print('  totalsize : %d' % struct.unpack_from('>I', blob, 4)[0])

root, rsvmap = parse(blob)
paths_before = set(p for p, _n in walk(root))
print('  nodes     : %d' % len(paths_before))

if '/' + MARK_NODE in paths_before:
    print('  marker node already present; nothing to do')
else:
    node = Node(MARK_NODE)
    root.children.append(node)
    print('  appended inert node /%s' % MARK_NODE)

out = serialise(root, rsvmap)
root2, _ = parse(out)
paths_after = set(p for p, _n in walk(root2))
print()
print('=== verify the marked DTB ===')
print('  rebuilt size : %d' % len(out))
print('  nodes        : %d -> %d' % (len(paths_before), len(paths_after)))
print('  marker present: %s' % ('/' + MARK_NODE in paths_after))
print('  extra paths  : %s' % sorted(paths_after - paths_before))

# our tree must keep the two labels ABL requires
syms = set(root2.children and [] or [])
for p, n in walk(root2):
    if p == '/__symbols__':
        syms = set(n.props)
print('  __symbols__  : %d labels' % len(syms))
print('  qcom_tzlog   : %s' % ('qcom_tzlog' in syms))
print('  arch_timer   : %s' % ('arch_timer' in syms))

dst = os.path.join(WS, 'out', 'xigua-marked.dtb')
open(dst, 'wb').write(out)
print()
print('wrote %s' % dst)
print()
print('NEXT: build boot image from Image + this DTB, erase dtbo on the active')
print('      slot, then fastboot boot it.')

"""Use standard fdtput to prepare bq28z610 DTBs; no device access."""
import hashlib
import json
from pathlib import Path
import struct
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'tools'))
from fdt import FDT, scan_for_fdt

OUT = ROOT/'out/battery-bringup-20261016'
OUT.mkdir(exist_ok=True)
base = ROOT/'out/native-install-20261016/native-images/vendor_boot_a.img'
original = base.read_bytes()
expected = json.loads((base.parent/'manifest.json').read_text())['files'][base.name]['sha256']
assert hashlib.sha256(original).hexdigest() == expected
hsize, dsize = struct.unpack_from('<II', original, 2096)
rdsize = struct.unpack_from('<I', original, 24)[0]
align = lambda n: (n+4095)//4096*4096
dtboff = align(align(hsize)+rdsize)
region = original[dtboff:dtboff+dsize]
trees = scan_for_fdt(region)
assert len(trees) == 4
candidate = bytearray(original)
changes = []

for index, (offset, size, tree) in enumerate(trees):
    nodes = tree.nodes()
    if nodes['/'].get('model') != b'OnePlus Ace 2 Pro\0':
        continue  # Preserve the three original Qualcomm fallback DTBs.
    bus = '/soc@0/geniqup@8c0000/i2c@880000'
    pins = '/soc@0/pinctrl@f100000/qup-i2c8-data-clk-state'
    assert nodes[bus]['status'] == b'disabled\0'
    assert nodes['/soc@0/geniqup@8c0000']['status'] == b'okay\0'
    assert nodes[pins+'/scl-pins']['pins'] == b'gpio57\0'
    assert nodes[pins+'/sda-pins']['pins'] == b'gpio56\0'
    path = OUT/f'battery-{index}.dtb'
    path.write_bytes(region[offset:offset+size])
    def put(node, prop, *values, kind='s'):
        subprocess.run(['fdtput', '-t', kind, str(path), node, prop, *values], check=True)
    put(bus, 'status', 'okay')
    put(bus, 'clock-frequency', '100000', kind='u')
    put(pins+'/scl-pins', 'pins', 'gpio1')
    put(pins+'/scl-pins', 'function', 'qup2_se0_l1_mirb')
    put(pins+'/sda-pins', 'pins', 'gpio0')
    put(pins+'/sda-pins', 'function', 'qup2_se0_l0_mirb')
    gauge = bus+'/fuel-gauge@55'
    subprocess.run(['fdtput', '-c', str(path), gauge], check=True)
    put(gauge, 'compatible', 'ti,bq28z610')
    put(gauge, 'reg', '55', kind='x')
    new = path.read_bytes()
    updated = FDT(new).nodes()
    permitted = {(bus, 'status'), (bus, 'clock-frequency'),
                 (pins+'/scl-pins', 'pins'), (pins+'/scl-pins', 'function'),
                 (pins+'/sda-pins', 'pins'), (pins+'/sda-pins', 'function'),
                 (gauge, 'compatible'), (gauge, 'reg')}
    actual = {(p, k) for p in nodes.keys() | updated.keys()
              for k in nodes.get(p, {}).keys() | updated.get(p, {}).keys()
              if nodes.get(p, {}).get(k) != updated.get(p, {}).get(k)}
    assert actual == permitted, actual ^ permitted
    assert tree.reserved_memory() == FDT(new).reserved_memory()
    assert len(new) <= size
    padded = bytearray(new.ljust(size, b'\0'))
    struct.pack_into('>I', padded, 4, size)
    assert FDT(padded).nodes() == updated
    path.write_bytes(padded)
    candidate[dtboff+offset:dtboff+offset+size] = padded
    changes.append({'index': index, 'offset': offset, 'bytes': size,
                    'changed_properties': sorted(map(list, actual)),
                    'sha256': hashlib.sha256(padded).hexdigest()})

assert candidate[:dtboff] == original[:dtboff]
assert candidate[dtboff+dsize:] == original[dtboff+dsize:]
assert len(changes) == 1 and changes[0]['index'] == 0
assert candidate[dtboff+trees[0][1]:] == original[dtboff+trees[0][1]:]
target = OUT/'vendor_boot_a-battery.img'
target.write_bytes(candidate)
record = {'base_sha256': expected, 'candidate_sha256': hashlib.sha256(candidate).hexdigest(),
          'bytes': len(candidate), 'dtb_offset': dtboff, 'dtb_bytes': dsize,
          'trees': changes, 'driver': 'unmodified upstream bq27xxx',
          'kernel_rebuild_required': False, 'phone_written': False,
          'battery_design_parameters_added': False, 'charging_parameters_changed': False,
          'all_bytes_outside_dtb_region_unchanged': True}
(OUT/'candidate.json').write_text(json.dumps(record, indent=2)+'\n')
print('PASS: PJA110 DTB updated with standard fdtput; exact property diff checked; other three DTBs, ramdisk, offsets and AVB tail unchanged')

"""Export vendor panel descendants, DSC and complete DSI command records."""
import hashlib
import json
import struct
from pathlib import Path
from fdt import FDT

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/display-baseline-20261013'
OUT.mkdir(exist_ok=True)
source=ROOT/'live-from-device.dtb'
nodes=FDT(source.read_bytes()).nodes()
target='qcom,mdss_dsi_panel_AA536_P_3_A0001_dsc_cmd'
paths=[p for p in nodes if p.split('/')[-1]==target]
assert len(paths)==1
panel=paths[0]
records={}
commands={}
for path,props in nodes.items():
    if not (path==panel or path.startswith(panel+'/') or
            any(t in path.lower() for t in ('oplus_xigua_dsi_panel_pwr','display_panel_avdd','mdss_dsi@','dsi_panel_pwr'))):
        continue
    decoded={}
    for key,data in props.items():
        item={'hex':data.hex(),'bytes':len(data)}
        if data and data.endswith(b'\0') and all(c==0 or 32<=c<127 for c in data):
            item['strings']=data.rstrip(b'\0').decode().split('\0')
        elif data and len(data)%4==0:
            item['u32']=list(struct.unpack('>'+'I'*(len(data)//4),data))
        decoded[key]=item
        if 'command' in key and key.endswith('-command') and key != 'qcom,mdss-dsi-te-dcs-command':
            parsed=[]; offset=0
            # Qualcomm downstream command format: 7 byte header, BE payload size.
            while offset<len(data):
                if offset+7>len(data):
                    raise ValueError(f'truncated command header: {path} {key}')
                header=data[offset:offset+7]
                length=int.from_bytes(header[5:7],'big')
                payload=data[offset+7:offset+7+length]
                if len(payload)!=length: raise ValueError('truncated DSI payload')
                parsed.append({'type':header[0],'last':header[1],'vc':header[2],
                               'vendor_flags':header[3],'wait_ms':header[4],'payload_hex':payload.hex()})
                offset+=7+length
            commands[path+':'+key]=parsed
    records[path]=decoded
(OUT/'vendor-display.json').write_text(json.dumps({'source':source.name,
    'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'panel':panel,'nodes':records},indent=2)+'\n')
(OUT/'dsi-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
timing={p:{k:v for k,v in props.items() if any(t in k for t in ('width','height','porch','pulse','framerate','dsc','reset','lane'))} for p,props in records.items() if p==panel or p.startswith(panel+'/')}
(OUT/'timings-dsc.json').write_text(json.dumps(timing,indent=2)+'\n')
print(f'PASS: {len(records)} vendor display nodes; {len(commands)} command tables parsed')
for p,props in timing.items():
    if props:
        print(p)
        for k,v in props.items(): print(' ',k,v.get('u32',v.get('strings',v['hex'])))

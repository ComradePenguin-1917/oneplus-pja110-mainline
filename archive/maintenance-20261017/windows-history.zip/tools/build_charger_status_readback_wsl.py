"""Build a read-only GLINK status probe from the already reviewed probe."""
from pathlib import Path
import hashlib, json, subprocess

root = Path.home() / 'workspace/PJA110-Mainline/charger-native-a'
tree = root / 'linux-6.14'
src = Path('/mnt/h/workspace/PJA110-Mainline/out/native-install-20261017/charger-state-readback/qcom_battmgr-state.c')
out = Path('/mnt/h/workspace/PJA110-Mainline/out/native-install-20261017/charger-status-readback')
build = root / 'charger-status-readback'
out.mkdir(exist_ok=True); build.mkdir(exist_ok=True)
s = src.read_text()
s = s.replace('static int query_result[6] = {-115, -115, -115, -115, -115, -115};',
              'static int query_result[12] = {-115, -115, -115, -115, -115, -115, -115, -115, -115, -115, -115, -115};')
s = s.replace('static unsigned int query_value[6], firmware_result[6];',
              'static unsigned int query_value[12], firmware_result[12];')
s = s.replace('static const u32 opcodes[] = {0x30, 0x32, 0x32, 0x30, 0x30, 0x32};\n    static const u32 properties[] = {24, 29, 5, 10, 11, 4};',
'''static const u32 opcodes[] = {0x30, 0x30, 0x30, 0x30, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32};
    static const u32 properties[] = {0, 1, 2, 3, 0, 1, 3, 4, 5, 6, 11, 14};''')
s = s.replace('while (++i < ARRAY_SIZE(properties))\n                query_result[i] = -ECANCELED;',
              'while (++i < ARRAY_SIZE(properties))\n                query_result[i] = -ECANCELED;')
(build / 'qcom_battmgr.c').write_text(s)
(build / 'Makefile').write_text('obj-m += qcom_battmgr.o\n')
p = subprocess.run(['make','-C',str(tree),'ARCH=arm64',
    'CROSS_COMPILE=/opt/aarch64-linux-gnu-toolchain-13.3/bin/aarch64-none-linux-gnu-',
    'M='+str(build),'modules'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(out/'build.log').write_bytes(p.stdout); print(p.stdout.decode(errors='replace')); p.check_returncode()
data=(build/'qcom_battmgr.ko').read_bytes(); (out/'qcom_battmgr-status.ko').write_bytes(data)
(out/'source.c').write_text(s)
(out/'manifest.json').write_text(json.dumps({'sha256':hashlib.sha256(data).hexdigest(),
 'queries': list(zip([0x30]*4+[0x32]*8,[0,1,2,3,0,1,3,4,5,6,11,14])),
 'property_sets':False,'phone_modified':False}, indent=2)+'\n')
print((out/'manifest.json').read_text())

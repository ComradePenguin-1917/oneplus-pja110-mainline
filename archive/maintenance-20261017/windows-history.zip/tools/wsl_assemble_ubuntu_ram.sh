#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
OUT="$WIN/out/ubuntu-ram-20261014"
BUILD="$ROOT/ubuntu-ram-24.04-merged"
mkdir -p "$BUILD"
python3 - "$OUT" "$BUILD" <<'PY'
import json,sys,subprocess,hashlib,shutil
from pathlib import Path
out,build=map(Path,sys.argv[1:]);m=json.loads((out/'manifest.json').read_text())
base=out/m['base_file'];assert hashlib.sha256(base.read_bytes()).hexdigest()==m['base_sha256']
subprocess.run(['tar','--no-same-owner','-xzf',str(base),'-C',str(build)],check=True)
for p in m['packages']:
 file=out/'debs'/p['file'];assert hashlib.sha256(file.read_bytes()).hexdigest()==p['sha256']
 subprocess.run(['dpkg-deb','-x',str(file),str(build)],check=True)
for name in ('lib','bin','sbin'):
 path=build/name
 if path.is_dir() and not path.is_symlink():
  shutil.copytree(path,build/'usr'/name,dirs_exist_ok=True,symlinks=True)
  preserved=build/(name+'.pre-merge')
  if preserved.exists():
   shutil.copytree(path,build/'usr'/name,dirs_exist_ok=True,symlinks=True)
   shutil.rmtree(path)
   path.symlink_to('usr/'+name)
   continue
  path.rename(preserved)
  path.symlink_to('usr/'+name)
# Keep the current portable debug tools for bounded validation and recovery.
for name,src in [('mesa-offscreen-test',Path.home()/'workspace/PJA110-Mainline/mesa-offscreen-runtime/mesa-offscreen-test'),('gpu-probe',Path('/mnt/h/workspace/PJA110-Mainline/out/gpu-port-20261014/gpu-probe'))]:
 dest=build/'usr/local/bin'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest);dest.chmod(0o755)
etc=build/'etc';(etc/'weston').mkdir(exist_ok=True)
(etc/'weston/weston.ini').write_text('''[core]
idle-time=0
xwayland=false

[shell]
background-color=0xff304050
panel-position=top
locking=false

[output]
name=DSI-1
mode=preferred
transform=normal
''')
(etc/'ssh/sshd_config_pja').write_text('''Port 2222
ListenAddress 169.254.42.1
HostKey /etc/ssh/ssh_host_ed25519_key
PermitRootLogin prohibit-password
PasswordAuthentication no
KbdInteractiveAuthentication no
PubkeyAuthentication yes
UsePAM no
StrictModes yes
AuthorizedKeysFile .ssh/authorized_keys
Subsystem sftp /usr/lib/openssh/sftp-server
PidFile /run/sshd-ubuntu.pid
''')
# Unlock the account for key authentication, without assigning a usable password.
shadow=etc/'shadow'
lines=shadow.read_text().splitlines();updated=[]
for line in lines:
 fields=line.split(':')
 if fields[0]=='root':fields[1]='*'
 updated.append(':'.join(fields))
shadow.write_text('\n'.join(updated)+'\n')
passwd=etc/'passwd'
if not any(l.startswith('sshd:') for l in passwd.read_text().splitlines()):
 with passwd.open('a') as f:f.write('sshd:x:100:65534:SSH privilege separation:/run/sshd:/usr/sbin/nologin\n')
archive=out/'ubuntu-ram-rootfs.tar.gz'
subprocess.run(['tar','--owner=0','--group=0','-C',str(build),'-czf',str(archive),'.'],check=True)
m.update(runtime_file=archive.name,runtime_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
 runtime_bytes=archive.stat().st_size,packages_extracted_not_dpkg_configured=True)
(out/'runtime-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print('PASS: official Ubuntu rootfs with Weston/Mesa/SSH binaries assembled; no system installation')
PY

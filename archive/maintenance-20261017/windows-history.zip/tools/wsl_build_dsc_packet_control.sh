#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
TREE="$ROOT/linux"
OUT="$WIN/out/dsc-packet-control-20261014"
mkdir -p "$OUT"
export PATH="$ROOT/toolchain/gcc-12-aarch64/usr/bin:$PATH"
export LD_LIBRARY_PATH="$ROOT/toolchain/gcc-12-aarch64/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu-
cmp "$TREE/arch/arm64/boot/Image" "$WIN/out/te-height-control-20261014/Image"
cmp "$TREE/.config" "$WIN/out/te-height-control-20261014/.config"
cmp "$TREE/drivers/gpu/drm/msm/dsi/dsi_host.c" "$WIN/out/weston-kms-diagnosis-20261014/dsi_host-current.c"
cmp "$TREE/drivers/gpu/drm/msm/disp/dpu1/dpu_encoder_phys_cmd.c" "$WIN/out/te-height-control-20261014/dpu_encoder_phys_cmd.height65520.c"
cp "$WIN/out/dsc-packet-audit-20261014/dsi_host.packet2.c" "$TREE/drivers/gpu/drm/msm/dsi/dsi_host.c"
cp "$WIN/out/dsc-packet-audit-20261014/packet2-only.patch" "$OUT/"
cd "$TREE"
make -j12 Image > "$OUT/build.log" 2>&1
cp arch/arm64/boot/Image System.map .config "$OUT/"
cmp .config "$WIN/out/te-height-control-20261014/.config"
echo 'PASS: AA536 packetization-only control built; TE and config unchanged'

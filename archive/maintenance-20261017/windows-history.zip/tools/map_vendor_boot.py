#!/usr/bin/env python3
"""Fully map the vendor_boot partition so we can surgically replace its DTB.

Route (b) plan: vendor_boot's dtb section holds the BASE device trees that ABL
picks from before applying the dtbo overlay. If we replace the entry matching
this device with our own DTB, we get full control while keeping ABL's normal
flow.

The device's vendor_boot differs from the OTA copy (4b3e8008 vs e085f83a), so we
analyse the DEVICE's copy.

Needed facts:
  * exact header layout and section offsets
  * the 4 DTBs, their msm-id/board-id and which one this device uses
  * the vendor ramdisk section and the ramdisk table (must be preserved intact)
  * total sizes so we can rebuild a byte-faithful image
"""
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fdt import FDT

WS = r'H:\WorkSpace\PJA110-Mainline'
PAGE = 4096
p = os.path.join(WS, 'backup', 'vendor_boot_a.img')
v = open(p, 'rb').read()

print('=== header ===')
print('  file size      : %d (%.2f MiB)' % (len(v), len(v)/2**20))
magic = v[:8]
hver, pagesz, kaddr, raddr = struct.unpack_from('<4I', v, 8)
vrsize = struct.unpack_from('<I', v, 24)[0]
cmdline = v[28:28+2048].rstrip(b'\0')
tags = struct.unpack_from('<I', v, 28+2048)[0]
name = v[28+2048+4:28+2048+4+16].rstrip(b'\0')
hsize, dtbsize = struct.unpack_from('<2I', v, 28+2048+4+16)
dtbaddr = struct.unpack_from('<Q', v, 28+2048+4+16+8)[0]
tbl_size, tbl_num, tbl_esize = struct.unpack_from('<3I', v, 28+2048+4+16+16)
bc_size = struct.unpack_from('<I', v, 28+2048+4+16+16+12)[0]

print('  magic          : %r' % magic)
print('  header_version : %d' % hver)
print('  page_size      : %d' % pagesz)
print('  header_size    : %d' % hsize)
print('  cmdline        : %r' % cmdline)
print('  name           : %r' % name)
print('  vendor_ramdisk_size : %d (%.2f MiB)' % (vrsize, vrsize/2**20))
print('  dtb_size       : %d (%.2f MiB)' % (dtbsize, dtbsize/2**20))
print('  dtb_addr       : 0x%x' % dtbaddr)
print('  ramdisk table  : %d entries x %d bytes (size field %d)' % (tbl_num, tbl_esize, tbl_size))
print('  bootconfig_size: %d' % bc_size)


def align(x):
    return (x + PAGE - 1) // PAGE * PAGE


print()
print('=== section layout ===')
off = align(hsize)
print('  header         : 0x%08x .. 0x%08x  (%d bytes)' % (0, hsize, hsize))
print('  vendor_ramdisk : 0x%08x .. 0x%08x  (%d bytes)' % (off, off+vrsize, vrsize))
ramdisk_off = off
dtb_off = align(off + vrsize)
print('  dtb            : 0x%08x .. 0x%08x  (%d bytes)' % (dtb_off, dtb_off+dtbsize, dtbsize))
tbl_off = align(dtb_off + dtbsize)
print('  ramdisk_table  : 0x%08x .. 0x%08x  (%d bytes)' % (tbl_off, tbl_off+tbl_size, tbl_size))
bc_off = align(tbl_off + tbl_size)
print('  bootconfig     : 0x%08x .. 0x%08x  (%d bytes)' % (bc_off, bc_off+bc_size, bc_size))
print('  rest           : zero padding to %d' % len(v))

print()
print('=== verify section magics ===')
print('  dtb_off magic  : %s  (d00dfeed = FDT)' % v[dtb_off:dtb_off+4].hex())
print('  ramdisk magic  : %s' % v[ramdisk_off:ramdisk_off+4].hex())
print('  bootconfig     : %r' % v[bc_off:bc_off+24])

print()
print('=== the DTBs inside the dtb section ===')
# dtb section: a dt_table? or concatenated DTBs at aligned offsets?
# check for dt_table magic first
d0 = struct.unpack_from('>I', v, dtb_off)[0]
print('  first u32 at dtb_off: 0x%08x' % d0)
if d0 == 0xD7B7AB1E:
    print('  -> dt_table container')
    total, hsz, esz, cnt = struct.unpack_from('>4I', v, dtb_off+4)
    eoff = struct.unpack_from('>I', v, dtb_off+20)[0]
    print('     entries=%d entry_size=%d' % (cnt, esz))
    for i in range(cnt):
        e = dtb_off + eoff + i*esz
        sz, o = struct.unpack_from('>2I', v, e)
        ident, rev = struct.unpack_from('>2I', v, e+8)
        print('     entry %d: size=%-8d off=%-8d id=0x%x rev=0x%x' % (i, sz, o, ident, rev))
else:
    print('  -> NOT a dt_table; scanning for FDT magics in the section')
    seg = v[dtb_off:dtb_off+dtbsize]
    offs = []
    i = 0
    while True:
        i = seg.find(b'\xd0\x0d\xfe\xed', i)
        if i < 0:
            break
        sz = struct.unpack_from('>I', seg, i+4)[0]
        offs.append((i, sz))
        i += 4
    for i, sz in offs:
        print('     FDT at +0x%06x  totalsize=%d' % (i, sz))
        f = FDT(seg[i:i+sz])
        n = f.nodes()
        root = n.get('/', {})
        mid = root.get('qcom,msm-id')
        bid = root.get('qcom,board-id')
        model = root.get('model', b'').rstrip(b'\0').decode('ascii', 'replace')
        ms = ' '.join('0x%x' % x for x in struct.unpack('>%dI' % (len(mid)//4), mid)) if mid else '-'
        bs = ' '.join('0x%x' % x for x in struct.unpack('>%dI' % (len(bid)//4), bid)) if bid else '-'
        print('        model    = %s' % model)
        print('        msm-id   = %s' % ms)
        print('        board-id = %s' % bs)
        print('        nodes    = %d' % len(n))

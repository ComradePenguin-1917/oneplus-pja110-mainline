#!/bin/bash
# QEMU printed NOTHING. Find out why before drawing any conclusion.
#
# Candidate causes, cheapest first:
#   1. -nographic swallows output unless serial is wired to stdio
#   2. our Image needs a DTB (arm64 kernels generally do) and we passed none
#   3. the Image is an EFI-stub kernel and QEMU's -kernel path cannot run it
#      without a firmware (edk2) providing EFI services
#   4. the kernel really does die instantly
#
# We distinguish these with a CONTROLLED comparison: boot a stock/known-good
# arm64 kernel in exactly the same way. If that also prints nothing, the problem
# is the invocation, not our kernel.
set -uo pipefail

ROOT="$HOME/workspace/PJA110-Mainline"
SY="$ROOT/toolchain/qemu/sysroot"
QEMU="$SY/usr/bin/qemu-system-aarch64"
export LD_LIBRARY_PATH="$SY/usr/lib/x86_64-linux-gnu:${LD_LIBRARY_PATH:-}"
export QEMU_DATADIR="$SY/usr/share/qemu"

echo "=== A) is our Image really an EFI-stub kernel? ==="
head -c 64 "$ROOT/out/Image-poweroff" | xxd | head -4 | sed 's/^/  /'
python3 - <<'PY'
import struct
p='/home/comrade_penguin_desktop/workspace/PJA110-Mainline/out/Image-poweroff'
b=open(p,'rb').read(64)
print('  first 2 bytes : %r' % b[:2])
print('  magic@56      : %r  (want b"ARM\\x64")' % b[56:60])
print('  -> %s' % ('EFI stub (PE/COFF, starts with MZ)' if b[:2]==b'MZ' else 'raw arm64 Image'))
PY

echo
echo "=== B) EFFORT 1: does qemu-system-aarch64 print anything AT ALL? ==="
echo "  (boot with no kernel: should still show firmware/BIOS banner or a warning)"
timeout 10 "$QEMU" -M virt -cpu cortex-a57 -m 512 -nographic -serial mon:stdio 2>&1 | head -20 | sed 's/^/  /'
echo "  rc=$?"

echo
echo "=== C) EFFORT 2: serial explicitly on stdio, kernel given a DTB ==="
# Build a throwaway DTB so the kernel has one (QEMU can also generate it with
# -machine dumpdtb). Use QEMU's own generated DTB: that is the most correct one
# for the machine we are asking for.
timeout 20 "$QEMU" -M virt,dumpdtb=/tmp/virt.dtb -cpu cortex-a57 -smp 2 -m 2048 2>&1 | head -3 | sed 's/^/  /'
if [ -f /tmp/virt.dtb ]; then
    echo "  QEMU generated /tmp/virt.dtb: $(stat -c%s /tmp/virt.dtb) bytes"
    file /tmp/virt.dtb | sed 's/^/  /'
else
    echo "  no dtb produced"
fi

echo
echo "=== D) boot our kernel WITH that DTB and an explicit pl011 console ==="
if [ -f /tmp/virt.dtb ]; then
    timeout 60 "$QEMU" \
        -M virt -cpu cortex-a57 -smp 2 -m 2048 \
        -kernel "$ROOT/out/Image-poweroff" \
        -initrd "$ROOT/initramfs/initramfs.cpio.gz" \
        -dtb /tmp/virt.dtb \
        -append "console=ttyAMA0 earlycon=pl011,0x9000000 loglevel=8 rdinit=/init ignore_loglevel" \
        -nographic -serial stdio -monitor none \
        2>&1 | head -80 | sed 's/^/  /'
    echo "  rc=$?"
fi

echo
echo "=== E) is there an EFI firmware available to run the stub properly? ==="
for f in "$SY/usr/share/qemu-efi-aarch64/QEMU_EFI.fd" \
         "$SY/usr/share/qemu/QEMU_EFI.fd" \
         /usr/share/qemu-efi-aarch64/QEMU_EFI.fd \
         /usr/share/AAVMF/AAVMF_CODE.fd; do
    [ -f "$f" ] && echo "  found: $f ($(stat -c%s "$f") bytes)"
done
echo "  (edk2-aarch64 package not installed would explain an EFI-stub kernel"
echo "   producing no output when loaded with plain -kernel)"

"""Request a normal native reboot without waiting for authentication."""
from pathlib import Path
import subprocess
from prepare_native_install import SSH
args = SSH[:]
args[-1] = 'penguin@172.16.42.1'
args = [x if not x.startswith('UserKnownHostsFile=') else
        'UserKnownHostsFile=out/native-install-20261017/known_hosts' for x in args]
cmd = 'cat /proc/sys/kernel/random/boot_id; busctl --allow-interactive-authorization=no call org.freedesktop.login1 /org/freedesktop/login1 org.freedesktop.login1.Manager Reboot b false'
p = subprocess.run(args + [cmd], capture_output=True, timeout=20)
Path('out/native-install-20261017/adc-gen3/reboot-request.txt').write_bytes(p.stdout + p.stderr)
print(p.stdout.decode(errors='replace'))
print(p.stderr.decode(errors='replace'))
print('SSH exit:', p.returncode)

"""Build bounded OEM charger GET diagnostics against the prepared native A tree."""
from pathlib import Path
import hashlib
import json
import subprocess

win = Path('/mnt/h/workspace/PJA110-Mainline')
root = Path.home() / 'workspace/PJA110-Mainline/charger-native-a'
tree = root / 'linux-6.14'
build = root / 'charger-state-readback'
out = win / 'out/native-install-20261017/charger-state-readback'
build.mkdir(exist_ok=True)
out.mkdir(exist_ok=True)
s = (win / 'out/native-install-20261017/temperature-handoff/qcom_battmgr-temperature.c').read_text()
s = s.replace('#include "pja110-ap-gauge.h"\n', '')
start = s.index('static int pja110_match_temp')
end = s.index('#define BATTMGR_CHEMISTRY_LEN', start)
s = s[:start] + '''/* Fixed GET list: battery enable, USB suspend, ICL, FCC, FCC max, USB max. */
static int query_result[6] = {-115, -115, -115, -115, -115, -115};
static unsigned int query_value[6], firmware_result[6];
module_param_array(query_result, int, NULL, 0444);
module_param_array(query_value, uint, NULL, 0444);
module_param_array(firmware_result, uint, NULL, 0444);
static bool readback_done, readback_attempted;
module_param(readback_done, bool, 0444);
static int diagnostic_opcode, diagnostic_property, diagnostic_index;
#include <linux/soc/qcom/smem.h>
#include <linux/unaligned.h>

''' + s[end:]
needle = '\topcode = le32_to_cpu(hdr->opcode);\n'
pos = s.index(needle, s.index('static void qcom_battmgr_callback')) + len(needle)
s = s[:pos] + '''    if (smp_load_acquire(&diagnostic_opcode)) {
        int index = diagnostic_index;
        if (opcode != READ_ONCE(diagnostic_opcode) ||
            le32_to_cpu(hdr->owner) != PMIC_GLINK_OWNER_BATTMGR ||
            le32_to_cpu(hdr->type) != PMIC_GLINK_REQ_RESP ||
            len != sizeof(*hdr) + sizeof(resp->intval) ||
            le32_to_cpu(resp->intval.property) != diagnostic_property)
            return;
        firmware_result[index] = le32_to_cpu(resp->intval.result);
        battmgr->error = firmware_result[index] ? -EREMOTEIO : 0;
        if (!battmgr->error)
            query_value[index] = le32_to_cpu(resp->intval.value);
        complete(&battmgr->ack);
        return;
    }
''' + s[pos:]
start = s.index('/* One-shot property 29')
end = s.index('static void qcom_battmgr_enable_worker', start)
s = s[:start] + '''/* Called with the existing request mutex held. No property SET calls. */
static int qcom_battmgr_pja110_init(struct qcom_battmgr *b)
{
    static const u32 opcodes[] = {0x30, 0x32, 0x32, 0x30, 0x30, 0x32};
    static const u32 properties[] = {24, 29, 5, 10, 11, 4};
    const void *project;
    size_t size;
    int i, ret = -ENODEV;

    if (readback_attempted)
        return 0;
    readback_attempted = true;
    if (!of_machine_is_compatible("oneplus,xigua") ||
        b->variant != QCOM_BATTMGR_SM8350 || !b->service_up)
        goto failed;
    project = qcom_smem_get(QCOM_SMEM_HOST_ANY, 135, &size);
    if (IS_ERR(project)) {
        ret = PTR_ERR(project);
        goto failed;
    }
    if (size < 8 || get_unaligned_le32((const u8 *)project + 4) != 22851)
        goto failed;
    for (i = 0; i < ARRAY_SIZE(properties); i++) {
        diagnostic_index = i;
        diagnostic_property = properties[i];
        smp_store_release(&diagnostic_opcode, opcodes[i]);
        ret = qcom_battmgr_request_property(b, opcodes[i], properties[i], 0);
        smp_store_release(&diagnostic_opcode, 0);
        query_result[i] = ret;
        dev_info(b->dev,
                 "PJA110 charger GET: index=%d opcode=%#x property=%u result=%d firmware=%u value=%u\\n",
                 i, opcodes[i], properties[i], ret,
                 firmware_result[i], query_value[i]);
        if (READ_ONCE(b->request_failed)) {
            while (++i < ARRAY_SIZE(properties))
                query_result[i] = -ECANCELED;
            break;
        }
    }
    WRITE_ONCE(readback_done, true);
    return 0;
failed:
    for (i = 0; i < ARRAY_SIZE(properties); i++)
        query_result[i] = ret;
    WRITE_ONCE(readback_done, true);
    return ret;
}

''' + s[end:]
assert 'BATTMGR_BAT_PROPERTY_SET,' not in s
assert 'BATTMGR_USB_PROPERTY_SET,' not in s
(build / 'qcom_battmgr.c').write_text(s)
(build / 'Makefile').write_text('obj-m += qcom_battmgr.o\n')
p = subprocess.run(['make', '-C', str(tree), 'ARCH=arm64',
    'CROSS_COMPILE=/opt/aarch64-linux-gnu-toolchain-13.3/bin/aarch64-none-linux-gnu-',
    'M=' + str(build), 'modules'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(out / 'build.log').write_bytes(p.stdout)
print(p.stdout.decode(errors='replace'))
p.check_returncode()
data = (build / 'qcom_battmgr.ko').read_bytes()
(out / 'qcom_battmgr-state.ko').write_bytes(data)
(out / 'qcom_battmgr-state.c').write_text(s)
(out / 'build-result.json').write_text(json.dumps({
    'sha256': hashlib.sha256(data).hexdigest(), 'strict_link_passed': True,
    'property_sets': False, 'runtime_tested': False,
    'queries': [[48,24], [50,29], [50,5], [48,10], [48,11], [50,4]],
}, indent=2) + '\n')

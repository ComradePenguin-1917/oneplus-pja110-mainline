"""Reboot into the verified budget kernel and check automatic debug userspace."""
import subprocess,time,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
shutdown='--shutdown' in sys.argv
out=ROOT/('out/drm-shutdown-20261014/kernel' if shutdown else 'out/display-budget-20261014')
expected='24' if shutdown else '23'
keys=ROOT/'out/usb-ncm-20261013/ssh'
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(keys/'client_key_host'),
 '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
 '-o',f'UserKnownHostsFile={keys/"known_hosts"}','-o','ConnectTimeout=3','root@169.254.42.1']
def run(cmd):return subprocess.run(ssh+[cmd],capture_output=True,timeout=9)
emergency='--emergency' in sys.argv
resume='--resume' in sys.argv or emergency
if resume:
 before_bytes=(out/'reboot-before.txt').read_bytes()
else:
 before=run('cat /proc/sys/kernel/random/boot_id; uname -a')
 before.check_returncode();before_bytes=before.stdout
 (out/'reboot-before.txt').write_bytes(before_bytes)
assert json.loads((out/'after-write.json').read_text())['boot_b']==json.loads((out/'manifest.json').read_text())['boot_b_sha256']
start=time.monotonic()
if not resume or emergency:
 try:
  p=run('echo b > /proc/sysrq-trigger' if emergency else 'sync; reboot -f')
  (out/'reboot-request.txt').write_bytes(p.stdout+p.stderr)
 except subprocess.TimeoutExpired:
  (out/'reboot-request.txt').write_text('SSH disconnected or timed out during requested reboot; polling device state\n')
time.sleep(4)
while time.monotonic()-start<90:
 p=run('cat /proc/sys/kernel/random/boot_id; uname -a; cat /tmp/touch-init.log; dmesg | grep "PJA_ASTON fixed report rate code=3"; cat /sys/kernel/debug/dri/0/debug/core_perf/perf_mode 2>/dev/null; cat /proc/uptime')
 if p.returncode==0 and p.stdout.splitlines()[0]!=before_bytes.splitlines()[0]:
  (out/'reboot-after.txt').write_bytes(p.stdout)
  assert f'#{expected} SMP'.encode() in p.stdout,p.stdout
  assert b'PJA_ASTON fixed report rate code=3 readback verified' in p.stdout
  (out/'reboot-result.json').write_text(json.dumps({'automatic_ssh_returned':True,'elapsed_seconds':round(time.monotonic()-start,2),'kernel':'#'+expected,'boot_id_changed':True},indent=2)+'\n')
  print(p.stdout.decode());print('PASS: budget kernel rebooted with automatic SSH and touch; RAM fixed perf reset')
  break
 time.sleep(2)
else:
 (out/'reboot-error.txt').write_bytes(p.stdout+p.stderr)
 raise SystemExit('SSH did not return after reboot; device state required')

#!/usr/bin/env python3
"""Decide whether the STOCK kernel can run OUR initramfs.

This is a much better validation target than QEMU:
  * the stock kernel is KNOWN to boot on this exact phone
  * it exercises our initramfs, our aarch64 busybox and our /init for real
  * if /init runs, its poweroff signal makes the phone go dark -- unmistakable
  * and it needs NO flash writes (fastboot boot is a memory boot)

For it to work the stock Android GKI kernel must have the pieces our /init needs:
    * initramfs / ramdisk support        (CONFIG_BLK_DEV_INITRD)
    * devtmpfs, proc, sysfs
    * configfs + libcomposite + a gadget function (ecm/rndis/ncm)
    * USB DWC3 + its PHY
    * PSCI poweroff (always present on arm64)

Android GKI kernels usually ship gadget functions as MODULES, and our initramfs
carries no modules, so USB may well fail. That is fine: the value of this test is
the POWEROFF SIGNAL, which needs none of that. It proves the initramfs executed.

So: look for the config symbols in the stock kernel binary. If CONFIG_IKCONFIG is
present we can extract the real config; otherwise probe for strings.
"""
import os
import re
import struct
import sys
import zlib

WS = r'H:\WorkSpace\PJA110-Mainline'

k = open(os.path.join(WS, 'out', 'stock-kernel.bin'), 'rb').read()
print('=== stock kernel ===')
print('  size: %d bytes' % len(k))

print()
print('=== 1) try to extract the embedded kernel config (IKCONFIG) ===')
# IKCONFIG data is usually zlib-compressed and starts with the magic
# "IKCFG_ST" ... "IKCFG_ED" when uncompressed; when compressed it appears as a
# zlib stream right after the magic.
i = k.find(b'IKCFG_ST')
if i >= 0:
    print('  IKCFG_ST at 0x%x' % i)
    start = i + 8
    end = k.find(b'IKCFG_ED', start)
    blob = k[start:end] if end > 0 else k[start:start + 300000]
    for attempt, data in (('raw gzip', None), ('zlib', None)):
        pass
    try:
        cfg = zlib.decompress(blob)
        print('  decompressed zlib: %d bytes' % len(cfg))
    except Exception:
        try:
            cfg = zlib.decompressobj().decompress(blob)
            print('  decompressed (stream): %d bytes' % len(cfg))
        except Exception as e:
            cfg = None
            print('  could not decompress: %s' % e)
    if cfg:
        p = os.path.join(WS, 'out', 'stock-kernel.config')
        open(p, 'wb').write(cfg)
        print('  saved -> out/stock-kernel.config')
else:
    print('  no IKCFG_ST marker -> IKCONFIG not embedded')
    cfg = None

print()
print('=== 2) probe the binary for the symbols our /init needs ===')
# even without IKCONFIG we can look for driver/module names and messages
probes = {
    'initramfs support'      : [b'Unpacking initramfs', b'initramfs'],
    'devtmpfs'               : [b'devtmpfs'],
    'configfs'               : [b'configfs'],
    'libcomposite'           : [b'libcomposite', b'usb_gadget'],
    'ecm function'           : [b'usb_f_ecm', b'ecm'],
    'rndis function'         : [b'usb_f_rndis', b'rndis'],
    'ncm function'           : [b'usb_f_ncm'],
    'dwc3'                   : [b'dwc3'],
    'dwc3-qcom'              : [b'dwc3-qcom', b'dwc_usb3_msm'],
    'sysrq'                  : [b'SysRq', b'sysrq'],
    'psci'                   : [b'psci', b'PSCI'],
}
for label, pats in probes.items():
    hits = [p.decode() for p in pats if p in k]
    print('  %-22s %s' % (label, hits or '-'))

if cfg:
    print()
    print('=== 3) real config values (from the extracted config) ===')
    vals = {}
    for line in cfg.decode('utf-8', 'replace').splitlines():
        line = line.strip()
        if '=' in line and not line.startswith('#'):
            a, b = line.split('=', 1)
            vals[a] = b
        elif line.startswith('# ') and 'is not set' in line:
            vals[line[2:].split(' ')[0]] = 'NOT SET'
    for key in ('CONFIG_BLK_DEV_INITRD', 'CONFIG_RD_GZIP', 'CONFIG_DEVTMPFS',
                'CONFIG_DEVTMPFS_MOUNT', 'CONFIG_CONFIGFS_FS', 'CONFIG_USB_GADGET',
                'CONFIG_USB_CONFIGFS', 'CONFIG_USB_CONFIGFS_ECM',
                'CONFIG_USB_CONFIGFS_RNDIS', 'CONFIG_USB_CONFIGFS_NCM',
                'CONFIG_USB_DWC3', 'CONFIG_USB_DWC3_QCOM', 'CONFIG_MAGIC_SYSRQ',
                'CONFIG_ARM64', 'CONFIG_SERIAL_AMBA_PL011_CONSOLE'):
        print('  %-38s %s' % (key, vals.get(key, '(absent)')))

#!/bin/bash
# Rebuild with the NEW /init (poweroff-when-no-USB signal).
#
# Path note: the /init I edited lives on the Windows side
# (H:\WorkSpace\PJA110-Mainline\initramfs\init) and is visible in WSL at
# /mnt/h/WorkSpace/PJA110-Mainline/initramfs/init. The build tree that gets
# packed lives in the WSL home (tree/init). Earlier I edited the Windows copy but
# ran the build against the WSL copy, so my change was silently not included.
# This script takes the Windows copy as the single source of truth.
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WS="/mnt/h/WorkSpace/PJA110-Mainline"
WORK="$ROOT/initramfs"
TREE="$WORK/tree"
SRC_INIT="$WS/initramfs/init"
MARK='=== NO USB: /init RAN, so signalling that userspace was reached ==='

echo "=== 1) source of truth ==="
echo "  $SRC_INIT : $(stat -c%s "$SRC_INIT") bytes"
echo "  poweroff marker lines: $(grep -c "$MARK" "$SRC_INIT")"

echo
echo "=== 2) syntax check ==="
if sh -n "$SRC_INIT"; then
    echo "  OK"
else
    echo "  SYNTAX ERROR -- aborting"
    exit 1
fi

echo
echo "=== 3) install into the build tree ==="
cp "$SRC_INIT" "$TREE/init"
chmod 755 "$TREE/init"
echo "  tree/init now: $(stat -c%s "$TREE/init") bytes"
echo "  marker present: $(grep -c "$MARK" "$TREE/init")"

echo
echo "=== 4) repack ==="
cd "$TREE"
find . -print0 | cpio --null -o --format=newc 2>/dev/null | gzip -9 > "$WORK/initramfs.cpio.gz"
echo "  archive: $(stat -c%s "$WORK/initramfs.cpio.gz") bytes"
cpio -t < <(zcat "$WORK/initramfs.cpio.gz") 2>/dev/null > /tmp/l.txt
echo "  entries: $(wc -l < /tmp/l.txt)"
for f in init bin/busybox bin/sh bin/poweroff bin/reboot; do
    printf '    %-16s %s\n' "$f" "$(grep -cx "$f" /tmp/l.txt)"
done

echo
echo "=== 5) prove the new /init is inside the archive ==="
zcat "$WORK/initramfs.cpio.gz" > /tmp/n.cpio
rm -rf /tmp/ck && mkdir -p /tmp/ck
(cd /tmp/ck && cpio -idm < /tmp/n.cpio 2>/dev/null)
echo "  extracted /init: $(stat -c%s /tmp/ck/init) bytes"
echo "  marker lines   : $(grep -c "$MARK" /tmp/ck/init)"
if [ "$(grep -c "$MARK" /tmp/ck/init)" -eq 0 ]; then
    echo "  ERROR: new logic did not make it into the archive"
    exit 1
fi

echo
echo "=== 6) rebuild the kernel ==="
export PATH="$ROOT/toolchain/gcc-12-aarch64/usr/bin:$PATH"
export LD_LIBRARY_PATH="$ROOT/toolchain/gcc-12-aarch64/usr/lib/x86_64-linux-gnu:${LD_LIBRARY_PATH:-}"
cd "$ROOT/linux"
cp "$WORK/initramfs.cpio.gz" "$ROOT/linux/initramfs-xigua.cpio.gz"
make -j"$(nproc)" ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu- Image 2>&1 | tail -4

echo
echo "=== 7) confirm it is embedded in the new Image ==="
python3 - <<'PY'
import gzip, io
img = open('/home/comrade_penguin_desktop/workspace/PJA110-Mainline/linux/arch/arm64/boot/Image','rb').read()
raw = open('/home/comrade_penguin_desktop/workspace/PJA110-Mainline/initramfs/initramfs.cpio.gz','rb').read()
print('  Image       : %d bytes' % len(img))
print('  our archive : %d bytes' % len(raw))
i = img.find(raw[:32])
print('  found       : %s' % ('YES at 0x%x' % i if i >= 0 else 'NO'))
if i >= 0:
    d = gzip.GzipFile(fileobj=io.BytesIO(img[i:i+len(raw)])).read()
    print('  decompressed: %d bytes' % len(d))
    print('  poweroff marker inside: %s'
          % (b'powering off as the kernel-reached-userspace signal' in d))
PY

cp "$ROOT/linux/arch/arm64/boot/Image" "$ROOT/out/Image-poweroff"
echo
echo "saved -> out/Image-poweroff"

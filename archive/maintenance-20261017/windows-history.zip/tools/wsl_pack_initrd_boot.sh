#!/bin/bash
# Repack boot.img now that the kernel carries an embedded initramfs.
#
# Key differences from the previous attempt:
#   * the kernel now runs our /init (no more "VFS: unable to mount root fs")
#   * /init brings up a USB network gadget -> adb/telnet becomes possible
#   * we still append the DTB (harmless; ABL supplies its own, but if the
#     bootloader honours a concatenated DTB we win too)
#
# Also: this time put the initramfs in the boot image's *ramdisk* field as well,
# so it works whether the kernel finds its embedded copy or the bootloader
# supplies a separate initrd.
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
OUT="$ROOT/out"
WIN="/mnt/h/WorkSpace/PJA110-Mainline"
INITRD="$ROOT/initramfs/initramfs.cpio.gz"
DTB="$OUT/sm8550-oneplus-xigua-16G.dtb"

mkdir -p "$OUT"
cp "$ROOT/linux/arch/arm64/boot/Image" "$OUT/Image-initrd"
cp "$ROOT/linux/Image.gz" "$OUT/" 2>/dev/null || true
cp "$ROOT/linux/arch/arm64/boot/Image.gz" "$OUT/Image-initrd.gz" 2>/dev/null || true

echo "=== inputs ==="
ls -l "$OUT/Image-initrd" "$INITRD" "$DTB"

echo
echo "=== concat Image + DTB (as before) ==="
cat "$OUT/Image-initrd" "$DTB" > "$OUT/Image_w_dtb_initrd"
ls -l "$OUT/Image_w_dtb_initrd"

echo
echo "=== pack with python mkbootimg ==="
cd "$WIN"

CMDLINE="console=ttyMSM0,115200 loglevel=8 earlycon ignore_loglevel"

# Variant 1: kernel field only (our embedded initramfs does the work)
python3 tools/bootimg.py pack \
    --kernel "$OUT/Image_w_dtb_initrd" \
    --stock boot-A14.img \
    --cmdline "$CMDLINE" \
    -o "$OUT/boot-xigua-initrd.img"

# Variant 2: also supply the initramfs in the ramdisk field (belt and braces)
python3 tools/bootimg.py pack \
    --kernel "$OUT/Image_w_dtb_initrd" \
    --ramdisk "$INITRD" \
    --stock boot-A14.img \
    --cmdline "$CMDLINE" \
    -o "$OUT/boot-xigua-initrd-rd.img"

echo
echo "=== results ==="
ls -l "$OUT"/boot-xigua-initrd*.img
sha256sum "$OUT"/boot-xigua-initrd*.img

echo
echo "=== read-back verification of BOTH ==="
for img in "$OUT/boot-xigua-initrd.img" "$OUT/boot-xigua-initrd-rd.img"; do
    echo "--- $(basename "$img")"
    python3 - "$img" <<'PY'
import gzip, io, struct, sys, re
p = sys.argv[1]
b = open(p,'rb').read()
assert b[:8] == b'ANDROID!', 'bad magic'
ksize, rsize = struct.unpack_from('<2I', b, 8)
hver = struct.unpack_from('<I', b, 40)[0]
cmd = b[44:44+1536].rstrip(b'\0').decode('utf-8','replace')
print('    hdr v%d  kernel=%d  ramdisk=%d' % (hver, ksize, rsize))
print('    cmdline=%r' % cmd)
k = b[4096:4096+ksize]
print('    kernel magic=%r' % k[:2])
# DTB appended?
off = k.find(b'\xd0\x0d\xfe\xed', max(0,len(k)-400000))
print('    appended DTB at %s' % ('0x%x size=%d' % (off, struct.unpack_from('>I', k, off+4)[0]) if off>=0 else 'NONE'))
# embedded initramfs marker: look for the gzip stream that decompresses to cpio with busybox
found = False
for m in re.finditer(rb'\x1f\x8b\x08', k):
    try:
        d = gzip.GzipFile(fileobj=io.BytesIO(k[m.start():])).read(4_000_000)
    except Exception:
        continue
    if b'busybox' in d and b'[initramfs]' in d:
        print('    embedded initramfs: YES (at 0x%x, %d bytes decompressed)' % (m.start(), len(d)))
        found = True
        break
if not found:
    print('    embedded initramfs: not detected in kernel field')
if rsize:
    rd = b[4096+((ksize+4095)//4096*4096):][:rsize]
    print('    ramdisk magic=%r  (gzip=%s)' % (rd[:2], rd[:2]==b'\x1f\x8b'))
PY
done

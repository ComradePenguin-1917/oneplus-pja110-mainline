#!/usr/bin/env python3
"""Build the observation-channel test image and run it.

The signal
----------
Our /init now powers the SoC OFF (PSCI SYSTEM_OFF) when it cannot bring up USB.
So AFTER flashing this to slot B:

    phone goes dark and STAYS dark   -> /init RAN   => kernel reached userspace
    Android comes back as usual      -> kernel died => failure is in early boot

This is the first test that can distinguish those two, and it needs no serial
port, no USB enumeration and no storage.

Images:
    boot_b        <- OUR kernel with the new initramfs  (NO appended DTB, so the
                     only tree available is vendor_boot entry0)
    vendor_boot_b <- OUR device tree as entry0          (the verified channel)
    dtbo_b        <- erased
"""
import hashlib
import os
import struct
import subprocess
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
WSL_WS = '/mnt/h/WorkSpace/PJA110-Mainline'


def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''):
            h.update(c)
    return h.hexdigest()


kern = os.path.join(WS, 'out', 'Image-poweroff')
print('=== kernel ===')
print('  %s : %d bytes' % (os.path.basename(kern), os.path.getsize(kern)))
print('  sha256: %s' % sha(kern)[:32])

out_boot = os.path.join(WS, 'out', 'boot_b-poweroff.img')
cmd = ('cd %s && python3 tools/bootimg.py pack --kernel out/Image-poweroff '
       '--stock boot-A14.img --cmdline "console=ttyMSM0,115200 loglevel=8 earlycon ignore_loglevel" '
       '-o out/boot_b-poweroff.img' % WSL_WS)
r = subprocess.run(['wsl.exe', '-d', 'Ubuntu-22.04', '--', 'bash', '-lc', cmd],
                   capture_output=True)
for line in (r.stdout or b'').decode('utf-8', 'replace').splitlines():
    if line.strip() and 'localh' not in line and 'N/e' not in line:
        print('  %s' % line.strip()[:100])

# verify: embedded initramfs present, no appended DTB
if os.path.exists(out_boot):
    b = open(out_boot, 'rb').read()
    ksize = struct.unpack_from('<I', b, 8)[0]
    k = b[4096:4096 + ksize]
    import gzip
    import io
    raw = open(os.path.join(WS, 'initramfs', 'initramfs.cpio.gz'), 'rb').read()
    i = k.find(raw[:32])
    print()
    print('  size          : %d' % len(b))
    print('  kernel field  : %d' % ksize)
    dtb_at = k.find(b'\xd0\x0d\xfe\xed', len(k) - 400000)
    print('  appended DTB  : %s' % ('yes at 0x%x' % dtb_at if dtb_at >= 0 else 'no (intended)'))
    print('  embedded initrd: %s' % ('yes @0x%x' % i if i >= 0 else 'NO'))
    if i >= 0:
        d = gzip.GzipFile(fileobj=io.BytesIO(k[i:i + len(raw)])).read()
        print('  poweroff logic in it: %s'
              % (b'powering off as the kernel-reached-userspace signal' in d))

# vendor_boot_b with our tree (already built)
vb = os.path.join(WS, 'out', 'vendor_boot_b-ourdtb.img')
print()
print('=== vendor_boot_b (our tree as entry0) ===')
print('  %s : %d bytes' % (os.path.basename(vb), os.path.getsize(vb)))
print('  sha256: %s' % sha(vb)[:32])

print()
print('=' * 78)
print('RUN PLAN')
print('=' * 78)
for line in (
    'fastboot flash vendor_boot_b out/vendor_boot_b-ourdtb.img',
    'fastboot flash boot_b        out/boot_b-poweroff.img',
    'fastboot erase dtbo_b',
    'fastboot set_active b',
    'fastboot reboot',
):
    print('  %s' % line)
print()
print('  then WATCH:')
print('    * phone stays dark  -> /init ran, kernel reached userspace (we finally win)')
print('    * Android returns   -> kernel died early')
print()
print('  IMPORTANT: if the phone goes dark, it will NOT come back on its own.')
print('  Power it on with the power button (or the key combo if needed).')
print()
print('ROLLBACK')
for line in (
    'fastboot flash boot_b        backup/boot_b.img',
    'fastboot flash vendor_boot_b backup/vendor_boot_b.img',
    'fastboot flash dtbo_b        backup/dtbo_b.img',
    'fastboot set_active a',
):
    print('  %s' % line)

# save hashes for verification later
with open(os.path.join(WS, 'out', 'poweroff-test-hashes.txt'), 'w') as f:
    f.write('boot_b-poweroff.img  %s\n' % sha(out_boot))
    f.write('vendor_boot_b-ourdtb.img %s\n' % sha(vb))
print()
print('hashes saved -> out/poweroff-test-hashes.txt')

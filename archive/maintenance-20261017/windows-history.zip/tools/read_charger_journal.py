from pathlib import Path
import subprocess
from prepare_native_install import SSH
cmd='''set -eu
mkdir -p /tmp/a-log-readonly
losetup -r -o 511705088 /dev/loop0 /dev/sda14
trap 'umount /tmp/a-log-readonly 2>/dev/null || true; losetup -d /dev/loop0' EXIT
mount -t ext4 -o ro,noload /dev/loop0 /tmp/a-log-readonly
chroot /tmp/a-log-readonly /usr/bin/journalctl --no-pager _TRANSPORT=kernel
'''
p=subprocess.run(SSH+[cmd],capture_output=True,timeout=45)
Path('out/native-install-20261017/charger-a-kernel.txt').write_bytes(p.stdout)
print(p.stderr.decode(errors='replace'));print('exit',p.returncode,'bytes',len(p.stdout))

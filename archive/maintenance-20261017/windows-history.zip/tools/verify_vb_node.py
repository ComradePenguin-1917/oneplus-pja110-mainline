#!/usr/bin/env python3
"""Compact, targeted verification of the inert-node vendor_boot image.

The previous byte-diff was enormous and unhelpful: inserting 24 bytes shifts the
entire strings block, so thousands of offsets legitimately differ. What actually
matters:

  1. file size unchanged
  2. header fields consistent (dtb_size grew by exactly the inserted amount)
  3. off_dt_strings / size_dt_struct updated by the same amount
  4. all 4 DTBs still walk correctly from dtb_off to dtb_off+dtb_size
  5. entry0 now exposes /xigua-vbtest; entries 1..3 have identical msm-ids to
     before
  6. the region from the page-aligned ramdisk_table onward is byte-identical
  7. the vendor_ramdisk is byte-identical
  8. every base-tree label is still present (so ABL's overlay fixups resolve)
"""
import hashlib
import os
import struct
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
sys.path.insert(0, os.path.join(WS, 'tools'))
from fdt import FDT

PAGE = 4096
NODE = 'xigua-vbtest'
src = open(os.path.join(WS, 'backup', 'vendor_boot_b.img'), 'rb').read()
new = open(os.path.join(WS, 'out', 'vendor_boot_b-node.img'), 'rb').read()

ok = True


def check(label, cond, extra=''):
    global ok
    ok = ok and bool(cond)
    print('  [%s] %-52s %s' % ('OK ' if cond else 'FAIL', label, extra))


print('=' * 78)
print('VERIFY out/vendor_boot_b-node.img')
print('=' * 78)

check('file size unchanged', len(src) == len(new), '%d' % len(new))

h = 28 + 2048 + 4 + 16
hsize_o, dtbsize_o = struct.unpack_from('<2I', src, h)
hsize_n, dtbsize_n = struct.unpack_from('<2I', new, h)
check('header_size unchanged', hsize_o == hsize_n, '%d' % hsize_n)
check('dtb_size grew by 24', dtbsize_n - dtbsize_o == 24, '%d -> %d' % (dtbsize_o, dtbsize_n))

vrsize = struct.unpack_from('<I', new, 24)[0]
dtb_off = (((hsize_n + PAGE - 1)//PAGE)*PAGE + vrsize + PAGE - 1)//PAGE*PAGE
tbl_off = ((dtb_off + dtbsize_o + PAGE - 1)//PAGE)*PAGE
check('dtb_off unchanged', dtb_off == 0xff9000, '0x%x' % dtb_off)
check('table offset unchanged', tbl_off == ((dtb_off + dtbsize_n + PAGE-1)//PAGE)*PAGE,
      '0x%x' % tbl_off)

# walk the 4 entries
print()
print('  dtb section walk (as ABL would do):')
off = dtb_off
msm = []
for i in range(4):
    total = struct.unpack_from('>I', new, off+4)[0]
    f = FDT(new[off:off+total])
    n = f.nodes()
    mid = n['/'].get('qcom,msm-id')
    s = ' '.join('0x%x' % x for x in struct.unpack('>%dI' % (len(mid)//4), mid))[:22] if mid else '-'
    msm.append(s)
    paths = set(p for _d, p, _n, pr in f.walk() if pr is None)
    has = ('/' + NODE) in paths
    print('    entry%d @0x%06x size=%-7d nodes=%-5d msm-id=%-22s %s'
          % (i, off, total, len(n), s, ('HAS ' + NODE) if (has and i == 0) else ''))
    if i == 0:
        check('entry0 contains /%s' % NODE, has)
        # base tree labels must all still exist, or ABL's fixups break
        syms_new = set(n.get('/__symbols__', {}))
        f_old = FDT(src[dtb_off:dtb_off+struct.unpack_from('>I', src, dtb_off+4)[0]])
        syms_old = set(f_old.nodes().get('/__symbols__', {}))
        check('all base __symbols__ labels kept', syms_old <= syms_new,
              '%d -> %d' % (len(syms_old), len(syms_new)))
    off += total
check('walk lands exactly on dtb_off+dtb_size', off == dtb_off + dtbsize_n,
      'end 0x%x vs 0x%x' % (off, dtb_off + dtbsize_n))
check('msm-ids unchanged', msm == ['0x207 0x20000', '0x207 0x10000',
                                   '0x218 0x20000', '0x218 0x10000'], ' '.join(msm))

# untouched regions
print()
rd_start = ((hsize_n + PAGE - 1)//PAGE)*PAGE
check('vendor_ramdisk byte-identical', new[rd_start:rd_start+vrsize] == src[rd_start:rd_start+vrsize])
check('from table onward byte-identical', new[tbl_off:] == src[tbl_off:])
check('header up to 0x834 byte-identical except dtb_size',
      new[:h+4] == src[:h+4], 'header prefix intact')

print()
print('  sha256 original: %s' % hashlib.sha256(src).hexdigest())
print('  sha256 patched : %s' % hashlib.sha256(new).hexdigest())
print()
print('RESULT: %s' % ('ALL CHECKS PASSED' if ok else 'SOME CHECKS FAILED'))
sys.exit(0 if ok else 1)

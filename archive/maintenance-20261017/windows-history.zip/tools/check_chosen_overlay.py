#!/usr/bin/env python3
"""Re-examine my marker experiment for a confound.

I appended the vendor live DTB + a marker at /chosen/xigua-marker, and after
booting the marker was ABSENT. I concluded "ABL ignores the appended DTB".

BUT that conclusion is only valid if nothing overwrote /chosen. If the vendor
dtbo contains a fragment that targets /chosen (very common: it sets bootargs),
then ABL -- applying the flash dtbo on top of whatever base it chose -- would
replace /chosen wholesale and my marker would vanish even though the appended
DTB WAS used as the base.

So: does the vendor dtbo touch /chosen?
"""
import os
import re
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fdt import FDT, load_entries

WS = r'H:\WorkSpace\PJA110-Mainline'

def dec(v):
    return v.rstrip(b'\0').decode('ascii', 'replace')

print('=' * 74)
print('1) Do the dtbo overlays touch /chosen or set bootargs?')
print('=' * 74)
entries, _ = load_entries(os.path.join(WS, 'dtbo-A14.img'))
for label, sub in entries:
    f = FDT(sub)
    nodes = f.nodes()
    hits = []
    for p, props in nodes.items():
        if 'chosen' in p.lower():
            hits.append((p, sorted(props)))
        elif 'bootargs' in props:
            hits.append((p + ' [bootargs]', sorted(props)))
    print('--- %s: %d node(s) mentioning chosen/bootargs' % (label, len(hits)))
    for p, ks in hits[:12]:
        print('      %s   props=%s' % (p[:70], ks[:6]))

print()
print('=' * 74)
print('2) What do the overlays actually target? (node names at depth 1)')
print('=' * 74)
label, sub = entries[1]
f = FDT(sub)
names = {}
for p in f.nodes():
    if p.startswith('/fragment@'):
        parts = p.split('/')
        if len(parts) >= 4 and parts[2] == '__overlay__':
            names.setdefault(parts[3].split('@')[0], 0)
            names[parts[3].split('@')[0]] += 1
interesting = [n for n in names if re.search(r'chosen|bootargs|memory|reserved|mem', n, re.I)]
print('  of %d distinct overlay nodes, these relate to memory/chosen:' % len(names))
for n in sorted(interesting):
    print('      %s' % n)

print()
print('=' * 74)
print('3) Does the vendor dtbo define its own /memory or reserved-memory?')
print('=' * 74)
for label, sub in entries:
    f = FDT(sub)
    found = False
    for p, props in f.nodes().items():
        if re.search(r'__overlay__/(memory|reserved-memory)', p):
            print('   %s: %s' % (label, p[:80]))
            found = True
    if not found:
        print('   %s: none' % label)

print()
print('=' * 74)
print('4) the bootloader_log node in the dtbo (its target may reveal the scheme)')
print('=' * 74)
for label, sub in entries[:2]:
    f = FDT(sub)
    for p, props in f.nodes().items():
        if re.search(r'bootloader_log|botloader_mem|device_info_mem|^/fragment@\d+$', p):
            if p.count('/') == 2:
                tgt = props.get('target')
                tp = props.get('target-path')
                tv = '0x%x' % struct.unpack('>I', tgt[:4])[0] if tgt and len(tgt) >= 4 else '-'
                print('   %-10s %-14s target=%s target-path=%s'
                      % (label, p.split('/')[-1], tv,
                         dec(tp) if tp else '-'))

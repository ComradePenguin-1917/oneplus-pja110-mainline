#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
OUT="$WIN/out/dpu-sdma-control-20261014"
if [ "${1:-}" = "--firstline" ]; then OUT="$WIN/out/dsc-firstline-control-20261014"; fi
if [ "${1:-}" = "--te-height" ]; then OUT="$WIN/out/te-height-control-20261014"; fi
if [ "${1:-}" = "--packet2" ]; then OUT="$WIN/out/dsc-packet-control-20261014"; fi
if [ "${1:-}" = "--trace" ]; then OUT="$WIN/out/display-timing-20261014"; fi
if [ "${1:-}" = "--budget" ]; then OUT="$WIN/out/display-budget-20261014"; fi
if [ "${1:-}" = "--shutdown" ]; then OUT="$WIN/out/drm-shutdown-20261014/kernel"; fi
QEMU="$ROOT/toolchain/qemu/sysroot/usr/bin/qemu-system-aarch64"
export LD_LIBRARY_PATH="$ROOT/toolchain/qemu/sysroot/usr/lib/x86_64-linux-gnu:${LD_LIBRARY_PATH:-}"
export QEMU_DATADIR="$ROOT/toolchain/qemu/sysroot/usr/share/qemu"
INITRD="$WIN/out/gpu-port-20261014/initramfs-gpu.cpio.gz"
if [ "${1:-}" = "--trace" ]; then INITRD="$OUT/initramfs-trace.cpio.gz"; fi
if [ "${1:-}" = "--budget" ]; then INITRD="$WIN/out/display-timing-20261014/initramfs-trace.cpio.gz"; fi
if [ "${1:-}" = "--shutdown" ]; then INITRD="$WIN/out/display-timing-20261014/initramfs-trace.cpio.gz"; fi
timeout 45 "$QEMU" -M virt -cpu cortex-a57 -smp 2 -m 2048 -kernel "$OUT/Image" -initrd "$INITRD" -append 'console=ttyAMA0 earlycon=pl011,0x9000000 loglevel=7 rdinit=/init pja.qemu_validation=1' -nographic -no-reboot > "$OUT/qemu-console.txt" 2>&1
grep -q 'QEMU touch modules validated' "$OUT/qemu-console.txt"
grep -q 'QEMU debug userspace validated' "$OUT/qemu-console.txt"
echo 'PASS: new Image boots retained GPU/touch/SSH initramfs; display hardware not emulated'

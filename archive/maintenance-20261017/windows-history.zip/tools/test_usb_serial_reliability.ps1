param(
    [ValidateSet('Existing','Async','Continuous','Thread')][string]$ReadMode='Existing',
    [string]$PortName='COM12',
    [string]$OutputDirectory='out/usb-serial-reliability-20261013',
    [int]$Rounds=2,
    [string]$CommandOnly='',
    [int[]]$Sizes=@(128,511,512,513,1023,4096,16384,65536),
    [switch]$RandomPayload,
    [switch]$SoftwareFlowControl
)
$ErrorActionPreference='Stop'
$target=[IO.Path]::GetFullPath([IO.Path]::Combine($PWD.Path,$OutputDirectory))
$workspace=[IO.Path]::GetFullPath($PWD.Path)+[IO.Path]::DirectorySeparatorChar
if(-not $target.StartsWith($workspace,[StringComparison]::OrdinalIgnoreCase)){throw 'Output must stay in workspace'}
[IO.Directory]::CreateDirectory($target) | Out-Null
$port=[IO.Ports.SerialPort]::new($PortName,115200)
$port.DtrEnable=$true
$port.RtsEnable=$true
$port.ReadBufferSize=262144
$port.WriteTimeout=3000
if($SoftwareFlowControl){$port.Handshake=[IO.Ports.Handshake]::XOnXOff}
$script:pending=$null
$script:buffer=[byte[]]::new(65536)
$transcript=[Text.StringBuilder]::new()
$continuous=$null
. (Join-Path $PSScriptRoot 'UsbSerialReader.ps1')
if($ReadMode -in @('Continuous','Thread')){Initialize-UsbSerialReaderType}
$finished=$false
$results=[Collections.Generic.List[object]]::new()
function Read-Available {
    if($ReadMode -in @('Continuous','Thread')){return [Text.Encoding]::ASCII.GetString($continuous.Drain())}
    if($ReadMode -eq 'Existing'){return $port.ReadExisting()}
    if($null -eq $script:pending){$script:pending=$port.BaseStream.ReadAsync($script:buffer,0,$script:buffer.Length)}
    if(-not $script:pending.IsCompleted){return ''}
    $n=$script:pending.GetAwaiter().GetResult()
    $value=[Text.Encoding]::ASCII.GetString($script:buffer,0,$n)
    $script:pending=$port.BaseStream.ReadAsync($script:buffer,0,$script:buffer.Length)
    return $value
}
function Run-Command([string]$Command,[string]$Marker,[double]$Timeout=8,[switch]$Control) {
    $reply=[Text.StringBuilder]::new()
    $timer=[Diagnostics.Stopwatch]::StartNew()
    $port.Write($Command+"`n")
    $nextFlush=3
    $tail=''
    $complete=$false
    do {
        $data=Read-Available
        [void]$reply.Append($data)
        if($data.Length -gt 0){
            $scan=$tail+$data.Replace("`r",'')
            if($scan -match ("(?m)^"+[regex]::Escape($Marker)+"$")){$complete=$true;break}
            $tail=$scan.Substring([Math]::Max(0,$scan.Length-$Marker.Length-4))
        }
        if($Control -and $timer.Elapsed.TotalSeconds -ge $nextFlush){$port.Write("echo $Marker`n"); $nextFlush+=3}
        Start-Sleep -Milliseconds 5
    }while($timer.Elapsed.TotalSeconds -lt $Timeout)
    $text=$reply.ToString().Replace("`r",'')
    [void]$transcript.Append($text)
    return [pscustomobject]@{Text=$text;Elapsed=$timer.Elapsed.TotalSeconds;Complete=$complete}
}
try {
    $port.Open()
    if($ReadMode -in @('Continuous','Thread')){
        $continuous=[UsbSerialContinuousReader]::new($port,($ReadMode -eq 'Thread'))
    }
    if($SoftwareFlowControl){
        $flow=Run-Command 'stty ixon -ixoff; echo USB_FLOW_READY' 'USB_FLOW_READY' 30 -Control
        if(-not $flow.Complete){throw 'Cannot enable phone software flow control'}
    }
    if($CommandOnly){
        $reply=Run-Command ($CommandOnly+'; echo USB_CONTROL_DONE') 'USB_CONTROL_DONE' 30 -Control
        [IO.File]::WriteAllText((Join-Path $target "control-$ReadMode.txt"),$reply.Text)
        Write-Output $reply.Text
        if(-not $reply.Complete){throw 'Incomplete control command response'}
        if($reply.Text -match 'sh: syntax error'){throw 'Control command had a shell syntax error'}
        $finished=$true
        return
    }
    # Keep a single asynchronous USB read outstanding across command boundaries.
    $identity=Run-Command 'uname -a; cat /proc/uptime; stty -a; echo USB_ID_DONE' 'USB_ID_DONE' -Control
    $before=Run-Command 'dmesg | grep -c gs_write_complete; echo USB_BEFORE_DONE' 'USB_BEFORE_DONE' -Control
    $initialErrors=[regex]::Match($before.Text,'(?m)^\d+$').Value
    for($round=1;$round -le $Rounds;$round++){
        foreach($size in $Sizes){
            if($size -lt 1 -or $size -gt 4194304){throw 'Payload size must be 1 through 4 MiB'}
            $tag="USB_${round}_${size}"
            $expectedHash=''
            if($RandomPayload){
                $prep=Run-Command "head -c $size /dev/urandom > /tmp/usb-random.bin; sha256sum /tmp/usb-random.bin; echo ${tag}_HASH" "${tag}_HASH" 30 -Control
                $hm=[regex]::Match($prep.Text,'(?m)^([0-9a-f]{64})\s+/tmp/usb-random.bin')
                if(-not $hm.Success){throw 'Cannot read expected random payload SHA256'}
                $expectedHash=$hm.Groups[1].Value
                $command="printf '\n${tag}_BEGIN\n'; base64 /tmp/usb-random.bin; printf '\n${tag}_END\n'"
            }else{
                $command="printf '\n${tag}_BEGIN\n'; head -c $size /dev/zero | tr '\000' X; printf '\n${tag}_END\n'"
            }
            $reply=Run-Command $command "${tag}_END" 30
            $match=[regex]::Match($reply.Text,"(?s)(?:^|\n)${tag}_BEGIN\n(.*?)\n${tag}_END(?:\n|$)")
            $payload=if($match.Success){$match.Groups[1].Value}else{''}
            $captured=$payload.Length
            $actualHash=''
            if($RandomPayload -and $match.Success){
                try {
                    $decoded=[Convert]::FromBase64String($payload)
                    $captured=$decoded.Length
                    $hasher=[Security.Cryptography.SHA256]::Create()
                    try {$actualHash=[BitConverter]::ToString($hasher.ComputeHash($decoded)).Replace('-','').ToLowerInvariant()}finally{$hasher.Dispose()}
                }catch{$captured=0}
            }
            $passed=$reply.Complete -and $match.Success -and $captured -eq $size -and $(if($RandomPayload){$actualHash -eq $expectedHash}else{$payload -ceq ('X'*$size)})
            $results.Add([pscustomobject]@{Round=$round;Size=$size;Passed=$passed;EndMarkerSeen=$reply.Complete;CapturedPayloadBytes=$captured;ElapsedSeconds=$reply.Elapsed;ExpectedSHA256=$expectedHash;ActualSHA256=$actualHash})
            Write-Output "$ReadMode round=$round bytes=$size passed=$passed end=$($reply.Complete)"
            if(-not $passed){[void](Run-Command "echo ${tag}_RECOVER" "${tag}_RECOVER" -Control)}
        }
    }
    $after=Run-Command 'dmesg | grep -c gs_write_complete; cat /proc/uptime; echo USB_AFTER_DONE' 'USB_AFTER_DONE' -Control
    $finalErrors=[regex]::Match($after.Text,'(?m)^\d+$').Value
    $result=[ordered]@{ObservedAt=(Get-Date).ToString('o');ReadMode=$ReadMode;SingleOpenDuringTransfers=$true;RandomPayload=$RandomPayload.IsPresent;Rounds=$Rounds;Before=$before.Text;After=$after.Text;Identity=$identity.Text;ErrorsBefore=$initialErrors;ErrorsAfter=$finalErrors;Transfers=$results;AllPassed=(@($results | Where-Object {-not $_.Passed}).Count -eq 0)}
    $result['SoftwareFlowControl']=$SoftwareFlowControl.IsPresent
    if($continuous){$result['WindowsSerialErrors']=$continuous.Errors}
    $result | ConvertTo-Json -Depth 8 | Set-Content -Encoding utf8 (Join-Path $target "result-$ReadMode.json")
    Write-Output ($result | ConvertTo-Json -Depth 8)
    $finished=$true
}finally {
    [IO.File]::WriteAllText((Join-Path $target "transcript-$ReadMode.txt"),$transcript.ToString())
    if(-not $finished){
        $partial=[ordered]@{ReadMode=$ReadMode;Complete=$false;RandomPayload=$RandomPayload.IsPresent;Transfers=$results;Identity=$identity.Text;Before=$before.Text}
        if($continuous){$partial['WindowsSerialErrors']=$continuous.Errors}
        $partial | ConvertTo-Json -Depth 8 | Set-Content -Encoding utf8 (Join-Path $target "result-incomplete-$ReadMode.json")
    }
    if($continuous){$continuous.Stop()}else{$port.Dispose()}
}

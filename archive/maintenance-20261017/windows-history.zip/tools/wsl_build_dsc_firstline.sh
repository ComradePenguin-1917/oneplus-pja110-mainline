#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
TREE="$ROOT/linux"
OUT="$WIN/out/dsc-firstline-control-20261014"
mkdir -p "$OUT"
export PATH="$ROOT/toolchain/gcc-12-aarch64/usr/bin:$PATH"
export LD_LIBRARY_PATH="$ROOT/toolchain/gcc-12-aarch64/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu-
python3 - "$TREE" "$WIN" "$OUT" <<'PY'
from pathlib import Path
import sys,json,difflib
tree,win,out=map(Path,sys.argv[1:])
for item in json.loads((win/'out/aston-display-comparison-20261014/manifest.json').read_text())['files']:
 p=item['path']
 expected=win/'out/aston-display-comparison-20261014/local'/p
 if p.endswith('catalog/dpu_9_0_sm8550.h'):expected=win/'out/dpu-sdma-control-20261014/catalog.sdma.h'
 assert (tree/p).read_bytes()==expected.read_bytes(),p
assert (tree/'drivers/gpu/drm/panel/panel-oneplus-aa536.c').read_bytes()==(win/'drivers/gpu/drm/panel/panel-oneplus-aa536-generated.c').read_bytes()
p=tree/'drivers/gpu/drm/msm/dsi/dsi_host.c'
before=p.read_text()
needle='\tdsc->initial_scale_value = drm_dsc_initial_scale_value(dsc);'
assert before.count(needle)==1
addition='''\t/* PJA110 DSC 1.1 SCR1: stock sde_dsc_helper uses 15, not 1.2 table's 12. */
\tif (dsc->dsc_version_major == 1 && dsc->dsc_version_minor == 1 &&
\t    of_property_read_bool(msm_host->pdev->dev.of_node, "oneplus,dsc-scr1"))
\t\tdsc->first_line_bpg_offset = 15;

'''
after=before.replace(needle,addition+needle)
(out/'dsi_host.before.c').write_text(before);(out/'dsi_host.firstline15.c').write_text(after)
(out/'firstline-only.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(p),tofile=str(p))))
p.write_text(after)
PY
cmp "$TREE/.config" "$WIN/out/dpu-sdma-control-20261014/.config"
cd "$TREE"
make -j12 Image > "$OUT/build.log" 2>&1
cp arch/arm64/boot/Image System.map .config "$OUT/"
cmp .config "$WIN/out/dpu-sdma-control-20261014/.config"
echo 'PASS: first_line_bpg_offset=15 only in DSC 1.1 PJA110 SCR1; derived values use upstream helper'

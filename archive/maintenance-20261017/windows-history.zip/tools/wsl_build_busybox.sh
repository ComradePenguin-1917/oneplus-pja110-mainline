#!/bin/bash
# Get a REAL aarch64 static busybox.
#
# Findings so far:
#   * host busybox        -> x86-64, useless on the phone
#   * busybox.net armv8l  -> actually ELF 32-bit ARM (EABI5), still useless
#   * apt busybox-static:arm64 -> not available for this arch in the sources
#
# So: build it ourselves with the cross toolchain we already have. busybox is
# small and builds in ~1 minute; this also guarantees the right ABI and a
# static binary with no library dependencies in the initramfs.
set -uo pipefail

ROOT="$HOME/workspace/PJA110-Mainline"
DL="$ROOT/initramfs/dl"
TC="$ROOT/toolchain/gcc-12-aarch64"

export PATH="$TC/usr/bin:$PATH"
export LD_LIBRARY_PATH="$TC/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export CROSS_COMPILE=aarch64-linux-gnu-

echo "=== toolchain ==="
${CROSS_COMPILE}gcc --version | head -1

mkdir -p "$DL"
cd "$DL"

# --- source ---------------------------------------------------------------
VER=1.36.1
TAR="busybox-$VER.tar.bz2"
if [ ! -f "$TAR" ]; then
    echo "=== fetching busybox $VER source ==="
    ok=0
    for u in \
      "https://busybox.net/downloads/$TAR" \
      "https://mirrors.tuna.tsinghua.edu.cn/busybox/$TAR" \
      ; do
        echo "  $u"
        if curl -fsSL --max-time 180 -o "$TAR" "$u"; then ok=1; break; fi
    done
    [ "$ok" = 1 ] || { echo "  download failed"; exit 1; }
fi
ls -l "$TAR"

rm -rf "busybox-$VER"
tar -xjf "$TAR"
cd "busybox-$VER"

# --- configure: static, minimal but with the applets we need --------------
echo
echo "=== configuring (static, defconfig) ==="
make ARCH=arm64 CROSS_COMPILE="$CROSS_COMPILE" defconfig >/dev/null 2>&1

# turn on static linking
sed -i 's/^# CONFIG_STATIC is not set/CONFIG_STATIC=y/' .config
grep -q '^CONFIG_STATIC=y' .config || echo 'CONFIG_STATIC=y' >> .config

# make sure the applets our /init uses are present (defconfig has them all,
# but assert it so a future defconfig change cannot silently break us)
for opt in CONFIG_ASH CONFIG_MOUNT CONFIG_IP CONFIG_TELNETD CONFIG_UDHCPD \
           CONFIG_DD CONFIG_DMESG CONFIG_GREP CONFIG_SED CONFIG_MKNOD \
           CONFIG_SETSID CONFIG_PS CONFIG_FREE CONFIG_DF CONFIG_SYNC ; do
    sed -i "s/^# $opt is not set/$opt=y/" .config
done

echo
echo "=== building (this takes ~1 minute) ==="
make ARCH=arm64 CROSS_COMPILE="$CROSS_COMPILE" -j"$(nproc)" >/tmp/bb.log 2>&1
rc=$?
tail -5 /tmp/bb.log
if [ $rc -ne 0 ]; then
    echo "BUILD FAILED (see /tmp/bb.log)"; exit 1
fi

echo
echo "=== result ==="
ls -l busybox
file busybox
echo -n "  NEEDED entries (0 = static): "
readelf -d busybox 2>/dev/null | grep -c NEEDED
echo -n "  version: "
./busybox 2>&1 | head -1 || true

cp busybox "$DL/busybox-aarch64-static"
echo
echo "installed: $DL/busybox-aarch64-static ($(stat -c%s "$DL/busybox-aarch64-static") bytes)"

#!/bin/bash
# Supply the missing aarch64 libc startup objects (crti.o/crt1.o/crtn.o) needed
# for static linking. Our toolchain came from extracted .debs and is missing the
# libc dev package, which is why the busybox link failed.
set -uo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
TC="$ROOT/toolchain/gcc-12-aarch64"
CACHE="$ROOT/toolchain/.debcache"
mkdir -p "$CACHE"
cd "$CACHE"

echo "=== what is missing ==="
find "$TC" -name 'crti.o' -o -name 'crt1.o' -o -name 'crtn.o' 2>/dev/null | sed 's/^/  found: /'
echo "  (empty means absent)"

echo
echo "=== which packages provide them ==="
apt-cache search --names-only 'arm64-cross' 2>/dev/null | grep -iE 'libc6-dev|libc-dev' | head
echo "--- candidates ---"
for p in libc6-dev-arm64-cross libc6-dev-arm64-cross-dev; do
    v=$(apt-cache policy "$p" 2>/dev/null | awk '/Candidate:/{print $2}')
    printf '  %-28s %s\n' "$p" "${v:-<unavailable>}"
done

echo
echo "=== download + extract ==="
apt-get download libc6-dev-arm64-cross 2>&1 | tail -2
for d in libc6-dev-arm64-cross*.deb; do
    [ -f "$d" ] || continue
    echo "  extracting $d"
    dpkg-deb -x "$d" "$TC"
done

echo
echo "=== verify ==="
find "$TC" -name 'crti.o' -o -name 'crt1.o' -o -name 'crtn.o' 2>/dev/null | sed 's/^/  /'
echo
echo "=== also check for the arm64 libc.so link script ==="
find "$TC" -path '*aarch64-linux-gnu*' -name 'libc.so' 2>/dev/null | head -3 | sed 's/^/  /'
find "$TC" -name 'libc.a' 2>/dev/null | head -3 | sed 's/^/  libc.a: /'
find "$TC" -name 'libm.a' 2>/dev/null | head -3 | sed 's/^/  libm.a: /'

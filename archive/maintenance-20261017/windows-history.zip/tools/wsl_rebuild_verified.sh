#!/bin/bash
# Rebuild the existing 6.14 source tree and export independently verified inputs.
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN="/mnt/h/workspace/PJA110-Mainline"
TREE="$ROOT/linux"
OUT="$WIN/out/rebuild-20261012"
PREFIX="$ROOT/toolchain/gcc-12-aarch64"
export PATH="$PREFIX/usr/bin:$PATH"
export LD_LIBRARY_PATH="$PREFIX/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu-
JOBS="${JOBS:-12}"
mkdir -p "$OUT"
cd "$TREE"
if [ "${1:-}" = '--rebuild-busybox' ]; then
    if [ ! -f "$PREFIX/usr/aarch64-linux-gnu/include/linux/limits.h" ]; then
        CACHE="$ROOT/toolchain/.debcache"
        mkdir -p "$CACHE"
        cd "$CACHE"
        apt-get download linux-libc-dev-arm64-cross 2>&1 | tee "$OUT/busybox-headers-download.log"
        for pkg in linux-libc-dev-arm64-cross_*.deb; do
            dpkg-deb -x "$pkg" "$PREFIX"
        done
        test -f "$PREFIX/usr/aarch64-linux-gnu/include/linux/limits.h"
    fi
    BB_WORK="$ROOT/out/rebuild-20261012-busybox"
    BB_TAR="$ROOT/initramfs/dl/busybox-1.36.1.tar.bz2"
    mkdir -p "$BB_WORK"
    if [ ! -d "$BB_WORK/busybox-1.36.1" ]; then
        tar -xjf "$BB_TAR" -C "$BB_WORK"
    fi
    cd "$BB_WORK/busybox-1.36.1"
    if [ ! -f .config ]; then
        make ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu- defconfig > "$OUT/busybox-configure.log" 2>&1
        python3 - "$PREFIX" <<'PY'
from pathlib import Path
import re, sys
p=Path('.config')
c=p.read_text()
c=re.sub(r'^# CONFIG_STATIC is not set$', 'CONFIG_STATIC=y', c, flags=re.M)
c=re.sub(r'^CONFIG_SYSROOT=.*$', 'CONFIG_SYSROOT="'+sys.argv[1]+'"', c, flags=re.M)
p.write_text(c)
assert 'CONFIG_STATIC=y' in c.splitlines()
PY
    fi
    make ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu- -j"$JOBS" 2>&1 | tee "$OUT/busybox-build.log"
    cp busybox "$OUT/busybox"
    cp .config "$OUT/busybox.config"
    aarch64-linux-gnu-readelf -l busybox > "$OUT/busybox-program-headers.txt"
    if grep -q 'INTERP' "$OUT/busybox-program-headers.txt"; then
        echo 'BusyBox unexpectedly has an interpreter dependency.'
        exit 1
    fi
    echo 'FRESH STATIC BUSYBOX BUILD COMPLETE'
    exit 0
fi
if [ "${1:-}" = '--qemu-smoke' ] || [ "${1:-}" = '--qemu-debug' ]; then
    QEMU_ROOT="$ROOT/toolchain/qemu/sysroot"
    QEMU="$QEMU_ROOT/usr/bin/qemu-system-aarch64"
    if [ ! -x "$QEMU" ]; then
        echo 'QEMU binary is not available in the existing project toolchain.'
        exit 2
    fi
    export LD_LIBRARY_PATH="$QEMU_ROOT/usr/lib/x86_64-linux-gnu:$LD_LIBRARY_PATH"
    export QEMU_DATADIR="$QEMU_ROOT/usr/share/qemu"
    "$QEMU" --version | head -1
    QEMU_EXTRA=()
    QEMU_TIMEOUT=45
    QEMU_LOG="$OUT/qemu-smoke.log"
    if [ "$1" = '--qemu-debug' ]; then
        QEMU_EXTRA=(-d int -D "$OUT/qemu-interrupts.log")
        QEMU_TIMEOUT=12
        QEMU_LOG="$OUT/qemu-debug.log"
    fi
    set +e
    sha256sum "$OUT/Image" > "$OUT/qemu-image.sha256"
    timeout "$QEMU_TIMEOUT" "$QEMU" "${QEMU_EXTRA[@]}" -M virt -cpu cortex-a57 -smp 2 -m 2048 \
        -kernel "$OUT/Image" \
        -append 'console=ttyAMA0 earlycon=pl011,0x9000000 loglevel=7 rdinit=/init ignore_loglevel' \
        -display none -serial stdio -monitor none -net none > "$QEMU_LOG" 2>&1
    rc=$?
    set -e
    echo "$rc" > "$OUT/qemu-exit-code.txt"
    tail -35 "$QEMU_LOG"
    grep -q '\[initramfs\] boot:' "$QEMU_LOG"
    if [ "$1" = '--qemu-smoke' ]; then
        test "$rc" -eq 0
        grep -q '\[initramfs\] boot: Linux' "$QEMU_LOG"
        grep -q 'reboot: Power down' "$QEMU_LOG"
        if grep -Eq 'Kernel panic|stack smashing|/init:.*not found|Aborted' "$QEMU_LOG"; then
            echo 'QEMU smoke test found a userland or kernel failure.'
            exit 1
        fi
    fi
    echo 'QEMU REACHED EMBEDDED /init'
    exit 0
fi
if [ "${1:-}" = '--inspect-config' ]; then
    grep -A60 -B4 'config CMDLINE' arch/arm64/Kconfig
    grep -E 'CMDLINE|INITRAMFS_FORCE' .config
    exit 0
fi
if [ "${1:-}" = '--inspect-busybox' ]; then
    SRC="$ROOT/initramfs/dl/busybox-1.36.1"
    ls -l "$SRC/.config" "$SRC/busybox" "$PREFIX/usr/aarch64-linux-gnu/lib/libc.a"
    grep -E 'CONFIG_(STATIC|SYSROOT|EXTRA_CFLAGS|EXTRA_LDFLAGS|STACK_OPTIMIZATION_386|FEATURE_SH|ASH|SH_IS)' "$SRC/.config"
    aarch64-linux-gnu-gcc -v -E -x c /dev/null 2>&1
    aarch64-linux-gnu-gcc -print-file-name=libc.a
    ls "$ROOT/toolchain/.debcache/"*libc* "$ROOT/toolchain/.debcache/"*gcc* 2>/dev/null || true
    tail -35 "$SRC/busybox_unstripped.map" 2>/dev/null || true
    exit 0
fi
if [ ! -f "$OUT/config.before" ]; then
    cp .config "$OUT/config.before"
fi
sha256sum "$WIN/initramfs/initramfs.cpio.gz" "$WIN/dts/"*.dts > "$OUT/source-input-hashes.txt"
cp "$WIN/initramfs/initramfs.cpio.gz" initramfs-xigua.cpio.gz
cp "$WIN/initramfs/initramfs.cpio.gz" "$ROOT/initramfs/initramfs.cpio.gz"
if [ -f "$OUT/busybox" ]; then
    cp "$OUT/busybox" "$ROOT/initramfs/tree/bin/busybox"
    cp "$OUT/busybox" "$ROOT/initramfs/dl/busybox-aarch64-static"
fi
cmp "$WIN/dts/sm8550-oneplus-xigua.dts" arch/arm64/boot/dts/qcom/sm8550-oneplus-xigua.dts
cmp "$WIN/dts/sm8550-oneplus-xigua-16G.dts" arch/arm64/boot/dts/qcom/sm8550-oneplus-xigua-16G.dts
scripts/config --disable CMDLINE_FORCE --enable CMDLINE_FROM_BOOTLOADER --set-str CMDLINE ''
scripts/config --set-str INITRAMFS_SOURCE "$TREE/initramfs-xigua.cpio.gz"
scripts/config --disable INITRAMFS_FORCE --enable BLK_DEV_INITRD --enable RD_GZIP --enable RD_LZ4
scripts/config --set-str LOCALVERSION '-sm8550-xigua-r1'
make olddefconfig 2>&1 | tee "$OUT/configure.log"
python3 - <<'PY'
from pathlib import Path
c = Path('.config').read_text()
for line in ['CONFIG_CMDLINE=""', 'CONFIG_BLK_DEV_INITRD=y',
             'CONFIG_RD_GZIP=y', 'CONFIG_RD_LZ4=y', 'CONFIG_ARM_PSCI_FW=y',
             'CONFIG_SERIAL_QCOM_GENI_CONSOLE=y', 'CONFIG_USB_DWC3_QCOM=y']:
    assert line in c.splitlines(), line
assert 'root=PARTLABEL=win' not in c
assert 'CONFIG_CMDLINE_FORCE=y' not in c.splitlines()
# In arm64 6.14 the command-line choice depends on CMDLINE != "".
# An empty default hides both choice symbols and uses bootloader arguments.
print('Resolved configuration verified before build.')
PY
aarch64-linux-gnu-gcc --version | head -1 | tee "$OUT/toolchain.txt"
free -h | head -2
echo "Building with $JOBS jobs"
make -j"$JOBS" Image Image.gz qcom/sm8550-oneplus-xigua.dtb qcom/sm8550-oneplus-xigua-16G.dtb 2>&1 | tee "$OUT/build.log"
cp arch/arm64/boot/Image "$OUT/Image"
cp arch/arm64/boot/Image.gz "$OUT/Image.gz"
cp arch/arm64/boot/dts/qcom/sm8550-oneplus-xigua.dtb "$OUT/"
cp arch/arm64/boot/dts/qcom/sm8550-oneplus-xigua-16G.dtb "$OUT/"
cp .config "$OUT/kernel.config"
cp System.map "$OUT/System.map"
cp include/config/kernel.release "$OUT/kernel.release"
cp initramfs-xigua.cpio.gz "$OUT/initramfs.cpio.gz"
sha256sum "$OUT/Image" "$OUT/Image.gz" "$OUT/"*.dtb "$OUT/kernel.config" "$OUT/initramfs.cpio.gz" > "$OUT/SHA256SUMS.inputs"
cat "$OUT/kernel.release"
echo 'BUILD COMPLETE'

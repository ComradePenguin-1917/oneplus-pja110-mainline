#!/bin/bash
# Verify the initramfs is actually bootable, rather than assuming.
#
# Two things tripped the earlier check:
#   1. the archive lists "init" not "./init" -- need to confirm the kernel will
#      find /init (it looks for the literal path "init" at the archive root)
#   2. readelf reported no interpreter -> busybox may be static. If it IS static
#      then the lib copy loop found nothing, which is correct and fine, but we
#      must prove it rather than suspect it.
set -uo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WORK="$ROOT/initramfs"
TREE="$WORK/tree"

echo "=== 1) is busybox static or dynamic? ==="
file "$TREE/bin/busybox"
echo -n "  NEEDED entries: "
readelf -d "$TREE/bin/busybox" 2>/dev/null | grep -c NEEDED
echo -n "  program headers interpreter: "
readelf -l "$TREE/bin/busybox" 2>/dev/null | grep -c interpreter
echo -n "  ldd says: "
ldd "$TREE/bin/busybox" 2>&1 | head -2

echo
echo "=== 2) archive layout (kernel looks for 'init' at root) ==="
cd "$WORK"
zcat initramfs.cpio.gz > /tmp/x.cpio
echo "  root-level entries:"
cpio -t < /tmp/x.cpio 2>/dev/null | grep -v / | head -20
echo
echo -n "  exact 'init' entry present: "
cpio -t < /tmp/x.cpio 2>/dev/null | grep -cx 'init'

echo
echo "=== 3) extract and test-run OUR init in a chroot ==="
rm -rf /tmp/xtest && mkdir -p /tmp/xtest
cd /tmp/xtest && cpio -idm < /tmp/x.cpio 2>/dev/null
ls -l /tmp/xtest/init /tmp/xtest/bin/busybox
echo
echo "  does /init parse as a shell script?"
sh -n /tmp/xtest/init && echo "    syntax OK" || echo "    SYNTAX ERROR"
echo
echo "  can busybox run standalone?"
/tmp/xtest/bin/busybox echo "    busybox works: $(${TREE}/bin/busybox --help 2>&1 | head -1)" 2>&1 | head -2
/tmp/xtest/bin/busybox uname -m 2>&1 | sed 's/^/    uname: /'

echo
echo "=== 4) simulate /init's gadget logic against a fake sysfs ==="
echo "  (checking the shell logic does not have obvious bugs)"
bash -n /tmp/xtest/init && echo "    bash -n passed"
grep -c 'GADGET=' /tmp/xtest/init | sed 's/^/    GADGET refs: /'
grep -c 'find_udc' /tmp/xtest/init | sed 's/^/    find_udc refs: /'
rm -rf /tmp/xtest /tmp/x.cpio

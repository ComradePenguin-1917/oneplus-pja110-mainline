#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
OUT="$WIN/out/pmbootstrap-wsl-probe-20261015"
COMMIT=7d23010a125ca7386fec4e390d14128b6c24d266
mkdir -p "$ROOT" "$OUT"
if [ ! -e "$ROOT/pmbootstrap/.git" ]; then
 git init "$ROOT/pmbootstrap" > "$OUT/git-init.log" 2>&1
 git -C "$ROOT/pmbootstrap" remote add origin https://gitlab.postmarketos.org/postmarketOS/pmbootstrap.git
fi
git -C "$ROOT/pmbootstrap" fetch --depth=1 origin "$COMMIT" > "$OUT/git-fetch.log" 2>&1
git -C "$ROOT/pmbootstrap" checkout --detach "$COMMIT" > "$OUT/git-checkout.log" 2>&1
test "$(git -C "$ROOT/pmbootstrap" rev-parse HEAD)" = "$COMMIT"
cd "$ROOT/pmbootstrap"
python3 pmbootstrap.py --version > "$OUT/pmbootstrap-version.txt" 2>&1
cat "$OUT/pmbootstrap-version.txt"
python3 pmbootstrap.py --help > "$OUT/pmbootstrap-help.txt" 2>&1
echo 'PASS: pinned pmbootstrap runs and help parses as normal WSL user'

"""Stock B kernel retention test, with pre-Android read-only pstore witness."""
import json
import pathlib
import re
import subprocess
import sys
import time

import run_r1_flash_test as f

ROOT=f.ROOT
OUT=ROOT/'out/stock-pstore-control-20261012'
f.OUT=OUT
MARKER='PJA110_STOCK_PMSG_20261012_R1'
ADB=f.ADB
SERIAL=f.SERIAL

def shell(cmd, binary=False, timeout=20):
    p=subprocess.run([ADB,'-s',SERIAL,'exec-out' if binary else 'shell',cmd],capture_output=True,timeout=timeout)
    return p

def wait_android(slot='b', previous=None):
    start=time.monotonic()
    with (OUT/'connection-watch.jsonl').open('a') as log:
        while time.monotonic()-start<120:
            try:
                p=shell('getprop ro.boot.slot_suffix; getprop sys.boot_completed; cat /proc/sys/kernel/random/boot_id',timeout=4)
                lines=p.stdout.decode(errors='replace').splitlines()
                log.write(json.dumps({'seconds':round(time.monotonic()-start,2),'state':lines,'exit':p.returncode})+'\n'); log.flush()
                if p.returncode==0 and len(lines)>=3 and lines[:2]==['_'+slot,'1'] and lines[2]!=previous:
                    return lines[2]
                if p.returncode==0 and len(lines)>=2 and lines[1]=='1' and lines[0]!='_'+slot:
                    raise RuntimeError('Unexpected active slot: '+repr(lines))
            except subprocess.TimeoutExpired:
                pass
            time.sleep(1)
    raise RuntimeError('Android did not complete the expected boot')

def witness(name):
    p=shell('getprop ro.boot.slot_suffix; getprop sys.boot_completed; cat /proc/version; cat /proc/uptime; cat /proc/sys/kernel/random/boot_id; id')
    p.check_returncode(); (OUT/(name+'-state.txt')).write_bytes(p.stdout)
    subprocess.run([ADB,'-s',SERIAL,'push',str(ROOT/'out/init-experiment-20261012/read-domain'),'/data/local/tmp/pja-read-domain'],capture_output=True,check=True,timeout=15)
    shell('chmod 755 /data/local/tmp/pja-read-domain').check_returncode()
    p=shell('/data/local/tmp/pja-read-domain',binary=True)
    p.check_returncode(); (OUT/(name+'-domain.bin')).write_bytes(p.stdout)
    assert len(p.stdout)==65,p.stdout
    m=re.search(rb'S([0-9a-f]{2})_M([0-9a-f]{2})_P([0-9a-f]{2})_C([0-9a-f]{2})_H([01])([01])_A([0-9a-f]{13})_R1',p.stdout)
    assert m,'Early-reader execution witness absent: '+repr(p.stdout)
    data={k:int(v,16) for k,v in zip(['sysfs_mount_errno','pstore_mount_errno','pmsg_read_errno','console_read_errno','pmsg_marker_found','console_marker_found','ramoops_address'],m.groups())}
    (OUT/(name+'-witness.json')).write_text(json.dumps(data,indent=2)+'\n')
    print(name,repr(p.stdout),json.dumps(data),flush=True)
    return data

def main(mode):
    if mode=='preflight':
        assert not (OUT/'preflight.json').exists()
        status,hashes=f.state('preflight-device')
        assert status==['_a','1']
        for p in ('vendor_boot_b','init_boot_b','dtbo_b'):
            assert f.sha(ROOT/'backup'/(p+'.img'))==hashes[p],p
        assert f.sha(f.RESTORE['boot_b'])==hashes['boot_b']
        package=json.loads((OUT/'package.json').read_text())
        assert f.sha(OUT/'init_boot_b-early-reader.img')==package['init_boot_image_sha256']
        assert f.sha(ROOT/'backup/boot_b.img')==package['original_boot_b_sha256']
        (OUT/'preflight.json').write_text(json.dumps({'partition_hashes_before':hashes,'package':package},indent=2)+'\n')
        for case,expected in [('positive',b'PJA110_SCAN_H1_RC00'),('negative',b'PJA110_SCAN_H0_RC00')]:
            p=shell('/data/local/tmp/pja-pstore-reader --selftest /data/local/tmp/pja-scan-'+case)
            p.check_returncode(); assert p.stdout.strip()==expected
            (OUT/('selftest-'+case+'.txt')).write_bytes(p.stdout)
        print('PASS: A healthy, B backups and read-helper selftests verified.')
    elif mode=='flash-stock':
        pre=json.loads((OUT/'preflight.json').read_text())
        status,hashes=f.state('immediately-before-flash')
        assert status==['_a','1'] and hashes==pre['partition_hashes_before']
        assert f.sha(OUT/'init_boot_b-early-reader.img')==pre['package']['init_boot_image_sha256']
        subprocess.run([ADB,'-s',SERIAL,'reboot','bootloader'],check=True,timeout=15)
        f.fb([['getvar','current-slot'],['getvar','unlocked'],['flash','boot_b',ROOT/'backup/boot_b.img'],['flash','init_boot_b',OUT/'init_boot_b-early-reader.img'],['set_active','b'],['reboot']],'flash-stock')
        wait_android()
        data=witness('stock-first-boot')
        assert data['sysfs_mount_errno']==0 and data['pstore_mount_errno']==0,data
        assert data['ramoops_address']>0,data
    elif mode=='mark-reboot':
        assert not (OUT/'marker-written.txt').exists()
        first=json.loads((OUT/'stock-first-boot-witness.json').read_text())
        assert first['pstore_mount_errno']==0 and first['sysfs_mount_errno']==0
        p=shell('getprop ro.boot.slot_suffix; cat /proc/sys/kernel/random/boot_id')
        p.check_returncode(); lines=p.stdout.decode().splitlines(); assert lines[0]=='_b'
        previous=lines[1]
        p=shell('echo '+MARKER+' > /dev/pmsg0; echo PMSG_EXIT:$?; log -p e -t PJA110_RETENTION '+MARKER+'; logcat -d -s PJA110_RETENTION:*')
        p.check_returncode(); assert b'PMSG_EXIT:0' in p.stdout and MARKER.encode() in p.stdout
        (OUT/'marker-write-output.txt').write_bytes(p.stdout)
        (OUT/'marker-written.txt').write_text(MARKER+'\n'+previous+'\n')
        subprocess.run([ADB,'-s',SERIAL,'reboot'],check=True,timeout=15)
        wait_android(previous=previous)
        data=witness('stock-after-reboot')
        assert data['sysfs_mount_errno']==0 and data['pstore_mount_errno']==0,data
        assert data['ramoops_address']==first['ramoops_address'],data
    elif mode=='return-a-readback':
        subprocess.run([ADB,'-s',SERIAL,'reboot','bootloader'],check=True,timeout=15)
        f.fb([['set_active','a'],['reboot']],'return-a-for-readback')
        wait_android(slot='a')
        status,hashes=f.state('test-images-readback')
        pre=json.loads((OUT/'preflight.json').read_text())
        expected=dict(pre['partition_hashes_before'])
        expected['boot_b']=pre['package']['original_boot_b_sha256']
        expected['init_boot_b']=pre['package']['init_boot_image_sha256']
        assert status==['_a','1'] and hashes==expected,hashes
        print('PASS: stock boot and collector init_boot full partition hashes verified; all other partitions unchanged.')
    elif mode=='restore':
        pre=json.loads((OUT/'preflight.json').read_text())
        for p in ('boot_b','init_boot_b'):
            assert f.sha(f.RESTORE[p])==pre['partition_hashes_before'][p]
        # Caller enters fastboot, including recovery after an interrupted test.
        f.fb([['flash','boot_b',f.RESTORE['boot_b']],['flash','init_boot_b',f.RESTORE['init_boot_b']],['set_active','a'],['reboot']],'restore')
        wait_android(slot='a')
        status,hashes=f.state('restored-device')
        assert status==['_a','1'] and hashes==pre['partition_hashes_before']
        print('PASS: Android A completed boot and all eight partition hashes restored.')
    else: raise ValueError(mode)

if __name__=='__main__': main(sys.argv[1])

#!/usr/bin/env python3
"""Robustly run `fastboot boot` and confirm the image was actually accepted.

Problem observed: `fastboot boot probe2.img` printed
    Booting FAILED (Status read failed (Too many links))
and the device then booted normally from flash. So the image was never executed,
and any conclusion drawn from that run would be worthless.

"Too many links" is a USB-level failure. It happened twice in a row right after
`set_active`, which may disturb enumeration.

This helper:
  * retries `fastboot boot` up to N times
  * treats only "Booting OKAY" as success
  * refuses to report a result if the device came up on its normal slot instead
    of from the image
"""
import re
import shutil
import subprocess
import sys
import time

FB = shutil.which('fastboot') or r'C:\platform-tools\fastboot.exe'
ADB = shutil.which('adb') or r'C:\platform-tools\adb.exe'
SERIAL = 'bc7a542e'


def run(cmd, timeout=300):
    r = subprocess.run(cmd, capture_output=True, timeout=timeout)
    out = (r.stdout or b'').decode('utf-8', 'replace') + \
          (r.stderr or b'').decode('utf-8', 'replace')
    return r.returncode, out


def fb_devices():
    _, out = run([FB, 'devices'])
    return [l.split()[0] for l in out.splitlines() if l.strip() and 'fastboot' in l]


def adb_devices():
    _, out = run([ADB, 'devices'])
    return [l.split()[0] for l in out.splitlines() if l.strip().endswith('device')]


def wait_fastboot(secs=60):
    for _ in range(secs // 2):
        if SERIAL in fb_devices():
            return True
        time.sleep(2)
    return False


def wait_android(secs=180):
    for _ in range(secs // 3):
        if SERIAL in adb_devices():
            return True
        time.sleep(3)
    return False


def main(image, attempts=4):
    print('=== enter bootloader ===')
    if SERIAL in adb_devices():
        run([ADB, '-s', SERIAL, 'reboot', 'bootloader'])
    if not wait_fastboot(90):
        print('  device did not appear in fastboot')
        return 2
    print('  fastboot: present')

    # settle: give USB time to enumerate fully before transferring 50 MB
    time.sleep(6)

    for i in range(1, attempts + 1):
        print()
        print('=== attempt %d/%d: fastboot boot ===' % (i, attempts))
        rc, out = run([FB, 'boot', image], timeout=600)
        for line in out.splitlines():
            if line.strip():
                print('    %s' % line.strip()[:110])

        # success criterion: ABL reports Booting OKAY (no FAILED)
        ok = re.search(r'Booting\s+OKAY', out) and 'FAILED' not in out
        if not ok:
            print('    -> image NOT accepted; retrying after a pause')
            # if the device already left fastboot, it booted from flash
            if not wait_fastboot(30):
                print('    -> device left fastboot; it booted from FLASH, not the image')
                if wait_android(180):
                    print('    -> Android is up (slot came from flash)')
                return 3
            time.sleep(5)
            continue

        print('    -> Booting OKAY: image accepted')
        if wait_android(240):
            print()
            print('=== device is up; verify it booted FROM THE IMAGE ===')
            run([ADB, '-s', SERIAL, 'wait-for-device'])
            time.sleep(12)
            checks = {
                'cmdline has our probe marker':
                    'xiguaprobe' ,
                'slot suffix':
                    'ro.boot.slot_suffix',
            }
            _, cmd = run([ADB, '-s', SERIAL, 'shell', 'cat /proc/cmdline'])
            print('  cmdline: %s' % cmd.strip()[:150])
            print('  contains xiguaprobe: %s' % ('xiguaprobe' in cmd))
            return 0
        else:
            print('    -> device did not come up')
            return 4

    print()
    print('all attempts failed to get the image accepted')
    return 5


if __name__ == '__main__':
    img = sys.argv[1] if len(sys.argv) > 1 else r'H:\WorkSpace\PJA110-Mainline\out\probe2.img'
    sys.exit(main(img))

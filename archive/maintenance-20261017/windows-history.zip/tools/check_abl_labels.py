#!/usr/bin/env python3
"""Verify the ABL-required labels are present in the compiled DTB.

DTC only emits labels into the blob when built with -@ (symbols). ABL does not
read __symbols__; it looks at the *node names* it can find, but the upstream
discussion is explicit that it wants a label named qcom_tzlog and a timer node
labelled arch_timer. Practically what ABL seems to need is that these names
appear in the blob, so we check both __symbols__ (if -@ was used) and the
resulting structure.
"""
import os
import struct
import subprocess
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
DTC = r'D:\msys64\ucrt64\bin\dtc.exe'


def check(dtb):
    p = os.path.join(WS, 'dts', dtb)
    if not os.path.exists(p):
        print('missing %s' % dtb)
        return
    raw = open(p, 'rb').read()
    print('=== %s (%d bytes) ===' % (dtb, len(raw)))
    for name in (b'qcom_tzlog', b'arch_timer', b'\x00timer\x00'):
        print('  %-16s present in blob: %s' % (name.decode(errors='replace'),
                                               name in raw))
    # decompile and look for the labels
    r = subprocess.run([DTC, '-I', 'dtb', '-O', 'dts', p],
                       capture_output=True, text=True)
    if r.returncode != 0:
        print('  decompile failed')
        return
    txt = r.stdout
    import re
    for lbl in ('qcom_tzlog', 'arch_timer'):
        m = re.search(r'%s:\s*(\S+)\s*\{' % lbl, txt)
        print('  label %-14s -> %s' % (lbl, m.group(1) if m else 'NOT FOUND'))
    # show the timer node
    i = txt.find('timer {')
    if i > 0:
        j = txt.find('};', i)
        blk = txt[max(0, i - 200):j + 2]
        print('  --- timer node context ---')
        for line in blk.split('\n')[-8:]:
            print('     %s' % line.rstrip())
    print()


for d in ('sm8550-oneplus-xigua.dtb', 'sm8550-oneplus-xigua-16G.dtb'):
    check(d)

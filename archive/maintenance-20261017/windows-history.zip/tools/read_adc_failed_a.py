"""Inspect A image and persistent capture from B using partition labels."""
from pathlib import Path
import subprocess
import time
from prepare_native_install import SSH
cmd = '''set -eu
v=/dev/disk/by-partlabel/vendor_boot_a
u=/dev/disk/by-partlabel/userdata
readlink -f "$v"
sha256sum "$v"
/tmp/qbootctl -b 0
test -z "$(losetup -a)"
mkdir -p /tmp/adc-a-read
losetup -r -o 511705088 /dev/loop0 "$u"
trap 'umount /tmp/adc-a-read 2>/dev/null || true; losetup -d /dev/loop0' EXIT
mount -t ext4 -o ro,noload /dev/loop0 /tmp/adc-a-read
echo CAPTURE_DIRS
ls -lt /tmp/adc-a-read/var/log/pja110-charger
echo ADC_SERVICE
cat /tmp/adc-a-read/etc/systemd/system/pja110-adc-test.service
echo BOOT_SUCCESS
ls /tmp/adc-a-read/etc/systemd/system/*boot* /tmp/adc-a-read/usr/lib/systemd/system/*boot* 2>/dev/null || true
echo LATEST_CAPTURE
latest=$(ls -t /tmp/adc-a-read/var/log/pja110-charger | head -n 1)
find "/tmp/adc-a-read/var/log/pja110-charger/$latest" -maxdepth 2 -type f
for f in /tmp/adc-a-read/var/log/pja110-charger/"$latest"/*; do
 [ -f "$f" ] || continue
 echo FILE=$f
 tail -n 90 "$f"
done
'''
p = subprocess.run(SSH + [cmd], capture_output=True, timeout=60)
dest = Path('out/native-install-20261017/adc-gen3') / ('failed-a-' + time.strftime('%Y%m%d-%H%M%S') + '.txt')
dest.write_bytes(p.stdout + p.stderr)
print(p.stdout.decode(errors='replace'))
print(p.stderr.decode(errors='replace'))
print(dest, 'SSH exit', p.returncode)
p.check_returncode()

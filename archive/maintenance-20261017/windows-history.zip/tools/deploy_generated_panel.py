"""Deploy a panel-only kernel change against the verified 240Hz touch baseline."""
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/('out/display-generator-avb-retest-20261014' if '--avb-retest' in sys.argv else 'out/display-generator-20261013')
KEYS=ROOT/'out/usb-ncm-20261013/ssh'
SSH=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(KEYS/'client_key_host'),
     '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
     '-o',f'UserKnownHostsFile={KEYS/"known_hosts"}','-o','ConnectTimeout=5',
     '-o','ServerAliveInterval=5','root@169.254.42.1']
def ssh(cmd,data=None):
    p=subprocess.run(SSH+[cmd],input=data,capture_output=True,timeout=90)
    (OUT/'last-ssh-error.txt').write_bytes(p.stderr)
    p.check_returncode()
    return p.stdout
def hashes():
    raw=ssh('for f in /sys/class/block/sd*/uevent; do cat "$f"; echo END; done')
    wanted=set(json.loads((OUT/'deployment-manifest.json').read_text())['baseline_hashes'])
    devices={}
    for record in raw.decode().split('END'):
        props=dict(line.split('=',1) for line in record.splitlines() if '=' in line)
        label=props.get('PARTNAME')
        if label in wanted:
            assert label not in devices and re.fullmatch(r'sd[a-z]+[0-9]+',props['DEVNAME'])
            devices[label]=props['DEVNAME']
    assert set(devices)==wanted
    result={}
    for label,dev in devices.items():
        assert ssh(f"grep '^PARTNAME=' /sys/class/block/{dev}/uevent").decode().strip()=='PARTNAME='+label
        result[label]=ssh(f'sha256sum /dev/{dev}').decode().split()[0]
    return result
def draw():
    data=(ROOT/'out/display-port-20261013/fb-pattern').read_bytes()
    response=ssh('cat > /tmp/fb-pattern; chmod 700 /tmp/fb-pattern; sha256sum /tmp/fb-pattern',data)
    assert response.decode().split()[0]==hashlib.sha256(data).hexdigest()
    (OUT/'framebuffer-pattern.txt').write_bytes(ssh('/tmp/fb-pattern'))
auto=json.loads((OUT/'deployment-manifest.json').read_text())
mode=sys.argv[1]
if mode=='preflight':
    assert not (OUT/'device-before.json').exists()
    actual=hashes();assert actual==auto['baseline_hashes']
    (OUT/'device-before.json').write_text(json.dumps(actual,indent=2)+'\n')
    (OUT/'device-before.txt').write_bytes(ssh('uname -a; cat /proc/sys/kernel/random/boot_id; cat /proc/bus/input/devices; dmesg | tail -n 15'))
    print('PASS: all eight partitions match verified display + Aston 240Hz baseline')
elif mode=='flash':
    assert json.loads((OUT/'device-before.json').read_text())==auto['baseline_hashes']
    image=OUT/'boot_b-generated-panel.img'
    assert hashlib.sha256(image.read_bytes()).hexdigest()==auto['boot_b_sha256']
    assert auto['only_boot_b_to_flash'] and auto['embedded_ssh_initramfs_preserved']
    qemu=(OUT/'qemu-console.txt').read_bytes()
    assert b'QEMU touch modules validated' in qemu and b'QEMU debug userspace validated' in qemu
    def fb(args):
        p=subprocess.run(['C:/platform-tools/fastboot.exe','-s','bc7a542e']+args,capture_output=True,timeout=120)
        with (OUT/'fastboot.log').open('ab') as f:f.write(('COMMAND '+' '.join(args)+'\n').encode()+p.stdout+p.stderr)
        p.check_returncode();result=(p.stdout+p.stderr).decode(errors='replace');print(result,flush=True)
        return result
    assert 'current-slot: b' in fb(['getvar','current-slot'])
    assert 'unlocked: yes' in fb(['getvar','unlocked'])
    assert 'slot-successful:a: yes' in fb(['getvar','slot-successful:a'])
    fb(['flash','boot_b',str(image)]);fb(['set_active','b']);fb(['reboot'])
elif mode=='capture':
    state=ssh('uname -a; cat /proc/sys/kernel/random/boot_id; cat /tmp/touch-init.log; '
              'cat /proc/bus/input/devices; cat /sys/module/synaptics_aston/parameters/report_rate_code; '
              'cat /sys/class/drm/card0-DSI-1/status; cat /sys/kernel/debug/gpio; dmesg')
    (OUT/'device-after.txt').write_bytes(state)
    assert b'AA536 generator-based 60Hz driver' in state and b'AA536 60 Hz initialization complete' in state
    assert b'AA536 Iris7 analog bypass confirmed' in state
    assert b'Aston S3910 240Hz touch modules loaded' in state
    assert b'PJA_ASTON fixed report rate code=3 readback verified' in state
    assert b'Internal error:' not in state and b'Unable to handle kernel' not in state
    actual=hashes()
    assert actual['boot_b']==auto['boot_b_sha256']
    assert all(actual[p]==auto['baseline_hashes'][p] for p in actual if p!='boot_b')
    (OUT/'device-after.json').write_text(json.dumps(actual,indent=2)+'\n')
    draw()
    auto.update(phone_execution_confirmed=True,other_seven_boot_partitions_unchanged=True,
                ssh_and_240hz_touch_autostart_preserved=True,visual_confirmation_pending=True)
    (OUT/'deployment-manifest.json').write_text(json.dumps(auto,indent=2)+'\n')
    print('PASS: generated panel initialized, Iris bypass confirmed, SSH and 240Hz touch active; only boot_b changed; visual confirmation required')
elif mode=='live-flash':
    assert '--avb-retest' in sys.argv
    assert auto['only_boot_b_to_flash'] and auto['original_avb_tail_preserved']
    assert auto['embedded_ssh_initramfs_preserved']
    before=hashes()
    assert before==auto['baseline_hashes'], 'live baseline changed; refusing write'
    image=OUT/'boot_b-generated-panel.img'
    data=image.read_bytes()
    assert hashlib.sha256(data).hexdigest()==auto['boot_b_sha256']
    rollback=ROOT/'out/boot-recovery-diagnosis-20261014/boot_b-working-restored-avb.img'
    assert hashlib.sha256(rollback.read_bytes()).hexdigest()==before['boot_b']
    stock=(ROOT/'backup/boot_b.img').read_bytes()
    assert len(data)==len(stock)==201326592
    assert data[auto['avb_offset']:]==stock[auto['avb_offset']:]
    qemu=(OUT/'qemu-console.txt').read_bytes()
    assert b'QEMU touch modules validated' in qemu and b'QEMU debug userspace validated' in qemu
    state=ssh('uname -a; cat /proc/sys/kernel/random/boot_id; cat /proc/meminfo')
    assert b'#14 SMP' in state
    assert int(re.search(rb'MemAvailable:\s*(\d+)',state).group(1))*1024>len(data)*2
    raw=ssh('for f in /sys/class/block/sd*/uevent; do cat "$f"; echo END; done').decode()
    found=[]
    misc=[]
    for record in raw.split('END'):
        props=dict(line.split('=',1) for line in record.splitlines() if '=' in line)
        if props.get('PARTNAME')=='boot_b': found.append(props['DEVNAME'])
        if props.get('PARTNAME')=='misc': misc.append(props['DEVNAME'])
    assert len(found)==1 and re.fullmatch(r'sd[a-z]+[0-9]+',found[0])
    assert len(misc)==1 and re.fullmatch(r'sd[a-z]+[0-9]+',misc[0])
    control=ssh(f'dd if=/dev/{misc[0]} bs=1 skip=2048 count=32 2>/dev/null')
    # This device does not store AOSP bootloader_control at misc+2048.
    # Running #14 plus exact stock A and recovered mainline B hashes identify
    # the baseline; do not infer or modify slot metadata from an empty field.
    assert len(control)==32
    (OUT/'live-slot-control-before.bin').write_bytes(control)
    dev=found[0]
    assert int(ssh(f'cat /sys/class/block/{dev}/size'))*512==len(data)
    staged='/tmp/generated-panel-boot.img'
    print('Uploading full candidate to RAM before any block write',flush=True)
    assert ssh(f'cat > {staged}; sha256sum {staged}',data).decode().split()[0]==auto['boot_b_sha256']
    (OUT/'live-before.txt').write_bytes(state)
    (OUT/'live-before.json').write_text(json.dumps(before,indent=2)+'\n')
    assert ssh(f"grep '^PARTNAME=' /sys/class/block/{dev}/uevent").decode().strip()=='PARTNAME=boot_b'
    print(f'RAM image hash verified; writing only /dev/{dev} (boot_b)',flush=True)
    result=ssh(f'set -e; dd if={staged} of=/dev/{dev} bs=1048576 conv=fsync; sync; sha256sum /dev/{dev}')
    (OUT/'live-write-readback.txt').write_bytes(result)
    assert result.decode().split()[0]==auto['boot_b_sha256'], 'readback mismatch; do not reboot'
    after=hashes()
    assert after['boot_b']==auto['boot_b_sha256']
    assert all(after[p]==before[p] for p in before if p!='boot_b')
    (OUT/'live-after-write.json').write_text(json.dumps(after,indent=2)+'\n')
    print('PASS: candidate written and full partition readback matched; other seven partitions unchanged; not rebooted')
else:
    raise SystemExit('preflight | flash | live-flash --avb-retest | capture')

"""Save bounded RAM bring-up evidence, including failed round and timing limits."""
import collections
import hashlib
import json
import re
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'out/aston-touch-20261013'
events = (OUT/'physical-touch-events3.txt').read_text()
physical = json.loads((OUT/'physical-result3.json').read_text())
assert physical['frames'] > 0 and not physical['evdev_overflow']
assert 'active=0\nSUMMARY' in events
assert 'PASS' not in events  # Native evidence is events + SUMMARY, not host verdicts.
assert json.loads((OUT/'device-after-ram.json').read_text()) == json.loads((OUT/'device-before.json').read_text())
assert b'PJA110 Synaptics S3910"' in (OUT/'lifecycle-result.txt').read_bytes()
assert b'PJA110 Synaptics S3910 (Aston TCM)' in (OUT/'lifecycle-result.txt').read_bytes()
log = (OUT/'physical-dmesg3.txt').read_text()
assert 'Internal error:' not in log and 'Unable to handle kernel' not in log
physical.update(user_observation_pending=False, user_two_sequences_position_and_multitouch_confirmed=True,
                all_contacts_released_at_end=True)
(OUT/'physical-result3.json').write_text(json.dumps(physical, indent=2)+'\n')
times = [float(x) for x in re.findall(r'^FRAME ([0-9.]+)', events, re.M)]
intervals = [round((b-a)*1000, 3) for a,b in zip(times, times[1:])]
continuous = [x for x in intervals if 0 < x <= 30]
timing = {'source': 'userspace SYN_REPORT processing timestamps, printed to 1ms',
          'filter': 'positive consecutive intervals <=30ms; pauses excluded',
          'intervals_used': len(continuous), 'total_frames': len(times),
          'median_interval_ms': statistics.median(continuous),
          'mean_interval_ms': statistics.mean(continuous),
          'estimated_report_rate_hz': 1000/statistics.mean(continuous),
          'hardware_scan_rate_confirmed': False, 'visual_marker_update_limit_hz': 20,
          'interval_modes_ms': collections.Counter(continuous).most_common(8)}
(OUT/'report-timing.json').write_text(json.dumps(timing, indent=2)+'\n')
source = json.loads((OUT/'source-manifest.json').read_text())
source.update(phone_execution_confirmed=True, ram_input_verified=True,
              unload_restore_reload_verified=True, all_eight_boot_partitions_unchanged=True,
              fixed_boot_image_updated=False, original_driver_returns_after_reboot=True)
(OUT/'source-manifest.json').write_text(json.dumps(source, indent=2)+'\n')
frozen = OUT/'verified-ram'
frozen.mkdir(exist_ok=True)
files = ['synaptics-aston.ko', 'source-manifest.json', 'build.log', 'lifecycle-result.txt',
         'physical-touch-events3.txt', 'physical-result3.json', 'physical-dmesg3.txt',
         'device-before.json', 'device-after-ram.json', 'report-timing.json']
records = {}
for name in files:
    data = (OUT/name).read_bytes()
    (frozen/name).write_bytes(data)
    records[name] = hashlib.sha256(data).hexdigest()
for name in ('syna_tcm2.c', 'syna_tcm2.h', 'syna_tcm2_spi.c', 'Makefile'):
    data = (ROOT/'drivers/input/touchscreen/synaptics-aston'/name).read_bytes()
    (frozen/name).write_bytes(data)
    records[name] = hashlib.sha256(data).hexdigest()
(frozen/'sha256.json').write_text(json.dumps(records, indent=2)+'\n')
print(f"PASS: Aston RAM touch/lifecycle verified; report interval {timing['mean_interval_ms']:.3f}ms, approximate {timing['estimated_report_rate_hz']:.1f}Hz")

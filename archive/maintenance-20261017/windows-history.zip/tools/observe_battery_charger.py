"""Start a finite, unprivileged sysfs recording across USB disconnection."""
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
scope = {'__file__': str(ROOT/'tools/check_battery_runtime.py')}
exec((ROOT/'tools/check_battery_runtime.py').read_text().split('state = run(')[0], scope)
run = scope['run']
tag = time.strftime('%Y%m%d-%H%M%S')
folder = '/home/penguin/battery-candidate'
remote_log = f'{folder}/charger-observation-{tag}.txt'
script = '''#!/bin/sh
for n in $(seq 1 120); do
 echo SAMPLE
 cat /proc/uptime
 cat /sys/class/power_supply/bq28z610-0/uevent
 sleep 5
done
'''
p = subprocess.run(scope['SSH']+[f'cat > {folder}/record-charger.sh; chmod 755 {folder}/record-charger.sh'], input=script.encode(), capture_output=True, timeout=15)
p.check_returncode()
pid = run(f'nohup sh {folder}/record-charger.sh > {remote_log} 2>&1 < /dev/null & echo $!').decode().strip()
assert pid.isdecimal()
(ROOT/'out/battery-bringup-20261016/charger-observation-path.txt').write_text(remote_log+'\n')
print(f'Finite 10-minute recording started, PID {pid}; no root, charging controls or services changed')

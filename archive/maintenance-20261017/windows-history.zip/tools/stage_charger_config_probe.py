"""Upload a bounded config-buffer read and restoration script."""
from pathlib import Path
import hashlib
import subprocess
from prepare_native_install import SSH

out = Path('out/native-install-20261017/charger-config-probe')
data = (out / 'qcom_battmgr-config.ko').read_bytes()
sha = hashlib.sha256(data).hexdigest()
script = '''#!/bin/sh
set -eu
test "$(id -u)" = 0
mkdir /run/pja110-charger-watchdog-lock || exit 1
trap 'rmdir /run/pja110-charger-watchdog-lock' EXIT
cd /home/penguin/charger-config-probe
exec > result.log 2>&1
chmod 644 result.log
test "$(uname -r)" = 6.14.0-oneplus-xigua
test "$(cat /sys/module/qcom_battmgr/parameters/pja110_charger_init)" = N
echo '@SHA@  qcom_battmgr-config.ko' | sha256sum -c -
test -f /usr/local/lib/pja110/qcom_battmgr.ko
restore() {
 if [ -d /sys/module/qcom_battmgr ]; then rmmod qcom_battmgr || return 1; fi
 insmod /usr/local/lib/pja110/qcom_battmgr.ko pja110_charger_init=0
 echo READONLY_MODULE_RESTORED
}
cleanup() { restore; rmdir /run/pja110-charger-watchdog-lock; }
cat /proc/sys/kernel/random/boot_id /proc/uptime
cat /sys/class/power_supply/bq28z610-0/uevent
rmmod qcom_battmgr
trap cleanup EXIT
insmod ./qcom_battmgr-config.ko
result=-115
for i in $(seq 1 12); do
 result=$(cat /sys/module/qcom_battmgr/parameters/readback_result)
 [ "$result" = -115 ] || break
 sleep 1
done
echo CONFIG_BUFFER_RESULT=$result
cat /sys/module/qcom_battmgr/parameters/snapshot_size /sys/module/qcom_battmgr/parameters/snapshot
restore
trap 'rmdir /run/pja110-charger-watchdog-lock' EXIT
test "$result" = 0
cat /sys/class/power_supply/bq28z610-0/uevent
echo CONFIG_PROBE_COMPLETE
'''.replace('@SHA@', sha)
(out / 'probe.sh').write_bytes(script.encode())
args = SSH[:]
args[-1] = 'penguin@172.16.42.1'
args = [x if not x.startswith('UserKnownHostsFile=') else
        'UserKnownHostsFile=out/native-install-20261017/known_hosts' for x in args]

def run(cmd, payload=None):
    p = subprocess.run(args + [cmd], input=payload, capture_output=True, timeout=30)
    print(p.stdout.decode(errors='replace'))
    print(p.stderr.decode(errors='replace'))
    p.check_returncode()
    return p.stdout

v = run('umask 077; mkdir -p /home/penguin/charger-config-probe; '
        'cat > /home/penguin/charger-config-probe/qcom_battmgr-config.ko; '
        'sha256sum /home/penguin/charger-config-probe/qcom_battmgr-config.ko', data)
assert v.decode().split()[0] == sha
run('cat > /home/penguin/probe-charger-config.sh', script.encode())
run('sh -n /home/penguin/probe-charger-config.sh')
p = subprocess.run(args + ['sudo -n true'], capture_output=True, timeout=15)
print('Noninteractive sudo:', p.returncode == 0)
print(p.stderr.decode(errors='replace'))

"""Build one guarded stock charger-enable cycle with config readbacks."""
from pathlib import Path
import hashlib
import json
import subprocess

win = Path('/mnt/h/workspace/PJA110-Mainline')
root = Path.home() / 'workspace/PJA110-Mainline/charger-native-a'
build = root / 'charger-enable-cycle'
out = win / 'out/native-install-20261017/charger-enable-cycle'
build.mkdir(exist_ok=True)
out.mkdir(exist_ok=True)
s = (win / 'out/native-install-20261017/charger-config-probe/source.c').read_text()
s = s.replace('#include <linux/module.h>', '#include <linux/module.h>\n#include <linux/delay.h>')
s = s.replace('static bool readback_attempted, readback_pending;', '''static bool restore_only, cycle_started;
module_param(restore_only, bool, 0444);
module_param(cycle_started, bool, 0444);
static unsigned int before[12], disabled[12], enabled[12];
module_param_array(before, uint, NULL, 0444);
module_param_array(disabled, uint, NULL, 0444);
module_param_array(enabled, uint, NULL, 0444);
static int disable_result = -EINPROGRESS, enable_result = -EINPROGRESS;
static int restore_retry_result = -EINPROGRESS;
module_param(disable_result, int, 0444);
module_param(enable_result, int, 0444);
module_param(restore_retry_result, int, 0444);
static bool readback_attempted, readback_pending;''')
# SET acknowledgements must have the same owner as the request.
s = s.replace('if (opcode != READ_ONCE(battmgr->pending_set_opcode) ||',
'''if (le32_to_cpu(hdr->owner) != PMIC_GLINK_OWNER_BATTMGR ||
            opcode != READ_ONCE(battmgr->pending_set_opcode) ||''')
start = s.index('/* Stock firmware config buffer handler;')
end = s.index('static void qcom_battmgr_enable_worker', start)
s = s[:start] + '''/* Only the stock config-buffer read and battery-property-24 switch. */
static int pja110_config_read(struct qcom_battmgr *b)
{
    struct {
        struct pmic_glink_hdr hdr;
        __le32 data_size;
    } req = {
        .hdr.owner = cpu_to_le32(PMIC_GLINK_OWNER_BATTMGR),
        .hdr.type = cpu_to_le32(PMIC_GLINK_REQ_RESP),
        .hdr.opcode = cpu_to_le32(0x10002),
        .data_size = cpu_to_le32(512),
    };
    int ret;
    memset(snapshot, 0, sizeof(snapshot));
    WRITE_ONCE(readback_pending, true);
    ret = qcom_battmgr_request(b, &req, sizeof(req));
    WRITE_ONCE(readback_pending, false);
    return ret;
}

static int qcom_battmgr_pja110_init(struct qcom_battmgr *b)
{
    const void *project;
    size_t size;
    int ret = -ENODEV, off_read;
    if (readback_attempted)
        return 0;
    readback_attempted = true;
    if (!of_machine_is_compatible("oneplus,xigua"))
        goto done;
    project = qcom_smem_get(QCOM_SMEM_HOST_ANY, 135, &size);
    if (IS_ERR(project)) {
        ret = PTR_ERR(project);
        goto done;
    }
    if (size < 8 || get_unaligned_le32((const u8 *)project + 4) != 22851)
        goto done;
    ret = pja110_config_read(b);
    if (ret)
        goto done;
    memcpy(before, snapshot, sizeof(before));
    /* Match the measured faulted baseline and its conservative limits. */
    if ((!restore_only && (before[0] != 7 || before[2] != 1)) ||
        before[1] != 0 || before[2] > 1 ||
        before[3] != 95 || before[4] != 6 || before[6] != 0) {
        ret = -ESTALE;
        goto done;
    }
    off_read = 0;
    if (restore_only && before[2] == 1) {
        memcpy(enabled, before, sizeof(enabled));
        goto done;
    }
    if (!restore_only) {
        cycle_started = true;
        disable_result = qcom_battmgr_request_property(b, BATTMGR_BAT_PROPERTY_SET, 24, 0);
        msleep(500);
        off_read = pja110_config_read(b);
        if (!off_read)
            memcpy(disabled, snapshot, sizeof(disabled));
    }
    /* Always restore the verified initial enable=1, including failed OFF ACK. */
    enable_result = qcom_battmgr_request_property(b, BATTMGR_BAT_PROPERTY_SET, 24, 1);
    if (enable_result)
        restore_retry_result = qcom_battmgr_request_property(b, BATTMGR_BAT_PROPERTY_SET, 24, 1);
    msleep(2000);
    ret = pja110_config_read(b);
    if (!ret) {
        memcpy(enabled, snapshot, sizeof(enabled));
        if (enabled[2] != 1)
            ret = -EIO;
    }
    if (!ret && !restore_only && disable_result)
        ret = disable_result;
    if (!ret && off_read)
        ret = off_read;
    if (!ret && enable_result && restore_retry_result)
        ret = enable_result;
done:
    WRITE_ONCE(readback_result, ret);
    dev_info(b->dev, "PJA110 one-shot enable cycle: off=%d on=%d retry=%d result=%d\\n",
             disable_result, enable_result, restore_retry_result, ret);
    return ret;
}

''' + s[end:]
(build / 'qcom_battmgr.c').write_text(s)
(build / 'Makefile').write_text('obj-m += qcom_battmgr.o\n')
p = subprocess.run(['make', '-C', str(root / 'linux-6.14'), 'ARCH=arm64',
                    'CROSS_COMPILE=/opt/aarch64-linux-gnu-toolchain-13.3/bin/aarch64-none-linux-gnu-',
                    'M=' + str(build), 'modules'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(out / 'build.log').write_bytes(p.stdout)
print(p.stdout.decode(errors='replace'))
p.check_returncode()
data = (build / 'qcom_battmgr.ko').read_bytes()
(out / 'qcom_battmgr-cycle.ko').write_bytes(data)
(out / 'source.c').write_text(s)
manifest = dict(sha256=hashlib.sha256(data).hexdigest(), property_set='battery 24: 0, then 1',
                limits_changed=False, watchdog_configuration_changed=False,
                guarded_state=7, guarded_fcc_ma=300, guarded_fv_mv=9100,
                phone_tested=False)
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest, indent=2))

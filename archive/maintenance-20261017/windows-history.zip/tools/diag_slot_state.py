#!/usr/bin/env python3
"""Did ABL actually attempt slot B, or did it refuse?

This matters enormously: if ABL never tried slot B, the experiment did not
exercise our kernel at all and tells us nothing about the kernel.

Where the answer lives
----------------------
AOSP stores A/B slot state in a `bootloader_control` struct in the `misc`
partition (offset 2048), magic 0x42414342 (`BCAB`):

    struct slot_metadata {
        uint8_t priority        : 4;
        uint8_t tries_remaining : 3;
        uint8_t successful_boot : 1;
    };

If slot B shows tries_remaining == 0 or successful_boot == 0 after our attempt,
that proves ABL selected B, tried it, and recorded a failure -- i.e. the kernel
(or at least the boot) failed on B, not that ABL ignored the slot.

Also verifies our flashed images survived, and dumps anything the ABL log says
about the slot decision.
"""
import hashlib
import os
import shutil
import struct
import subprocess
import sys

ADB = shutil.which('adb') or r'C:\platform-tools\adb.exe'
WS = r'H:\WorkSpace\PJA110-Mainline'
SERIAL = 'bc7a542e'
MAGIC = 0x42414342


def sh(cmd, timeout=600):
    r = subprocess.run([ADB, '-s', SERIAL, 'shell', 'su -c "%s"' % cmd],
                       capture_output=True, timeout=timeout)
    return ((r.stdout or b'') + (r.stderr or b'')).decode('utf-8', 'replace')


def sha_local(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''):
            h.update(c)
    return h.hexdigest()


print('=' * 78)
print('1) DID OUR FLASHED IMAGES SURVIVE?')
print('=' * 78)
dev = sh('for p in boot_b vendor_boot_b dtbo_b; do printf "%-16s " $p; '
         'sha256sum /dev/block/by-name/$p | cut -c1-24; done')
print(dev.strip())
print()
expect = {
    'boot_b': sha_local(os.path.join(WS, 'out', 'boot_b-ourkernel.img'))[:24],
    'vendor_boot_b': sha_local(os.path.join(WS, 'out', 'vendor_boot_b-ourdtb.img'))[:24],
}
for k, v in expect.items():
    print('  expected %-16s %s' % (k, v))

print()
print('=' * 78)
print('2) SLOT METADATA (misc / bootloader_control)')
print('=' * 78)
out = os.path.join(WS, 'backup', 'misc.img')
if not os.path.exists(out):
    sh('dd if=/dev/block/by-name/misc of=/data/local/tmp/misc.img bs=4096 2>/dev/null; '
       'chmod 644 /data/local/tmp/misc.img')
    r = subprocess.run([ADB, '-s', SERIAL, 'pull', '/data/local/tmp/misc.img', out],
                       capture_output=True, timeout=600)
    print('  pulled misc: %d bytes' % (os.path.getsize(out) if os.path.exists(out) else -1))

for src in (out, os.path.join(WS, 'backup', 'devinfo.img')):
    if not os.path.exists(src):
        continue
    b = open(src, 'rb').read()
    print()
    print('--- %s (%d bytes)' % (os.path.basename(src), len(b)))
    idx = b.find(struct.pack('<I', MAGIC))
    if idx < 0:
        idx = b.find(struct.pack('>I', MAGIC))
        endian = '>'
    else:
        endian = '<'
    if idx < 0:
        print('    no bootloader_control magic found')
        continue
    print('    magic at 0x%x (endian %s)' % (idx, endian))
    suffix = b[idx - 4:idx]
    print('    slot_suffix = %r' % suffix)
    ver = b[idx + 4]
    flags = b[idx + 5]
    nb_slot = flags & 0x7
    rec_tries = (flags >> 3) & 0x7
    merge = (flags >> 6) & 0x3
    print('    version=%d nb_slot=%d recovery_tries=%d merge_status=%d'
          % (ver, nb_slot, rec_tries, merge))
    for i in range(min(nb_slot, 3)):
        o = idx + 8 + i
        v = b[o]
        prio = v & 0xF
        tries = (v >> 4) & 0x7
        succ = (v >> 7) & 0x1
        name = chr(ord('a') + i)
        print('      slot %s: priority=%d tries_remaining=%d successful_boot=%d'
              % (name, prio, tries, succ))

print()
print('=' * 78)
print('3) CURRENT SLOT AS SEEN NOW')
print('=' * 78)
print('  slot_suffix : %s' % sh('getprop ro.boot.slot_suffix').strip())
print('  boot_completed: %s' % sh('getprop sys.boot_completed').strip())
print('  kernel      : %s' % sh('uname -r').strip())

print()
print('=' * 78)
print('4) WHAT THE ABL LOG SAYS ABOUT THE SLOT DECISION')
print('=' * 78)
log = os.path.join(WS, 'bootloader-log-bfail.txt')
if os.path.exists(log):
    txt = open(log, encoding='utf-8', errors='replace').read()
    for line in txt.splitlines():
        if any(k in line for k in ('Booting from slot', 'Active_a', 'Active_b',
                                   'Unbootable', 'BootSuccess', 'AlternateSlot',
                                   'retry', 'slot_suffix')):
            print('  %s' % line.strip()[:120])

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static HANDLE port;
static FILE *output;
static volatile LONG stop_read;
static const char *marker;
static unsigned long long received;
static DWORD failure;

static DWORD WINAPI receive_thread(void *unused)
{
    char buffer[65536], scan[65792], tail[256] = {0};
    size_t tail_len = 0, marker_len = strlen(marker);
    OVERLAPPED ov = {0};
    ov.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
    if (!ov.hEvent) { failure = GetLastError(); return 1; }
    while (!InterlockedCompareExchange(&stop_read, 0, 0)) {
        DWORD n = 0;
        ResetEvent(ov.hEvent);
        if (!ReadFile(port, buffer, sizeof(buffer), &n, &ov)) {
            DWORD error = GetLastError();
            if (error != ERROR_IO_PENDING || !GetOverlappedResult(port, &ov, &n, TRUE)) {
                if (!InterlockedCompareExchange(&stop_read, 0, 0)) failure = GetLastError();
                break;
            }
        }
        if (!n) continue;
        if (fwrite(buffer, 1, n, output) != n) { failure = ERROR_WRITE_FAULT; break; }
        received += n;
        memcpy(scan, tail, tail_len);
        memcpy(scan + tail_len, buffer, n);
        scan[tail_len + n] = 0;
        if (strstr(scan, marker)) break;
        size_t total = tail_len + n;
        tail_len = total < marker_len ? total : marker_len;
        memcpy(tail, scan + total - tail_len, tail_len);
    }
    CloseHandle(ov.hEvent);
    fflush(output);
    return failure ? 1 : 0;
}

int main(int argc, char **argv)
{
    if (argc != 5) { fprintf(stderr, "usage: capture COM12 command.txt output.txt marker\n"); return 2; }
    char name[64];
    snprintf(name, sizeof(name), "\\\\.\\%s", argv[1]);
    marker = argv[4];
    if (strlen(marker) > 200) return 2;
    port = CreateFileA(name, GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_FLAG_OVERLAPPED, NULL);
    if (port == INVALID_HANDLE_VALUE) { fprintf(stderr,"CreateFile error=%lu\n",GetLastError()); return 1; }
    DCB dcb = {0}; dcb.DCBlength = sizeof(dcb);
    if (!GetCommState(port, &dcb)) return 1;
    dcb.BaudRate=CBR_115200; dcb.ByteSize=8; dcb.Parity=NOPARITY; dcb.StopBits=ONESTOPBIT;
    dcb.fBinary=TRUE; dcb.fParity=FALSE; dcb.fOutxCtsFlow=FALSE; dcb.fOutxDsrFlow=FALSE;
    dcb.fDtrControl=DTR_CONTROL_ENABLE; dcb.fRtsControl=RTS_CONTROL_ENABLE;
    dcb.fOutX=FALSE; dcb.fInX=FALSE; dcb.fNull=FALSE; dcb.fAbortOnError=FALSE;
    if (!SetCommState(port,&dcb) || !SetupComm(port,4194304,65536)) return 1;
    COMMTIMEOUTS timeouts={MAXDWORD,MAXDWORD,100,0,10000};
    if (!SetCommTimeouts(port,&timeouts)) return 1;
    output=fopen(argv[3],"wb");
    FILE *input=fopen(argv[2],"rb");
    if (!output || !input) return 1;
    char command[16384]; size_t size=fread(command,1,sizeof(command)-1,input); fclose(input);
    command[size++]='\n';
    HANDLE worker=CreateThread(NULL,0,receive_thread,NULL,0,NULL);
    if (!worker) return 1;
    OVERLAPPED write_ov={0}; write_ov.hEvent=CreateEvent(NULL,TRUE,FALSE,NULL);
    DWORD written=0;
    BOOL ok=WriteFile(port,command,(DWORD)size,&written,&write_ov);
    if (!ok && GetLastError()==ERROR_IO_PENDING) ok=GetOverlappedResult(port,&write_ov,&written,TRUE);
    if (!ok || written!=size) { failure=GetLastError(); fprintf(stderr,"Write error=%lu\n",failure); }
    DWORD status=WaitForSingleObject(worker,120000);
    if (status!=WAIT_OBJECT_0) { failure=ERROR_TIMEOUT; InterlockedExchange(&stop_read,1); CancelIoEx(port,NULL); WaitForSingleObject(worker,2000); }
    fclose(output); CloseHandle(worker); CloseHandle(write_ov.hEvent); CloseHandle(port);
    printf("received=%llu failure=%lu\n",received,failure);
    return failure ? 1 : 0;
}

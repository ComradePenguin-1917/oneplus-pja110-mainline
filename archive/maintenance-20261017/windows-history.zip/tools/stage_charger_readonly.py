"""Stage an explicitly write-disabled battmgr for the next A boot."""
from pathlib import Path
import hashlib, subprocess
from prepare_native_install import SSH
out = Path('out/native-install-20261017/charger-init-candidate')
def run(cmd, data=None):
    p = subprocess.run(SSH + [cmd], input=data, capture_output=True, timeout=45)
    with (out / 'stage-readonly.log').open('ab') as f:
        f.write((cmd + '\n').encode() + p.stdout + p.stderr)
    p.check_returncode()
    return p.stdout
data = (out / 'qcom_battmgr.ko').read_bytes()
sha = hashlib.sha256(data).hexdigest()
assert run('cat > /tmp/qcom_battmgr-readonly.ko && sha256sum /tmp/qcom_battmgr-readonly.ko', data).decode().split()[0] == sha
unit = b'''[Unit]
Description=PJA110 temporary battmgr read-only diagnosis
After=local-fs.target systemd-modules-load.service
Before=pja110-charger-capture.service upower.service
[Service]
Type=oneshot
ExecStart=/sbin/insmod /usr/local/lib/pja110/qcom_battmgr.ko pja110_charger_init=0
RemainAfterExit=yes
[Install]
WantedBy=multi-user.target
'''
run('cat > /tmp/pja110-battmgr-readonly.service', unit)
cmd = '''set -eu
test -z "$(losetup -a)"
test "$(sed -n 's/^PARTNAME=//p' /sys/class/block/sda14/uevent)" = userdata
mkdir -p /tmp/a-battmgr-stage
losetup -o 511705088 /dev/loop0 /dev/sda14
trap 'umount /tmp/a-battmgr-stage 2>/dev/null || true; losetup -d /dev/loop0' EXIT
mount -t ext4 /dev/loop0 /tmp/a-battmgr-stage
test -e /tmp/a-battmgr-stage/usr/lib/modules/6.14.0-oneplus-xigua
mkdir -p /tmp/a-battmgr-stage/usr/local/lib/pja110
cp /tmp/qcom_battmgr-readonly.ko /tmp/a-battmgr-stage/usr/local/lib/pja110/qcom_battmgr.ko
cp /tmp/pja110-battmgr-readonly.service /tmp/a-battmgr-stage/etc/systemd/system/
ln -sf ../pja110-battmgr-readonly.service /tmp/a-battmgr-stage/etc/systemd/system/multi-user.target.wants/pja110-battmgr-readonly.service
sha256sum /tmp/a-battmgr-stage/usr/local/lib/pja110/qcom_battmgr.ko
sync
'''
result = run(cmd)
assert result.decode().split()[0] == sha
print('PASS: staged explicit pja110_charger_init=0 service; A root unmounted; no reboot')

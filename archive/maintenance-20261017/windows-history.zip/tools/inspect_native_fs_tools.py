from pathlib import Path
import subprocess

root=Path.home()/'workspace/PJA110-Mainline/pmbootstrap-work/chroot_native'
for directory in ['usr/bin','usr/sbin','bin','sbin','usr/lib','lib']:
    d=root/directory
    if d.is_dir():
        for p in d.iterdir():
            if p.name in ['e2fsck','ld-musl-x86_64.so.1','libc.musl-x86_64.so.1']:
                print(p, 'symlink='+str(p.is_symlink()), 'exists='+str(p.exists()))
print(subprocess.run(['which','qemu-aarch64'],capture_output=True,text=True).stdout)

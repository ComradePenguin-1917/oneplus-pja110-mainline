#!/bin/bash
# Embed our initramfs into the kernel build.
#
# CONFIG_INITRAMFS_SOURCE can point at a directory OR a cpio archive. Using the
# .cpio.gz we built is simplest and avoids the kernel needing busybox to
# regenerate the archive.
#
# Important: an embedded initramfs is ALWAYS used as the initial rootfs, so the
# kernel will run our /init rather than panicking on a missing root device --
# which is exactly how we make the kernel observable.
set -uo pipefail

ROOT="$HOME/workspace/PJA110-Mainline"
TREE="$ROOT/linux"
INITRAMFS="$ROOT/initramfs/initramfs.cpio.gz"

export PATH="$ROOT/toolchain/gcc-12-aarch64/usr/bin:$PATH"
export LD_LIBRARY_PATH="$ROOT/toolchain/gcc-12-aarch64/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export ARCH=arm64
export CROSS_COMPILE=aarch64-linux-gnu-

cd "$TREE"

echo "=== current setting ==="
grep -E '^CONFIG_INITRAMFS_SOURCE' .config || echo "  (unset)"

echo
echo "=== set CONFIG_INITRAMFS_SOURCE to our archive ==="
# Use the in-tree path so the value is portable inside the build.
cp "$INITRAMFS" "$TREE/initramfs-xigua.cpio.gz"
./scripts/config --set-str CONFIG_INITRAMFS_SOURCE "$TREE/initramfs-xigua.cpio.gz"

echo
echo "=== use Android bootloader cmdline ==="
# The previous image forced a desktop-oriented root=PARTLABEL=win command
# line. Android ABL supplies the real cmdline through the DT chosen node and
# bootconfig; letting the kernel accept it is required for this target.
./scripts/config --disable CONFIG_CMDLINE_FORCE
./scripts/config --enable CONFIG_CMDLINE_FROM_BOOTLOADER
./scripts/config --set-str CONFIG_CMDLINE ""
./scripts/config --enable CONFIG_BLK_DEV_INITRD
./scripts/config --enable CONFIG_RD_GZIP

# keep compression of the embedded archive as-is (it is already gzip)
./scripts/config --set-str CONFIG_INITRAMFS_COMPRESSION_NONE "" 2>/dev/null || true

echo
echo "=== resolve config ==="
make ARCH=arm64 CROSS_COMPILE="$CROSS_COMPILE" olddefconfig 2>&1 | tail -3
grep -E '^CONFIG_INITRAMFS_SOURCE' .config

echo
echo "=== rebuild the kernel with the embedded initramfs ==="
make -j"$(nproc)" ARCH=arm64 CROSS_COMPILE="$CROSS_COMPILE" Image 2>&1 | tail -8

echo
echo "=== artifacts ==="
ls -l arch/arm64/boot/Image

echo
echo "=== sanity: is the initramfs inside the Image? ==="
python3 - <<'PY'
import gzip, io, os, re, tarfile
img = 'arch/arm64/boot/Image'
d = open(img, 'rb').read()
print('  Image size: %d (%.1f MiB)' % (len(d), len(d)/2**20))
# our busybox is a distinctive marker
# look for the gzip magic followed by a decompressible stream containing "busybox"
found = 0
for m in re.finditer(rb'\x1f\x8b\x08', d):
    off = m.start()
    try:
        dec = gzip.GzipFile(fileobj=io.BytesIO(d[off:off+2000000])).read(200000)
    except Exception:
        continue
    if b'busybox' in dec and b'TRAILER!!!' in dec:
        print('  initramfs found at offset 0x%x' % off)
        found += 1
        break
print('  embedded initramfs present: %s' % bool(found))
PY

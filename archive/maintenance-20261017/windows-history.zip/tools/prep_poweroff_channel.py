#!/usr/bin/env python3
"""Two observation channels, and which to build first.

Channel A: ramoops/pstore
    our kernel has PSTORE + PSTORE_RAM + PSTORE_CONSOLE enabled, so printk can
    write into a reserved RAM window that survives reset; the Android kernel we
    fall back into then exposes it at /sys/fs/pstore.
    Gaps: our DTB has no ramoops node at all, and we must pin a fixed address
    that (a) lies inside our /memory map and (b) collides with nothing.

Channel B: an unconditionally fatal /init (poweroff)
    zero drivers needed. If /init runs at all, the kernel reached userspace and
    we force a PSCI SYSTEM_OFF, so the device powers down and STAYS down instead
    of falling back to Android.
    Reading it is trivial and needs no tooling: the phone simply does not come
    back. Compare with the current behaviour, where it always comes back on
    Android within ~20 s.

Channel B answers the single most important open question -- "does our kernel
reach userspace at all?" -- with a binary, unmistakable signal, and it costs one
line of shell. Channel A is richer but needs a new reserved-memory region and a
config that writes on panic; it is the natural second step once B tells us the
kernel is alive.

This script prepares B and verifies every assumption it rests on.

Assumptions to verify:
  1. busybox in the initramfs supports `poweroff` (it is an applet we symlinked)
  2. /proc/sysrq-trigger exists in our config, giving a driver-free reboot path
  3. PSCI SYSTEM_OFF is reachable -- our DTB must have /psci with method=smc
  4. the initramfs we embed is the one we think it is
"""
import gzip
import io
import os
import struct
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
sys.path.insert(0, os.path.join(WS, 'tools'))
from fdt import FDT

print('=' * 78)
print('1) IS THE INITRAMFS WHAT WE THINK?')
print('=' * 78)
p = os.path.join(WS, 'initramfs', 'initramfs.cpio.gz')
raw = open(p, 'rb').read()
print('  %s : %d bytes' % (os.path.basename(p), len(raw)))
cpio = gzip.GzipFile(fileobj=io.BytesIO(raw)).read()
print('  decompresses to %d bytes' % len(cpio))

# list entries from the cpio (newc) to confirm the applets we rely on
entries = []
i = 0
while i < len(cpio) - 110:
    if cpio[i:i + 6] not in (b'070701', b'070702'):
        i += 1
        continue
    try:
        namesize = int(cpio[i + 94:i + 102], 16)
        filesize = int(cpio[i + 54:i + 64], 16)
    except ValueError:
        i += 1
        continue
    name = cpio[i + 110:i + 110 + namesize - 1].decode('utf-8', 'replace')
    entries.append(name)
    i += 110 + namesize
    i += (4 - (i % 4)) % 4
    i += filesize
    i += (4 - (i % 4)) % 4
print('  entries: %d' % len(entries))
for want in ('init', 'bin/busybox', 'bin/sh', 'bin/poweroff', 'bin/reboot',
             'bin/halt', 'bin/telnetd', 'bin/udhcpd', 'bin/ip', 'bin/mount'):
    print('    %-16s %s' % (want, 'present' if want in entries else 'MISSING'))

print()
print('=' * 78)
print('2) THE CURRENT /init (what it does today)')
print('=' * 78)
src = open(os.path.join(WS, 'initramfs', 'init'), encoding='utf-8', errors='replace').read()
print('  %d bytes, %d lines' % (len(src), src.count('\n') + 1))
for n, line in enumerate(src.splitlines()[:40], 1):
    print('    %3d  %s' % (n, line[:100]))

print()
print('=' * 78)
print('3) DOES OUR KERNEL SUPPORT SYSRQ?  (driver-free reboot)')
print('=' * 78)
cfg = os.path.join(WS, 'out', 'config-6.14-xigua')
vals = {}
if os.path.exists(cfg):
    for l in open(cfg, encoding='utf-8', errors='replace'):
        l = l.strip()
        if '=' in l and not l.startswith('#'):
            k, v = l.split('=', 1)
            vals[k] = v
        elif l.startswith('# ') and 'is not set' in l:
            vals[l[2:].split(' ')[0]] = 'NOT SET'
for k in ('CONFIG_MAGIC_SYSRQ', 'CONFIG_MAGIC_SYSRQ_DEFAULT_ENABLE',
          'CONFIG_PSCI_CHECKER', 'CONFIG_ARM64_ACPI_PARKING_PROTOCOL',
          'CONFIG_PM', 'CONFIG_SUSPEND'):
    print('  %-38s %s' % (k, vals.get(k, '(absent)')))

print()
print('=' * 78)
print('4) PSCI IN OUR DTB (needed for SYSTEM_OFF/poweroff)')
print('=' * 78)
ours = FDT(open(os.path.join(WS, 'dts', 'sm8550-oneplus-xigua-16G.dtb'), 'rb').read()).nodes()
psci = ours.get('/psci')
if psci:
    for k in sorted(psci):
        v = psci[k]
        print('  /psci/%-16s %s' % (k, v.rstrip(b'\0').decode('ascii', 'replace') if len(v) < 40 else v.hex()[:32]))
else:
    print('  /psci MISSING')

print()
print('=' * 78)
print('VERDICT')
print('=' * 78)
print('  Channel B is buildable if:')
print('    * bin/poweroff (or bin/reboot) is in the initramfs')
print('    * /psci exists with method=smc')
print('  Both are checkable above. The change to /init is additive and small:')
print('  after the existing USB attempts, force an unmistakable outcome instead')
print('  of looping forever.')

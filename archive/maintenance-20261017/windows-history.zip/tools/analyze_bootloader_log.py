#!/usr/bin/env python3
"""Analyze the ABL (bootloader) log pulled from /proc/bootloader_log.

This log is the observability channel we were missing: it records exactly what
ABL did with partitions, what it verified, what cmdline it built, and how it
handed off to the kernel. It survives across boots in a reserved region.

Usage:
    python analyze_bootloader_log.py [bootloader-log.txt]
"""
import io
import os
import re
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(WS, 'bootloader-log.txt')
txt = io.open(path, encoding='utf-8', errors='replace').read()
lines = txt.splitlines()

print('=== log size: %d bytes, %d lines ===' % (len(txt), len(lines)))

print()
print('=' * 72)
print('1) WHICH PARTITIONS ABL LOADED (and in what order)')
print('=' * 72)
seen = []
for l in lines:
    m = re.search(r'Load Image (\S+) total time', l)
    if m and m.group(1) not in seen:
        seen.append(m.group(1))
for s in seen:
    print('   %s' % s)

print()
print('=' * 72)
print('2) AVB / verification verdicts')
print('=' * 72)
for l in lines:
    if 'avb_slot_verify' in l or 'boot state' in l or 'Authenticate' in l:
        print('   %s' % l.strip())

print()
print('=' * 72)
print('3) DTB / DTBO handling')
print('=' * 72)
for l in lines:
    if re.search(r'dtb|dtbo', l, re.I):
        print('   %s' % l.strip())

print()
print('=' * 72)
print('4) the CMDLINE ABL built')
print('=' * 72)
for i, l in enumerate(lines):
    if l.startswith('Cmdline:') or 'AddOppoBootModeCmdLine' in l or 'bootconfig_len' in l:
        print('   %s' % l.strip())

print()
print('=' * 72)
print('5) errors / warnings')
print('=' * 72)
for l in lines:
    if re.search(r'\berror\b|\bfail|\bFailed\b|WARN|assert', l, re.I):
        print('   %s' % l.strip())

print()
print('=' * 72)
print('6) handoff to kernel')
print('=' * 72)
for l in lines:
    if re.search(r'Exit boot services|ExitBootServices|Shutting Down|kernel|start.*linux|'
                 r'Booting|boot_linux|jump', l, re.I):
        print('   %s' % l.strip())

print()
print('=' * 72)
print('7) does ABL mention ANY dtb being applied/merged? (the DTBO question)')
print('=' * 72)
found = False
for l in lines:
    if re.search(r'dtbo.*appl|appl.*dtbo|merge|overlay|fdt_', l, re.I):
        print('   %s' % l.strip())
        found = True
if not found:
    print('   (nothing about applying/merging a DTB or overlay)')

print()
print('=' * 72)
print('8) last 25 lines (the handoff moment)')
print('=' * 72)
for l in lines[-25:]:
    print('   %s' % l.rstrip())

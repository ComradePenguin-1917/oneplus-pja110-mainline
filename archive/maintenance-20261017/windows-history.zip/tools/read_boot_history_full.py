"""Read-only full boot-history snapshot; never reboot or write phone storage."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from fdt import FDT

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / (sys.argv[1] if len(sys.argv) > 1 else 'out/boot-history-full-20261012')
OUT.mkdir(parents=True, exist_ok=True)
ADB = r'C:\platform-tools\adb.exe'

def read(command):
    result = subprocess.run([ADB, '-s', 'bc7a542e', 'exec-out',
                             "su -c '" + command + "'"],
                            capture_output=True, timeout=120)
    result.check_returncode()
    return result.stdout

size = int(read('blockdev --getsize64 /dev/block/by-name/oplusreserve1').strip())
if size != 8388608:
    raise RuntimeError(f'Unexpected partition size: {size}')
raw = read('cat /dev/block/by-name/oplusreserve1')
if len(raw) != size:
    raise RuntimeError(f'Short snapshot: {len(raw)} != {size}')
(OUT / 'oplusreserve1.img').write_bytes(raw)
matches = []
for match in re.finditer(rb'[\x20-\x7e]{8,}', raw):
    line = match.group().decode('ascii')
    if re.search(r'boot|fail|panic|watchdog|slot|kernel|reset|phoenix|hang|uefi', line, re.I):
        matches.append({'offset': match.start(), 'text': line[:2000]})
(OUT / 'boot-keywords.json').write_text(json.dumps(matches, indent=2), encoding='utf-8')
for name, command in {
    'bootloader-log.txt': 'cat /proc/bootloader_log',
    'driver-state.txt': 'cat /proc/modules | grep -i -E "ufs|wdt|watchdog|gunyah"; ls -l /sys/bus/platform/drivers/gh-watchdog; cat /proc/cmdline',
}.items():
    (OUT / name).write_bytes(read(command))
nodes = {}
for name, path in {
    'stock': ROOT / 'out/boot-chain-audit-20261012/live-fdt.dtb',
    'mainline': ROOT / 'out/rebuild-20261012/sm8550-oneplus-xigua-16G.dtb',
}.items():
    selected = []
    for node, props in FDT(path.read_bytes()).nodes().items():
        compatible = props.get('compatible', b'').decode('ascii', 'replace').replace('\0', ',')
        if re.search(r'watchdog|wdt|wdog', node + compatible, re.I):
            selected.append({'path': node, 'compatible': compatible,
                             'properties': {k: v.hex() for k, v in props.items()}})
    nodes[name] = selected
report = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
          'keyword_count': len(matches), 'watchdog_nodes': nodes,
          'phone_partition_writes': False, 'phone_reboot': False}
(OUT / 'result.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report, indent=2))
print(json.dumps(matches[-15:], indent=2))

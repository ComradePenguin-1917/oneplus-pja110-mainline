"""Decode already captured registers; never access or modify the phone."""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'out/weston-kms-diagnosis-20261014'
if '--te-height' in sys.argv:
    OUT = ROOT / 'out/te-height-control-20261014/runtime'
if '--packet2' in sys.argv:
    OUT = ROOT / 'out/dsc-packet-control-20261014/runtime'
if '--trace' in sys.argv:
    OUT = ROOT / 'out/display-timing-20261014/runtime'
blocks = {}
current = None
for line in (OUT / 'kms-registers.txt').read_text().splitlines():
    header = re.fullmatch(r'=+([^=]+)=+', line)
    if header:
        current = blocks.setdefault(header[1], {})
        continue
    row = re.fullmatch(r'0x([0-9a-f]+) : ((?:[0-9a-f]{8} ?)+)', line)
    if row and current is not None:
        base = int(row[1], 16)
        current.update({base + 4 * i: int(v, 16)
                        for i, v in enumerate(row[2].split())})
intf = blocks['intf_1']
dsi = blocks['dsi0_ctrl']
result = {
    'source': 'existing MSM debugfs KMS register dump',
    'registers_written': False,
    'te_source_selection': intf[0x280] & 15,
    'tearcheck_enabled': intf[0x284],
    'vsync_counter_enabled': bool(intf[0x288] & (1 << 19)),
    'external_te_enabled': bool(intf[0x288] & (1 << 20)),
    'vsync_count': intf[0x288] & 0xffff,
    'sync_config_height': intf[0x28c],
    'vsync_initial_line': intf[0x294],
    'start_line': intf[0x2a0],
    'read_pointer_irq_line': intf[0x2a4],
    'sync_threshold_start': intf[0x29c] & 0xffff,
    'sync_threshold_continue': intf[0x29c] >> 16,
    'dsi_command_word_count': dsi[0x54] >> 16,
    'factory_sync_config_height': 0xfff0,
    'factory_dsc_slices_per_packet': 2,
    'current_dsc_packets_per_line': 1 << ((dsi[0x2a4] >> 6) & 3),
    'current_dsc_slice_bytes': dsi[0x2a8] & 0xffff,
    'root_cause_confirmed': False,
}
(OUT / 'sync-decoded.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))

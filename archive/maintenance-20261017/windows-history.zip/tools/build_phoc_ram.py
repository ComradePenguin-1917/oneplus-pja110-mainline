"""Build the upstream Phoc candidate inside the phone's disposable RAM rootfs."""
from pathlib import Path
import subprocess
import sys
import threading
import http.server
import urllib.request
import urllib.error
import hashlib
import json
import time

sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/phoc-atomic-fix-20261016'
KEYS=ROOT/'out/usb-ncm-20261013/ssh'
SSH=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(KEYS/'client_key_host'),
 '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
 '-o',f'UserKnownHostsFile={KEYS/"known_hosts"}','-o','ConnectTimeout=8',
 '-o','ServerAliveInterval=5','root@169.254.42.1']
def run(command,data=None,timeout=60):
 p=subprocess.run(SSH+[command],input=data,capture_output=True,timeout=timeout)
 if p.returncode:raise RuntimeError((p.stdout+p.stderr).decode(errors='replace'))
 return p.stdout
stage=sys.argv[1]
if stage=='inspect':
 data=run('''test -d /tmp/postmarketos-ram
chroot /tmp/postmarketos-ram /bin/sh -c 'cat /etc/apk/repositories; command -v cc || true; command -v meson || true; apk --help | head -n 18; df -h /tmp; cat /etc/resolv.conf'
''')
 (OUT/'build-environment.txt').write_bytes(data)
 print(data.decode())
elif stage=='dependencies':
 repos=['https://mirror.postmarketos.org/postmarketos/extra-repos/systemd/main',
        'https://mirror.postmarketos.org/postmarketos/main',
        'https://mirrors.ustc.edu.cn/alpine/edge/main',
        'https://mirrors.ustc.edu.cn/alpine/edge/community',
        'https://mirrors.ustc.edu.cn/alpine/edge/testing']
 cache=OUT/'repository-cache';cache.mkdir(exist_ok=True)
 class Handler(http.server.BaseHTTPRequestHandler):
  def log_message(self,*args):pass
  def do_GET(self):
   try:
    parts=self.path.split('/')
    idx=int(parts[1]); relative='/'.join(parts[2:])
    if idx<0 or idx>=len(repos) or '..' in relative or '?' in relative:
     raise ValueError('invalid repository path')
    url=repos[idx]+'/'+relative
    cached=cache/(hashlib.sha256(url.encode()).hexdigest()+'-'+relative.split('/')[-1])
    if cached.exists():body=cached.read_bytes()
    else:
     body=urllib.request.urlopen(url,timeout=50).read()
     cached.write_bytes(body)
    self.send_response(200);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
   except Exception as e:
    print('Repository fetch failed:',self.path,str(e),flush=True)
    self.send_error(502)
 server=http.server.ThreadingHTTPServer(('127.0.0.1',18080),Handler)
 threading.Thread(target=server.serve_forever,daemon=True).start()
 command='''set -e
r=/tmp/postmarketos-ram
test -f /tmp/pmos-rootfs.ext4
test "$(cat /tmp/pmos-loop-device)" = /dev/loop0
cat > "$r/tmp/build-repositories" <<'EOF'
http://127.0.0.1:18080/0
http://127.0.0.1:18080/1
http://127.0.0.1:18080/2
http://127.0.0.1:18080/3
http://127.0.0.1:18080/4
EOF
chroot "$r" apk --repositories-file /tmp/build-repositories add --no-cache e2fsprogs-extra
truncate -s 4G /tmp/pmos-rootfs.ext4
losetup -c /dev/loop0
chroot "$r" /usr/sbin/resize2fs /dev/loop0
chroot "$r" apk --repositories-file /tmp/build-repositories add --no-cache --virtual .phoc-build \
 build-base meson pkgconf glib-dev wayland-dev wayland-protocols libinput-dev \
 libxkbcommon-dev pixman-dev libdrm-dev mesa-dev libdisplay-info-dev \
 libxcb-dev xcb-util-renderutil-dev xcb-util-wm-dev xcb-util-image-dev \
 xcb-util-errors-dev xcb-util-keysyms-dev xcb-util-dev \
 vulkan-headers vulkan-loader-dev gmobile-dev gnome-desktop-dev \
 cairo-dev pango-dev gsettings-desktop-schemas-dev systemd-dev gettext-dev \
 glslang python3 patch xwayland-dev hwdata-dev
chroot "$r" /bin/sh -c 'cc --version | head -n 1; meson --version; df -h /'
'''
 args=SSH[:-1]+['-o','ExitOnForwardFailure=yes','-R','127.0.0.1:18080:127.0.0.1:18080',SSH[-1],command]
 try:
  with (OUT/'dependencies.log').open('wb') as log:
   p=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=900)
  print((OUT/'dependencies.log').read_text(encoding='utf-8',errors='replace')[-7000:])
  p.check_returncode()
 finally:server.shutdown()
elif stage=='seat-headers':
 url='https://mirrors.ustc.edu.cn/alpine/edge/community/aarch64/libseat-dev-0.9.3-r1.apk'
 package=OUT/'libseat-dev-0.9.3-r1.apk'
 if not package.exists():package.write_bytes(urllib.request.urlopen(url,timeout=40).read())
 run('cat > /tmp/postmarketos-ram/tmp/libseat-dev.apk',package.read_bytes())
 data=run('''set -e
chroot /tmp/postmarketos-ram /bin/sh -ec '
apk verify /tmp/libseat-dev.apk
cd /
tar xzf /tmp/libseat-dev.apk usr/include/libseat.h usr/lib/pkgconfig/libseat.pc
cat /usr/lib/pkgconfig/libseat.pc
'
''')
 (OUT/'seat-headers.log').write_bytes(data)
 print(data.decode())
elif stage=='seat-link':
 url='https://mirrors.ustc.edu.cn/alpine/edge/community/aarch64/elogind-dev-255.24-r0.apk'
 package=OUT/'elogind-dev-255.24-r0.apk'
 if not package.exists():package.write_bytes(urllib.request.urlopen(url,timeout=40).read())
 run('cat > /tmp/postmarketos-ram/tmp/elogind-dev.apk',package.read_bytes())
 print(run('''set -e
chroot /tmp/postmarketos-ram /bin/sh -ec '
apk verify /tmp/elogind-dev.apk
cd /
tar xzf /tmp/elogind-dev.apk usr/lib/pkgconfig/libelogind.pc usr/lib/libelogind.so usr/include/elogind
ln -sf libseat.so.1 /usr/lib/libseat.so
pkg-config --cflags --libs libseat
'
''').decode())
elif stage=='sources':
 run('mkdir -p /tmp/postmarketos-ram/tmp/phoc-build')
 for name in ('phoc.tar.gz','wlroots.tar.gz','gvdb.tar.gz'):
  run('cat > /tmp/postmarketos-ram/tmp/phoc-build/'+name,(OUT/name).read_bytes())
 patch=ROOT/'out/phoc-commit-20261015/cursor-patch-candidate/0001-drm-avoid-redundant-disabled-cursor-commits.patch'
 run('cat > /tmp/postmarketos-ram/tmp/phoc-build/cursor.patch',patch.read_bytes())
 data=run('''set -e
chroot /tmp/postmarketos-ram /bin/sh -ec '
cd /tmp/phoc-build
if test ! -d phoc; then
mkdir phoc
tar xzf phoc.tar.gz -C phoc --strip-components=1
mkdir -p phoc/subprojects/wlroots-0.20.x phoc/subprojects/gvdb
tar xzf wlroots.tar.gz -C phoc/subprojects/wlroots-0.20.x --strip-components=1
tar xzf gvdb.tar.gz -C phoc/subprojects/gvdb --strip-components=1
fi
test ! -f phoc/.pja-cursor-patched
cd phoc/subprojects/wlroots-0.20.x
patch -p1 < ../packagefiles/wlroots/0001-Revert-layer-shell-error-on-0-dimension-without-anch.patch
patch -p1 < ../../../cursor.patch
cd ../..
touch .pja-cursor-patched
sha256sum subprojects/wlroots-0.20.x/backend/drm/atomic.c subprojects/wlroots-0.20.x/include/backend/drm/drm.h
'
''')
 (OUT/'sources.log').write_bytes(data)
 print(data.decode())
elif stage=='build':
 print(run('date; date -u -s @'+str(int(time.time()))+'; date').decode())
 command='''chroot /tmp/postmarketos-ram /bin/sh -ec '
cd /tmp/phoc-build/phoc
if test ! -f .pja-times-normalized; then
find . -path ./_build -prune -o -type f -exec touch {} +
touch .pja-times-normalized
fi
meson setup _build --prefix=/usr --buildtype=release --wrap-mode=nodownload \
 -Dembed-wlroots=enabled -Dtests=false -Dman=false -Dgtk_doc=false \
 -Dwlroots:examples=false -Dwlroots:renderers=gles2,vulkan -Dwlroots:libliftoff=disabled
ninja -C _build -j4
_build/src/phoc --version
sha256sum _build/src/phoc
' '''
 with (OUT/'build.log').open('wb') as log:
  p=subprocess.run(SSH+[command],stdout=log,stderr=subprocess.STDOUT,timeout=1200)
 print((OUT/'build.log').read_text(encoding='utf-8',errors='replace')[-6500:])
 p.check_returncode()
else:
 raise SystemExit('inspect')

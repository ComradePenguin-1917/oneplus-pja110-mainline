"""Stage a bounded status GET probe, without invoking sudo."""
from pathlib import Path
import hashlib, subprocess
from prepare_native_install import SSH

args=SSH[:]
args[-1]='penguin@172.16.42.1'
args=[x if not x.startswith('UserKnownHostsFile=') else
      'UserKnownHostsFile=out/native-install-20261017/known_hosts' for x in args]
out=Path('out/native-install-20261017/charger-status-readback')
data=(out/'qcom_battmgr-status.ko').read_bytes()
sha=hashlib.sha256(data).hexdigest()
script=Path('out/native-install-20261017/charger-state-readback/read-charger-state.sh').read_text()
oldsha=hashlib.sha256(Path('out/native-install-20261017/charger-state-readback/qcom_battmgr-state.ko').read_bytes()).hexdigest()
script=script.replace(oldsha,sha).replace('charger-state','charger-status').replace('qcom_battmgr-state.ko','qcom_battmgr-status.ko')
script=script.replace('seq 1 12','seq 1 20').replace(
 'battery_enable,usb_suspend,usb_icl,battery_fcc,battery_fcc_max,usb_current_max',
 'battery_status,battery_health,battery_present,battery_charge_type,usb_online,usb_voltage,usb_current,usb_max,usb_icl,usb_type,usb_real_type,usb_collapse_sticky')
script=script.replace('CHARGER_STATE_READBACK_COMPLETE','CHARGER_STATUS_READBACK_COMPLETE')
script=script.replace('\r\n','\n')
(out/'read-charger-status.sh').write_bytes(script.encode())
def run(command, payload=None):
    p=subprocess.run(args+[command],input=payload,capture_output=True,timeout=30)
    print(p.stdout.decode(errors='replace'),end=''); print(p.stderr.decode(errors='replace'),end='')
    p.check_returncode(); return p.stdout
v=run('umask 077; mkdir -p /home/penguin/charger-status-readback; cat > /home/penguin/charger-status-readback/qcom_battmgr-status.ko; sha256sum /home/penguin/charger-status-readback/qcom_battmgr-status.ko',data)
assert v.decode().split()[0]==sha
run('cat > /home/penguin/read-charger-status.sh',script.encode())
run('sh -n /home/penguin/read-charger-status.sh')
p=subprocess.run(args+['sudo -n true'],capture_output=True,timeout=15)
print('Staged and shell syntax checked. Noninteractive sudo available:',p.returncode==0)
if p.returncode:
    print(p.stderr.decode(errors='replace'),end='')

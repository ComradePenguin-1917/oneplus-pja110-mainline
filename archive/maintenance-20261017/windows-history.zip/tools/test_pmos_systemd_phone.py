"""RAM-only systemd startup experiments; rescue PID1/SSH remain outside the guest."""
from pathlib import Path
import subprocess
import sys
import hashlib
import json
import shlex
import time
import re
sys.stdout.reconfigure(encoding='utf-8')
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'out/postmarketos-integration-20261016/phone-systemd'
OUT.mkdir(parents=True, exist_ok=True)
KEYS = ROOT / 'out/usb-ncm-20261013/ssh'
SSH = ['C:/Windows/System32/OpenSSH/ssh.exe', '-F', 'none', '-T', '-i', str(KEYS/'client_key_host'),
       '-o', 'BatchMode=yes', '-o', 'IdentitiesOnly=yes', '-o', 'StrictHostKeyChecking=yes',
       '-o', f'UserKnownHostsFile={KEYS/"known_hosts"}', '-o', 'ConnectTimeout=8',
       '-o', 'ServerAliveInterval=5', 'root@169.254.42.1']
def run(command, data=None, timeout=60):
    p = subprocess.run(SSH+[command], input=data, capture_output=True, timeout=timeout)
    if p.returncode:
        raise RuntimeError((p.stdout+p.stderr).decode(errors='replace'))
    return p.stdout

def guest(command, timeout=60):
    setup = '''set -e
c=$(cat /tmp/pmos-systemd-cgroup)
p=$(head -n 1 "$c/payload/init.scope/cgroup.procs")
test -n "$p"
chroot /tmp/postmarketos-ram /usr/bin/nsenter --target "$p" --mount --pid --net --uts --ipc --cgroup --root --wd -- /bin/sh -c '''
    return run(setup + shlex.quote(command), timeout=timeout)

stage = sys.argv[1] if len(sys.argv)>1 else 'probe'
if stage == 'probe':
    command = '''uname -a
cat /proc/sys/kernel/random/boot_id
cat /proc/1/comm
df -k /tmp
cat /proc/cgroups
cat /proc/self/cgroup
grep -E 'cgroup|/tmp/postmarketos| /sys ' /proc/mounts
ls -ld /sys/fs/cgroup /sys/fs/cgroup/* 2>/dev/null || true
chroot /tmp/postmarketos-ram /usr/bin/systemd-nspawn --version
chroot /tmp/postmarketos-ram /usr/bin/systemd-nspawn --help
ls -l /dev/tty0 /dev/tty7 /dev/dri/* /dev/input/* 2>/dev/null || true
ps | grep -E 'phoc|phosh|seatd|udevd|sshd' || true
'''
    result = run(command)
    (OUT/'probe.txt').write_bytes(result)
    print(result.decode(errors='replace'))
elif stage == 'isolation':
    result = run('''set -e
grep -w cgroup2 /proc/filesystems
if ! grep -q ' /sys/fs/cgroup cgroup2 ' /proc/mounts; then
 mount -t cgroup2 none /sys/fs/cgroup
fi
r=/tmp/postmarketos-ram
if ! grep -q ' /tmp/postmarketos-ram/sys/fs/cgroup cgroup2 ' /proc/mounts; then
 mount --bind /sys/fs/cgroup "$r/sys/fs/cgroup"
fi
p="$r/tmp/nspawn-probe"
mkdir -p "$p/bin" "$p/usr/lib" "$p/etc" "$p/tmp" "$p/run" "$p/proc" "$p/sys" "$p/dev" "$p/var/tmp"
cp /bin/busybox "$p/bin/busybox"
cp "$r/usr/lib/os-release" "$p/usr/lib/os-release"
chroot "$r" /usr/bin/systemd-nspawn --directory=/tmp/nspawn-probe --register=no --keep-unit --settings=no --console=pipe --read-only --timezone=off --resolv-conf=off -- /bin/busybox sh -c 'echo NS_PROBE_PASS; /bin/busybox cat /proc/1/comm; /bin/busybox cat /proc/self/cgroup; /bin/busybox grep NSpid /proc/self/status'
''', timeout=45)
    (OUT/'isolation.txt').write_bytes(result)
    print(result.decode(errors='replace'))
elif stage == 'deploy':
    manifest = json.loads((OUT/'root-artifact.json').read_text())
    assert manifest['raw_sha256'] == json.loads((OUT.parent/'image-verification.json').read_text())['root_partition_sha256']
    artifact = OUT/manifest['artifact']
    with artifact.open('rb') as stream:
        assert hashlib.file_digest(stream, 'sha256').hexdigest() == manifest['compressed_sha256']
    before = run('cat /proc/sys/kernel/random/boot_id; cat /proc/1/comm; df -k /tmp')
    assert b'8beb5772-f237-4266-bd53-d38ba70692a0' in before and b'\ninit\n' in before
    (OUT/'before-deploy.txt').write_bytes(before)
    command = ('set -e; test ! -e /tmp/pmos-integrated-root.ext4; '
               'avail=$(df -k /tmp | tail -n 1 | awk \'{print $4}\'); '
               f'test "$avail" -gt {(manifest["raw_bytes"]+512*1024*1024)//1024}; '
               'gzip -dc > /tmp/pmos-integrated-root.ext4; sha256sum /tmp/pmos-integrated-root.ext4')
    print('Uploading verified integrated root partition into phone RAM', flush=True)
    with artifact.open('rb') as source:
        p = subprocess.run(SSH+[command], stdin=source, capture_output=True, timeout=600)
    (OUT/'upload.txt').write_bytes(p.stdout+p.stderr)
    p.check_returncode()
    assert p.stdout.decode().split()[0] == manifest['raw_sha256']
    result = run('''set -e
r=/tmp/postmarketos-ram/tmp/systemd-root
mkdir -p "$r"
loop=$(losetup -f)
losetup "$loop" /tmp/pmos-integrated-root.ext4
echo "$loop" > /tmp/pmos-integrated-loop
mount -t ext4 "$loop" "$r"
test -x "$r/usr/lib/systemd/systemd"
sha256sum "$r/usr/bin/phoc"
df -k /tmp
''')
    (OUT/'mounted.txt').write_bytes(result)
    print(result.decode())
elif stage == 'launch':
    mode = sys.argv[2] if len(sys.argv)>2 else 'basic'
    assert mode in ('basic', 'display')
    binds = '' if mode == 'basic' else '--bind=/dev/dri --bind=/dev/input --bind=/dev/tty0 --bind=/dev/tty7 --bind-ro=/run/udev '
    unit = 'multi-user.target' if mode == 'basic' else 'graphical.target'
    cgroup = f'/sys/fs/cgroup/pja110-systemd-test/run-{int(time.time())}'
    command = '''set -e
test -f /tmp/pmos-integrated-loop
test ! -e /tmp/pmos-systemd-nspawn.pid
test -x /tmp/postmarketos-ram/tmp/systemd-root/usr/lib/systemd/systemd
mkdir -p CGROUP_PATH
echo CGROUP_PATH > /tmp/pmos-systemd-cgroup
: > /tmp/postmarketos-ram/tmp/systemd-empty-fstab
cat > /tmp/pmos-launch-systemd.sh <<'EOF'
#!/bin/sh
set -e
echo $$ > CGROUP_PATH/cgroup.procs
exec chroot /tmp/postmarketos-ram /usr/bin/systemd-nspawn --directory=/tmp/systemd-root --machine=pja110-systemd-test --register=no --keep-unit --settings=no --console=read-only --boot --private-network --timezone=off --resolv-conf=off --link-journal=no --capability=CAP_IPC_LOCK,CAP_SYS_NICE,CAP_SYS_RESOURCE,CAP_SYS_TTY_CONFIG --rlimit=RLIMIT_MEMLOCK=infinity --bind-ro=/tmp/systemd-empty-fstab:/etc/fstab EXTRA_BINDS -- --unit=BOOT_UNIT --log-target=console
EOF
chmod 700 /tmp/pmos-launch-systemd.sh
nohup /tmp/pmos-launch-systemd.sh > /tmp/pmos-systemd-nspawn.log 2>&1 < /dev/null &
echo $! > /tmp/pmos-systemd-nspawn.pid
cat /tmp/pmos-systemd-nspawn.pid
'''.replace('EXTRA_BINDS', binds).replace('BOOT_UNIT', unit).replace('CGROUP_PATH', cgroup)
    result = run(command)
    (OUT/'launch.txt').write_bytes(result)
    print(result.decode())
elif stage == 'status':
    result = run('''cat /proc/sys/kernel/random/boot_id
cat /proc/1/comm
cat /tmp/pmos-systemd-nspawn.pid
c=$(cat /tmp/pmos-systemd-cgroup)
cat "$c/cgroup.procs"
for f in /proc/[0-9]*/comm; do
 read name < "$f" 2>/dev/null || continue
 if test "$name" = systemd; then
  p=${f%/comm}
  echo SYSTEMD_PID=${p##*/}
  readlink "$p/root"
  cat "$p/cgroup"
  grep NSpid "$p/status"
 fi
done
tail -n 95 /tmp/pmos-systemd-nspawn.log
''')
    (OUT/'status.txt').write_bytes(result)
    (OUT/'console.log').write_bytes(run('cat /tmp/pmos-systemd-nspawn.log'))
    print(result.decode(errors='replace'))
elif stage == 'services':
    result = run('''set -e
c=$(cat /tmp/pmos-systemd-cgroup)
p=$(head -n 1 "$c/payload/init.scope/cgroup.procs")
test -n "$p"
chroot /tmp/postmarketos-ram /usr/bin/nsenter --target "$p" --mount --pid --root --wd -- /bin/sh -c '
export SYSTEMD_COLORS=0 SYSTEMD_PAGER=cat
echo GUEST_CHECK_BEGIN
cat /proc/1/comm
cat /proc/self/cgroup
findmnt /
cat /etc/fstab
systemctl is-system-running || true
systemctl list-jobs --no-pager
systemctl --failed --no-pager
systemctl show -p Id -p ActiveState -p SubState -p Result -p UnitFileState systemd-firstboot.service sshd.service NetworkManager.service systemd-logind.service dbus.service
journalctl -b --no-pager -n 70
echo GUEST_CHECK_END
'
''', timeout=45)
    (OUT/'services.txt').write_bytes(result)
    (OUT/'console.log').write_bytes(run('cat /tmp/pmos-systemd-nspawn.log'))
    print(result.decode(errors='replace'))
elif stage == 'diagnose':
    result = guest('''export SYSTEMD_COLORS=0 SYSTEMD_PAGER=cat
journalctl -b -u systemd-firstboot -u systemd-machine-id-commit -u greetd -u nftables -u postmarketos-zram-swap -u rtkit-daemon -u upower --no-pager -n 140
journalctl -b -t phrog --no-pager -n 40
cat /etc/systemd/system/display-manager.service
findmnt /etc/machine-id
ls -l /etc/machine-id /run/machine-id
cat /proc/1/status | grep -E 'Cap|NSpid'
''')
    (OUT/'diagnose.txt').write_bytes(result)
    print(result.decode(errors='replace'))
elif stage == 'quiet':
    print(guest('systemctl stop unudhcpd.service hkdm.service; systemctl is-active sshd.service dbus.service systemd-logind.service').decode())
elif stage == 'graphical':
    result = guest('''export SYSTEMD_COLORS=0 SYSTEMD_PAGER=cat
systemctl is-active greetd.service sshd.service dbus.service systemd-logind.service
loginctl list-sessions --no-pager
ps -eo user,pid,comm,args | grep -E 'phoc|phrog|phosh|gnome-session|greetd' | head -n 35
journalctl -b -t phrog --no-pager -n 65
systemctl cat rtkit-daemon.service
getent passwd rtkit
systemctl show -p LimitNPROC -p LimitRTPRIO -p LimitMEMLOCK rtkit-daemon.service
''')
    (OUT/'graphical.txt').write_bytes(result)
    print(result.decode(errors='replace'))
elif stage == 'journal':
    result = guest('journalctl -b --no-pager -o short-monotonic', timeout=90)
    (OUT/f'journal-{int(time.time())}.log').write_bytes(result)
    print(f'Saved {len(result)} bytes of guest journal')
elif stage == 'verify':
    result = guest('''export SYSTEMD_COLORS=0 SYSTEMD_PAGER=cat
echo SYSTEMD_SESSION_VERIFY_BEGIN
cat /proc/1/comm
cat /proc/1/cgroup
findmnt /
uname -r
apk info -v phoc device-oneplus-xigua device-oneplus-xigua-phosh linux-oneplus-xigua
sha256sum /usr/bin/phoc
s=$(loginctl list-sessions --no-legend | awk '$3 == "penguin" && $4 == "seat0" {print $1; exit}')
test -n "$s" && loginctl show-session "$s" -p Name -p User -p Seat -p TTY -p Active -p State -p Type -p Class -p Service
for p in $(pidof phoc); do
 echo PHOC_PID=$p
 grep -E 'Uid:|Gid:|NSpid:' /proc/$p/status
 tr '\\0' '\\n' < /proc/$p/environ | grep -E 'WLR_|LD_LIBRARY_PATH|LIBSEAT|XDG_RUNTIME_DIR' || true
 grep -E 'libwlroots|/opt/phoc' /proc/$p/maps || true
done
journalctl -b _UID=10000 --no-pager | grep -E 'GL renderer|EGL driver|1240x2772|libseat|session|Atomic commit failed|Page-flip failed|phoc-output|Phosh ready' | tail -n 55
systemctl --failed --no-pager
echo SYSTEMD_SESSION_VERIFY_END
''')
    (OUT/'verified-session.txt').write_bytes(result)
    print(result.decode(errors='replace'))
    assert b'Uid:\t10000\t10000\t10000\t10000' in result
    assert b'GL renderer: FD740' in result
    assert b'WLR_DRM_NO_ATOMIC=1' not in result
    assert b'5a1a1fdf112489d76ba28e0bc84641aa18fda7e76709445808a3488c235d7453' in result
    outer = run('cat /proc/1/comm; cat /proc/sys/kernel/random/boot_id; dmesg | grep -iE "gpu.*fault|iommu.*fault|underflow|underrun|hangcheck" | tail -n 15')
    (OUT/'outer-rescue.txt').write_bytes(outer)
    print(outer.decode(errors='replace'))
elif stage == 'warnings':
    result = guest('''export SYSTEMD_COLORS=0 SYSTEMD_PAGER=cat
uname -r
systemctl --failed --no-pager
for u in upower nftables postmarketos-zram-swap systemd-vconsole-setup; do
 echo "SERVICE=$u"
 systemctl show "$u.service" -p ActiveState -p SubState -p Result -p ExecMainStatus -p PrivateUsers -p RestrictNamespaces -p SystemCallFilter -p CapabilityBoundingSet
 journalctl -b -u "$u.service" --no-pager -n 14
 systemctl cat "$u.service"
done
echo KERNEL_MODULES
ls /usr/lib/modules
for m in nf_tables nfnetlink zram zsmalloc; do
 modinfo "$m" 2>&1 | head -n 9
done
echo CONSOLE
cat /etc/vconsole.conf 2>/dev/null || true
ls -l /dev/tty0 /dev/tty1 /dev/tty7 /dev/console
echo COMPRESSION_CONFIG
grep zram /usr/share/deviceinfo/deviceinfo
findmnt /sys
findmnt /proc/sys
cat /proc/sys/user/max_user_namespaces 2>/dev/null || true
''')
    result += run('''echo OUTER_KERNEL
uname -r
if test -r /proc/config.gz; then zcat /proc/config.gz | grep -E 'CONFIG_(USER_NS|NF_TABLES|NETFILTER_NETLINK|NFNETLINK|ZRAM|ZSMALLOC|VT|VT_CONSOLE|MEMCG)'; fi
echo LOADED_MODULES
cat /proc/modules | grep -E 'nf_|netfilter|zram|zsmalloc' || true
ls -ld /sys/module/nf_tables /sys/module/nfnetlink /sys/module/zram /sys/module/zsmalloc /sys/block/zram* 2>/dev/null || true
cat /proc/sys/user/max_user_namespaces 2>/dev/null || true
''')
    (OUT/'warning-audit.txt').write_bytes(result)
    print(result.decode(errors='replace'))
elif stage == 'warning-details':
    result = guest('''exec 2>&1
export SYSTEMD_COLORS=0 SYSTEMD_PAGER=cat
echo MATCHING_DISTRO_MODULES
for m in nf_tables nfnetlink zram zsmalloc; do
 modinfo -k 6.14.0-oneplus-xigua "$m" | grep -E 'filename:|vermagic:|depends:'
done
echo ZRAM_SCRIPT
cat /usr/bin/zramstart
echo CONSOLE_JOURNAL
journalctl -b --no-pager _COMM=systemd-vconsol -n 15
echo USER_NAMESPACE_TEST
grep -E 'Seccomp|CapEff' /proc/1/status /proc/self/status
command -v unshare
unshare --user --map-root-user /usr/bin/id
echo DIRECT_USERNS_EXIT=$?
systemd-run --unit=pja110-audit-userns --wait --pipe --property=PrivateUsers=yes /usr/bin/id
echo PID1_USERNS_EXIT=$?
journalctl -b -u pja110-audit-userns --no-pager -n 12
''')
    (OUT/'warning-details.txt').write_bytes(result)
    print(result.decode(errors='replace'))
elif stage == 'namespace-check':
    result = run('''exec 2>&1
echo HOST_USERNS
/bin/busybox unshare -U /bin/busybox id
echo HOST_USERNS_EXIT=$?
echo CHROOT_USERNS
chroot /tmp/postmarketos-ram /usr/sbin/unshare --user /usr/bin/id
echo CHROOT_USERNS_EXIT=$?
''')
    result += guest('''exec 2>&1
echo GUEST_USERNS
unshare --user /usr/bin/id
echo GUEST_USERNS_EXIT=$?
echo CONSOLE_EARLY_LOG
journalctl -b --no-pager _COMM=systemd-vconsol -n 15
ls /dev/vcs* /dev/tty1 2>/dev/null || true
''')
    result += run('grep -iE "vconsole|console|keymap|utf|font|virtual" /tmp/pmos-systemd-nspawn.log | head -n 30')
    (OUT/'namespace-console-audit.txt').write_bytes(result)
    print(result.decode(errors='replace'))
elif stage == 'console-audit':
    result = guest('''exec 2>&1
echo VCONSOLE_DIAGNOSTIC
SYSTEMD_LOG_LEVEL=debug /usr/lib/systemd/systemd-vconsole-setup
echo VCONSOLE_EXIT=$?
echo ZRAM_DRY_RUN
modprobe --dry-run --verbose zram
echo ZRAM_DRY_RUN_EXIT=$?
echo GUEST_BATTERY_DEVICES
ls -ld /sys/class/power_supply /sys/class/power_supply/* 2>/dev/null || true
''')
    result += run('''exec 2>&1
echo OUTER_CONSOLE_DEVICES
ls -l /dev/tty1 /dev/vcs /dev/vcs1 /dev/vcs7 /dev/vcsa* 2>/dev/null || true
echo OUTER_BATTERY_DEVICES
ls -ld /sys/class/power_supply /sys/class/power_supply/* 2>/dev/null || true
''')
    (OUT/'console-battery-audit.txt').write_bytes(result)
    print(result.decode(errors='replace'))
elif stage == 'warning-cleanup':
    result = guest('''export SYSTEMD_COLORS=0 SYSTEMD_PAGER=cat
systemctl reset-failed pja110-audit-userns.service
systemctl is-active greetd.service sshd.service systemd-logind.service rtkit-daemon.service
loginctl list-sessions --no-pager
''')
    (OUT/'after-warning-audit.txt').write_bytes(result)
    print(result.decode(errors='replace'))
elif stage == 'auxiliary':
    result = run('''for f in /proc/[0-9]*/comm; do
 read name < "$f" 2>/dev/null || continue
 test "$name" = rtkit-daemon || continue
 p=${f%/comm}
 echo RTKIT_HOST_PID=${p##*/}
 readlink "$p/root"
 grep -E 'Uid:|Threads:|NSpid:' "$p/status"
 cat "$p/limits" | grep -E 'processes|locked'
done
''')
    (OUT/'rtkit-host.txt').write_bytes(result)
    print(result.decode())
elif stage == 'rtkit-release':
    result = run('''set -e
p=2236
test "$(cat /proc/$p/comm)" = rtkit-daemon
test "$(readlink /proc/$p/ns/pid)" = "$(readlink /proc/1/ns/pid)"
grep -q '^Uid:[[:space:]]*103[[:space:]]' /proc/$p/status
echo 'Stopping stale rtkit in the outer debug environment only'
kill -TERM "$p"
''')
    time.sleep(1)
    result += guest('systemctl reset-failed rtkit-daemon.service; systemctl start rtkit-daemon.service; systemctl is-active rtkit-daemon.service; journalctl -b -u rtkit-daemon --no-pager -n 8')
    (OUT/'rtkit-recovery.txt').write_bytes(result)
    print(result.decode(errors='replace'))
elif stage == 'stop':
    launcher = int(run('cat /tmp/pmos-systemd-nspawn.pid').strip())
    if run(f'if test -d /proc/{launcher}; then echo RUNNING; else echo STOPPED; fi').strip() == b'STOPPED':
        (OUT/f'failed-launch-{int(time.time())}.log').write_bytes(run('cat /tmp/pmos-systemd-nspawn.log'))
        print(run('rm /tmp/pmos-systemd-nspawn.pid; cat /proc/1/comm').decode())
        raise SystemExit(0)
    (OUT/f'before-stop-{int(time.time())}.log').write_bytes(run('cat /tmp/pmos-systemd-nspawn.log'))
    guest('systemctl poweroff', timeout=30)
    for _ in range(30):
        gone = run(f'if test -d /proc/{launcher}; then echo RUNNING; else echo STOPPED; fi').strip()
        if gone == b'STOPPED':
            break
        time.sleep(1)
    else:
        raise RuntimeError('Container shutdown did not finish; leaving rescue SSH intact')
    (OUT/f'shutdown-{int(time.time())}.log').write_bytes(run('cat /tmp/pmos-systemd-nspawn.log'))
    print(run('rm /tmp/pmos-systemd-nspawn.pid; cat /proc/1/comm; cat /proc/sys/kernel/random/boot_id').decode())
elif stage == 'ssh':
    public = (KEYS/'client_key_host.pub').read_text().strip()
    assert public.startswith('ssh-ed25519 ') and '\n' not in public
    setup = ('install -d -m700 -o penguin -g penguin /home/penguin/.ssh; '
             f'printf "%s\\n" {shlex.quote(public)} > /home/penguin/.ssh/authorized_keys; '
             'chown penguin:penguin /home/penguin/.ssh/authorized_keys; '
             'chmod 600 /home/penguin/.ssh/authorized_keys; '
             'cat /etc/ssh/ssh_host_ed25519_key.pub')
    hostkey = guest(setup).decode().strip()
    assert hostkey.startswith('ssh-ed25519 ') and '\n' not in hostkey
    known = OUT/'guest_known_hosts'
    known.write_text('pmos-systemd-ram '+hostkey+'\n', encoding='utf-8')
    pid = int(run('c=$(cat /tmp/pmos-systemd-cgroup); head -n 1 "$c/payload/init.scope/cgroup.procs"').strip())
    proxy = subprocess.list2cmdline(SSH + [f'chroot /tmp/postmarketos-ram /usr/bin/nsenter --target {pid} --net -- /bin/busybox nc 127.0.0.1 22'])
    remote = ('id; cat /proc/1/comm; echo XDG_RUNTIME_DIR=$XDG_RUNTIME_DIR; '
              'systemctl is-active sshd.service dbus.service systemd-logind.service; loginctl list-sessions --no-pager')
    args = [SSH[0], '-F', 'none', '-T', '-i', str(KEYS/'client_key_host'),
            '-o', 'BatchMode=yes', '-o', 'IdentitiesOnly=yes', '-o', 'StrictHostKeyChecking=yes',
            '-o', 'ConnectTimeout=10', '-o', 'HostKeyAlias=pmos-systemd-ram',
            '-o', f'UserKnownHostsFile={known}', '-o', 'ProxyCommand='+proxy,
            'penguin@pmos-systemd-ram', remote]
    p = subprocess.run(args, capture_output=True, timeout=40)
    (OUT/'guest-ssh.txt').write_bytes(p.stdout+p.stderr)
    print((p.stdout+p.stderr).decode(errors='replace'))
    p.check_returncode()
    match = re.search(rb'uid=(\d+)\(penguin\)', p.stdout)
    assert match and int(match[1]) > 0 and b'\nsystemd\n' in p.stdout.replace(b'\r', b'')
elif stage == 'display-stop':
    (OUT/'original-desktop.log').write_bytes(run('cat /tmp/pmos-phosh.log'))
    print(run('''set -e
for f in /proc/[0-9]*/comm; do
 read name < "$f" 2>/dev/null || continue
 test "$name" = phoc || continue
 p=${f%/comm}
 test "$(readlink "$p/root")" = /tmp/postmarketos-ram || continue
 kill -TERM "${p##*/}"
done
''').decode())
    for _ in range(30):
        left = run('''for f in /proc/[0-9]*/comm; do
 read name < "$f" 2>/dev/null || continue
 test "$name" = phoc || continue
 p=${f%/comm}
 test "$(readlink "$p/root")" = /tmp/postmarketos-ram || continue
 echo "${p##*/}"
done''').strip()
        if not left:
            print('Original compositor stopped; rescue SSH remains active')
            break
        time.sleep(.5)
    else:
        raise RuntimeError('Original compositor has not exited; refuse duplicate DRM master')
else:
    raise SystemExit('Unknown stage')


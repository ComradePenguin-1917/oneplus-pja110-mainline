#!/usr/bin/env python3
"""One more non-invasive possibility worth checking, then a clear answer.

There IS a Qualcomm mechanism that exposes a debug UART WITHOUT opening the
phone: the USB-C "debug accessory mode" / EUD (Embedded USB Debugger). On many
Snapdragon designs the SoC routes a debug UART onto the Type-C SBU1/SBU2 pins,
and a passive adapter cable reaches it.

For it to apply here we would expect to find, somewhere in the vendor tree, a
typec/BC1.2/PD node with a "debug accessory" or SBU pinmux, or an EUD node.

Let me check for all of those, plus whether the SoC even has the EUD block
wired on this board. Then give a straight answer.
"""
import os
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
sys.path.insert(0, os.path.join(WS, 'tools'))
from fdt import FDT


def dec(v):
    return v.rstrip(b'\0').decode('ascii', 'replace')


live = FDT(open(os.path.join(WS, 'live-from-device.dtb'), 'rb').read()).nodes()
ours = FDT(open(os.path.join(WS, 'dts', 'sm8550-oneplus-xigua-16G.dtb'), 'rb').read()).nodes()

print('=' * 78)
print('1) EUD (Embedded USB Debugger) -- Qualcomm debug-accessory path')
print('=' * 78)
for name, nodes in (('vendor live tree', live), ('our DTB', ours)):
    hits = [p for p in nodes if 'eud' in p.lower()]
    print('  %-18s %s' % (name, hits or 'NO EUD NODE'))

print()
print('=' * 78)
print('2) TYPEC / PD / BC1.2 nodes (would host an SBU debug mux)')
print('=' * 78)
for key in ('pmic-glink', 'typec', 'pd@', 'tcpc', 'bc12', 'usb-role-switch',
            'role-switch', 'ucsi'):
    hits_l = [p for p in live if key in p.lower()]
    hits_o = [p for p in ours if key in p.lower()]
    print('  %-18s vendor=%-3d ours=%-3d %s'
          % (key, len(hits_l), len(hits_o), (hits_l[0][:46] if hits_l else '')))

print()
print('=' * 78)
print('3) HOW MANY PINS DOES THE CONSOLE USE, AND ARE THEY USED ELSEWHERE?')
print('=' * 78)
print('  console UART pins: gpio26 (TX), gpio27 (RX)')
print()
print('  any OTHER function claiming gpio26/gpio27 in either tree?')
for name, nodes in (('vendor', live), ('ours', ours)):
    claims = []
    for p, props in nodes.items():
        pins = props.get('pins')
        if not pins:
            continue
        s = dec(pins)
        if 'gpio26' in s or 'gpio27' in s:
            fn = dec(props.get('function', b''))
            claims.append((p, s, fn))
    print('  --- %s: %d claimant(s)' % (name, len(claims)))
    for p, s, fn in claims:
        print('      %-58s pins=%-14s fn=%s' % (p[:58], s, fn))

print()
print('=' * 78)
print('ANSWER')
print('=' * 78)
print('  Everything points the same way:')
print()
print('    * the console is TX=gpio26 / RX=gpio27, plain TLMM balls')
print('    * NO EUD node, so no Qualcomm debug-accessory path is wired up')
print('    * NO typec / SBU debug mux anywhere')
print('    * no debug-connector or external-pad node in either tree')
print('    * the Ace 2 Pro has no 3.5 mm jack, so UART-over-jack is impossible')
print()
print('  A Type-C "debug cable" only works when the board muxes a UART onto the')
print('  SBU pins. Nothing here does that, so such a cable is very unlikely to')
print('  produce anything on this model.')
print()
print('  => YES: attaching a UART here means opening the phone and finding the test')
print('     pads, which on OnePlus SM8550 boards are two small points near the')
print('     mainboard edge, usually labelled TX/RX/GND.')
print()
print('  A useful precedent check before you open anything: the OnePlus 12R/Ace 3')
print('  (aston) is the same SM8550 family with the same OPPO ABL, and its port is')
print('  public -- if its author documented the pads, this board may match.')
print('  But note their port never needed UART: they boot by putting the DTB in the')
print('  boot image and relying on USB gadget, exactly the route we have been')
print('  trying. So a working aston port is evidence that UART is NOT required.')

"""Stage checked vendor_boot candidate and guarded sudo installer; no raw writes."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'out/battery-bringup-20261016'
BASE = ROOT/'out/native-install-20261016'
SSH = ['C:/Windows/System32/OpenSSH/ssh.exe', '-F', 'none', '-T', '-i',
       str(ROOT/'out/usb-ncm-20261013/ssh/client_key_host'), '-o', 'BatchMode=yes',
       '-o', 'IdentitiesOnly=yes', '-o', 'StrictHostKeyChecking=yes', '-o',
       f'UserKnownHostsFile={BASE/"first-native-boot/known_hosts"}', '-o',
       'ConnectTimeout=6', 'penguin@172.16.42.1']

def run(command, data=None, timeout=60):
    p = subprocess.run(SSH+[command], input=data, capture_output=True, timeout=timeout)
    p.check_returncode()
    return p.stdout

manifest = json.loads((OUT/'candidate.json').read_text())
candidate = (OUT/'vendor_boot_a-battery.img').read_bytes()
assert hashlib.sha256(candidate).hexdigest() == manifest['candidate_sha256']
state = run('uname -r; cat /proc/1/comm; cat /proc/sys/kernel/random/boot_id; df -k /home/penguin; modinfo bq27xxx_battery_i2c | head -n 8')
assert b'6.14.0-oneplus-xigua' in state and b'\nsystemd\n' in state
(OUT/'stage-system.txt').write_bytes(state)
remote = '/home/penguin/battery-candidate'
actual = run(f'mkdir -p {remote}; cat > {remote}/vendor_boot_a.img; sha256sum {remote}/vendor_boot_a.img', candidate)
assert actual.decode().split()[0] == manifest['candidate_sha256']
backups = json.loads((BASE/'backup-verification.json').read_text())
script = '''#!/bin/sh
set -eu
test "$(id -u)" = 0
test "$(uname -r)" = 6.14.0-oneplus-xigua
test "$(cat /proc/1/comm)" = systemd
test "$(cat /sys/bus/platform/devices/1d84000.ufshc/attributes/boot_lun_enabled)" = 0x00000001
cd /home/penguin/battery-candidate
test "$(sha256sum vendor_boot_a.img | cut -d ' ' -f 1)" = CANDIDATE
target=
for entry in /sys/class/block/sd*/uevent; do
 if grep -qx 'PARTNAME=vendor_boot_a' "$entry"; then
  test -z "$target"
  target=/dev/$(sed -n 's/^DEVNAME=//p' "$entry")
 fi
done
test -n "$target"
test "$(blockdev --getsize64 "$target")" = 201326592
test "$(sha256sum "$target" | cut -d ' ' -f 1)" = ORIGINAL
test ! -e write-started
'''.replace('CANDIDATE', manifest['candidate_sha256']).replace('ORIGINAL', manifest['base_sha256'])
checks = []
for name in ('boot_b', 'init_boot_b', 'vendor_boot_b', 'dtbo_b'):
    checks.append(f'test "$(sha256sum /dev/disk/by-partlabel/{name} | cut -d \' \' -f 1)" = {backups[name]["sha256"]}')
script += '\n'.join(checks)+'\n'
script += '''cp "$target" vendor_boot_a-before.img
test "$(sha256sum vendor_boot_a-before.img | cut -d ' ' -f 1)" = ORIGINAL
touch write-started
dd if=vendor_boot_a.img of="$target" bs=4194304 conv=fsync
test "$(sha256sum "$target" | cut -d ' ' -f 1)" = CANDIDATE
'''.replace('ORIGINAL', manifest['base_sha256']).replace('CANDIDATE', manifest['candidate_sha256'])
script += '\n'.join(checks)+'\n'
script += '''echo 'PASS: vendor_boot_a readback verified; all four B startup partitions unchanged' | tee install-result.txt
sync
systemctl reboot
'''
(OUT/'install.sh').write_text(script, newline='\n')
run(f'cat > {remote}/install.sh; chmod 755 {remote}/install.sh', script.encode())
manifest['phone_candidate_staged'] = True
manifest['phone_written'] = False
(OUT/'candidate.json').write_text(json.dumps(manifest, indent=2)+'\n')
print('PASS: candidate uploaded and hash verified; guarded installer staged; no partition writes or reboot performed')

#!/usr/bin/env python3
"""Catch the pstore records in the window before they are cleared.

Evidence that this device IS built to use pstore (from /system/etc/init/hw/init.rc):
    mount pstore pstore /sys/fs/pstore nodev noexec nosuid
    chown system log /sys/fs/pstore
    chown system log /sys/fs/pstore/console-ramoops
    chown system log /sys/fs/pstore/console-ramoops-0
    chown system log /sys/fs/pstore/pmsg-ramoops-0

So the mount points and the expected record names exist. The earlier control read
pstore ~20 s AFTER boot_completed, by which point something may have consumed or
cleared the records.

Plan: panic again, then poll pstore as aggressively as possible from the very
first moment adbd answers, logging a timestamp for each observation. If records
ever appear and then vanish, we have found the cleanup. If they never appear,
the kernel genuinely does not record.
"""
import os
import shutil
import subprocess
import sys
import time

ADB = shutil.which('adb') or r'C:\platform-tools\adb.exe'
SERIAL = 'bc7a542e'
WS = r'H:\WorkSpace\PJA110-Mainline'
LOG = os.path.join(WS, 'out', 'pstore-watch.log')


def run(cmd, timeout=30):
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=timeout)
        return ((r.stdout or b'') + (r.stderr or b'')).decode('utf-8', 'replace')
    except subprocess.TimeoutExpired:
        return ''


def root(cmd, timeout=30):
    return run([ADB, '-s', SERIAL, 'shell', "su -c '%s'" % cmd], timeout)


def plain(cmd, timeout=30):
    return run([ADB, '-s', SERIAL, 'shell', cmd], timeout)


def adb_state():
    out = run([ADB, 'devices'])
    for l in out.splitlines():
        if l.startswith(SERIAL):
            return l.split()[1] if len(l.split()) > 1 else 'unknown'
    return 'absent'


log = open(LOG, 'w', encoding='utf-8')


def note(msg):
    line = '[%s] %s' % (time.strftime('%H:%M:%S'), msg)
    print(line)
    log.write(line + '\n')
    log.flush()


note('=== state before panic ===')
note('slot: %s   kernel: %s' % (plain('getprop ro.boot.slot_suffix').strip(),
                                plain('uname -r').strip()))
note('pstore: %r' % plain('ls /sys/fs/pstore/ 2>&1').strip()[:150])

note('')
note('=== firing sysrq-c (controlled panic) ===')
root('echo c > /proc/sysrq-trigger')

note('')
note('=== polling pstore from the earliest possible moment ===')
start = time.time()
seen_any = False
seen_records = []
for i in range(240):
    st = adb_state()
    if st == 'device':
        # read as fast as possible, and also try the raw kernel path
        listing = plain('ls -la /sys/fs/pstore/ 2>&1')
        names = [l.split()[-1] for l in listing.splitlines()
                 if l.strip() and not l.strip().startswith(('total', 'd'))]
        names = [n for n in names if n not in ('.', '..')]
        boot = plain('getprop sys.boot_completed').strip()
        if names:
            seen_any = True
            for n in names:
                if n not in seen_records:
                    seen_records.append(n)
                    note('  +%.1fs RECORD APPEARED: %s (boot_completed=%s)'
                         % (time.time() - start, n, boot))
                    content = root('cat /sys/fs/pstore/%s 2>/dev/null | head -c 2000' % n)
                    note('    content[:600]: %s' % content.strip()[:600])
        else:
            if i % 10 == 0:
                note('  +%.1fs adb up, pstore empty (boot_completed=%s)'
                     % (time.time() - start, boot))
        if names and boot == '1':
            break
    else:
        if i % 10 == 0:
            note('  +%.1fs adb=%s' % (time.time() - start, st))
    time.sleep(1.5)

note('')
note('=== final ===')
note('records ever seen: %s' % (seen_records or 'NONE'))
note('pstore now: %r' % plain('ls /sys/fs/pstore/ 2>&1').strip()[:200])
note('boot_completed: %s' % plain('getprop sys.boot_completed').strip())

# also check the vendor crash pipelines for anything fresh
note('')
note('=== vendor crash pipelines (may hold the panic instead) ===')
for d in ('/data/vendor/ramdump', '/data/ramdump', '/data/tombstones',
          '/data/vendor/ssr', '/data/vendor/qcom'):
    out = root('ls -lat %s 2>/dev/null | head -5' % d).strip()
    note('--- %s' % d)
    for l in out.splitlines():
        note('    %s' % l[:110])

log.close()
print()
print('log saved -> %s' % LOG)

if seen_records:
    print()
    print('>>> pstore DID contain records; the channel works and something clears it')
else:
    print()
    print('>>> pstore never contained anything, even seconds after the panic')
    print('    => this device does not record panics to pstore in a recoverable way')

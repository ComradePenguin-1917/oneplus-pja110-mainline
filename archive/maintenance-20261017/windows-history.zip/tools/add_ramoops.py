#!/usr/bin/env python3
"""Pin ramoops in OUR DTB at the exact address Android uses, so a panic by our
kernel survives into the fallback Android and becomes readable.

The address, read straight from the running Android kernel's ramoops module
parameters (not guessed):

    mem_address = 51482722304 = 0xBF800000
    mem_size    = 2359296     = 0x240000
    console_size= 262144      = 0x40000
    pmsg_size   = 2097152     = 0x200000

Steps:
  1. verify 0xBF800000 + 0x240000 does not collide with anything else in our
     DTB's reserved-memory, and that it lies inside a /memory region
  2. add a `ramoops` node with a FIXED reg (not alloc-ranges) plus the same
     console/pmsg sizes
  3. keep everything else in the tree byte-identical
"""
import os
import struct
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
sys.path.insert(0, os.path.join(WS, 'tools'))
from fdt import FDT
from fdtwrite import parse, serialise, Node, walk

BASE = 0xBF800000
SIZE = 0x240000
CONSOLE = 0x40000
PMSG = 0x200000

print('=' * 78)
print('1) COLLISION CHECK for 0x%X + 0x%X' % (BASE, SIZE))
print('=' * 78)

src = os.path.join(WS, 'dts', 'sm8550-oneplus-xigua-16G.dtb')
root, rsvmap = parse(open(src, 'rb').read())
nodes = dict(walk(root))


def regs_of(node):
    r = node.get('reg')
    if not r:
        return []
    out = []
    for i in range(0, len(r) - 15, 16):
        out.append(struct.unpack_from('>QQ', r, i))
    return out


lo, hi = BASE, BASE + SIZE
inside = False
print('  /memory regions:')
for p, n in nodes.items():
    if p.startswith('/memory'):
        for b, s in regs_of(n):
            if s:
                mark = ''
                if b <= lo and hi <= b + s:
                    mark = '   <== CONTAINS our ramoops'
                    inside = True
                print('    0x%011x + 0x%-10x%s' % (b, s, mark))
print()
print('  our ramoops lies inside a /memory region: %s' % inside)

print()
print('  reserved-memory overlaps:')
clash = 0
for p, n in nodes.items():
    if not p.startswith('/reserved-memory/'):
        continue
    for b, s in regs_of(n):
        if s and not (hi <= b or b + s <= lo):
            print('    CLASH %-52s 0x%x+0x%x' % (p.split('/')[-1][:52], b, s))
            clash += 1
if not clash:
    print('    none')
print()
print('  verdict: %s' % ('SAFE to place ramoops here' if (inside and not clash)
                          else 'NOT SAFE'))

if not (inside and not clash):
    sys.exit(1)

print()
print('=' * 78)
print('2) ADD the ramoops node to our DTB')
print('=' * 78)
rm = None
for p, n in nodes.items():
    if p == '/reserved-memory':
        rm = n
        break
if rm is None:
    sys.exit('no /reserved-memory node in our tree')

existing = [c.name for c in rm.children]
print('  /reserved-memory currently has %d children' % len(existing))
if any('ramoops' in c for c in existing):
    print('  a ramoops child already exists; will not duplicate')
else:
    node = Node('ramoops@%x' % BASE)
    # fixed placement, mirroring Android's own parameters
    node.set('compatible', b'ramoops\0')
    node.set('reg', struct.pack('>4I', BASE >> 32, BASE & 0xffffffff,
                                SIZE >> 32, SIZE & 0xffffffff))
    node.set('console-size', struct.pack('>I', CONSOLE))
    node.set('pmsg-size', struct.pack('>I', PMSG))
    node.set('record-size', struct.pack('>I', 0))
    node.set('mem-type', struct.pack('>I', 2))
    node.set('no-map', b'')
    rm.children.append(node)
    print('  added /reserved-memory/ramoops@%x' % BASE)

out = serialise(root, rsvmap)
dst = os.path.join(WS, 'out', 'xigua-with-ramoops.dtb')
open(dst, 'wb').write(out)

print()
print('=' * 78)
print('3) VERIFY')
print('=' * 78)
n2 = dict(walk(parse(out)[0]))
hit = [p for p in n2 if 'ramoops' in p.lower()]
print('  ramoops node present : %s' % hit)
if hit:
    node = n2[hit[0]]
    for k in ('compatible', 'reg', 'console-size', 'pmsg-size', 'mem-type'):
        v = node.get(k)
        if v is None:
            print('    %-14s (absent)' % k)
        elif k == 'reg':
            print('    %-14s %s' % (k, ' '.join('0x%x' % x for x in struct.unpack('>4I', v))))
        elif len(v) == 4:
            print('    %-14s 0x%x' % (k, struct.unpack('>I', v)[0]))
        else:
            print('    %-14s %r' % (k, v))
print()
print('  size  : %d -> %d' % (os.path.getsize(src), len(out)))
print('  labels: %d' % len(n2.get('/__symbols__').props) if n2.get('/__symbols__') else 'n/a')
print()
print('wrote %s' % dst)
print()
print('=' * 78)
print('4) HOW THIS EARNS US A REAL LOG')
print('=' * 78)
print('  1. flash this DTB into vendor_boot entry0, our kernel into boot_b')
print('  2. boot slot B: our kernel writes any panic into 0x%X' % BASE)
print('  3. it fails, ABL falls back to slot A whose Android kernel maps the')
print('     SAME address as its own ramoops')
print('  4. read /sys/fs/pstore on Android -> our kernel panic text')
print()
print('  Requirement: the Android kernel must not wipe that window on boot.')
print('  It is a *reserved* region, so it should be left alone -- which is the')
print('  entire point of ramoops.')

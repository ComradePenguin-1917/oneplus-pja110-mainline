#!/usr/bin/env python3
"""Redo the ramoops placement with the CORRECT address.

My previous attempt used 0xBF800000, which I had mis-converted from the decimal
51482722304. That value is actually 0xBFC9C0000 (~51.5 GiB), whereas 0xBF800000
is ~3.2 GiB -- and with 16 GiB of RAM, 3.2 GiB is a plausible-looking address
that is nonetheless NOT where Android puts ramoops. Writing there would land in
ordinary usable RAM, so nothing would persist into pstore.

Correct values, straight from the running kernel:
    mem_address  = 51482722304 = 0xBFC9C0000
    mem_size     = 2359296    = 0x240000
    console_size = 262144     = 0x40000
    pmsg_size    = 2097152    = 0x200000

This script re-verifies everything in hex (not by eye) and rebuilds the DTB.
"""
import os
import struct
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
sys.path.insert(0, os.path.join(WS, 'tools'))
from fdt import FDT
from fdtwrite import parse, serialise, Node, walk

# read them as numbers, never by eyeballing hex
DEC_ADDR = 51482722304
DEC_SIZE = 2359296
DEC_CONS = 262144
DEC_PMSG = 2097152

BASE = DEC_ADDR
SIZE = DEC_SIZE
CONSOLE = DEC_CONS
PMSG = DEC_PMSG

print('=' * 78)
print('ADDRESS DERIVATION (verify by arithmetic, not by eye)')
print('=' * 78)
print('  %-14s %-14s %s' % ('field', 'decimal', 'hex'))
print('  %-14s %-14d 0x%X' % ('mem_address', DEC_ADDR, DEC_ADDR))
print('  %-14s %-14d 0x%X' % ('mem_size', DEC_SIZE, DEC_SIZE))
print('  %-14s %-14d 0x%X' % ('console_size', DEC_CONS, DEC_CONS))
print('  %-14s %-14d 0x%X' % ('pmsg_size', DEC_PMSG, DEC_PMSG))
print()
print('  ramoops window: 0x%X .. 0x%X' % (BASE, BASE + SIZE))
print('  (my earlier wrong value was 0x%X -- %.2f GiB, not in this window at all)'
      % (0xBF800000, 0xBF800000 / 2**30))

src = os.path.join(WS, 'dts', 'sm8550-oneplus-xigua-16G.dtb')
root, rsvmap = parse(open(src, 'rb').read())

# drop any previously added wrong ramoops node
rm = None
for p, n in walk(root):
    if p == '/reserved-memory':
        rm = n
        break
if rm is None:
    sys.exit('no /reserved-memory')

before = len(rm.children)
rm.children = [c for c in rm.children if 'ramoops' not in c.name]
print()
print('  removed %d stale ramoops node(s) from /reserved-memory'
      % (before - len(rm.children)))

print()
print('=' * 78)
print('COLLISION CHECK for the CORRECT window')
print('=' * 78)
nodes = dict(walk(root))
lo, hi = BASE, BASE + SIZE
inside = False
for p, n in nodes.items():
    if p.startswith('/memory'):
        r = n.get('reg')
        if not r:
            continue
        for i in range(0, len(r) - 15, 16):
            b, s = struct.unpack_from('>QQ', r, i)
            if s and b <= lo and hi <= b + s:
                inside = True
print('  inside a /memory region : %s' % inside)

clash = 0
for p, n in nodes.items():
    if not p.startswith('/reserved-memory/'):
        continue
    r = n.get('reg')
    if not r:
        continue
    for i in range(0, len(r) - 15, 16):
        b, s = struct.unpack_from('>QQ', r, i)
        if s and not (hi <= b or b + s <= lo):
            print('  CLASH %-50s 0x%X+0x%X' % (p.split('/')[-1][:50], b, s))
            clash += 1
print('  clashes                 : %d' % clash)

if not inside or clash:
    print()
    print('  -> not safe to use this window as-is; inspect the memory map.')
    sys.exit(1)

print()
print('=' * 78)
print('ADD ramoops AT THE CORRECT ADDRESS')
print('=' * 78)
node = Node('ramoops@%x' % BASE)
node.set('compatible', b'ramoops\0')
node.set('reg', struct.pack('>4I', BASE >> 32, BASE & 0xffffffff,
                            SIZE >> 32, SIZE & 0xffffffff))
node.set('console-size', struct.pack('>I', CONSOLE))
node.set('pmsg-size', struct.pack('>I', PMSG))
node.set('record-size', struct.pack('>I', 0))
node.set('mem-type', struct.pack('>I', 2))
node.set('no-map', b'')
rm.children.append(node)
print('  added /reserved-memory/ramoops@%x' % BASE)

out = serialise(root, rsvmap)
dst = os.path.join(WS, 'out', 'xigua-with-ramoops.dtb')
open(dst, 'wb').write(out)

# verify by re-reading the NUMBER back
n2 = dict(walk(parse(out)[0]))
hit = [p for p in n2 if 'ramoops' in p.lower()]
print()
print('=' * 78)
print('VERIFY (parse the value back and compare numerically)')
print('=' * 78)
print('  node: %s' % hit)
if hit:
    n = n2[hit[0]]
    a, b, c, d = struct.unpack('>4I', n.get('reg'))
    got_base = (a << 32) | b
    got_size = (c << 32) | d
    print('  reg   -> base=0x%X size=0x%X' % (got_base, got_size))
    print('  base matches Android: %s' % (got_base == DEC_ADDR))
    print('  size matches Android: %s' % (got_size == DEC_SIZE))
    if got_base != DEC_ADDR or got_size != DEC_SIZE:
        sys.exit('verification failed')
print('  size: %d -> %d bytes' % (os.path.getsize(src), len(out)))
print()
print('wrote %s' % dst)

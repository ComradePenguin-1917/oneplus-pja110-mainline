/* EGL device pbuffer rendering with pixel readback, without a desktop. */
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
typedef void *Handle;
typedef unsigned int U;
typedef int I;
#define FN(ret,name,args) static ret (*name) args
FN(I,eglGetError,(void));
FN(I,eglInitialize,(Handle,I*,I*));
FN(I,eglBindAPI,(U));
FN(I,eglChooseConfig,(Handle,const I*,Handle*,I,I*));
FN(Handle,eglCreatePbufferSurface,(Handle,Handle,const I*));
FN(Handle,eglCreateContext,(Handle,Handle,Handle,const I*));
FN(I,eglMakeCurrent,(Handle,Handle,Handle,Handle));
FN(I,eglTerminate,(Handle));
FN(void*,eglGetProcAddress,(const char*));
FN(const unsigned char*,glGetString,(U));
FN(void,glClearColor,(float,float,float,float));
FN(void,glClear,(U));
FN(void,glReadPixels,(I,I,I,I,U,U,void*));
FN(void,glFinish,(void));
FN(U,glGetError,(void));
FN(U,glCreateShader,(U));
FN(void,glShaderSource,(U,I,const char*const*,const I*));
FN(void,glCompileShader,(U));
FN(void,glGetShaderiv,(U,U,I*));
FN(U,glCreateProgram,(void));
FN(void,glAttachShader,(U,U));
FN(void,glLinkProgram,(U));
FN(void,glGetProgramiv,(U,U,I*));
FN(void,glUseProgram,(U));
FN(I,glGetAttribLocation,(U,const char*));
FN(void,glVertexAttribPointer,(U,I,U,unsigned char,I,const void*));
FN(void,glEnableVertexAttribArray,(U));
FN(void,glDrawArrays,(U,I,I));
FN(void,glViewport,(I,I,I,I));
#define LOAD(lib,n) do { *(void**)(&n)=dlsym(lib,#n); if(!n){fprintf(stderr,"missing %s\n",#n);return 1;} } while(0)
static void check(I ok,const char *what){if(!ok){fprintf(stderr,"%s EGL=0x%x\n",what,eglGetError());exit(2);}}
static U shader(U type,const char *src){U s=glCreateShader(type);I ok;glShaderSource(s,1,&src,NULL);glCompileShader(s);glGetShaderiv(s,0x8b81,&ok);if(!ok){fprintf(stderr,"shader compile failed\n");exit(3);}return s;}
int main(void){
    setbuf(stdout,NULL);
    void *e=dlopen("libEGL.so.1",RTLD_NOW|RTLD_GLOBAL),*g=dlopen("libGLESv2.so.2",RTLD_NOW|RTLD_GLOBAL);
    if(!e||!g){fprintf(stderr,"dlopen: %s\n",dlerror());return 1;}
    LOAD(e,eglGetError);LOAD(e,eglInitialize);LOAD(e,eglBindAPI);LOAD(e,eglChooseConfig);
    LOAD(e,eglCreatePbufferSurface);LOAD(e,eglCreateContext);LOAD(e,eglMakeCurrent);LOAD(e,eglGetProcAddress);LOAD(e,eglTerminate);
    LOAD(g,glGetString);LOAD(g,glClearColor);LOAD(g,glClear);LOAD(g,glReadPixels);LOAD(g,glFinish);LOAD(g,glGetError);
    LOAD(g,glCreateShader);LOAD(g,glShaderSource);LOAD(g,glCompileShader);LOAD(g,glGetShaderiv);
    LOAD(g,glCreateProgram);LOAD(g,glAttachShader);LOAD(g,glLinkProgram);LOAD(g,glGetProgramiv);LOAD(g,glUseProgram);
    LOAD(g,glGetAttribLocation);LOAD(g,glVertexAttribPointer);LOAD(g,glEnableVertexAttribArray);LOAD(g,glDrawArrays);LOAD(g,glViewport);
    I (*query)(I,Handle*,I*)=eglGetProcAddress("eglQueryDevicesEXT");
    Handle (*platform)(U,Handle,const I*)=eglGetProcAddress("eglGetPlatformDisplayEXT");
    const char*(*devstr)(Handle,I)=eglGetProcAddress("eglQueryDeviceStringEXT");
    if(!query||!platform)return 2;
    Handle devices[8],display=NULL;I count=0,major,minor;
    check(query(8,devices,&count),"query devices");
    for(I i=0;i<count;i++){
        const char *path=devstr?devstr(devices[i],0x3377):NULL;
        printf("EGL_DEVICE_%d_RENDER_NODE=%s\n",i,path?path:"none");
        if(path&&strstr(path,"renderD128"))display=platform(0x313f,devices[i],NULL);
    }
    check(display!=NULL,"select hardware device");check(eglInitialize(display,&major,&minor),"initialize");
    printf("EGL_VERSION=%d.%d\n",major,minor);check(eglBindAPI(0x30a0),"bind GLES");
    const I attrs[]={0x3033,1,0x3040,4,0x3024,8,0x3023,8,0x3022,8,0x3021,8,0x3038};
    Handle config;I n;check(eglChooseConfig(display,attrs,&config,1,&n)&&n,"config");
    const I pa[]={0x3057,64,0x3056,64,0x3038},ca[]={0x3098,2,0x3038};
    Handle surface=eglCreatePbufferSurface(display,config,pa),ctx=eglCreateContext(display,config,NULL,ca);
    check(surface&&ctx,"create pbuffer/context");check(eglMakeCurrent(display,surface,surface,ctx),"make current");
    const char *renderer=(const char*)glGetString(0x1f01);
    printf("GL_VENDOR=%s\nGL_RENDERER=%s\nGL_VERSION=%s\n",glGetString(0x1f00),renderer,glGetString(0x1f02));
    if(!renderer||(!strstr(renderer,"FD740")&&!(strstr(renderer,"Adreno")&&strstr(renderer,"740"))))return 4;
    glViewport(0,0,64,64);
    const unsigned char colors[][4]={{255,0,0,255},{0,255,0,255},{0,0,255,255},{255,255,255,255}};
    unsigned char pixels[64*64*4];
    for(I k=0;k<4;k++){
        glClearColor(colors[k][0]/255.f,colors[k][1]/255.f,colors[k][2]/255.f,1);glClear(0x4000);glFinish();
        glReadPixels(0,0,64,64,0x1908,0x1401,pixels);
        for(I p=0;p<64*64;p++)if(memcmp(pixels+p*4,colors[k],4)){fprintf(stderr,"clear mismatch %d/%d\n",k,p);return 5;}
    }
    U vs=shader(0x8b31,"attribute vec2 pos; void main(){gl_Position=vec4(pos,0.,1.);}");
    U fs=shader(0x8b30,"precision mediump float; void main(){gl_FragColor=vec4(1.,0.,1.,1.);}");
    U prog=glCreateProgram();I ok;glAttachShader(prog,vs);glAttachShader(prog,fs);glLinkProgram(prog);glGetProgramiv(prog,0x8b82,&ok);if(!ok)return 6;glUseProgram(prog);
    float vertices[]={-1,-1,3,-1,-1,3};I loc=glGetAttribLocation(prog,"pos");
    if(loc<0)return 6;
    glVertexAttribPointer(loc,2,0x1406,0,0,vertices);glEnableVertexAttribArray(loc);
    for(I frame=0;frame<120;frame++){
        glClearColor(0,0,0,1);glClear(0x4000);glDrawArrays(4,0,3);glFinish();glReadPixels(0,0,64,64,0x1908,0x1401,pixels);
        for(I p=0;p<64*64;p++)if(pixels[p*4]!=255||pixels[p*4+1]!=0||pixels[p*4+2]!=255||pixels[p*4+3]!=255)return 7;
        if(glGetError())return 8;
    }
    puts("PASS: Adreno 740 hardware EGL/GLES; four color clears and 120 shader-rendered frames pixel-verified");
    eglMakeCurrent(display,NULL,NULL,NULL);eglTerminate(display);return 0;
}

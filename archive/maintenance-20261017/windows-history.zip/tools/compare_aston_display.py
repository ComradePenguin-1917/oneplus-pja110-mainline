"""Pin Aston display pipeline files for comparison against actual build sources."""
import hashlib,json,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/aston-display-comparison-20261014';OUT.mkdir(exist_ok=True)
commit='5d5c840896bb49291ae4578acefd5a3ec65524f6'
paths=['drivers/gpu/drm/msm/disp/dpu1/dpu_plane.c',
       'drivers/gpu/drm/msm/disp/dpu1/dpu_crtc.c',
       'drivers/gpu/drm/msm/disp/dpu1/dpu_hw_sspp.c',
       'drivers/gpu/drm/msm/disp/dpu1/dpu_hw_dsc_1_2.c',
       'drivers/gpu/drm/msm/disp/dpu1/catalog/dpu_9_0_sm8550.h',
       'drivers/gpu/drm/msm/dsi/dsi_host.c',
       'drivers/gpu/drm/msm/msm_fb.c',
       'drivers/gpu/drm/msm/msm_gem.c']
paths += ['drivers/gpu/drm/msm/disp/dpu1/'+name for name in
          ('dpu_hw_catalog.c','dpu_hw_catalog.h','dpu_hw_ctl.c','dpu_hw_ctl.h',
           'dpu_rm.c','dpu_rm.h','dpu_encoder.c','dpu_encoder_phys_cmd.c',
           'dpu_hw_mdss.h','dpu_hw_sspp.h')]
records=[]
for path in paths:
    url=f'https://raw.githubusercontent.com/jiganomegsdfdf/aston-mainline/{commit}/{path}'
    target=OUT/'aston'/path;target.parent.mkdir(parents=True,exist_ok=True)
    data=target.read_bytes() if target.exists() else urllib.request.urlopen(url,timeout=45).read()
    target.write_bytes(data)
    records.append(dict(path=path,sha256=hashlib.sha256(data).hexdigest(),url=url))
(OUT/'manifest.json').write_text(json.dumps(dict(commit=commit,files=records),indent=2)+'\n')
print('PASS: pinned Aston display pipeline sources downloaded')

#!/bin/bash
# DECISIVE TEST: is the boot.img cmdline merged into the kernel's cmdline, or
# discarded in favour of one ABL builds itself?
#
# Method: use the STOCK kernel (boots fine) and give it a UNIQUE marker token in
# the boot.img cmdline. After it boots Android, read /proc/cmdline.
#   * marker present  -> boot.img cmdline IS merged -> we can control
#     console=/earlycon, which is our only hope of output
#   * marker absent   -> ABL discards it -> we must find another channel
#
# This is observable, unlike our own kernel, and changes nothing on the device.
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
OUT="$ROOT/out"
WIN="/mnt/h/WorkSpace/PJA110-Mainline"

MARKER="xiguaprobe=hello123 console=ttyMSM0,115200 loglevel=8 earlycon"
echo "marker cmdline: $MARKER"

cp "$OUT/stock-kernel.bin" "$OUT/probe-kernel.bin"

cd "$WIN"
python3 tools/bootimg.py pack \
    --kernel "$OUT/probe-kernel.bin" \
    --stock boot-A14.img \
    --cmdline "$MARKER" \
    -o "$OUT/probe-cmdline.img"

echo
ls -l "$OUT/probe-cmdline.img"
echo
echo "=== read back what we packed ==="
python3 - "$OUT/probe-cmdline.img" <<'PY'
import struct, sys
b = open(sys.argv[1],'rb').read()
print('  cmdline in image: %r' % b[44:44+1536].rstrip(b'\0').decode())
PY

"""Read-only local audit of Image headers and reserved physical ranges."""
from pathlib import Path
import gzip
import json
import struct
from bootimg import BootImage
from fdt import FDT

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'out/arm64-handoff-audit-20261012'
OUT.mkdir(exist_ok=True)
headers = {}
for label, name in [('stock', 'backup/boot_b.img'),
                    ('mainline', 'out/rebuild-20261012/boot-xigua-r1.img')]:
    image = BootImage.parse(str(ROOT / name)).kernel
    compression = 'raw'
    if image[:2] == b'\x1f\x8b':
        image = gzip.decompress(image)
        compression = 'gzip'
    assert image[56:60] == b'ARM\x64', label
    offset, size, flags = struct.unpack_from('<QQQ', image, 8)
    headers[label] = {'compression': compression, 'file_bytes': len(image),
                      'text_offset': offset, 'image_size': size, 'flags': flags,
                      'placement_anywhere_flag': bool(flags & 8),
                      'first_instructions': image[:8].hex()}

def ranges(path):
    result = []
    for name, props in FDT(path.read_bytes()).nodes().items():
        if name.startswith('/reserved-memory/') and 'reg' in props:
            reg = props['reg']
            if len(reg) % 16:
                continue
            for off in range(0, len(reg), 16):
                start, size = struct.unpack_from('>QQ', reg, off)
                result.append({'path': name, 'start': start, 'size': size,
                               'no_map': 'no-map' in props})
    return result

stock = ranges(ROOT / 'out/boot-chain-audit-20261012/live-fdt.dtb')
mainline = ranges(ROOT / 'out/usb2-control-20261012/usb2-control.dtb')
key = lambda r: (r['start'], r['size'])
old = {key(r): r for r in stock}
new = {key(r): r for r in mainline}
report = {'image_headers': headers,
          'mainline_only_reserved_ranges': [r for k, r in new.items() if k not in old],
          'stock_only_reserved_ranges': [r for k, r in old.items() if k not in new],
          'no_map_differences': [{'stock': old[k], 'mainline': new[k]}
                                 for k in new.keys() & old.keys()
                                 if new[k]['no_map'] != old[k]['no_map']],
          'actual_kernel_load_address_known': False}
(OUT / 'result.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report, indent=2))

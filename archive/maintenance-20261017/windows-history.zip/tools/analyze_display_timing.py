"""Summarize tracepoint timing without treating IRQ latency as panel scan time."""
import argparse,bisect,json,re,statistics
from collections import defaultdict
from pathlib import Path
OUT=Path(__file__).resolve().parents[1]/'out/display-timing-20261014/runtime'
parser=argparse.ArgumentParser()
parser.add_argument('--label', choices=('repaint1', 'repaint7', 'ruler-single'))
args=parser.parse_args()
if args.label:
 OUT=OUT/args.label
events=defaultdict(list)
wait_failures=[]
for line in (OUT/'frame-events.txt').read_text().splitlines():
 m=re.search(r'\s(\d+\.\d+): (\w+): (.*)',line)
 if m:
  events[m[2]].append(float(m[1]))
  if m[2]=='tracing_mark_write':
   marker=re.fullmatch(r'B\|\d+\|(\w+)',m[3])
   if marker:events['irq_or_scope_'+marker[1]].append(float(m[1]))
  if m[2]=='dpu_enc_wait_event_timeout':
   rc=re.search(r'rc=(-?\d+)',m[3])
   if rc and int(rc[1])<=0:wait_failures.append(line)
def stats(values):
 v=sorted(values)
 return {'count':len(v),'min_ms':v[0]*1000,'median_ms':statistics.median(v)*1000,
         'p95_ms':v[int((len(v)-1)*.95)]*1000,'max_ms':v[-1]*1000} if v else None
def since_previous(ends,starts):
 vals=[]
 for t in ends:
  i=bisect.bisect_right(starts,t)-1
  if i>=0:vals.append(t-starts[i])
 return vals
te=events['dpu_crtc_vblank_cb']
done=events['dpu_enc_phys_cmd_pp_tx_done']
kick=events['dpu_enc_trigger_start']
result={'event_counts':{k:len(v) for k,v in events.items()},
 'wait_events_with_nonpositive_rc':len(wait_failures),
 'te_irq_intervals':stats([b-a for a,b in zip(te,te[1:])]),
 'completion_irq_intervals':stats([b-a for a,b in zip(done,done[1:])]),
 'completion_since_previous_trigger':stats(since_previous(done,kick)),
 'completion_since_previous_te':stats(since_previous(done,te)),
 'trigger_since_previous_te':stats(since_previous(kick,te)),
 'caveat':'Software trigger and IRQ timestamps include scheduling and IRQ latency; they do not directly measure physical TE phase or panel scan.',
 'root_cause_confirmed':False}
rd=events['irq_or_scope_rd_ptr_irq']
pp=events['irq_or_scope_pp_done_irq']
ctl=events['irq_or_scope_ctl_start_irq']
result.update(rd_pointer_irq_intervals=stats([b-a for a,b in zip(rd,rd[1:])]),
              pp_done_since_previous_rd_pointer=stats(since_previous(pp,rd)),
              pp_done_since_previous_ctl_start=stats(since_previous(pp,ctl)))
(OUT/'timing-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

"""Populate local firmware/verified DTB and checksum the APKBUILD sources."""
import gzip,hashlib,json,struct,sys,re
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from build_init_marker_test import parse_cpio
ROOT=Path(__file__).resolve().parents[1]
base=ROOT/'postmarketos/device/testing'
entries=parse_cpio(gzip.decompress((ROOT/'out/display-timing-20261014/initramfs-trace.cpio.gz').read_bytes()))
mapping={n.removeprefix('./'):d for f,n,d in entries}
firm=base/'firmware-oneplus-xigua-adreno'
for dest,src in [('a740_sqe.fw','lib/firmware/qcom/a740_sqe.fw'),('gmu_gen70200.bin','lib/firmware/qcom/gmu_gen70200.bin'),('a740_zap.mbn','lib/firmware/qcom/sm8550/xigua/a740_zap.mbn')]:
 (firm/dest).write_bytes(mapping[src])
vendor=ROOT/'out/gpu-port-20261014/vendor_boot_b-gpu.img'
blob=vendor.read_bytes()
verified=json.loads((ROOT/'out/drm-shutdown-20261014/kernel/after.json').read_text())
assert hashlib.sha256(blob).hexdigest()==verified['vendor_boot_b']
align=lambda n:(n+4095)//4096*4096
offset=align(align(struct.unpack_from('<I',blob,2096)[0])+struct.unpack_from('<I',blob,24)[0])
size=struct.unpack_from('>I',blob,offset+4)[0]
dtb=blob[offset:offset+size];assert dtb[:4]==b'\xd0\x0d\xfe\xed'
(base/'device-oneplus-xigua/verified-vendor.dtb').write_bytes(dtb)
km=json.loads((base/'linux-oneplus-xigua/source-manifest.json').read_text())
for folder,names in [('device-oneplus-xigua',['deviceinfo','kernel-cmdline.conf','modules-initfs','modules-load.conf','modprobe.conf','initfs-files','verified-vendor.dtb','phoc.ini']),
 ('linux-oneplus-xigua',['linux-6.14.tar.xz','pja110-kernel-overlay.tar.gz','config-oneplus-xigua.aarch64']),
 ('firmware-oneplus-xigua-adreno',['a740_sqe.fw','gmu_gen70200.bin','a740_zap.mbn'])]:
 lines=[]
 for name in names:
  digest=km['base_sha512'] if name=='linux-6.14.tar.xz' else hashlib.sha512((base/folder/name).read_bytes()).hexdigest()
  lines.append(digest+'  '+name)
 path=base/folder/'APKBUILD';text=path.read_text()
 text=re.sub(r'\nsha512sums="[\s\S]*?"\n?$', '\n',text)
 path.write_text(text+'\nsha512sums="\n'+'\n'.join(lines)+'\n"\n',newline='\n')
manifest={'reference_pmaports_commit':json.loads((ROOT/'out/postmarketos-reference-20261014/manifest.json').read_text())['commit'],
 'kernel_hardware_reference':'#24','device_package_hardware_booted':False,
 'flash_method':'none','auto_kernel_flash':False,'vendor_boot_sha256':verified['vendor_boot_b'],
 'verified_dtb_sha256':hashlib.sha256(dtb).hexdigest(),'firmware_source':'locally verified PJA110 initramfs','firmware_redistribution_authorized':False,
 'packages':['device-oneplus-xigua','linux-oneplus-xigua','firmware-oneplus-xigua-adreno','phoc'],
 'integration_profile':'integration-profile.json'}
(ROOT/'postmarketos/manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Finalized3 local packages; source SHA512 sums and verified vendor DTB retained; no keys exported')

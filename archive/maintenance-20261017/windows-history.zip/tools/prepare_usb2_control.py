"""Make a USB2 peripheral DTB control; keep kernel and both initramfs unchanged."""
import hashlib
import json
import pathlib
import shutil
import struct

from fdt import FDT
from fdtwrite import parse, serialise, walk

ROOT = pathlib.Path(__file__).resolve().parents[1]
BASE = ROOT / 'out/rebuild-20261012'
OUT = ROOT / 'out/usb2-control-20261012'
OUT.mkdir(exist_ok=True)

def sha(b):
    return hashlib.sha256(b).hexdigest()

def main():
    manifest = json.loads((BASE / 'manifest.json').read_text())
    source = (BASE / 'vendor_boot_b-xigua-r1.img').read_bytes()
    assert sha(source) == manifest['files']['vendor_boot_b-xigua-r1.img']['sha256']
    header_size = struct.unpack_from('<I', source, 2096)[0]
    ramdisk_size = struct.unpack_from('<I', source, 24)[0]
    align = lambda n: (n + 4095) // 4096 * 4096
    off = align(align(header_size) + ramdisk_size)
    size = struct.unpack_from('>I', source, off + 4)[0]
    old = source[off:off + size]
    tree, reservations = parse(old)
    nodes = dict(walk(tree))
    core = '/soc@0/usb@a6f8800/usb@a600000'
    phy = '/soc@0/phy@88e8000'
    assert len(nodes[core].props['phys']) == 12
    nodes[core].set('phys', nodes[core].props['phys'][:4])
    nodes[core].set('phy-names', b'usb2-phy\0')
    nodes[core].set('maximum-speed', b'high-speed\0')
    nodes[core].set('dr_mode', b'peripheral\0')
    nodes[core].props.pop('usb-role-switch')
    nodes[core].order.remove('usb-role-switch')
    nodes[phy].set('status', b'disabled\0')
    raw = serialise(tree, reservations)
    assert len(raw) <= size
    padded = bytearray(raw) + b'\0' * (size - len(raw))
    struct.pack_into('>I', padded, 4, size)
    result = bytearray(source)
    result[off:off + size] = padded
    assert result[:off] == source[:off] and result[off + size:] == source[off + size:]
    before, after = FDT(old).nodes(), FDT(bytes(padded)).nodes()
    assert before.keys() == after.keys()
    delta = []
    for path in before:
        for key in sorted(before[path].keys() | after[path].keys()):
            a, b = before[path].get(key), after[path].get(key)
            if a != b:
                delta.append({'node': path, 'property': key, 'before': a.hex() if a is not None else None, 'after': b.hex() if b is not None else None})
    assert {(d['node'], d['property']) for d in delta} == {(core, p) for p in ('phys','phy-names','maximum-speed','dr_mode','usb-role-switch')} | {(phy, 'status')}
    (OUT / 'vendor_boot_b-xigua-r1.img').write_bytes(result)
    (OUT / 'usb2-control.dtb').write_bytes(padded)
    for name in ('boot-xigua-r1.img', 'init_boot_b-xigua-r1.img'):
        shutil.copyfile(BASE / name, OUT / name)
        assert sha((OUT / name).read_bytes()) == manifest['files'][name]['sha256']
    files = ['boot-xigua-r1.img','init_boot_b-xigua-r1.img','vendor_boot_b-xigua-r1.img','usb2-control.dtb']
    evidence = {'release': manifest['release'], 'baseline': '../rebuild-20261012/manifest.json', 'kernel_sha256': manifest['files']['Image']['sha256'], 'logical_variable': 'USB2-only fixed peripheral DTB profile', 'dtb_changes': delta, 'files': {n: {'bytes': (OUT/n).stat().st_size,'sha256': sha((OUT/n).read_bytes())} for n in files}}
    (OUT / 'manifest.json').write_text(json.dumps(evidence, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(evidence, indent=2))

if __name__ == '__main__':
    main()

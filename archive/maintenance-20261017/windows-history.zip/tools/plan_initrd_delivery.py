#!/usr/bin/env python3
"""Build the test variant that removes the biggest unknown.

Problem with "stock kernel + our initramfs in the ramdisk field":
  Android header v4 keeps the generic ramdisk in vendor_boot, and whether ABL
  actually loads the boot.img ramdisk field is UNVERIFIED here. If it does not,
  the test cannot tell us anything about our initramfs.

Fix that needs no ABL cooperation: embed the initramfs in a kernel that we CAN
rebuild. We cannot rebuild the stock kernel, but we do not have to -- we only
need to know whether OUR initramfs executes on this hardware.

The cleanest arrangement that still keeps a KNOWN-GOOD kernel:
  * vendor_boot_b -> VENDOR base tree (restore it) so the stock kernel gets the
    device tree it expects, including the UFS/PHY the overlays would enable
  * dtbo_b        -> RESTORED, because the vendor tree needs its overlays to
    enable UFS (the stock kernel drives that hardware)
  * boot_b        -> stock kernel (known good)
  and then the ramdisk question remains.

So the decisive arrangement for validating our initramfs is actually:
  boot_b <- OUR kernel, because OUR kernel carries the initramfs EMBEDDED and
            therefore does not depend on any ramdisk handoff.
But our kernel does not boot, which is the separate problem.

=> Conclusion: our initramfs can only be validated on this device once our
   kernel boots. The two questions are entangled, and I should stop trying to
   answer the initramfs question with a kernel that never reaches userspace.

What IS worth doing with zero ambiguity: restore slot B to fully STOCK, verify it
boots (it did before), and then use the proven-good vendor_boot dtb-section
channel with OUR initramfs -- because that channel is one we have experimentally
confirmed works.

Wait -- vendor_boot's ramdisk section is the GENERIC ramdisk, and it is a real,
loadable section (we mapped it: 16 MiB at offset 0x1000). THAT is the section
ABL demonstrably consumes. Putting our initramfs there is therefore the one
variant whose delivery mechanism is already proven.
"""
import hashlib
import os
import struct
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
PAGE = 4096


def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''):
            h.update(c)
    return h.hexdigest()


print('=' * 78)
print('THE DELIVERY MECHANISM WE HAVE ALREADY PROVEN')
print('=' * 78)
print('  Proven: changes to vendor_boot ARE consumed by ABL (the inert-node test)')
print('  Proven: vendor_boot has a real 16 MiB ramdisk section that ABL loads')
print()
print('  Therefore: put OUR initramfs into vendor_boot'"'"'s ramdisk section.')
print('  Delivery is then via a section ABL definitely reads, and the kernel that')
print('  unpacks it can be the STOCK one, so no part of the test depends on our')
print('  (still-unbootable) kernel.')
print()

src = os.path.join(WS, 'backup', 'vendor_boot_b.img')
v = bytearray(open(src, 'rb').read())
hsize, dtbsize = struct.unpack_from('<2I', v, 28 + 2048 + 4 + 16)
vrsize = struct.unpack_from('<I', v, 24)[0]
rd_off = ((hsize + PAGE - 1)//PAGE)*PAGE
print('  vendor_boot_b (stock): %d bytes' % len(v))
print('    header_size        : %d' % hsize)
print('    vendor_ramdisk_size: %d (%.2f MiB) at 0x%x' % (vrsize, vrsize/2**20, rd_off))

initrd = open(os.path.join(WS, 'initramfs', 'initramfs.cpio.gz'), 'rb').read()
print('    our initramfs      : %d bytes' % len(initrd))
print()
print('  our initramfs FITS in the ramdisk section: %s' % (len(initrd) <= vrsize))
print('  NOTE: the vendor ramdisk is an Android ramdisk with its own format;')
print('        simply overwriting it with a cpio.gz will break Android boot')
print('        behaviour, but ABL will still pass it to the kernel as the initrd,')
print('        and the kernel will try to unpack it. That is exactly the test:')
print('        does the STOCK kernel end up running OUR /init?')
print()
print('  This rewrites vendor_boot_b only, which is backed up and restorable.')

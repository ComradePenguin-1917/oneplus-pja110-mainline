"""OEM PMIC snapshot plus one watchdog pet; intentionally not read-only."""
from pathlib import Path
import subprocess, hashlib, json
win=Path('/mnt/h/workspace/PJA110-Mainline')
root=Path.home()/'workspace/PJA110-Mainline/charger-native-a'
build=root/'charger-watchdog-probe'; build.mkdir(exist_ok=True)
out=win/'out/native-install-20261017/charger-watchdog-probe'; out.mkdir(exist_ok=True)
s=(win/'out/native-install-20261017/temperature-readback/qcom_battmgr-readback.c').read_text()
s=s.replace('static int matched_temp = -10000;\nmodule_param(matched_temp, int, 0444);', 'static unsigned int snapshot[128], snapshot_size;\nmodule_param_array(snapshot, uint, NULL, 0444);\nmodule_param(snapshot_size, uint, 0444);')
s=s.replace('0x10003','0x10006')
s=s.replace('matched_temp = (s32)le32_to_cpu(bcc->data[7]);', 'unsigned int i;\n            snapshot_size = le32_to_cpu(bcc->data_size);\n            for (i = 0; i < snapshot_size / sizeof(__le32); i++)\n                snapshot[i] = le32_to_cpu(bcc->data[i]);')
s=s.replace('PJA110 BCC matched-temp readback: dC=%d result=%d', 'PJA110 OEM PMIC snapshot and watchdog pet: bytes=%u result=%d').replace('matched_temp, ret','snapshot_size, ret')
s=s.replace('/* Factory bcc_read_buffer request. No property SET is issued. */','/* Factory PMIC snapshot request ALSO PETS THE CHARGER WATCHDOG ONCE. */')
(build/'qcom_battmgr.c').write_text(s)
(build/'Makefile').write_text('obj-m += qcom_battmgr.o\n')
p=subprocess.run(['make','-C',str(root/'linux-6.14'),'ARCH=arm64','CROSS_COMPILE=/opt/aarch64-linux-gnu-toolchain-13.3/bin/aarch64-none-linux-gnu-','M='+str(build),'modules'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(out/'build.log').write_bytes(p.stdout); print(p.stdout.decode(errors='replace')); p.check_returncode()
data=(build/'qcom_battmgr.ko').read_bytes(); (out/'qcom_battmgr-watchdog.ko').write_bytes(data); (out/'source.c').write_text(s)
(out/'manifest.json').write_text(json.dumps(dict(sha256=hashlib.sha256(data).hexdigest(),opcode='0x10006',watchdog_pet=True,one_shot=True,phone_tested=False),indent=2)+'\n')
print((out/'manifest.json').read_text())

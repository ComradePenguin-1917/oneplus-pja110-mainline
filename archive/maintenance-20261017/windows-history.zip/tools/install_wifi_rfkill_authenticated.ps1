$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path -Parent $PSScriptRoot
$sshArgs = @('-F', 'none', '-tt', '-i', "$taskRoot/out/usb-ncm-20261013/ssh/client_key_host",
    '-o', 'BatchMode=yes', '-o', 'IdentitiesOnly=yes', '-o', 'StrictHostKeyChecking=yes',
    '-o', "UserKnownHostsFile=$taskRoot/out/native-install-20261017/known_hosts",
    '-o', 'ConnectTimeout=6', 'penguin@172.16.42.1')
& 'C:/Windows/System32/OpenSSH/ssh.exe' @sshArgs 'sudo /bin/sh /home/penguin/wifi-bringup/aston-rfkill/install.sh'
$moduleExit = $LASTEXITCODE
if ($moduleExit -notin @(0,255)) { throw "Aston RF-kill module command exited $moduleExit" }

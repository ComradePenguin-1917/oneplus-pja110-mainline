"""Offline evidence for gauge fallback values and OEM charger commands."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'out/battery-bringup-20261016/charger-source'
assert hashlib.sha256((OUT / 'firmware/qcom/sm8550/xigua/adsp.b18').read_bytes()).hexdigest() == 'a1f79a3901637d9e8e24a69eae838547a05a36977467e52934e8b9fd6b5c8d18'
instructions = {}
for line in (OUT / 'adsp-charger-analysis-only.dis').read_text().splitlines():
    match = re.match(r'^([0-9a-f]+):', line)
    if match:
        instructions[int(match[1], 16)] = line
expected = {
    0x601af44c: 'memb(##0x603672a8)',
    0x601af454: 'jump:nt 0x601af474',
    0x601af50c: 'memw(r2+#0x0) = ##0xfa',
    0x601af518: 'jump 0x601b0c48',
    0x601b0ffc: 'memb(##0x603672a8)',
    0x601b1004: 'jump:nt 0x601b1024',
    0x601b10bc: 'memh(r2+#0x0) = ##0x1388',
    0x601b10c8: 'jump 0x601b1240',
    0x601a2a10: 'cmp.eq(r2,#0x1d)',
    0x601a2a24: 'call 0x60068100',
    0x60068130: 'memw(r2+#0x6c) = r3',
    0x600682cc: 'memw(r2+#0x6c)',
    0x601a5474: 'call 0x600681f0',
    0x601a5478: 'memw(r30+#-0x2c) = r0',
    0x601a1bb0: 'cmp.eq(r2,#0x18)',
    0x601a1bc8: 'call 0x600aacc0',
    0x600aadf0: 'callr r2',
    0x600a0654: 'r0 = #0x7f',
}
for address, text in expected.items():
    assert text in instructions[address], hex(address)
vendor = (OUT / 'oplus_battery_sm8550.c').read_text()
charger = (OUT / 'oplus_charger.c').read_text()
mainline = (OUT / 'qcom_battmgr.c').read_text()
dts = (OUT.parent / 'oplus-chg-22851.dtsi').read_text()
assert 'write_property_id(bcdev, pst, BATT_SET_MATCH_TEMP, match_temp)' in vendor
assert 'write_property_id(bcdev, pst, BATT_CHG_EN, 1)' in vendor
assert '.set_property' not in mainline
assert 'qcom,voocphy_support = <2>' in dts
assert 'if (oplus_chg_get_voocphy_support() == ADSP_VOOCPHY)' in charger
ranges = ['601af430:601af51c', '601b0fe0:601b10cc',
          '601a29f0:601a2a2c', '60068100:600682e0',
          '601a544c:601a5484', '601a1bac:601a1c88',
          '600aacc0:600aaed0', '600a0610:600a0734']
result = subprocess.run([sys.executable, str(ROOT / 'tools/inspect_adsp_disassembly.py'),
                         *ranges], capture_output=True, check=True)
(OUT / 'gauge-data-sources-annotated.dis').write_bytes(result.stdout)
report = {
    'scope': 'offline; not a runtime charging test',
    'bq_uninitialized_fallback_raw': {'temperature': 250, 'soc': 5000},
    'oem_temperature': {'property': 29, 'setter': '0x60068100',
                        'getter': '0x600681f0', 'object_offset': '0x6c',
                        'consumer_seen': '0x601a5474 (not full policy traced)'},
    'oem_charging_enable': {'property': 24, 'handler_call': '0x601a1bc8',
                            'callee': 'PmSchgChgr_SetEnableChargingForAP (log-inferred)',
                            'backend': 'indirect callback; physical effect unverified'},
    'factory_voocphy': {'value': 2, 'enum': 'AP_SINGLE_CP_VOOCPHY',
                        'periodic_temperature_send_guard': 'ADSP_VOOCPHY == 1',
                        'probe_temperature_send': 'present outside that guard',
                        'fast_charge_node': 'sc,sc8517-master at 0x69'},
    'standard_battmgr_has_set_property': False,
    'smem_charger_item': 127,
    'unknowns': ['Which firmware platform and policy paths execute at runtime',
                 'Whether OEM enable is required for basic charging or only overrides',
                 'Complete physical charger topology and ordinary 5V charging route',
                 'Current boot SMEM values and valid temperature source'],
    'phone_modified': False,
    'checked_instructions': {hex(a): instructions[a] for a in expected},
}
(OUT / 'gauge-data-sources.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: report[k] for k in ('bq_uninitialized_fallback_raw',
                                        'factory_voocphy', 'phone_modified')}, indent=2))

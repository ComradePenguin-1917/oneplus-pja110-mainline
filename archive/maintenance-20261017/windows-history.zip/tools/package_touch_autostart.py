"""Extend external init_boot with proven runtime modules; retain #14 boot."""
import gzip
import hashlib
import json
import struct
from pathlib import Path
from build_init_marker_test import parse_cpio, make_entry, lz4

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'out/debug-ncm-fixed-20261013'
OUT=ROOT/'out/touch-port-20261013'
assert json.loads((OUT/'input-result.json').read_text())['physical_touch_events_verified']
source=(BASE/'init_boot_b-xigua-r1.img').read_bytes()
old_size=struct.unpack_from('<I',source,12)[0]
archive=lz4(['-d','-l','-c'],source[4096:4096+old_size])
entries=parse_cpio(archive)
mapping={n.removeprefix('./'):(f,d) for f,n,d in entries}
assert mapping['init'][1]==(BASE/'init.sh').read_bytes()
init=mapping['init'][1]
hook=b'''# Runtime touch modules load independently after the SSH supervisor starts.
(
    if /bin/busybox insmod /lib/modules/spi-geni-qcom.ko &&
       /bin/busybox insmod /lib/modules/mainline_touch_probe.ko enable_touch=1; then
        log "S3910 touch modules loaded"
    else
        log "S3910 touch module load failed; SSH remains available"
    fi
) > /tmp/touch-init.log 2>&1 &
'''
assert init.count(b'cd /\nwhile :;')==1
init=init.replace(b'cd /\nwhile :;',hook+b'cd /\nwhile :;')
qemu=b'''    if test -s /lib/modules/spi-geni-qcom.ko &&
       test -s /lib/modules/mainline_touch_probe.ko &&
       /bin/busybox insmod /lib/modules/spi-geni-qcom.ko &&
       /bin/busybox insmod /lib/modules/mainline_touch_probe.ko enable_touch=1; then
        log "QEMU touch modules validated"
    else
        log "QEMU touch modules validation FAILED"
        poweroff -f
    fi
'''
anchor=b"if grep -q 'pja.qemu_validation=1' /proc/cmdline; then\n"
assert init.count(anchor)==1
init=init.replace(anchor,anchor+qemu)
changes={'init':(0o100755,init),
         'lib':(0o40755,b''),'lib/modules':(0o40755,b''),
         'lib/modules/spi-geni-qcom.ko':(0o100644,(OUT/'spi-geni-qcom.ko').read_bytes()),
         'lib/modules/mainline_touch_probe.ko':(0o100644,(OUT/'mainline_touch_probe.ko').read_bytes())}
for path in ('lib','lib/modules'):
    if path in mapping:
        assert mapping[path][0][1]&0o170000==0o40000
        del changes[path]
ino=max(f[0] for f,n,d in entries)+1
output=bytearray()
for fields,name,data in entries:
    normalized=name.removeprefix('./')
    if name=='TRAILER!!!':
        for path,(mode,content) in changes.items():
            if path not in mapping:
                output+=make_entry([ino,mode,0,0,1,0,0,0,0,0,0,0,0],path,content)
                ino+=1
    if normalized in changes:
        mode,data=changes[normalized];fields=list(fields);fields[1]=mode
    output+=make_entry(fields,name,data)
rebuilt={n.removeprefix('./'):(f,d) for f,n,d in parse_cpio(output)}
for path,(mode,data) in changes.items():
    assert rebuilt[path][0][1]==mode and rebuilt[path][1]==data,path
    parent=Path(path).parent
    while str(parent)!='.':
        assert parent.as_posix() in rebuilt and rebuilt[parent.as_posix()][0][1]&0o170000==0o40000
        parent=parent.parent
for path,record in mapping.items():
    if path not in changes:assert rebuilt[path]==record,path
ramdisk=lz4(['-z','-l','-12','-c'],output)
align=lambda n:(n+4095)//4096*4096
old_end=4096+align(old_size);new_end=4096+align(len(ramdisk))
assert new_end<=len(source)
if new_end>old_end:assert not any(source[old_end:new_end])
result=bytearray(source)
struct.pack_into('<I',result,12,len(ramdisk))
result[4096:max(old_end,new_end)]=ramdisk.ljust(max(old_end,new_end)-4096,b'\0')
assert lz4(['-d','-l','-c'],result[4096:4096+len(ramdisk)])==bytes(output)
assert result[:12]==source[:12] and result[16:4096]==source[16:4096]
assert result[max(old_end,new_end):]==source[max(old_end,new_end):]
(OUT/'init_boot_b-touch-autostart.img').write_bytes(result)
(OUT/'initramfs-touch.cpio.gz').write_bytes(gzip.compress(output,mtime=0))
(OUT/'init-touch.sh').write_bytes(init)
manifest={'external_initramfs_only_updated':True,'boot_kernel_unchanged':True,
          'embedded_fallback_retains_ssh_without_touch':True,'ssh_identity_and_all_other_entries_unchanged':True,
          'physical_touch_already_verified':True,'runtime_module_sha256':{n:hashlib.sha256((OUT/n).read_bytes()).hexdigest() for n in ('spi-geni-qcom.ko','mainline_touch_probe.ko')},
          'init_boot_sha256':hashlib.sha256(result).hexdigest(),'phone_execution_confirmed':False}
(OUT/'autostart-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('PASS: only external init and proven modules updated; SSH identities and all other entries preserved')

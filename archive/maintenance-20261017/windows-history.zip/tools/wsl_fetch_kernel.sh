#!/bin/bash
# Fetch and unpack a mainline kernel RELEASE TARBALL (no git history needed).
#
# Rationale: building needs the source, not the object store. A tarball is
# ~150 MB and unpacks in seconds; a full clone drags in ~4 GB of history.
#
# Source is a China mirror (measured fastest from this host: aliyun 5.6 MB/s
# vs cdn.kernel.org 1.5 MB/s). Fallbacks are tried in order.
set -uo pipefail

ROOT="$HOME/workspace/PJA110-Mainline"
VER="${1:-6.14}"
DEST="$ROOT/linux"
TARBALL="$ROOT/.cache/linux-$VER.tar.xz"
mkdir -p "$ROOT/.cache"

MIRRORS=(
  "https://mirrors.aliyun.com/linux-kernel"
  "https://mirrors.tuna.tsinghua.edu.cn/kernel"
  "https://cdn.kernel.org/pub/linux/kernel"
)

case "$VER" in
    6.*) SUB="v6.x" ;;
    7.*) SUB="v7.x" ;;
    *)   echo "unsupported version $VER"; exit 1 ;;
esac

if [ -d "$DEST" ]; then
    echo "=== $DEST already exists ==="
    cat "$DEST/Makefile" 2>/dev/null | sed -n '1,4p'
    exit 0
fi

if [ ! -s "$TARBALL" ]; then
    echo "=== downloading linux-$VER.tar.xz ==="
    ok=0
    for m in "${MIRRORS[@]}"; do
        url="$m/$SUB/linux-$VER.tar.xz"
        echo "  trying $url"
        if curl -fL --retry 2 --connect-timeout 20 -o "$TARBALL" "$url"; then
            if xz -t "$TARBALL" 2>/dev/null; then
                echo "  OK: $(du -h "$TARBALL" | cut -f1) (integrity check passed)"
                ok=1
                break
            else
                echo "  corrupt download, trying next mirror"
                rm -f "$TARBALL"
            fi
        fi
    done
    [ "$ok" = 1 ] || { echo "all mirrors failed"; exit 1; }
else
    echo "=== using cached $TARBALL ($(du -h "$TARBALL" | cut -f1)) ==="
fi

echo
echo "=== extracting ==="
mkdir -p "$DEST"
tar -xJf "$TARBALL" -C "$DEST" --strip-components=1
echo "extracted to $DEST"

echo
echo "=== result ==="
sed -n '1,4p' "$DEST/Makefile"
echo "size: $(du -sh "$DEST" | cut -f1)"

echo
echo "=== sanity: files our DTS needs ==="
for f in arch/arm64/boot/dts/qcom/sm8550.dtsi \
         arch/arm64/boot/dts/qcom/pm8550.dtsi \
         arch/arm64/boot/dts/qcom/pm8550b.dtsi \
         arch/arm64/boot/dts/qcom/pm8550ve.dtsi \
         arch/arm64/boot/dts/qcom/pm8550vs.dtsi \
         arch/arm64/boot/dts/qcom/pmk8550.dtsi \
         arch/arm64/boot/dts/qcom/pm8010.dtsi \
         arch/arm64/boot/dts/qcom/pmr735d_a.dtsi \
         arch/arm64/configs/defconfig ; do
    [ -f "$DEST/$f" ] && echo "  OK   $f" || echo "  MISS $f"
done

echo
echo "=== sm8550 boards this version knows about ==="
grep -oE 'sm8550[a-z0-9-]*\.dtb' "$DEST/arch/arm64/boot/dts/qcom/Makefile" | sort -u

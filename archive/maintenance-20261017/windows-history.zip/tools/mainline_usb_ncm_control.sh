#!/bin/sh
# Runtime ACM + NCM. All state lives in configfs or tmpfs, no partition writes.
PATH=/sbin:/bin:/usr/sbin:/usr/bin
export PATH
trap '' HUP
set -x
echo $$ > /tmp/usb-ncm-manager.pid
sleep 3
G=/sys/kernel/config/usb_gadget/g1
cd "$G" || exit 1
controller=$(cat UDC)
[ -n "$controller" ] || exit 1
restart_shell() {
    sleep 3
    while :; do
        setsid sh -i </dev/ttyGS0 >/dev/ttyGS0 2>&1
        sleep 1
    done
}
restore_acm() {
    rc=$?
    trap - EXIT
    echo "PJA_NCM_SETUP_FAILED rc=$rc restoring ACM"
    cd "$G" || exit 1
    printf '\n' > UDC
    rm -f configs/c.1/ncm.usb0 configs/c.1/Loopback.test os_desc/c.1
    rmdir functions/ncm.usb0 functions/Loopback.test 2>/dev/null
    echo 0 > os_desc/use
    echo 0x0108 > idProduct
    echo PJA110-ACM > strings/0x409/serialnumber
    echo xigua-mainline-usb-serial > strings/0x409/product
    echo "$controller" > UDC
    restart_shell
}
trap restore_acm EXIT
dmesg > /tmp/ncm-before.dmesg
printf '\n' > UDC || exit 1
sleep 1
rm -f configs/c.1/Loopback.test os_desc/c.1
rmdir functions/Loopback.test 2>/dev/null
echo 0 > os_desc/use || exit 1
echo 0x010a > idProduct || exit 1
echo PJA110-NCM > strings/0x409/serialnumber || exit 1
echo xigua-mainline-ncm > strings/0x409/product || exit 1
mkdir -p functions/ncm.usb0 || exit 1
echo 02:1a:11:00:00:01 > functions/ncm.usb0/dev_addr || exit 1
echo 02:1a:11:00:00:02 > functions/ncm.usb0/host_addr || exit 1
echo 'usb%d' > functions/ncm.usb0/ifname || exit 1
ln -s "$G/functions/ncm.usb0" configs/c.1/ncm.usb0 || exit 1
echo "$controller" > UDC || exit 1
iface=$(cat functions/ncm.usb0/ifname)
ip link set lo up || exit 1
ip addr add 172.16.42.1/24 dev "$iface" || exit 1
ip link set "$iface" up || exit 1
echo "PJA_NCM_BOUND iface=$iface ip=172.16.42.1"
trap - EXIT
restart_shell

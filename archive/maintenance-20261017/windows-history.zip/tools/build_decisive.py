#!/usr/bin/env python3
"""THE DECISIVE EXPERIMENT: our tree + our kernel + no overlays, on slot B.

Combination that has never been tested here:

    vendor_boot_b  <- OUR device tree as entry0   (the channel PROVEN to work)
    boot_b         <- OUR kernel + embedded initramfs
    dtbo_b         <- ERASED, so no overlay can overwrite anything
    active slot    <- b

Why this is the right test
--------------------------
Every earlier attempt was confounded:
  * with the vendor dtbo present, ABL applies overlays that rewrite `model` and
    recreate /chosen, so a missing marker could not distinguish "appended DTB
    ignored" from "appended DTB used then overwritten".
  * the vendor base tree needs those overlays to ENABLE UFS/PHY/sdhci
    (/soc/ufshc@1d84000 is `disabled` in the base tree, `ok` after overlays), so
    erasing the dtbo while feeding the vendor tree cannot boot either.

Our own tree enables UFS/USB/serial by itself, so it does not need the overlays
at all -- which is exactly why this combination can work where the others could
not.

Observation: our kernel carries an embedded initramfs whose /init brings up a USB
network gadget, so IF the kernel reaches userspace, adb/telnet appears. Total
silence therefore means the kernel never got that far.

An inert marker node is added to our DTB so that, if the kernel DOES come up, we
can confirm by a plain directory listing which tree it received.
"""
import hashlib
import os
import struct
import subprocess
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
WSL_WS = '/mnt/h/WorkSpace/PJA110-Mainline'
PAGE = 4096
MARK = 'xigua-ourdtb-vb'

sys.path.insert(0, os.path.join(WS, 'tools'))
from fdt import FDT
from fdtwrite import parse, serialise, Node, walk


def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''):
            h.update(c)
    return h.hexdigest()


# ============================================================ 1) our DTB + mark
print('=' * 78)
print('1) OUR DEVICE TREE (+ inert marker)')
print('=' * 78)
blob = open(os.path.join(WS, 'dts', 'sm8550-oneplus-xigua-16G.dtb'), 'rb').read()
root, rsvmap = parse(blob)
before = set(p for p, _ in walk(root))
if '/' + MARK not in before:
    root.children.append(Node(MARK))
dtb = serialise(root, rsvmap)
after = set(p for p, _ in walk(parse(dtb)[0]))

f = FDT(dtb)
nodes = f.nodes()
syms = set(nodes.get('/__symbols__', {}))
print('  size        : %d bytes' % len(dtb))
print('  node paths  : %d -> %d' % (len(before), len(after)))
print('  marker      : /%s present = %s' % (MARK, '/' + MARK in after))
print('  __symbols__ : %d labels' % len(syms))
print('  qcom_tzlog  : %s' % ('qcom_tzlog' in syms))
print('  arch_timer  : %s' % ('arch_timer' in syms))

# our tree must enable the essentials on its own
print()
print('  bring-up critical nodes in OUR tree:')
for want in ('ufshc', 'usb@', 'qup_uart', 'gcc', 'pinctrl@f710000', 'pinctrl'):
    for p in sorted(nodes):
        if want in p.lower() and p.count('/') <= 3:
            st = nodes[p].get('status', b'(none)').rstrip(b'\0').decode('ascii', 'replace')
            print('    %-42s status=%s' % (p[:42], st))
            break

p_dtb = os.path.join(WS, 'out', 'ourdtb-marked.dtb')
open(p_dtb, 'wb').write(dtb)

# ================================================= 2) vendor_boot_b with our DTB
print()
print('=' * 78)
print('2) vendor_boot_b  <- our DTB as entry0')
print('=' * 78)
SRC = os.path.join(WS, 'backup', 'vendor_boot_b.img')
v = bytearray(open(SRC, 'rb').read())
hsize, dtbsize = struct.unpack_from('<2I', v, 28 + 2048 + 4 + 16)
vrsize = struct.unpack_from('<I', v, 24)[0]
dtb_off = (((hsize + PAGE - 1)//PAGE)*PAGE + vrsize + PAGE - 1)//PAGE*PAGE
e0_slot = struct.unpack_from('>I', v, dtb_off + 4)[0]
print('  dtb section  @0x%x   entry0 slot = %d' % (dtb_off, e0_slot))
print('  our DTB      : %d  (fits: %s)' % (len(dtb), len(dtb) <= e0_slot))
if len(dtb) > e0_slot:
    sys.exit('our DTB does not fit entry0')

# pad to EXACTLY the slot size, updating totalsize -- this is what the vendor
# does too (their entry0 totalsize == its slot size), and it keeps ABL's walk
# landing precisely on entry1.
padded = bytearray(dtb) + b'\0' * (e0_slot - len(dtb))
struct.pack_into('>I', padded, 4, e0_slot)
print('  padded to    : %d  (totalsize now %d)'
      % (len(padded), struct.unpack_from('>I', padded, 4)[0]))

orig = bytes(v)
# sanity: everything outside entry0 must stay identical
v[dtb_off:dtb_off + e0_slot] = bytes(padded)
w = bytes(v)

same_head = w[:dtb_off] == orig[:dtb_off]
same_tail = w[dtb_off + e0_slot:] == orig[dtb_off + e0_slot:]
print('  head/ramdisk untouched : %s' % same_head)
print('  entries 1..3 untouched : %s' % same_tail)
if not (same_head and same_tail):
    sys.exit('edit leaked outside entry0')

out_vb = os.path.join(WS, 'out', 'vendor_boot_b-ourdtb.img')
open(out_vb, 'wb').write(w)

# verify the whole section still walks
print()
print('  rebuilt section walk:')
off = dtb_off
for i in range(4):
    total = struct.unpack_from('>I', w, off + 4)[0]
    fj = FDT(w[off:off + total])
    mid = fj.nodes()['/'].get('qcom,msm-id')
    ms = ' '.join('0x%x' % x for x in struct.unpack('>%dI' % (len(mid)//4), mid))[:22] if mid else '-'
    mdl = fj.nodes()['/'].get('model', b'').rstrip(b'\0').decode('ascii', 'replace')[:30]
    flag = ''
    if i == 0:
        flag = '  <== OURS, marker=%s' % ('/' + MARK in set(p for p, _ in walk(parse(w[off:off+total])[0])))
    print('    entry%d @0x%06x size=%-7d %-30s %s%s' % (i, off, total, mdl, ms, flag))
    off += total
print('    walk closed: %s' % (off == dtb_off + dtbsize))
print('    size unchanged: %s' % (len(w) == len(orig)))
print('    sha256 %s -> %s' % (sha(SRC)[:16], sha(out_vb)[:16]))

# ============================================== 3) boot_b with our kernel only
print()
print('=' * 78)
print('3) boot_b  <- our kernel (embedded initramfs), NO appended DTB')
print('=' * 78)
print('  deliberately no appended DTB: the only tree available to the kernel')
print('  will be vendor_boot_b entry0 (ours), which is the channel we are testing.')
kern = os.path.join(WS, 'out', 'Image-initrd')
print('  kernel: %s (%d bytes)' % (os.path.basename(kern), os.path.getsize(kern)))

out_boot = os.path.join(WS, 'out', 'boot_b-ourkernel.img')
cmd = ('cd %s && python3 tools/bootimg.py pack --kernel out/Image-initrd '
       '--stock boot-A14.img --cmdline "console=ttyMSM0,115200 loglevel=8 earlycon ignore_loglevel" '
       '-o out/boot_b-ourkernel.img' % WSL_WS)
r = subprocess.run(['wsl.exe', '-d', 'Ubuntu-22.04', '--', 'bash', '-lc', cmd],
                   capture_output=True)
for line in (r.stdout or b'').decode('utf-8', 'replace').splitlines():
    if line.strip() and 'localh' not in line and 'N/e' not in line:
        print('  %s' % line.strip()[:100])

# verify embedded initramfs by fingerprint (the reliable method)
import gzip
import io
if os.path.exists(out_boot):
    b = open(out_boot, 'rb').read()
    ksize = struct.unpack_from('<I', b, 8)[0]
    k = b[4096:4096 + ksize]
    raw = open(os.path.join(WS, 'initramfs', 'initramfs.cpio.gz'), 'rb').read()
    i = k.find(raw[:32])
    print()
    print('  image size     : %d' % len(b))
    print('  kernel field   : %d' % ksize)
    print('  appended DTB   : %s' % ('yes (unexpected!)' if k.find(b'\xd0\x0d\xfe\xed', len(k) - 400000) >= 0 else 'no (as intended)'))
    print('  embedded initrd: %s' % ('found @0x%x' % i if i >= 0 else 'NOT FOUND'))
    if i >= 0:
        d = gzip.GzipFile(fileobj=io.BytesIO(k[i:i + len(raw)])).read()
        print('    decompresses to %d bytes; has [initramfs]=%s busybox=%s telnetd=%s'
              % (len(d), b'[initramfs]' in d, b'busybox' in d, b'telnetd' in d))

print()
print('=' * 78)
print('ARTIFACTS')
print('=' * 78)
for p in (out_vb, out_boot):
    print('  %-46s %10d  %s' % (os.path.basename(p), os.path.getsize(p), sha(p)[:16]))

print()
print('=' * 78)
print('RUN PLAN (flash route; `fastboot flash` has been reliable)')
print('=' * 78)
print('  fastboot flash vendor_boot_b out/vendor_boot_b-ourdtb.img')
print('  fastboot flash boot_b        out/boot_b-ourkernel.img')
print('  fastboot erase dtbo_b')
print('  fastboot set_active b')
print('  fastboot reboot')
print()
print('ROLLBACK (all originals backed up)')
print('  fastboot flash boot_b        backup/boot_b.img')
print('  fastboot flash vendor_boot_b backup/vendor_boot_b.img')
print('  fastboot flash dtbo_b        backup/dtbo_b.img')
print('  fastboot set_active a')

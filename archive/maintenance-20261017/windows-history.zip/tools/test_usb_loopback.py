"""Run the native WinUSB test and preserve complete and incomplete results."""
import argparse
import json
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--rounds', type=int, default=10)
parser.add_argument('--output', default='out/usb-loopback-20261013/test')
args = parser.parse_args()
if not 1 <= args.rounds <= 1000:
    parser.error('rounds must be between 1 and 1000')
out = (root / args.output).resolve()
if root not in out.parents:
    parser.error('output must stay inside workspace')
out.mkdir(parents=True, exist_ok=True)
if (out / 'result.json').exists():
    parser.error('choose a new output directory to preserve previous evidence')
exe = root / 'out/usb-loopback-20261013/usb_loopback_winusb.exe'
command = [str(exe), str(args.rounds), str(out)]
(out / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
transfers = []
with (out / 'host-output.txt').open('w', encoding='utf-8') as stdout, \
     (out / 'host-errors.txt').open('w', encoding='utf-8') as stderr:
    run = subprocess.run(command, stdout=stdout, stderr=stderr, timeout=args.rounds * 30 + 60)
raw = (out / 'host-output.txt').read_text()
for line in raw.splitlines():
    if not line.startswith('RESULT,'):
        continue
    _, r, n, sent, received, match, seconds, we, re, hs, hr = line.split(',')
    transfers.append(dict(round=int(r), bytes=int(n), sent=int(sent), received=int(received),
                          passed=match == '1', seconds=float(seconds), write_error=int(we),
                          read_error=int(re), sent_sha256=hs, received_sha256=hr))
result = dict(all_passed=run.returncode == 0 and len(transfers) == args.rounds * 13
              and all(t['passed'] for t in transfers), exit_code=run.returncode,
              expected_transfers=args.rounds * 13, completed_transfers=len(transfers),
              successful_bytes_per_direction=sum(t['bytes'] for t in transfers if t['passed']),
              transfers=transfers)
(out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'transfers'}))
raise SystemExit(0 if result['all_passed'] else 1)

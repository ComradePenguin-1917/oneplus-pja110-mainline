"""Probe WSL inside the existing sandbox, forwarding only UTF-8 output."""
import json
import locale
import pathlib
import subprocess
import sys


def decode_output(data):
    if not data:
        return ''
    if data.startswith((b'\xff\xfe', b'\xfe\xff')):
        return data.decode('utf-16', errors='replace')
    if data.count(b'\0') > len(data) // 8:
        return data.decode('utf-16-le', errors='replace')
    for encoding in ('utf-8-sig', locale.getpreferredencoding(False), 'gb18030'):
        try:
            return data.decode(encoding)
        except (UnicodeDecodeError, LookupError):
            pass
    return data.decode('utf-8', errors='backslashreplace')


def main():
    sys.stdout.reconfigure(encoding='utf-8', errors='backslashreplace')
    sys.stderr.reconfigure(encoding='utf-8', errors='backslashreplace')
    distro = sys.argv[1] if len(sys.argv) > 1 else 'Ubuntu-22.04'
    command = ['wsl.exe', '-d', distro, '--', '/bin/true']
    try:
        result = subprocess.run(command, capture_output=True, timeout=30)
    except (OSError, subprocess.TimeoutExpired) as exc:
        print('WSL probe could not complete: %s' % exc)
        return 125
    stdout, stderr = decode_output(result.stdout), decode_output(result.stderr)
    for label, value in (('WSL stdout', stdout), ('WSL stderr', stderr)):
        if value:
            print('%s:\n%s' % (label, value.rstrip()))
    print('WSL_PROBE_EXIT=%d' % result.returncode)
    if len(sys.argv) > 2:
        log = pathlib.Path(sys.argv[2])
        log.parent.mkdir(parents=True, exist_ok=True)
        log.write_text(json.dumps({
            'command': command, 'returncode': result.returncode,
            'stdout': stdout, 'stderr': stderr,
            'stdout_hex': result.stdout.hex(), 'stderr_hex': result.stderr.hex(),
        }, indent=2, ensure_ascii=True), encoding='utf-8')
    return result.returncode


if __name__ == '__main__':
    exit_code = main()
    # subprocess may expose a Windows DWORD as unsigned, while SystemExit
    # expects a signed C int. Keep the same 32-bit exit status.
    if sys.platform == 'win32' and exit_code > 0x7fffffff:
        exit_code -= 0x100000000
    sys.exit(exit_code)

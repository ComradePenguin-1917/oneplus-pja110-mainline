#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <setupapi.h>
#include <winusb.h>
#include <bcrypt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const GUID loop_guid = {0x7e7804a3,0x47c8,0x4ddd,{0x9d,0xc9,0xda,0x15,0x54,0x82,0xc1,0x22}};
typedef struct { WINUSB_INTERFACE_HANDLE usb; UCHAR pipe; unsigned char *data;
                 ULONG size, count; DWORD error; } read_job;
static DWORD WINAPI receive_thread(void *arg) {
    read_job *job = arg;
    while (job->count < job->size) {
        ULONG n=0, want=job->size-job->count;
        if(want>65536) want=65536;
        if(!WinUsb_ReadPipe(job->usb,job->pipe,job->data+job->count,want,&n,NULL)) {
            job->error=GetLastError(); break;
        }
        if(!n) continue;
        job->count+=n;
    }
    return 0;
}
static void sha256(unsigned char *data, ULONG length, char result[65]) {
    BCRYPT_ALG_HANDLE alg=NULL; BCRYPT_HASH_HANDLE hash=NULL;
    unsigned char digest[32];
    if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,NULL,0)<0 ||
       BCryptCreateHash(alg,&hash,NULL,0,NULL,0,0)<0 ||
       BCryptHashData(hash,data,length,0)<0 || BCryptFinishHash(hash,digest,32,0)<0) {
        fprintf(stderr,"SHA256 failed\n"); exit(3);
    }
    for(int i=0;i<32;i++) sprintf(result+i*2,"%02x",digest[i]);
    BCryptDestroyHash(hash); BCryptCloseAlgorithmProvider(alg,0);
}
static void save_failure(const char *dir, const char *kind, int round, ULONG size,
                         unsigned char *data, ULONG n) {
    char path[1024]; snprintf(path,sizeof(path),"%s/%s-%d-%lu.bin",dir,kind,round,(unsigned long)size);
    FILE *file=fopen(path,"wb"); if(file){fwrite(data,1,n,file);fclose(file);}
}
int main(int argc, char **argv) {
    int rounds=argc>1?atoi(argv[1]):10;
    const char *out=argc>2?argv[2]:".";
    HDEVINFO devs=SetupDiGetClassDevsA(&loop_guid,NULL,NULL,DIGCF_PRESENT|DIGCF_DEVICEINTERFACE);
    SP_DEVICE_INTERFACE_DATA iface={0}; iface.cbSize=sizeof(iface);
    if(devs==INVALID_HANDLE_VALUE || !SetupDiEnumDeviceInterfaces(devs,NULL,&loop_guid,0,&iface)) {
        fprintf(stderr,"No Loopback device interface, error=%lu\n",GetLastError());return 2;
    }
    DWORD need=0;
    SetupDiGetDeviceInterfaceDetailA(devs,&iface,NULL,0,&need,NULL);
    PSP_DEVICE_INTERFACE_DETAIL_DATA_A detail=calloc(1,need);
    detail->cbSize=sizeof(*detail);
    if(!SetupDiGetDeviceInterfaceDetailA(devs,&iface,detail,need,NULL,NULL))return 2;
    printf("DEVICE,%s\n",detail->DevicePath);
    HANDLE file=CreateFileA(detail->DevicePath,GENERIC_READ|GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_WRITE,
                           NULL,OPEN_EXISTING,FILE_FLAG_OVERLAPPED,NULL);
    free(detail);SetupDiDestroyDeviceInfoList(devs);
    WINUSB_INTERFACE_HANDLE usb=NULL;
    if(file==INVALID_HANDLE_VALUE || !WinUsb_Initialize(file,&usb)) {
        fprintf(stderr,"WinUsb initialize error=%lu\n",GetLastError());return 2;
    }
    USB_INTERFACE_DESCRIPTOR desc;
    if(!WinUsb_QueryInterfaceSettings(usb,0,&desc))return 2;
    UCHAR in=0,outpipe=0; USHORT outpacket=0;
    for(int i=0;i<desc.bNumEndpoints;i++) {
        WINUSB_PIPE_INFORMATION pipe;
        if(!WinUsb_QueryPipe(usb,0,(UCHAR)i,&pipe))return 2;
        printf("PIPE,%02x,%u,%u\n",pipe.PipeId,pipe.PipeType,pipe.MaximumPacketSize);
        if(pipe.PipeType==UsbdPipeTypeBulk) {if(pipe.PipeId&0x80)in=pipe.PipeId;else {outpipe=pipe.PipeId;outpacket=pipe.MaximumPacketSize;}}
    }
    if(!in || !outpipe)return 2;
    UCHAR terminate=0;
    if(!WinUsb_SetPipePolicy(usb,outpipe,SHORT_PACKET_TERMINATE,sizeof(terminate),&terminate)) {
        fprintf(stderr,"Set short-packet policy error=%lu\n",GetLastError());return 2;
    }
    /* Reinitialize the function once, so a previous incomplete OUT is discarded. */
    if(!WinUsb_SetCurrentAlternateSetting(usb,0)) {
        fprintf(stderr,"Set interface error=%lu\n",GetLastError());return 2;
    }
    ULONG timeout=15000;
    WinUsb_SetPipePolicy(usb,in,PIPE_TRANSFER_TIMEOUT,sizeof(timeout),&timeout);
    WinUsb_SetPipePolicy(usb,outpipe,PIPE_TRANSFER_TIMEOUT,sizeof(timeout),&timeout);
    ULONG speed=0,speedlen=sizeof(speed);
    WinUsb_QueryDeviceInformation(usb,DEVICE_SPEED,&speedlen,&speed);
    printf("SPEED,%lu\n",(unsigned long)speed);fflush(stdout);
    ULONG sizes[]={1,63,64,65,511,512,513,4095,4096,4097,65536,1048576,4194304};
    int failures=0;
    for(int r=1;r<=rounds;r++)for(unsigned s=0;s<sizeof(sizes)/sizeof(sizes[0]);s++) {
        ULONG size=sizes[s],written=0;DWORD werror=0;
        unsigned char *tx=malloc(size),*rx=calloc(1,size);
        if(!tx || !rx || BCryptGenRandom(NULL,tx,size,BCRYPT_USE_SYSTEM_PREFERRED_RNG)<0)return 3;
        read_job job={usb,in,rx,size,0,0};
        LARGE_INTEGER start,end,freq;QueryPerformanceFrequency(&freq);QueryPerformanceCounter(&start);
        HANDLE thread=CreateThread(NULL,0,receive_thread,&job,0,NULL);
        if(!thread)return 3;
        if(!WinUsb_WritePipe(usb,outpipe,tx,size,&written,NULL))werror=GetLastError();
        /* The device OUT request is 4096 bytes. An integral packet smaller
         * than that request needs an explicit ZLP; do not rely on host policy. */
        if(!werror && size%4096 && size%outpacket==0) {
            ULONG zlp_written=0;
            if(!WinUsb_WritePipe(usb,outpipe,tx,0,&zlp_written,NULL))werror=GetLastError();
        }
        if(WaitForSingleObject(thread,20000)!=WAIT_OBJECT_0) {
            WinUsb_AbortPipe(usb,in);CancelIoEx(file,NULL);
            if(WaitForSingleObject(thread,5000)!=WAIT_OBJECT_0){fprintf(stderr,"Reader did not stop\n");return 3;}
        }
        CloseHandle(thread);QueryPerformanceCounter(&end);
        int match=!werror && !job.error && written==size && job.count==size && !memcmp(tx,rx,size);
        char hs[65],hr[65];sha256(tx,size,hs);sha256(rx,job.count,hr);
        printf("RESULT,%d,%lu,%lu,%lu,%d,%.6f,%lu,%lu,%s,%s\n",r,(unsigned long)size,
               (unsigned long)written,(unsigned long)job.count,match,(double)(end.QuadPart-start.QuadPart)/freq.QuadPart,
               (unsigned long)werror,(unsigned long)job.error,hs,hr);fflush(stdout);
        if(!match){failures++;save_failure(out,"sent",r,size,tx,size);save_failure(out,"received",r,size,rx,job.count);}
        free(tx);free(rx);
        if(!match)goto done; /* Do not hide recovery or contaminate later transactions. */
    }
done:
    WinUsb_Free(usb);CloseHandle(file);
    printf("DONE,failures=%d\n",failures);return failures?1:0;
}

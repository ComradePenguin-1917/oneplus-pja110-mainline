"""Reuse the stock snapshot/pet probe once after the enable-cycle recovery."""
from pathlib import Path
import subprocess
from prepare_native_install import SSH

out = Path('out/native-install-20261017/charger-watchdog-probe')
script = (out / 'probe.sh').read_text().replace('exec > result.log 2>&1',
                                              'exec > recovered-result.log 2>&1')
script = script.replace('chmod 644 result.log', 'chmod 644 recovered-result.log')
script = script.replace('WATCHDOG_ONESHOT_COMPLETE', 'RECOVERED_SNAPSHOT_COMPLETE')
(out / 'recovered-probe.sh').write_bytes(script.encode())
args = SSH[:]
args[-1] = 'penguin@172.16.42.1'
args = [x if not x.startswith('UserKnownHostsFile=') else
        'UserKnownHostsFile=out/native-install-20261017/known_hosts' for x in args]
for cmd, data in [
    ('cat > /home/penguin/read-charger-recovered-snapshot.sh', script.encode()),
    ('sh -n /home/penguin/read-charger-recovered-snapshot.sh; '
     'sha256sum /home/penguin/charger-watchdog-probe/qcom_battmgr-watchdog.ko', None),
]:
    p = subprocess.run(args + [cmd], input=data, capture_output=True, timeout=25)
    print(p.stdout.decode(errors='replace'))
    print(p.stderr.decode(errors='replace'))
    p.check_returncode()
p = subprocess.run(args + ['sudo -n true'], capture_output=True, timeout=15)
print('Noninteractive sudo:', p.returncode == 0)
print(p.stderr.decode(errors='replace'))

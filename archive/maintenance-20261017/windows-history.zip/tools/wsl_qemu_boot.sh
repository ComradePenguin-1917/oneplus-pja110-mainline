#!/bin/bash
# Boot OUR kernel + OUR initramfs under QEMU to get a REAL console.
#
# What this can and cannot tell us
# --------------------------------
# CAN: whether our kernel Image is a sane arm64 kernel that boots at all, whether
#      /init runs, whether the busybox applets work, and whether the signalling
#      ladder behaves as written. Those are properties of OUR artefacts.
# CANNOT: reproduce the phone (different SoC, memory map, device tree, firmware).
#      So a failure here is a real bug in our artefacts; a success here does not
#      prove the phone will work.
#
# QEMU virt provides a PL011 UART at 0x9000000, so use console=ttyAMA0 and
# earlycon=pl011,0x9000000 -- neither depends on a device tree.
set -uo pipefail

ROOT="$HOME/workspace/PJA110-Mainline"
QEMU="$ROOT/toolchain/qemu/sysroot/usr/bin/qemu-system-aarch64"
IMG="$ROOT/out/Image-poweroff"
INITRD="$ROOT/initramfs/initramfs.cpio.gz"

export LD_LIBRARY_PATH="$ROOT/toolchain/qemu/sysroot/usr/lib/x86_64-linux-gnu:${LD_LIBRARY_PATH:-}"
export QEMU_DATADIR="$ROOT/toolchain/qemu/sysroot/usr/share/qemu"

echo "=== sanity ==="
[ -x "$QEMU" ] && echo "  qemu: $("$QEMU" --version | head -1)" || { echo "  qemu missing"; exit 1; }
ls -l "$IMG" "$INITRD" | sed 's/^/  /'

echo
echo "=== boot (90s cap) ==="
echo "  console : pl011 @0x9000000 (explicitly, no DT needed)"
echo "  note    : our /init powers off when it finds no USB, so a SHUTDOWN here"
echo "            means /init ran -- which is exactly what we want to confirm."
echo

timeout 90 "$QEMU" \
    -M virt -cpu cortex-a57 -smp 2 -m 2048 \
    -kernel "$IMG" \
    -initrd "$INITRD" \
    -append "console=ttyAMA0 earlycon=pl011,0x9000000 loglevel=8 rdinit=/init ignore_loglevel" \
    -nographic -no-reboot \
    2>&1 | tail -150

rc=${PIPESTATUS[0]}
echo
echo "=== qemu exit: rc=$rc ==="
echo "  124 = timeout (still running at 90s)"
echo "  0   = exited cleanly (e.g. our poweroff/reboot ladder fired)"

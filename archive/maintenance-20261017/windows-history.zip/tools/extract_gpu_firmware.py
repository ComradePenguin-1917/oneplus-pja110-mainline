"""Extract stock GPU firmware from live super using read-only SSH reads."""
import hashlib
import json
import re
import struct
import subprocess
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/gpu-firmware-stock-20261014'
OUT.mkdir(exist_ok=True)
KEYS=ROOT/'out/usb-ncm-20261013/ssh'
SSH=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(KEYS/'client_key_host'),
     '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
     '-o',f'UserKnownHostsFile={KEYS/"known_hosts"}','-o','ConnectTimeout=5','root@169.254.42.1']

def read(cmd,timeout=60):
    p=subprocess.run(SSH+[cmd],capture_output=True,timeout=timeout)
    p.check_returncode()
    return p.stdout

def device():
    raw=read('for f in /sys/class/block/sd*/uevent; do cat "$f"; echo END; done').decode()
    found=[]
    for record in raw.split('END'):
        props=dict(line.split('=',1) for line in record.splitlines() if '=' in line)
        if props.get('PARTNAME')=='super':found.append(props['DEVNAME'])
    assert len(found)==1 and re.fullmatch(r'sd[a-z]+[0-9]+',found[0])
    return found[0]

dev=device()
if sys.argv[1]=='metadata':
    data=read(f'dd if=/dev/{dev} bs=4096 count=1024 2>/dev/null')
    assert len(data)==4194304
    (OUT/'super-metadata.bin').write_bytes(data)
    geom=data[4096:8192]
    magic,size=struct.unpack_from('<II',geom)
    assert magic==0x616c4467 and size==52
    check=bytearray(geom[:size]);check[8:40]=bytes(32)
    assert hashlib.sha256(check).digest()==geom[8:40]
    maxsize,slots,block=struct.unpack_from('<III',geom,40)
    results=[]
    for slot in range(slots):
        offset=12288+slot*maxsize
        head=data[offset:offset+maxsize]
        magic,major,minor,hsize=struct.unpack_from('<IHHI',head)
        if magic!=0x414c5030:continue
        check=bytearray(head[:hsize]);check[12:44]=bytes(32)
        assert hashlib.sha256(check).digest()==head[12:44]
        tsize=struct.unpack_from('<I',head,44)[0]
        tables=head[hsize:hsize+tsize]
        assert hashlib.sha256(tables).digest()==head[48:80]
        po,pn,ps=struct.unpack_from('<III',head,80)
        eo,en,es=struct.unpack_from('<III',head,92)
        assert ps==52 and es==24
        partitions=[]
        for i in range(pn):
            name,attrs,first,count,group=struct.unpack_from('<36sIIII',tables,po+i*ps)
            name=name.split(b'\0')[0].decode()
            extents=[]
            for j in range(first,first+count):
                sectors,kind,start,source=struct.unpack_from('<QIQI',tables,eo+j*es)
                extents.append(dict(sectors=sectors,kind=kind,start_sector=start,source=source))
            partitions.append(dict(name=name,attributes=attrs,extents=extents,
                                   size=sum(e['sectors']*512 for e in extents)))
        results.append(dict(slot=slot,major=major,minor=minor,partitions=partitions))
    report=dict(super_device=dev,logical_block_size=block,metadata=results)
    (OUT/'super-layout.json').write_text(json.dumps(report,indent=2)+'\n')
    print('PASS: super geometry, header and table SHA256 verified')
    for entry in results:
        print('Metadata slot',entry['slot'])
        for p in entry['partitions']:
            if p['name'].startswith('vendor'):print(p['name'],p['size'],'bytes')
elif sys.argv[1]=='partition':
    name=sys.argv[2]
    report=json.loads((OUT/'super-layout.json').read_text())
    part=next(p for p in report['metadata'][0]['partitions'] if p['name']==name)
    target=OUT/(name+'.img')
    with target.open('wb') as f:
        for extent in part['extents']:
            assert extent['kind']==0 and extent['source']==0
            start=extent['start_sector'];count=extent['sectors']
            assert start%8==0 and count%8==0
            print(f'Reading {name}: sector {start}, {count*512} bytes',flush=True)
            p=subprocess.run(SSH+[f'dd if=/dev/{dev} bs=4096 skip={start//8} count={count//8} 2>/dev/null'],
                             stdout=f,stderr=subprocess.PIPE,timeout=900)
            p.check_returncode()
    assert target.stat().st_size==part['size']
    print('SHA256',hashlib.sha256(target.read_bytes()).hexdigest(),flush=True)
else:
    raise SystemExit('metadata | partition NAME')

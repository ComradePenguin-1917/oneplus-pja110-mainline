"""Replace only the touch module and its init hooks in the verified init_boot."""
import gzip
import hashlib
import json
import struct
from pathlib import Path
from build_init_marker_test import parse_cpio, make_entry, lz4

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'out/aston-touch-240hz-20261013'
source = (ROOT / 'out/touch-port-20261013/init_boot_b-touch-autostart.img').read_bytes()
baseline = json.loads((OUT / 'device-before.json').read_text())
assert hashlib.sha256(source).hexdigest() == baseline['init_boot_b']
physical = json.loads((OUT / 'physical-result7.json').read_text())
assert physical['frames'] > 1000 and not physical['evdev_overflow']
assert physical['user_observation'] == '正常'
manifest = json.loads((OUT / 'source-manifest.json').read_text())
for item in manifest['files']:
    assert hashlib.sha256((ROOT / manifest['source_directory'] / item['path']).read_bytes()).hexdigest() == item['adapted_sha256']
assert b'IRQF_TRIGGER_LOW' in (ROOT / manifest['source_directory'] / 'syna_tcm2_spi.c').read_bytes()
old_size = struct.unpack_from('<I', source, 12)[0]
archive = lz4(['-d', '-l', '-c'], source[4096:4096 + old_size])
entries = parse_cpio(archive)
mapping = {n.removeprefix('./'): (f, d) for f, n, d in entries}
init = mapping['init'][1]
old = b'/lib/modules/mainline_touch_probe.ko'
assert init.count(old) == 3  # two insmod calls, one QEMU existence check
assert init.count(b'enable_touch=1') == 2
init = init.replace(old, b'/lib/modules/synaptics-aston.ko').replace(b'enable_touch=1', b'report_rate_code=3')
init = init.replace(b'S3910 touch modules loaded', b'Aston S3910 240Hz touch modules loaded')
changes = {'init': init, 'lib/modules/synaptics-aston.ko': (OUT / 'synaptics-aston.ko').read_bytes()}
removed = 'lib/modules/mainline_touch_probe.ko'
ino = max(f[0] for f, n, d in entries) + 1
output = bytearray()
for fields, name, data in entries:
    normalized = name.removeprefix('./')
    if normalized == removed:
        continue
    if name == 'TRAILER!!!':
        output += make_entry([ino, 0o100644, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
                             'lib/modules/synaptics-aston.ko', changes['lib/modules/synaptics-aston.ko'])
    output += make_entry(fields, name, changes.get(normalized, data))
rebuilt = {n.removeprefix('./'): (f, d) for f, n, d in parse_cpio(output)}
assert removed not in rebuilt
for name, data in changes.items():
    assert rebuilt[name][1] == data
for name, record in mapping.items():
    if name not in changes and name != removed:
        assert rebuilt[name] == record, name
ramdisk = lz4(['-z', '-l', '-12', '-c'], output)
align = lambda n: (n + 4095) // 4096 * 4096
old_end, new_end = 4096 + align(old_size), 4096 + align(len(ramdisk))
assert new_end <= len(source)
if new_end > old_end:
    assert not any(source[old_end:new_end])
result = bytearray(source)
struct.pack_into('<I', result, 12, len(ramdisk))
result[4096:max(old_end, new_end)] = ramdisk.ljust(max(old_end, new_end) - 4096, b'\0')
assert result[:12] == source[:12] and result[16:4096] == source[16:4096]
assert result[max(old_end, new_end):] == source[max(old_end, new_end):]
assert lz4(['-d', '-l', '-c'], result[4096:4096 + len(ramdisk)]) == bytes(output)
(OUT / 'init_boot_b-aston-240hz.img').write_bytes(result)
(OUT / 'initramfs-touch.cpio.gz').write_bytes(gzip.compress(output, mtime=0))
(OUT / 'init-aston-240hz.sh').write_bytes(init)
(OUT / 'autostart-manifest.json').write_text(json.dumps({
    'baseline_hashes': baseline,
    'init_boot_sha256': hashlib.sha256(result).hexdigest(),
    'module_sha256': hashlib.sha256(changes['lib/modules/synaptics-aston.ko']).hexdigest(),
    'rate_code': 3, 'irq_trigger': 'active-low level',
    'ssh_identity_and_other_entries_preserved': True,
    'phone_execution_confirmed': False,
}, indent=2) + '\n')
print('PASS: Aston code3/level IRQ autostart packaged; SSH identities and other archive entries preserved')

#!/bin/bash
set -euo pipefail
OUT=/mnt/h/workspace/PJA110-Mainline/out/gpu-firmware-stock-20261014
BUILD="$HOME/workspace/PJA110-Mainline/erofs-extraction-tools"
DEST="$BUILD/vendor-a-extracted"
if [ ! -f "$BUILD/vendor-a-extraction.complete" ]; then
    "$BUILD/erofs-utils-1.7.1/fsck/fsck.erofs" --no-preserve --overwrite --extract="$DEST" "$OUT/vendor_a.img" > "$OUT/vendor-a-extraction.log" 2>&1
    touch "$BUILD/vendor-a-extraction.complete"
fi
find "$DEST" -type f | grep -iE 'a740|a730|gmu|zap|sqe' | tee "$OUT/vendor-gpu-file-list.txt"
cp "$DEST/build.prop" "$OUT/vendor-build.prop"

$ErrorActionPreference = 'Stop'
$headers = @{ Accept='application/vnd.github+json'; 'User-Agent'='PJA110-port-comparison' }
$outputRoot = Join-Path $PSScriptRoot '../out/aston-usb-comparison-20261013'
[IO.Directory]::CreateDirectory($outputRoot) | Out-Null
$refs = @{
    vanilla = @{ Repo='torvalds/linux'; Commit='38fec10eb60d687e30c8c6b5420d86e8149f7557' }
    aston = @{ Repo='jiganomegsdfdf/aston-mainline'; Commit='5d5c840896bb49291ae4578acefd5a3ec65524f6' }
}
function Get-Tree($repo, $sha, $recursive=$false) {
    $uri = "https://api.github.com/repos/$repo/git/trees/$sha"
    if ($recursive) { $uri += '?recursive=1' }
    $result = Invoke-RestMethod $uri -Headers $headers
    if ($result.truncated) { throw "Truncated tree: $uri" }
    return $result.tree
}
$trees = @{}
foreach ($name in @('vanilla','aston')) {
    $ref = $refs[$name]
    $root = Get-Tree $ref.Repo $ref.Commit
    $driversSha = ($root | Where-Object path -eq 'drivers').sha
    $drivers = Get-Tree $ref.Repo $driversSha
    $usbSha = ($drivers | Where-Object path -eq 'usb').sha
    $phySha = ($drivers | Where-Object path -eq 'phy').sha
    $phy = Get-Tree $ref.Repo $phySha
    $qcomSha = ($phy | Where-Object path -eq 'qualcomm').sha
    $files = @{}
    foreach ($scope in @(@{Prefix='drivers/usb/';Sha=$usbSha}, @{Prefix='drivers/phy/qualcomm/';Sha=$qcomSha})) {
        foreach ($entry in (Get-Tree $ref.Repo $scope.Sha $true)) {
            if ($entry.type -eq 'blob') { $files[$scope.Prefix + $entry.path] = $entry.sha }
        }
    }
    $files | ConvertTo-Json -Depth 10 | Set-Content -Encoding utf8 (Join-Path $outputRoot "$name-tree.json")
    $trees[$name] = $files
    Write-Output "$name files=$($files.Count)"
}
$differences = @()
foreach ($path in (@($trees.vanilla.Keys) + @($trees.aston.Keys) | Sort-Object -Unique)) {
    if ($trees.vanilla[$path] -ne $trees.aston[$path]) {
        $differences += [pscustomobject]@{Path=$path;Vanilla=$trees.vanilla[$path];Aston=$trees.aston[$path]}
    }
}
$differences | ConvertTo-Json -Depth 10 | Set-Content -Encoding utf8 (Join-Path $outputRoot 'different-files.json')
$related = @(
    'drivers/usb/dwc3/ep0.c', 'drivers/usb/gadget/function/u_serial.c',
    'drivers/clk/qcom/gcc-sm8550.c',
    'drivers/interconnect/qcom/sm8550.c', 'drivers/interconnect/qcom/icc-rpmh.c',
    'drivers/interconnect/qcom/bcm-voter.c', 'drivers/pmdomain/qcom/rpmhpd.c',
    'drivers/regulator/qcom-rpmh-regulator.c', 'drivers/soc/qcom/pmic_glink.c',
    'drivers/soc/qcom/pmic_glink_altmode.c', 'drivers/soc/qcom/pdr_interface.c',
    'drivers/iommu/arm/arm-smmu/arm-smmu-qcom.c'
)
$related | ConvertTo-Json | Set-Content -Encoding utf8 (Join-Path $outputRoot 'related-paths.json')
$paths = @($differences.Path) + $related + @('Makefile','arch/arm64/boot/dts/qcom/sm8550.dtsi','arch/arm64/boot/dts/qcom/pm8550b.dtsi','arch/arm64/boot/dts/qcom/sm8550-oneplus-aston.dts','arch/arm64/configs/sm8550.config')
foreach ($name in @('vanilla','aston')) {
    $ref=$refs[$name]
    foreach ($path in $paths) {
        if ($name -eq 'vanilla' -and $path -in @('arch/arm64/boot/dts/qcom/sm8550-oneplus-aston.dts','arch/arm64/configs/sm8550.config')) { continue }
        if ($path -like 'drivers/usb/*' -and -not $trees[$name].ContainsKey($path)) { continue }
        $dest=Join-Path $outputRoot "$name/$path"
        [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($dest)) | Out-Null
        if (Test-Path $dest) { continue } # All downloads are pinned to the refs above.
        Invoke-WebRequest "https://raw.githubusercontent.com/$($ref.Repo)/$($ref.Commit)/$path" -Headers $headers -OutFile $dest
    }
}
$refs | ConvertTo-Json -Depth 10 | Set-Content -Encoding utf8 (Join-Path $outputRoot 'refs.json')
$differences | Format-Table -AutoSize
Write-Output "Changed files=$($differences.Count)"

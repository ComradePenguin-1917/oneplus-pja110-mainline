#!/bin/bash
set -euo pipefail
WIN=/mnt/h/workspace/PJA110-Mainline
PKGS="$WIN/postmarketos/device/testing"
REF="$WIN/out/postmarketos-reference-20261014/main/devicepkg-dev"
OUT="$WIN/out/postmarketos-package-validation-20261015"
mkdir -p "$OUT"
for package in device-oneplus-xigua linux-oneplus-xigua firmware-oneplus-xigua-adreno; do
 bash -n "$PKGS/$package/APKBUILD"
done
stage=$(mktemp -d "$OUT/device-stage.XXXXXX")
device_stage="$stage"
mkdir -p "$stage/src"
cp "$PKGS/device-oneplus-xigua/"* "$stage/src/"
export startdir="$stage" srcdir="$stage/src" pkgdir="$stage/pkg/device-oneplus-xigua"
devicepkg_build() { bash "$REF/devicepkg_build.sh" "$@"; }
devicepkg_package() { bash "$REF/devicepkg_package.sh" "$@"; }
source "$PKGS/device-oneplus-xigua/APKBUILD"
build
package
test -f "$pkgdir/usr/share/deviceinfo/device-oneplus-xigua"
test -L "$pkgdir/usr/share/deviceinfo/deviceinfo"
test -f "$pkgdir/usr/lib/modprobe.d/device-oneplus-xigua.conf"
test -f "$pkgdir/usr/share/mkinitfs/modules/00-device-oneplus-xigua.modules"
grep -q 'report_rate_code=3' "$pkgdir/usr/lib/modprobe.d/device-oneplus-xigua.conf"
grep -q 'HARDWARE_VENDOR="OnePlus"' "$pkgdir/etc/machine-info"
export subpkgdir="$device_stage/pkg/device-oneplus-xigua-phosh"
phosh
test "$depends" = 'phoc=0.57.0-r2 mesa-dri-gallium'
test "$install_if" = 'device-oneplus-xigua=1-r2 postmarketos-ui-phosh'
cmp "$PKGS/device-oneplus-xigua/phoc.ini" "$subpkgdir/usr/share/phosh/phoc.ini"
stage=$(mktemp -d "$OUT/firmware-stage.XXXXXX")
firmware_stage="$stage"
mkdir -p "$stage/src"
cp "$PKGS/firmware-oneplus-xigua-adreno/"* "$stage/src/"
export startdir="$stage" srcdir="$stage/src" pkgdir="$stage/pkg/firmware-oneplus-xigua-adreno"
source "$PKGS/firmware-oneplus-xigua-adreno/APKBUILD"
package
for file in qcom/a740_sqe.fw qcom/gmu_gen70200.bin qcom/sm8550/xigua/a740_zap.mbn; do
 test -s "$pkgdir/usr/lib/firmware/$file"
done
find "$device_stage/pkg" "$firmware_stage/pkg" -type f -o -type l > "$OUT/staged-files.txt"
echo 'PASS: APKBUILD shell syntax; pinned upstream devicepkg helpers and local firmware package staged without root'

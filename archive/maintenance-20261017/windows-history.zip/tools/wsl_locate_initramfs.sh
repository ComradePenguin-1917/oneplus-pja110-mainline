#!/bin/bash
# Locate the embedded initramfs in the built Image, definitively.
#
# Symbols prove it is in vmlinux:
#   __initramfs_start = 0xffff80008188c488
#   __initramfs_size  = 0xffff8000819ad508   (difference = 0x121080 = 1183872)
# which matches our 1183869-byte archive padded to 4 bytes.
#
# The earlier gzip scan failed, so find out HOW it is stored: verbatim gzip,
# or re-compressed by the kernel build, or plain cpio.
set -u pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
TREE="$ROOT/linux"
cd "$TREE"

export PATH="$ROOT/toolchain/gcc-12-aarch64/usr/bin:$PATH"
export LD_LIBRARY_PATH="$ROOT/toolchain/gcc-12-aarch64/usr/lib/x86_64-linux-gnu:${LD_LIBRARY_PATH:-}"

echo "=== 1) what does the kernel build do with our .cpio.gz? ==="
sed -n '1,60p' usr/Makefile | grep -nE 'INITRAMFS|cpio|gz|compress' | head -20

echo
echo "=== 2) generated archive in usr/ ==="
ls -l usr/initramfs_data.cpio* 2>/dev/null
for f in usr/initramfs_data.cpio usr/initramfs_data.cpio.gz; do
    [ -f "$f" ] || continue
    echo "  $f: $(stat -c%s "$f") bytes, first 8 = $(head -c8 "$f" | xxd -p)"
done

echo
echo "=== 3) symbols ==="
grep -E '__initramfs_(start|end|size)' System.map | sed 's/^/  /'

echo
echo "=== 4) find it inside the Image by content, not by offset math ==="
python3 - <<'PY'
import io, os, re, subprocess

img = open('arch/arm64/boot/Image','rb').read()
print('  Image: %d bytes' % len(img))

# (a) plain cpio newc magic
for magic, label in ((b'070701', 'cpio newc (070701)'), (b'070702', 'cpio crc (070702)')):
    hits = [m.start() for m in re.finditer(re.escape(magic), img)]
    print('  %-22s occurrences: %d %s' % (label, len(hits), ['0x%x' % h for h in hits[:4]]))

# (b) our init banner (only present if stored uncompressed)
hits = [m.start() for m in re.finditer(rb'\[initramfs\]', img)]
print('  %-22s occurrences: %d %s' % ('[initramfs] text', len(hits), ['0x%x' % h for h in hits[:4]]))

# (c) gzip magic anywhere
gz = [m.start() for m in re.finditer(rb'\x1f\x8b\x08', img)]
print('  %-22s occurrences: %d' % ('gzip magic', len(gz)))

# (d) try each gzip offset, fully decompress, look for our markers
import gzip
for off in gz:
    try:
        data = gzip.GzipFile(fileobj=io.BytesIO(img[off:])).read()
    except Exception:
        continue
    if b'busybox' in data or b'TRAILER!!!' in data:
        print('  -> gzip stream @0x%x decompresses to %d bytes (busybox=%s)'
              % (off, len(data), b'busybox' in data))
        break
else:
    print('  -> no gzip stream contained our archive')

# (e) where is the raw cpio archive? use the size we know
size = 1183869
# search for the start of our cpio: "070701" is the first 6 bytes of the newc header
cands = [m.start() for m in re.finditer(rb'070701', img)]
print()
print('  candidate archive starts (cpio): %s' % ['0x%x' % c for c in cands[:5]])
PY

echo
echo "=== 5) extract the archive straight out of the Image and list it ==="
python3 - <<'PY'
import io, re, subprocess, os
img = open('arch/arm64/boot/Image','rb').read()
m = re.search(rb'070701', img)
if not m:
    print('  no cpio found in Image')
    raise SystemExit
start = m.start()
# our archive is 1183869 bytes; take a bit more and let cpio stop at TRAILER!!!
blob = img[start:start + 1183869 + 4096]
open('/tmp/embedded.cpio','wb').write(blob)
print('  wrote /tmp/embedded.cpio (%d bytes) starting at 0x%x' % (len(blob), start))
PY
if [ -f /tmp/embedded.cpio ]; then
    cpio -t < /tmp/embedded.cpio 2>/dev/null | head -12 | sed 's/^/    /'
    echo "    ..."
    echo "    entries: $(cpio -t < /tmp/embedded.cpio 2>/dev/null | wc -l)"
fi

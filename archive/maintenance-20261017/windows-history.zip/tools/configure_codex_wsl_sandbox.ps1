param(
    [ValidateSet('mxc', 'unelevated')]
    [string]$Mode = 'mxc',
    [string]$Distro = 'Ubuntu-22.04'
)

$ErrorActionPreference = 'Stop'
if ($env:USERNAME -like 'codexsandbox*') {
    throw 'Run this script from your normal Windows PowerShell, outside the agent sandbox.'
}

$workspacePath = Split-Path -Parent $PSScriptRoot
$configPath = Join-Path $env:USERPROFILE '.codex\config.toml'
if ($env:CODEX_HOME) {
    $configPath = Join-Path $env:CODEX_HOME 'config.toml'
}
$configPath = [System.IO.Path]::GetFullPath($configPath)
$configBytes = [System.IO.File]::ReadAllBytes($configPath)
$configText = [System.IO.File]::ReadAllText($configPath)
$windowsPattern = '(?ms)^\[windows\][ \t]*\r?\n(?<body>.*?)(?=^\[|\z)'
$windowsMatch = [regex]::Match($configText, $windowsPattern)
if (-not $windowsMatch.Success) {
    throw 'Expected one existing [windows] section; configuration was not changed.'
}
$settingPattern = '(?m)^[ \t]*sandbox[ \t]*=[ \t]*"(?:elevated|unelevated|mxc)"[ \t]*(?:#[^\r\n]*)?(?<cr>\r?)$'
$body = $windowsMatch.Groups['body'].Value
if ([regex]::Matches($body, $settingPattern).Count -ne 1) {
    throw 'Expected one recognized sandbox setting in [windows]; configuration was not changed.'
}

# Resolve and respect managed requirements. Explicit MXC fails rather than
# silently falling back to a different sandbox implementation.
$codexResolved = Get-Command codex -ErrorAction Stop | Select-Object -First 1
$pythonResolved = Get-Command python.exe -CommandType Application -ErrorAction Stop |
    Where-Object { Test-Path -LiteralPath $_.Source -PathType Leaf } |
    Select-Object -First 1
if (-not $pythonResolved) {
    throw 'No existing Python executable was found. Configuration was not changed.'
}
[string]$codexCommand = $codexResolved.Source
[string]$pythonCommand = $pythonResolved.Source
$probeScript = Join-Path $PSScriptRoot 'probe_wsl_utf8.py'
$probeLog = Join-Path $workspacePath ('out\wsl-sandbox-probe-' + $Mode + '.json')
$override = 'windows.sandbox="' + $Mode + '"'
Write-Host "Testing WSL in Codex sandbox mode: $Mode"
Write-Host "Python executable: $pythonCommand"
# PowerShell 5 treats native stderr as an error record. WSL's proxy warning
# is nonfatal, so determine success using the actual native exit code.
$ErrorActionPreference = 'Continue'
& $codexCommand -c $override sandbox --include-managed-config --permission-profile ':workspace' -C $workspacePath -- $pythonCommand $probeScript $Distro $probeLog
$probeExitCode = $LASTEXITCODE
$ErrorActionPreference = 'Stop'
if ($probeExitCode -ne 0) {
    throw "WSL sandbox probe failed (exit $probeExitCode). Configuration was not changed."
}

$updatedBody = [regex]::Replace($body, $settingPattern, ('sandbox = "' + $Mode + '"${cr}'))
$newText = $configText.Substring(0, $windowsMatch.Groups['body'].Index) +
    $updatedBody + $configText.Substring($windowsMatch.Groups['body'].Index + $body.Length)
if ($newText -eq $configText) {
    Write-Host 'WSL probe passed. Configuration already selects this mode.'
    exit 0
}
if ([Convert]::ToBase64String($configBytes) -ne [Convert]::ToBase64String([System.IO.File]::ReadAllBytes($configPath))) {
    throw 'Configuration changed during the probe. No settings were written; rerun the script.'
}
$backupPath = $configPath + '.before-wsl-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff')
Copy-Item -LiteralPath $configPath -Destination $backupPath -ErrorAction Stop
[System.IO.File]::WriteAllText($configPath, $newText, (New-Object System.Text.UTF8Encoding($false)))
Write-Host "WSL probe passed. Updated: $configPath"
Write-Host "Backup: $backupPath"
Write-Host 'Restart Codex completely, then resume the project and verify whoami and WSL access.'

#!/bin/bash
# Build a self-contained aarch64 cross toolchain under the workspace, with NO
# root and NO system packages touched.
#
# Method: download Ubuntu's own gcc-12-aarch64-linux-gnu .deb set (rootless via
# `apt-get download`) and unpack them into toolchain/gcc-12-aarch64/.
#
# Usage:
#   bash wsl_setup_toolchain.sh            # install/refresh
#   bash wsl_setup_toolchain.sh --verify   # only verify what is there
set -euo pipefail

ROOT="$HOME/workspace/PJA110-Mainline"
TC="$ROOT/toolchain"
PREFIX="$TC/gcc-12-aarch64"
CACHE="$TC/.debcache"
PKGS="gcc-12-aarch64-linux-gnu binutils-aarch64-linux-gnu"

if [ "${1:-}" = "--verify" ]; then
    :
else
    mkdir -p "$PREFIX" "$CACHE"
    cd "$CACHE"

    echo "=== resolving dependency closure for: $PKGS ==="
    DEPS=$(apt-cache depends --recurse --no-recommends --no-suggests \
             --no-conflicts --no-breaks --no-replaces --no-enhances \
             $PKGS 2>/dev/null | grep -E '^\w' | sort -u)
    echo "$DEPS" | wc -l | xargs echo "packages:"

    echo "=== downloading (rootless) ==="
    apt-get download $DEPS 2>&1 | tail -2

    echo "=== extracting into $PREFIX ==="
    rm -rf "$PREFIX"
    mkdir -p "$PREFIX"
    for d in *.deb; do
        dpkg-deb -x "$d" "$PREFIX"
    done
    echo "extracted $(ls -1 *.deb | wc -l) packages"
fi

echo
echo "=== locate the compiler ==="
GCC=$(find "$PREFIX" -name 'aarch64-linux-gnu-gcc*' -type f 2>/dev/null | head -1)
if [ -z "$GCC" ]; then
    echo "  not found -- run without --verify first"
    exit 1
fi
echo "  $GCC"
echo "  real: $(readlink -f "$GCC")"

echo
echo "=== version check against kernel minimums ==="
"$GCC" --version | head -1
"$PREFIX/usr/bin/aarch64-linux-gnu-ld" --version 2>/dev/null | head -1 || \
    find "$PREFIX" -name 'aarch64-linux-gnu-ld' | head -1

echo
echo "=== size on disk ==="
du -sh "$PREFIX" "$CACHE" 2>/dev/null

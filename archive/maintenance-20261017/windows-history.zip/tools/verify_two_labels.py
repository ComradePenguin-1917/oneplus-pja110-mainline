#!/usr/bin/env python3
"""MAJOR CORRECTION: my "ABL ignores the appended DTB" conclusion was WRONG.

What I concluded
----------------
I appended a marked vendor DTB to the stock kernel, booted, and the markers were
absent from the running tree. I concluded "ABL ignores appended DTBs".

Why that was wrong
------------------
My own earliest research notes (docs/porting-status.md, section 3.6, written
before any of these experiments) already recorded the mechanism:

    SM8550 ABL only applies a DTBO if the BASE device tree contains two labels:
    `qcom_tzlog` and `arch_timer`. Without them ABL refuses and falls back to the
    bootloader menu. The community workaround is `fastboot erase dtbo`, or simply
    putting the DTB in the boot image.

And the Ace 3 / 12R port (aston, same SM8550 + same OPPO ABL) does exactly:

    cat arch/arm64/boot/Image sm8550-oneplus-aston.dtb > Image_w_dtb
    gzip Image_w_dtb
    mkbootimg --header_version 4 --kernel Image_w_dtb.gz -o boot.img

So the appended DTB clearly IS honoured on this family. The LKML thread
"arm64: dts: qcom: sm8550: Fix DTBO boot failure" (Pavan Kondeti / Aaron Kling,
Feb 2026) documents the two required labels, and Bjorn Andersson's reply notes
that a device can simply avoid ABL's overlay path.

So in my marker probe, ABL most likely DID use my appended DTB, and then
REPLACED it with the vendor tree built from vendor_boot + dtbo -- because the
vendor dtbo's overlays were applied on top, and those overlays write `model`.

That is consistent with everything observed:
  * the marker was gone                       (overlay rewrote /chosen and model)
  * yet `vendor_boot` injection DID survive    (that IS the base tree, in flash)

Let me verify the two required labels in each tree, which is the decisive check.
"""
import os
import struct
import sys

sys.path.insert(0, os.path.join(r'H:\WorkSpace\PJA110-Mainline', 'tools'))
from fdt import FDT

WS = r'H:\WorkSpace\PJA110-Mainline'


def labels_of(nodes):
    return set(nodes.get('/__symbols__', {}).keys())


print('=' * 78)
print('THE TWO LABELS ABL REQUIRES IN A BASE DTB')
print('=' * 78)

# our DTB
ours = FDT(open(os.path.join(WS, 'dts', 'sm8550-oneplus-xigua-16G.dtb'), 'rb').read()).nodes()
ol = labels_of(ours)

# the marked probe DTB I appended (derived from the live tree)
probe = FDT(open(os.path.join(WS, 'out', 'probe2.dtb'), 'rb').read()).nodes()
pl = labels_of(probe)

# vendor base tree
v = open(os.path.join(WS, 'backup', 'vendor_boot_b.img'), 'rb').read()
hsize, dtbsize = struct.unpack_from('<2I', v, 28+2048+4+16)
vrsize = struct.unpack_from('<I', v, 24)[0]
dtb_off = (((hsize+4095)//4096)*4096 + vrsize + 4095)//4096*4096
e0 = struct.unpack_from('>I', v, dtb_off+4)[0]
vl = labels_of(FDT(v[dtb_off:dtb_off+e0]).nodes())

for label, syms in (('OUR DTB', ol), ('probe2.dtb (marked live tree)', pl),
                    ('vendor_boot entry0', vl)):
    print('%-32s qcom_tzlog: %-6s arch_timer: %-6s (labels: %d)'
          % (label, 'qcom_tzlog' in syms, 'arch_timer' in syms, len(syms)))

print()
print('=' * 78)
print('WHAT probe2.dtb WAS')
print('=' * 78)
print('  probe2.dtb = the LIVE device tree (dumped from /sys/firmware/fdt)')
print('               + markers at /, /soc, /chosen')
print()
print('  The live tree is the POST-OVERLAY result. So it already has the overlays')
print('  baked in, and its root properties may not look like a pristine base DTB.')

print()
print('=' * 78)
print('THE DECISIVE NEXT TEST')
print('=' * 78)
print('  Per my own earlier notes, ABL refuses to apply a dtbo unless the base DTB')
print('  has qcom_tzlog + arch_timer. Our DTB HAS both.')
print()
print('  And the community workaround for the ABL dtbo bug is to remove the dtbo')
print('  entirely:  fastboot erase dtbo')
print()
print('  That combination has never been tested here:')
print('    1. fastboot erase dtbo        (so ABL has no overlay to apply)')
print('    2. fastboot boot our boot.img (Image + OUR dtb appended)')
print()
print('  If the appended DTB is honoured once the overlay is gone, our kernel')
print('  finally gets OUR device tree -- which is the whole goal.')
print()
print('  This is safe: dtbo_b is backed up and dtbo_a is stock (30b4002a...).')
print('  `fastboot flash dtbo backup/dtbo_a.img` restores it exactly.')

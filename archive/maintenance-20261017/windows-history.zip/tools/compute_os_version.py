#!/usr/bin/env python3
"""Compute the exact os_version/os_patch_level word aston's mkbootimg writes.

aston runs:
    mkbootimg --header_version 4 --base 0x0 \
              --os_version 15.0.0 --os_patch_level 2025-02 \
              --kernel Image_w_dtb.gz -o boot16G_A14.img

AOSP's mkbootimg packs BOTH os_version and os_patch_level into one 32-bit field:

    os_version      = (a << 25) | (b << 18) | (c << 11) | 0      (c = 0 here)
    os_patch_level  = (year-2000) << 4 | month
    packed          = os_version | os_patch_level
                    = (a<<25) | (b<<18) | (c<<11) | ((y-2000)<<4) | m

For --os_version 15.0.0 and --os_patch_level 2025-02:
    a=15, b=0, c=0, y=2025, m=2
    packed = (15<<25) | (0<<18) | (0<<11) | (25<<4) | 2

Let me compute it and compare with the stock value, and also check how aston's
own images read back so we match the real artefact rather than my arithmetic.
"""
stock = 0x1A000184

a, b, c = 15, 0, 0
y, m = 2025, 2
packed = (a << 25) | (b << 18) | (c << 11) | ((y - 2000) << 4) | m

print('=' * 78)
print('os_version WORD COMPARISON')
print('=' * 78)
print('  stock (what we have used all along) : 0x%08X' % stock)
print('    -> major=%d minor=%d year=%d month=%d'
      % ((stock >> 25) & 0x7F, (stock >> 18) & 0x7F,
         2000 + ((stock >> 11) & 0x7F), (stock >> 4) & 0x0F))
print()
print('  aston (--os_version 15.0.0 --os_patch_level 2025-02)')
print('    computed                          : 0x%08X' % packed)
print('    -> major=%d minor=%d year=%d month=%d'
      % ((packed >> 25) & 0x7F, (packed >> 18) & 0x7F,
         2000 + ((packed >> 11) & 0x7F), (packed >> 4) & 0x0F))
print()
print('  identical to stock? %s' % (packed == stock))
print('  difference        : %d (0x%X)' % (packed - stock, packed - stock))

#!/usr/bin/env python3
"""Before abandoning pstore: is Android DELETING the records on boot?

The control showed that even Android's own deliberate panic leaves
/sys/fs/pstore empty. Two very different explanations:

  (a) the kernel never records panics on this device at all -> channel is dead
  (b) the kernel DOES record them, but Android's init deletes /sys/fs/pstore/*
      during startup, so by the time adb is available the evidence is gone

(b) is common on Android: many devices ship an init action or a service that
clears pstore after collecting it for the vendor crash pipeline.

If (b) is true the channel is still usable -- I just have to read it EARLY, or
read the underlying RAM directly, or disable the cleanup.

Check the device's own init scripts for pstore handling.
"""
import shutil
import subprocess

ADB = shutil.which('adb') or r'C:\platform-tools\adb.exe'
SERIAL = 'bc7a542e'


def root(cmd, timeout=300):
    r = subprocess.run([ADB, '-s', SERIAL, 'shell', "su -c '%s'" % cmd],
                       capture_output=True, timeout=timeout)
    return ((r.stdout or b'') + (r.stderr or b'')).decode('utf-8', 'replace')


def plain(cmd, timeout=300):
    r = subprocess.run([ADB, '-s', SERIAL, 'shell', cmd], capture_output=True, timeout=timeout)
    return ((r.stdout or b'') + (r.stderr or b'')).decode('utf-8', 'replace')


print('=' * 78)
print('1) does any init script touch pstore?')
print('=' * 78)
out = root('grep -rl pstore /system/etc/init /vendor/etc/init /odm/etc/init '
           '/system/bin/init* 2>/dev/null | head -20')
print('  files mentioning pstore:')
for line in out.splitlines():
    if line.strip():
        print('    %s' % line.strip())

print()
print('  matching lines:')
out = root('grep -rn pstore /system/etc/init /vendor/etc/init /odm/etc/init 2>/dev/null | head -20')
for line in out.splitlines():
    if line.strip():
        print('    %s' % line.strip()[:130])

print()
print('=' * 78)
print('2) is there a pstore-related service or property?')
print('=' * 78)
for prop in ('ro.pstore', 'persist.vendor.pstore', 'vendor.pstore.enable',
             'ro.vendor.pstore', 'persist.sys.pstore'):
    v = plain('getprop %s' % prop).strip()
    if v:
        print('  %-32s %s' % (prop, v))
print()
print('  processes mentioning pstore:')
print(plain('ps -A 2>/dev/null | grep -i pstore').strip()[:300] or '  (none)')

print()
print('=' * 78)
print('3) the kernel side: is pstore actually registered as a backend?')
print('=' * 78)
print('  /sys/fs/pstore exists : %s' % ('yes' if 'pstore' in root('ls /sys/fs/ 2>&1') else 'no'))
print('  pstore backend dir    : %s' % root('ls /sys/fs/pstore/ 2>&1').strip()[:120])
print()
print('  kernel messages about pstore/ramoops at boot:')
print('   ', plain('dmesg 2>/dev/null | grep -i -E "pstore|ramoops" | head -12').strip()[:800] or
      '(dmesg restricted)')

print()
print('=' * 78)
print('4) does the vendor have its OWN crash pipeline instead of pstore?')
print('=' * 78)
print('  the ABL log earlier showed minidump is ON; check for its userspace side:')
for d in ('/data/vendor/ramdump', '/data/vendor/minidump', '/data/ramdump',
          '/data/vendor/ssr', '/data/tombstones', '/sys/kernel/boot_slpi'):
    r = root('ls -d %s 2>/dev/null && echo EXISTS || echo -' % d).strip()
    print('    %-30s %s' % (d, r.splitlines()[0] if r else '-'))

print()
print('=' * 78)
print('5) can we defeat a boot-time cleanup by reading pstore earlier?')
print('=' * 78)
print('  boot-completion marker comparison:')
print('    sys.boot_completed = %s' % plain('getprop sys.boot_completed').strip())
print('  If a cleanup runs on boot_completed, then reading pstore right after')
print('  adbd starts (well before boot_completed) would still find the records.')
print('  That is testable: panic, then poll pstore from the very first adb moment.')

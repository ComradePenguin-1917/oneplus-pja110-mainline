#!/usr/bin/env python3
"""CONTROL TEST: does slot B boot at all on this device?

This settles whether the decisive experiment was even valid.

  If slot B boots stock fine -> set_active works, B was attempted, and our
     kernel is what failed  => a REAL negative result for our kernel.
  If slot B does not boot stock either -> the slot mechanism itself is the
     problem, and our kernel was never exercised.

Method:
  1. restore boot_b and vendor_boot_b to their stock contents
  2. keep dtbo_b as it is (erased) -- irrelevant for a stock control
  3. set_active b, reboot, read ro.boot.slot_suffix

Everything is backed up, so this is safe and reversible.
"""
import hashlib
import os
import shutil
import subprocess
import sys
import time

ADB = shutil.which('adb') or r'C:\platform-tools\adb.exe'
FB = shutil.which('fastboot') or r'C:\platform-tools\fastboot.exe'
WS = r'H:\WorkSpace\PJA110-Mainline'
SERIAL = 'bc7a542e'


def run(cmd, timeout=900):
    r = subprocess.run(cmd, capture_output=True, timeout=timeout)
    return ((r.stdout or b'') + (r.stderr or b'')).decode('utf-8', 'replace')


def adb_up():
    return SERIAL in [l.split()[0] for l in run([ADB, 'devices']).splitlines()
                      if l.strip().endswith('device')]


def fb_up():
    return SERIAL in [l.split()[0] for l in run([FB, 'devices']).splitlines()
                      if 'fastboot' in l]


def wait(cond, secs=240):
    for _ in range(secs // 3):
        if cond():
            return True
        time.sleep(3)
    return False


print('=' * 78)
print('CONTROL: will slot B boot with STOCK images?')
print('=' * 78)

print()
print('--- enter bootloader ---')
if adb_up():
    run([ADB, '-s', SERIAL, 'reboot', 'bootloader'])
if not wait(fb_up, 120):
    print('  failed to reach fastboot')
    sys.exit(2)
print('  ok')
time.sleep(5)

print()
print('--- restore slot B to stock ---')
for part, src in (('boot_b', os.path.join(WS, 'backup', 'boot_b.img')),
                  ('vendor_boot_b', os.path.join(WS, 'backup', 'vendor_boot_b.img'))):
    out = run([FB, 'flash', part, src])
    ok = 'OKAY' in out and 'FAILED' not in out
    print('  %-16s %s' % (part, 'OKAY' if ok else out.strip()[:80]))

# dtbo_b: restore too, so this control is a clean stock slot
out = run([FB, 'flash', 'dtbo_b', os.path.join(WS, 'backup', 'dtbo_b.img')])
print('  %-16s %s' % ('dtbo_b', 'OKAY' if 'OKAY' in out else out.strip()[:80]))

print()
print('--- set active b ---')
print('  ', run([FB, 'set_active', 'b']).strip().splitlines()[0])
print('  ', run([FB, 'getvar', 'current-slot']).strip().splitlines()[0])

print()
print('--- reboot ---')
run([FB, 'reboot'])
ok = wait(adb_up, 300)
print('  device up: %s' % ok)

if ok:
    time.sleep(15)
    slot = run([ADB, '-s', SERIAL, 'shell', 'getprop', 'ro.boot.slot_suffix']).strip()
    boot = run([ADB, '-s', SERIAL, 'shell', 'getprop', 'sys.boot_completed']).strip()
    kern = run([ADB, '-s', SERIAL, 'shell', 'uname', '-r']).strip()
    print()
    print('  slot_suffix    : %s' % slot)
    print('  boot_completed : %s' % boot)
    print('  kernel         : %s' % kern)

    print()
    print('=' * 78)
    if slot == '_b':
        print('  RESULT: slot B BOOTS with stock images.')
        print('  => set_active works, and slot B is bootable.')
        print('  => our kernel/tree combination is what failed on B.')
        print('     The decisive experiment was VALID, and its outcome is a real')
        print('     negative: our kernel does not reach userspace even with our own')
        print('     device tree and no overlays.')
    else:
        print('  RESULT: asked for slot B, but came up on %s.' % slot)
        print('  => the slot switch is not being honoured the way I assumed, so the')
        print('     decisive experiment may not have exercised our kernel at all.')
        print('     Must resolve this before drawing conclusions.')
else:
    print('  device did not come up; recovery may be needed')

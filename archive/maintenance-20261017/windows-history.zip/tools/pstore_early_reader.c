/* Freestanding ARM64 init wrapper: read previous pstore before Android policy. */
typedef unsigned long u64;
void *memcpy(void *dst,const void *src,u64 n) {
    char *d=dst; const char *s=src; for(u64 i=0;i<n;++i) d[i]=s[i]; return dst;
}
static long sc(long n, long a, long b, long c, long d, long e, long f) {
    register long x0 __asm__("x0")=a, x1 __asm__("x1")=b, x2 __asm__("x2")=c;
    register long x3 __asm__("x3")=d, x4 __asm__("x4")=e, x5 __asm__("x5")=f;
    register long x8 __asm__("x8")=n;
    __asm__ volatile("svc 0" : "+r"(x0) : "r"(x1),"r"(x2),"r"(x3),"r"(x4),"r"(x5),"r"(x8) : "memory");
    return x0;
}
#define CALL(n,a,b,c) sc(n,(long)(a),(long)(b),(long)(c),0,0,0)
static char buf[4096];
static const char marker[]="PJA110_STOCK_PMSG_20261012_R1";
static unsigned len(const char *s) { unsigned n=0; while(s[n]) ++n; return n; }
static int equal(const char *a,const char *b) { while(*a&&*a==*b) {++a;++b;} return *a==*b; }
static void hex2(char *p,long rc) {
    unsigned n=rc<0 ? -rc : rc;
    p[0]="0123456789abcdef"[(n>>4)&15]; p[1]="0123456789abcdef"[n&15];
}
static long scan(const char *path, int *hit) {
    long fd=CALL(56,-100,path,0);
    if(fd<0) return fd;
    unsigned match=0, size=len(marker);
    long n;
    while((n=CALL(63,fd,buf,sizeof(buf)))>0) {
        for(long i=0;i<n;++i) {
            if(buf[i]==marker[match]) { if(++match==size) { *hit=1; match=0; } }
            else match=buf[i]==marker[0] ? 1 : 0;
        }
    }
    CALL(57,fd,0,0);
    return n<0 ? n : 0;
}
void start_c(u64 *stack) {
    u64 argc=stack[0]; char **argv=(char **)(stack+1), **env=argv+argc+1;
    if(argc>2 && equal(argv[1],"--selftest")) {
        int hit=0; long rc=scan(argv[2],&hit);
        char s[]="PJA110_SCAN_H0_RC00"; s[13]='0'+hit; hex2(s+17,rc);
        CALL(64,1,s,sizeof(s)-1); CALL(93,rc<0?1:0,0,0);
        for(;;) {}
    }
    int probe=argc>1 && equal(argv[1],"--probe");
    CALL(34,-100,"/sys",0755);
    long sys=sc(40,(long)"sysfs",(long)"/sys",(long)"sysfs",0,0,0);
    CALL(34,-100,"/sys/fs/pstore",0755);
    long mp=sc(40,(long)"pstore",(long)"/sys/fs/pstore",(long)"pstore",0,0,0);
    int ph=0,ch=0;
    long pp=scan("/sys/fs/pstore/pmsg-ramoops-0",&ph);
    long cp=scan("/sys/fs/pstore/console-ramoops-0",&ch);
    if(cp==-2) cp=scan("/sys/fs/pstore/console-ramoops",&ch);
    /* First 12 bytes may be reset to localdomain\0 by Android; retain the tail. */
    char witness[]="PJA110PROBE_S00_M00_P00_C00_H00_A0000000000000_R1";
    hex2(witness+13,sys); hex2(witness+17,mp); hex2(witness+21,pp); hex2(witness+25,cp);
    witness[29]='0'+ph; witness[30]='0'+ch;
    long fd=CALL(56,-100,"/sys/module/ramoops/parameters/mem_address",0);
    if(fd>=0) {
        long n=CALL(63,fd,buf,sizeof(buf)); u64 address=0;
        for(long i=0;i<n&&buf[i]>='0'&&buf[i]<='9';++i) address=address*10+buf[i]-'0';
        for(int i=0;i<13;++i) witness[33+i]="0123456789abcdef"[(address>>((12-i)*4))&15];
        CALL(57,fd,0,0);
    }
    if(mp==0) CALL(39,"/sys/fs/pstore",0,0);
    if(sys==0) CALL(39,"/sys",0,0);
    if(probe) {
        CALL(64,1,witness,sizeof(witness)-1);
        CALL(93,0,0,0);
    } else {
        CALL(162,witness,sizeof(witness)-1,0);
        CALL(221,"/init.real",argv,env);
        CALL(93,111,0,0);
    }
    for(;;) {}
}
__asm__(".global _start\n_start:\nmov x0, sp\nbl start_c\nb .\n");

#!/usr/bin/env python3
"""/proc/vmkmsg BLOCKS on read. Understand what it is before using it.

Observed: `head -c 400 /proc/vmkmsg` did not return in 300 s.
That is a strong signal -- a plain proc file never blocks. It means the read is
waiting for a producer.

Context from the device tree:
    /soc/dmesg-dump  compatible = "qcom,dmesg-dump"
                     gunyah-label = 7
                     shared-buffer = 0x3c (60)
                     peer-name = 2
                     qcom,primary-vm        <-- ABL is the primary VM

So `dmesg-dump` is a Gunyah shared-buffer channel between ABL (primary VM) and
Linux. /proc/vmkmsg is plausibly its userspace face. If ABL holds kernel-log
messages in a shared buffer, then:
  * our kernel's early log COULD be captured by ABL, and
  * the content would live in RAM that ABL owns across the handoff

That would be a genuine observation channel needing no cable and no 9008.

Investigate without blocking: never read the file directly; inspect the driver,
the Gunyah channel, and the buffer instead.
"""
import shutil
import subprocess
import sys

ADB = shutil.which('adb') or r'C:\platform-tools\adb.exe'
SERIAL = 'bc7a542e'


def run(cmd, timeout=25):
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=timeout)
        return ((r.stdout or b'') + (r.stderr or b'')).decode('utf-8', 'replace')
    except subprocess.TimeoutExpired:
        return '<<TIMEOUT>>'


def root(cmd, timeout=25):
    return run([ADB, '-s', SERIAL, 'shell', "su -c '%s'" % cmd], timeout)


def plain(cmd, timeout=25):
    return run([ADB, '-s', SERIAL, 'shell', cmd], timeout)


print('=' * 78)
print('1) WHAT BACKS /proc/vmkmsg?')
print('=' * 78)
print('  module/driver names containing vmkmsg:')
print(root('ls /sys/module/ 2>/dev/null | grep -i -E "vmkmsg|dmesg|dump"').strip()[:300] or '  (none)')
print()
print('  /proc entries with similar names:')
print(plain('ls /proc/ 2>/dev/null | grep -i -E "vmkmsg|dmesg|dump"').strip()[:300] or '  (none)')
print()
print('  who owns /proc/vmkmsg in the kernel? check kallsyms:')
print(root('grep -i vmkmsg /proc/kallsyms 2>/dev/null | head -8').strip()[:400] or '  (not in kallsyms)')

print()
print('=' * 78)
print('2) THE GUNYAH CHANNEL BEHIND dmesg-dump')
print('=' * 78)
print('  gunyah resources:')
print(root('ls /sys/bus/gunyah/ 2>/dev/null').strip()[:300] or '  (no gunyah bus)')
print()
print('  dmesg-dump platform device:')
print(root('ls -la /sys/bus/platform/devices/ 2>/dev/null | grep -i -E "dmesg|dump"').strip()[:400])
print()
print('  is a dmesg-dump driver bound?')
print(root('grep -r -l dmesg /sys/bus/platform/drivers/*/ 2>/dev/null | head -5').strip()[:300])
print()
print('  debugfs entries that might expose the buffer:')
print(root('ls /sys/kernel/debug/ 2>/dev/null | head -40').strip()[:600])

print()
print('=' * 78)
print('3) IS dmesg-dump A DRIVER WE COULD USE FROM OUR KERNEL?')
print('=' * 78)
print('  In mainline there is NO qcom,dmesg-dump driver -- it is vendor-only.')
print('  But if the mechanism is "ABL provides a shared buffer that any kernel can')
print('  write its log into", then a tiny vendor-free implementation is possible.')
print()
print('  The device tree tells us the contract:')
print('    gunyah-label  = 7')
print('    shared-buffer = 60 (0x3c)')
print('    peer-name     = 2')
print('    qcom,primary-vm')
print()
print('  To use it we would need the Gunyah message-queue API, which mainline')
print('  does have partially (drivers/virt/gunyah) but the buffer ABI here is')
print('  vendor-specific.')

print()
print('=' * 78)
print('4) A MUCH SIMPLER IDEA THAT USES THE SAME MECHANISM')
print('=' * 78)
print('  Instead of reverse-engineering the Gunyah ABI, use the fact we already')
print('  PROVED: ABL reads vendor_boot and dtbo from flash, and we can rewrite the')
print('  vendor_boot dtb. ABL also has a console/logo pipeline and writes')
print('  oplusreserve1 on every boot.')
print()
print('  But more directly: the ABL log itself (/proc/bootloader_log) is produced by')
print('  ABL and survives into Android. It is only readable when Android boots.')
print()
print('  Key insight: if OUR kernel never lets Android boot, we lose that channel.')
print('  What if instead our kernel hands off to Android on purpose after writing')
print('  its own log somewhere Android can read?')
print()
print('  Concretely: our /init could write its diagnostic output to a RAW UFS')
print('  PARTITION using dd, then exec Android. That needs no drivers beyond UFS,')
print('  which mainline supports on sm8550, and the data lands in flash where we')
print('  can read it later from fastboot (fastboot can dump partitions) or from')
print('  Android.')
print()
print('  Candidate partitions that are safe to scribble on:')
print('    misc, logfs, xbl_sc_logs, logdump, rawdump, or the tail of a backed-up')
print('    partition. We have full backups of the calibration partitions, so a')
print('    scratch area can be restored afterwards.')

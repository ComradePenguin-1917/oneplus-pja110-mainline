"""Download official Ubuntu Base and packages into project, never install."""
import gzip,hashlib,json,re,shutil,urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/ubuntu-ram-20261014';OUT.mkdir(exist_ok=True)
DEBS=OUT/'debs';DEBS.mkdir(exist_ok=True)
base='https://cdimage.ubuntu.com/ubuntu-base/releases/24.04/release/'
html=urllib.request.urlopen(base,timeout=45).read().decode()
names=set(re.findall(r'ubuntu-base-(24\.04\.\d+)-base-arm64.tar.gz',html))
version=max(names,key=lambda s:tuple(map(int,s.split('.'))))
name=f'ubuntu-base-{version}-base-arm64.tar.gz'
sums=urllib.request.urlopen(base+'SHA256SUMS',timeout=45).read();(OUT/'SHA256SUMS').write_bytes(sums)
expected=next(l.split()[0] for l in sums.decode().splitlines() if l.split()[-1].lstrip('*')==name)
path=OUT/name
if not path.exists():
 print('Downloading Ubuntu Base',version,'ARM64',flush=True)
 with urllib.request.urlopen(base+name,timeout=120) as r,path.open('wb') as f:shutil.copyfileobj(r,f)
assert hashlib.sha256(path.read_bytes()).hexdigest()==expected
packages={};ports='https://ports.ubuntu.com/ubuntu-ports/'
for pocket in ('noble','noble-updates','noble-security'):
 for component in ('main','universe'):
  path=OUT/(pocket+'-'+component+'-Packages.gz')
  cached=ROOT/'out/mesa-offscreen-20261014'/(pocket+'-arm64-Packages.gz')
  if not path.exists():
   if component=='main' and cached.exists():shutil.copyfile(cached,path)
   else:path.write_bytes(urllib.request.urlopen(ports+f'dists/{pocket}/{component}/binary-arm64/Packages.gz',timeout=120).read())
  for record in gzip.decompress(path.read_bytes()).decode().split('\n\n'):
   p={}
   for line in record.splitlines():
    if line and not line[0].isspace() and ': ' in line:
     k,v=line.split(': ',1);p[k]=v
   if 'Package' in p:packages[p['Package']]=p
pending=['weston','seatd','udev','openssh-server','libegl-mesa0','libgl1-mesa-dri','libgbm1','libgles2']
selected={};virtual={'debconf-2.0':'debconf','default-dbus-system-bus':'dbus','awk':'mawk','logind':'libpam-systemd'}
while pending:
 name=pending.pop()
 if name in selected:continue
 p=packages[name];selected[name]=p
 for item in (p.get('Pre-Depends','')+','+p.get('Depends','')).split(','):
  choices=[re.split(r'\s|:',c.strip())[0] for c in item.split('|') if c.strip()]
  if not choices:continue
  dep=next((c for c in choices if c in packages),None)
  if dep is None:dep=next((virtual[c] for c in choices if c in virtual),None)
  if dep:pending.append(dep)
  else:raise RuntimeError('unresolved '+item)
def download(item):
 name,p=item
 path=DEBS/Path(p['Filename']).name
 cached=ROOT/'out/mesa-offscreen-20261014/debs'/path.name
 if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest()!=p['SHA256']:
  if cached.exists():shutil.copyfile(cached,path)
  else:
   print('Downloading',name,p['Version'],flush=True)
   with urllib.request.urlopen(ports+p['Filename'],timeout=180) as r,path.open('wb') as f:shutil.copyfileobj(r,f)
 assert hashlib.sha256(path.read_bytes()).hexdigest()==p['SHA256']
 return dict(name=name,version=p['Version'],architecture=p['Architecture'],file=path.name,sha256=p['SHA256'],url=ports+p['Filename'])
with ThreadPoolExecutor(max_workers=6) as pool:
 manifest=list(pool.map(download,sorted(selected.items())))
(OUT/'manifest.json').write_text(json.dumps(dict(ubuntu_version=version,architecture='arm64',
 base_file=f'ubuntu-base-{version}-base-arm64.tar.gz',base_sha256=expected,packages=manifest),indent=2)+'\n')
print('PASS: official Base checksum and',len(manifest),'package SHA256 values verified; no installation')

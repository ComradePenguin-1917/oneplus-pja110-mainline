"""Trace a normal reboot with active KMS, preserving evidence if shutdown stalls."""
import argparse,json,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('--label',required=True)
parser.add_argument('--kernel',default='23')
args=parser.parse_args()
assert args.label.replace('-','').isalnum() and args.kernel.isdecimal()
out=ROOT/'out/drm-shutdown-20261014'/args.label;out.mkdir(parents=True,exist_ok=True)
assert not (out/'before.txt').exists(),'Use a fresh label for each test'
keys=ROOT/'out/usb-ncm-20261013/ssh'
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(keys/'client_key_host'),
 '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
 '-o',f'UserKnownHostsFile={keys/"known_hosts"}','-o','ConnectTimeout=3','root@169.254.42.1']
def run(cmd,timeout=10):
 try:return subprocess.run(ssh+[cmd],capture_output=True,timeout=timeout)
 except subprocess.TimeoutExpired:return None
before=run('cat /proc/sys/kernel/random/boot_id; uname -a; cat /proc/uptime; ps')
assert before and before.returncode==0
(out/'before.txt').write_bytes(before.stdout)
assert f'#{args.kernel} SMP'.encode() in before.stdout
setup='''set -e
grep -q ' /sys/kernel/tracing tracefs ' /proc/mounts || mount -t tracefs tracefs /sys/kernel/tracing
t=/sys/kernel/tracing/instances/pja_shutdown
mkdir -p "$t"
echo 0 > "$t/tracing_on"
echo 0 > "$t/events/enable"
echo 2048 > "$t/buffer_size_kb"
echo mono > "$t/trace_clock"
echo > "$t/trace"
for group in msm_atomic; do test ! -e "$t/events/$group/enable" || echo 1 > "$t/events/$group/enable"; done
for e in dpu_enc_rc dpu_enc_phys_cmd_irq_enable dpu_enc_phys_cmd_irq_disable dpu_enc_phys_cmd_pp_tx_done dpu_enc_wait_event_timeout dpu_enc_frame_done_timeout tracing_mark_write; do
test ! -e "$t/events/dpu/$e/enable" || echo 1 > "$t/events/dpu/$e/enable"
done
echo 1 > "$t/tracing_on"
'''
p=run(setup);assert p and p.returncode==0
start=time.monotonic();p=run('sync; reboot -f')
(out/'request.txt').write_bytes((p.stdout+p.stderr) if p else b'SSH timed out during reboot request\n')
captured=False
while time.monotonic()-start<75:
 time.sleep(2)
 p=run('cat /proc/sys/kernel/random/boot_id; uname -a; cat /proc/uptime; cat /tmp/touch-init.log; dmesg | grep "PJA_ASTON fixed report rate code=3"')
 if p and p.returncode==0:
  if p.stdout.splitlines()[0]!=before.stdout.splitlines()[0]:
   (out/'after.txt').write_bytes(p.stdout)
   assert f'#{args.kernel} SMP'.encode() in p.stdout
   assert b'code=3 readback verified' in p.stdout
   (out/'result.json').write_text(json.dumps({'normal_reboot_passed':True,'elapsed_seconds':round(time.monotonic()-start,2),'kernel':args.kernel},indent=2)+'\n')
   print('PASS: normal reboot, new boot ID, automatic SSH and 240Hz touch',flush=True)
   break
  if time.monotonic()-start>20 and not captured:
   command='''t=/sys/kernel/tracing/instances/pja_shutdown
echo 0 > "$t/tracing_on"; echo 0 > "$t/events/enable"; cat "$t/trace"
'''
   q=run(command,20)
   if q and q.returncode==0:(out/'stalled-trace.txt').write_bytes(q.stdout)
   command='''uname -a; cat /proc/uptime; cat /sys/kernel/debug/dri/0/debug/core_irq; dmesg | tail -n 40
for f in /proc/[0-9]*/comm; do
read name < "$f"
case "$name" in reboot|kworker*|atomic-worker*|kms-ruler|weston)
echo "TASK $f $name"; cat "${f%comm}wchan"; cat "${f%comm}stack";; esac
done
'''
   q=run(command,25)
   if q and q.returncode==0:(out/'stalled-stacks.txt').write_bytes(q.stdout)
   captured=True;print('Normal reboot still on old boot; saved trace and stacks',flush=True)
else:
 (out/'result.json').write_text(json.dumps({'normal_reboot_passed':False,'same_boot_after_75s':True,'kernel':args.kernel},indent=2)+'\n')
 raise SystemExit('Normal reboot stalled; evidence saved; no emergency reboot performed')

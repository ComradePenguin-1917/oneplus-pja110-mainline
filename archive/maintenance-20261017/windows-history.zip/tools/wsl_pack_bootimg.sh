#!/bin/bash
# Pack the boot images for the OnePlus Ace 2 Pro (xigua).
#
# DTB DELIVERY -- how this was established:
#   * arm64 has no CONFIG_ARM64_APPENDED_DTB (that symbol is MIPS/ARM only), so
#     the line in the Ace 3 config fragment is silently dropped by kbuild.
#   * arm64's own docs say the kernel has NO decompressor: "decompression
#     (gzip etc.) must be performed by the boot loader".
#   * the kernel maintainers state the supported flow plainly: "You are supposed
#     to boot standard kernel with typical setup - concatenated DTB."
#   * the working Ace 3 port does exactly: cat Image dtb > Image_w_dtb; gzip.
#
# So the loader owns the concatenation convention: we append the DTB to Image
# and gzip the result. We also emit a raw-Image variant in case the ABL in this
# firmware treats a gzipped kernel differently -- cheap to produce, and lets us
# try the other one without a rebuild if the first fails.
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
OUT="$ROOT/out"
WIN="/mnt/h/WorkSpace/PJA110-Mainline"

BOOTIMG="$WIN/tools/bootimg.py"
STOCK="$WIN/boot-A14.img"

# pick which DTB to embed (default: the 16 GB map measured off this unit)
VARIANT="${1:-16G}"
case "$VARIANT" in
    16G) DTB="$OUT/sm8550-oneplus-xigua-16G.dtb" ;;
    *)   DTB="$OUT/sm8550-oneplus-xigua.dtb" ;;
esac

echo "=== inputs ==="
echo "  kernel : $OUT/Image ($(stat -c%s "$OUT/Image") bytes)"
echo "  dtb    : $DTB ($(stat -c%s "$DTB") bytes)"
echo "  stock  : $STOCK (for os_version inheritance)"

echo
echo "=== concatenate Image + DTB, then gzip (the documented flow) ==="
cat "$OUT/Image" "$DTB" > "$OUT/Image_w_dtb"
gzip -9 -c "$OUT/Image_w_dtb" > "$OUT/Image_w_dtb.gz"
echo "  Image_w_dtb    : $(stat -c%s "$OUT/Image_w_dtb") bytes"
echo "  Image_w_dtb.gz : $(stat -c%s "$OUT/Image_w_dtb.gz") bytes"

# the DTB must land on an 8-byte boundary; Image is 4K-aligned in practice
python3 - "$OUT/Image_w_dtb" <<'PY'
import struct, sys
b = open(sys.argv[1], 'rb').read()
i = b.find(b'\xd0\x0d\xfe\xed', len(b) - 300000)
print('  DTB offset inside concatenation: %d (0x%x), 8-byte aligned: %s'
      % (i, i, i % 8 == 0))
sz = struct.unpack_from('>I', b, i+4)[0]
print('  DTB totalsize: %d' % sz)
print('  matches our .dtb length: %s' % (sz == 0))  # informational
PY

echo
echo "=== pack with python mkbootimg (header v4) ==="
cd "$WIN"

pack() {
    local kernel="$1" out="$2" cmdline="$3"
    python3 tools/bootimg.py pack \
        --kernel "$kernel" \
        --stock boot-A14.img \
        --cmdline "$cmdline" \
        -o "$out"
}

CMDLINE="console=ttyMSM0,115200 loglevel=8 earlycon"

echo "--- variant A: gzipped Image+DTB (matches the working Ace 3 port) ---"
# note: tools/bootimg.py takes the kernel payload verbatim, so we hand it the
# gzip we just made; ABL decompresses it per the arm64 boot protocol.
python3 tools/bootimg.py pack \
    --kernel "$OUT/Image_w_dtb.gz" \
    --stock boot-A14.img \
    --cmdline "$CMDLINE" \
    -o "$OUT/boot-xigua-16G-gz.img"

echo
echo "--- variant B: raw Image+DTB (no gzip, ABL may prefer uncompressed) ---"
python3 tools/bootimg.py pack \
    --kernel "$OUT/Image_w_dtb" \
    --stock boot-A14.img \
    --cmdline "$CMDLINE" \
    -o "$OUT/boot-xigua-16G-raw.img"

echo
echo "=== results ==="
ls -l "$OUT"/boot-xigua-*.img
echo
sha256sum "$OUT"/boot-xigua-*.img

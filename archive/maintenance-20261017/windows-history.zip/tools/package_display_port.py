"""Add only display nodes to the proven USB DTB and package the new kernel."""
import gzip
import hashlib
import json
import struct
from pathlib import Path
from bootimg import BootImage
from fdt import FDT
from fdtwrite import parse,serialise,walk

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/display-port-20261013'
BASE=ROOT/'out/debug-ncm-fixed-20261013'
VB=ROOT/'out/user-init-usb-serial-diag-20261013/vendor_boot_b-xigua-r1.img'
u32=lambda *values:struct.pack('>'+'I'*len(values),*values)
string=lambda s:s.encode()+b'\0'
source=VB.read_bytes()
align=lambda n:(n+4095)//4096*4096
off=align(align(struct.unpack_from('<I',source,2096)[0])+struct.unpack_from('<I',source,24)[0])
size=struct.unpack_from('>I',source,off+4)[0]
original=source[off:off+size]
tree,reservations=parse(original)
nodes=dict(walk(tree))
phandles=[int.from_bytes(n.props['phandle'],'big') for n in nodes.values() if 'phandle'in n.props]
next_handle=max(phandles)+1
def handle(node):
    global next_handle
    if 'phandle' not in node.props:
        node.set('phandle',u32(next_handle));next_handle+=1
    return node.props['phandle']
def compatible(needle):
    matches=[node for node in nodes.values() if needle.encode() in node.props.get('compatible',b'').split(b'\0')]
    assert len(matches)==1,(needle,len(matches))
    return matches[0]
def regulator(name):
    return next(n for n in nodes.values() if n.props.get('regulator-name')==string(name))
mdss=nodes['/soc@0/display-subsystem@ae00000']
dsi=nodes['/soc@0/display-subsystem@ae00000/dsi@ae94000']
phy=nodes['/soc@0/display-subsystem@ae00000/phy@ae95000']
tlmm=compatible('qcom,sm8550-tlmm')
tlmm_path=next(p for p,n in nodes.items() if n is tlmm)
pmk=compatible('qcom,pmk8550-gpio')
old_pmk_path=next(p for p,n in nodes.items() if n is pmk)
# The actual vendor DT and the newer PMK8550 DTS use GPIO base 0xb800.
# The proven boot DT was built from an older 0x8800 definition.
pmk.name='gpio@b800'
pmk.set('reg',u32(0xb800))
pmk_path=old_pmk_path.rsplit('/',1)[0]+'/gpio@b800'
symbol_changes=set()
if '/__symbols__' in nodes:
    for key,value in list(nodes['/__symbols__'].props.items()):
        if value.rstrip(b'\0').decode().startswith(old_pmk_path):
            nodes['/__symbols__'].set(key,string(value.rstrip(b'\0').decode().replace(old_pmk_path,pmk_path,1)))
            symbol_changes.add(key)
rpmh=compatible('qcom,sm8550-rpmh-clk')
for n in (mdss,dsi,phy):n.set('status',string('okay'))
dsi.set('vdda-supply',handle(regulator('vreg_l3e_1p2')))
dsi.set('oneplus,dsc-scr1',b'')
dsi.set('oneplus,command-mode-lane-rate',struct.pack('>Q',1094400000))
phy.set('vdds-supply',handle(regulator('vreg_l1e_0p88')))
def pinctrl(parent,name,pins,function,drive=None,**booleans):
    n=parent.child(name)
    n.set('pins',b''.join(string(p) for p in pins))
    n.set('function',string(function))
    n.set('bias-disable',b'')
    if drive is not None:n.set('drive-strength',u32(drive))
    for k,v in booleans.items():n.set(k.replace('_','-'),v)
    handle(n)
    return n
gpios=pinctrl(tlmm,'aa536-iris-gpios-state',['gpio133','gpio109','gpio129','gpio105','gpio90'],'gpio',8)
ready=pinctrl(tlmm,'aa536-iris-ready-state',['gpio181'],'gpio',8,input_enable=b'')
te=pinctrl(tlmm,'aa536-te-state',['gpio86'],'mdp_vsync',2,input_enable=b'')
clock=pinctrl(pmk,'aa536-iris-clock-state',['gpio5'],'func2',input_disable=b'',output_enable=b'')
clock.set('power-source',u32(0))
panel=dsi.child('panel@0')
panel.set('compatible',string('oneplus,aa536-p-3-a0001'))
panel.set('reg',u32(0))
panel.set('pinctrl-names',string('default'))
panel.set('pinctrl-0',b''.join(handle(n) for n in (gpios,ready,te,clock)))
panel.set('vddio-supply',handle(regulator('vreg_l12b_1p8')))
panel.set('vci-supply',handle(regulator('vreg_l13b_3p3')))
gpio_provider=handle(tlmm)
for name,pin,active_low in [('reset',133,1),('vout',90,0),('iris-reset',109,1),('iris-wakeup',129,0),('iris-abyp-ready',181,0),('iris-vdd09',105,0)]:
    panel.set(name+'-gpios',gpio_provider+u32(pin,active_low))
panel.set('clocks',handle(rpmh)+u32(17))
panel.set('clock-names',string('iris'))
endpoint=panel.child('port').child('endpoint')
dsi_out=nodes['/soc@0/display-subsystem@ae00000/dsi@ae94000/ports/port@1/endpoint']
endpoint.set('remote-endpoint',handle(dsi_out))
dsi_out.set('remote-endpoint',handle(endpoint))
dsi_out.set('data-lanes',u32(0,1,2,3))
raw=serialise(tree,reservations)
assert len(raw)<=size,('DTB would exceed proven allocation',len(raw),size)
padded=bytearray(raw).ljust(size,b'\0');struct.pack_into('>I',padded,4,size)
before,after=FDT(original).nodes(),FDT(padded).nodes()
allowed_roots=('/soc@0/display-subsystem@ae00000',tlmm_path+'/aa536-')
delta=[]
for path in before.keys()|after.keys():
    for key in before.get(path,{}).keys()|after.get(path,{}).keys():
        a=before.get(path,{}).get(key);b=after.get(path,{}).get(key)
        if a!=b:
            assert (path.startswith(allowed_roots) or path.startswith(pmk_path) or
                    path.startswith(old_pmk_path) or (path=='/__symbols__' and key in symbol_changes)),(path,key)
            delta.append({'node':path,'property':key,'before':a.hex() if a is not None else None,'after':b.hex() if b is not None else None})
for path,props in before.items():
    if any(t in path for t in ('usb@','phy@88e8000','phy@88e3000','ufs@','memory','reserved-memory')):
        assert after[path]==props,path
result=bytearray(source);result[off:off+size]=padded
assert result[:off]==source[:off] and result[off+size:]==source[off+size:]
(OUT/'vendor_boot_b-xigua-r1.img').write_bytes(result)
(OUT/'sm8550-xigua-display.dtb').write_bytes(padded)
image=(OUT/'Image-probe').read_bytes()
symbols={p[2]:int(p[0],16) for line in (OUT/'System.map').read_text().splitlines() if len(p:=line.split())==3}
start=symbols['__initramfs_start']-symbols['_text']
length=struct.unpack_from('<Q',image,symbols['__initramfs_size']-symbols['_text'])[0]
assert gzip.decompress(image[start:start+length])==gzip.decompress((BASE/'initramfs.cpio.gz').read_bytes())
assert 'aa536_probe' in symbols and 'aa536_prepare' in symbols
boot=BootImage.parse(str(BASE/'boot-xigua-r1.img'));boot.kernel=image
(OUT/'boot-xigua-r1.img').write_bytes(boot.pack(cmdline=boot.cmdline.decode()))
assert BootImage.parse(str(OUT/'boot-xigua-r1.img')).kernel==image
files=['boot-xigua-r1.img','vendor_boot_b-xigua-r1.img']
manifest={'experiment':'AA536 60Hz DSC10/SCR1 with minimal Iris7 analog bypass',
          'phone_execution_confirmed':False,'fixed_ncm_initramfs_unchanged':True,
          'init_boot_b_unchanged_from':str(BASE.relative_to(ROOT)),
          'usb_ufs_memory_unchanged':True,'dtb_delta':delta,
          'pmk8550_gpio_base_corrected_to_vendor_b800':True,
          'files':{n:{'bytes':(OUT/n).stat().st_size,'sha256':hashlib.sha256((OUT/n).read_bytes()).hexdigest()} for n in files}}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(f'PASS: display-only DT changes {len(delta)}; USB/UFS/memory and fixed SSH initramfs preserved')

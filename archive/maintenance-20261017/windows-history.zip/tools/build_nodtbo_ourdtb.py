#!/usr/bin/env python3
"""Build the decisive image: OUR kernel + OUR DTB, for a dtbo-erased boot.

Why every earlier attempt was inconclusive
------------------------------------------
  * attempts WITH the vendor dtbo present: ABL applies its overlays on top of
    whatever base tree it chose, and those overlays write `model` and recreate
    /chosen -- so a missing marker proved nothing about which base tree was used.
  * the erased-dtbo attempt used the VENDOR LIVE tree appended. But the vendor
    tree relies on those very overlays to ENABLE UFS/PHY/sdhci
    (/soc/ufshc@1d84000 is `disabled` in the base tree, `ok` after overlays).
    With the dtbo erased that tree cannot boot, so the device fell back to slot A
    and again we learned nothing.

The fix: append OUR device tree, which enables UFS/USB/serial BY ITSELF and does
not depend on any overlay. Then erase the dtbo so no overlay can interfere.

    active slot b, dtbo_b erased
      + boot image = our Image (embedded initramfs) + our DTB (+ inert marker)

Outcomes, and both are informative:
  * our kernel boots and the USB gadget comes up -> we finally get OUR tree,
    which is the entire goal
  * nothing happens -> the appended DTB is genuinely ignored, and the only route
    left is patching vendor_boot (already proven to work)

The inert marker /xigua-append-test is kept so that even without a shell we can
tell which tree the kernel received, via a plain directory listing.
"""
import os
import struct
import subprocess
import sys

sys.path.insert(0, os.path.join(r'H:\WorkSpace\PJA110-Mainline', 'tools'))
from fdt import FDT
from fdtwrite import parse, serialise, Node, walk

WS = r'H:\WorkSpace\PJA110-Mainline'
WSL_WS = '/mnt/h/WorkSpace/PJA110-Mainline'
MARK = 'xigua-append-test'

# ---- our kernel with the embedded initramfs ----
kern = os.path.join(WS, 'out', 'Image-initrd')
if not os.path.exists(kern):
    kern = os.path.join(WS, 'out', 'Image')
print('=== kernel ===')
print('  %s  (%d bytes)' % (kern, os.path.getsize(kern)))

# ---- our DTB + inert marker ----
blob = open(os.path.join(WS, 'dts', 'sm8550-oneplus-xigua-16G.dtb'), 'rb').read()
root, rsvmap = parse(blob)
before = set(p for p, _n in walk(root))
if '/' + MARK not in before:
    root.children.append(Node(MARK))
dtb = serialise(root, rsvmap)
after = set(p for p, _n in walk(parse(dtb)[0]))

f = FDT(dtb)
syms = set(f.nodes().get('/__symbols__', {}))
print()
print('=== our DTB + marker ===')
print('  size        : %d' % len(dtb))
print('  nodes       : %d -> %d' % (len(before), len(after)))
print('  /%s : %s' % (MARK, '/' + MARK in after))
print('  qcom_tzlog  : %s   (ABL requires this label)' % ('qcom_tzlog' in syms))
print('  arch_timer  : %s   (ABL requires this label)' % ('arch_timer' in syms))

# does our tree enable the things needed to boot?
for path, label in (('/soc@0/ufshc@1d84000', 'UFS host'),
                    ('/soc@0/usb@a600000', 'USB'),
                    ('/memory', 'memory')):
    n = None
    for p, node in walk(parse(dtb)[0]):
        if p == path:
            n = node
            break
    if n is None:
        # our tree may name it differently; search by substring
        for p, node in walk(parse(dtb)[0]):
            if label.split()[0].lower() in p.lower():
                n = node
                path = p
                break
    st = n.get('status', b'(none)').rstrip(b'\0').decode('ascii', 'replace') if n else '(node not found)'
    print('  %-22s status=%s' % (path[:22], st))

# ---- combine and pack ----
combined = os.path.join(WS, 'out', 'Image-initrd-w-markeddtb')
open(combined, 'wb').write(open(kern, 'rb').read() + dtb)
print()
print('=== combined ===')
print('  %d + %d = %d bytes' % (os.path.getsize(kern), len(dtb), os.path.getsize(combined)))

out_img = os.path.join(WS, 'out', 'xigua-nodtbo.img')
cmd = ('cd %s && python3 tools/bootimg.py pack --kernel out/Image-initrd-w-markeddtb '
       '--stock boot-A14.img --cmdline "console=ttyMSM0,115200 loglevel=8 earlycon ignore_loglevel" '
       '-o out/xigua-nodtbo.img' % WSL_WS)
r = subprocess.run(['wsl.exe', '-d', 'Ubuntu-22.04', '--', 'bash', '-lc', cmd],
                   capture_output=True)
for line in (r.stdout or b'').decode('utf-8', 'replace').splitlines():
    if line.strip() and 'localh' not in line and 'N/e' not in line:
        print('  %s' % line.strip()[:100])

print()
print('=== verify image ===')
if os.path.exists(out_img):
    b = open(out_img, 'rb').read()
    ksize = struct.unpack_from('<I', b, 8)[0]
    k = b[4096:4096 + ksize]
    print('  size          : %d' % len(b))
    print('  kernel field  : %d' % ksize)
    print('  marked DTB at : %s' % ('0x%x' % k.find(dtb) if k.find(dtb) >= 0 else 'NOT FOUND'))
    print('  marker present: %s' % (b'xigua-append-test' in k))
    print('  embedded initrd: %s' % (b'[initramfs]' in k))
else:
    print('  FAILED to produce the image')
    sys.exit(1)

print()
print('=== run plan ===')
print('  1. fastboot set_active b')
print('  2. fastboot erase dtbo_b            (no overlay may interfere)')
print('  3. fastboot boot out/xigua-nodtbo.img')
print('  4. watch for adb; if it appears, our tree + our kernel are live')
print('  5. restore: fastboot flash dtbo_b backup/dtbo_b.img; set_active a')

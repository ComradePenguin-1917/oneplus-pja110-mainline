#!/usr/bin/env python3
"""Back up the CURRENT on-device boot/dtbo partitions before any experiment.

Why this matters on this specific unit:
  * the phone runs KernelSU, so boot_a is a *patched* image whose hash
    (742105c6...) differs from the stock image in the OTA package
    (d9cf0ea6...). That patched image exists nowhere else -- if it is lost,
    the only way back is re-flashing stock + re-patching with KernelSU.
  * dtbo_a/dtb_b are byte-identical to stock, so they are recoverable, but we
    grab them anyway for completeness.

Read-only: never writes to a partition.
"""
import hashlib
import os
import shutil
import subprocess
import sys

ADB = shutil.which('adb') or r'C:\platform-tools\adb.exe'
OUT = r'H:\WorkSpace\PJA110-Mainline\backup'
SERIAL = 'bc7a542e'
PARTS = ('boot_a', 'boot_b', 'dtbo_a', 'dtbo_b')

# hashes observed on-device, so a corrupted pull is detectable
EXPECTED = {
    'boot_a': '742105c64ee25752eb9b5e03ad2f06ff1c6449bcd48c8e10c5d985e56a5b3c31',
    'dtbo_a': '30b4002ab717077c873ef8bd0961d35efa449ac2d8e8a9324bbe41dfd16e9795',
}


def sh(cmd, timeout=900):
    return subprocess.run([ADB, '-s', SERIAL, 'shell', 'su -c "%s"' % cmd],
                          capture_output=True, text=True, timeout=timeout)


def main():
    if not os.path.exists(OUT):
        os.makedirs(OUT)

    for part in PARTS:
        local = os.path.join(OUT, '%s.img' % part)
        remote = '/data/local/tmp/%s.img' % part

        if os.path.exists(local):
            print('%-8s already backed up (%d bytes), skipping'
                  % (part, os.path.getsize(local)))
            continue

        print('--- %s ---' % part)
        r = sh('dd if=/dev/block/by-name/%s of=%s bs=1M 2>&1; chmod 644 %s'
               % (part, remote, remote))
        if r.returncode != 0:
            print('    dd failed: %s' % (r.stdout + r.stderr)[:200])
            continue

        r = subprocess.run([ADB, '-s', SERIAL, 'pull', remote, local],
                           capture_output=True, text=True, timeout=1800)
        if not os.path.exists(local):
            print('    pull failed: %s' % (r.stdout + r.stderr)[:200])
            continue

        size = os.path.getsize(local)
        with open(local, 'rb') as fh:
            h = hashlib.sha256(fh.read()).hexdigest()
        print('    %d bytes  sha256=%s' % (size, h))
        exp = EXPECTED.get(part)
        if exp:
            print('    matches on-device hash: %s' % (h == exp))

        sh('rm -f %s' % remote)

    print()
    print('=== backup directory ===')
    for f in sorted(os.listdir(OUT)):
        p = os.path.join(OUT, f)
        print('  %-16s %12d' % (f, os.path.getsize(p)))


if __name__ == '__main__':
    sys.exit(main())

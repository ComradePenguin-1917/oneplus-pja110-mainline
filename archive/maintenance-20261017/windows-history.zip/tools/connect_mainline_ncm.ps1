param([string]$Command='')
$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$sshDirectory=Join-Path $root 'out/usb-ncm-20261013/ssh'
$key=Join-Path $sshDirectory 'client_key_host'
$known=Join-Path $sshDirectory 'known_hosts'
if(-not (Test-Path $key) -or -not (Test-Path $known)){throw 'NCM SSH key or verified host key is missing'}
$arguments=@('-F','none','-i',$key,'-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
             '-o',"UserKnownHostsFile=$known",'-o','ConnectTimeout=10','-o','ServerAliveInterval=5')
if($Command){$arguments+=@('-T','root@169.254.42.1',$Command)}else{$arguments+=@('-t','root@169.254.42.1')}
& C:\Windows\System32\OpenSSH\ssh.exe @arguments
exit $LASTEXITCODE

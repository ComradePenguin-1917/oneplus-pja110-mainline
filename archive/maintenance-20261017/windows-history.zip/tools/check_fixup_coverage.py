#!/usr/bin/env python3
"""THE decisive feasibility check for replacing the base DTB in vendor_boot.

How the dtbo actually works (established just now):
  * every fragment has `target = 0xffffffff` -- a PLACEHOLDER
  * the dtbo carries /__fixups__ : 114 entries mapping a LABEL NAME to the
    offset inside the fragment where the placeholder sits
  * the dtbo carries /__symbols__ : 209 entries defining labels it exports

So ABL must, at boot, resolve each fixup by looking the label up in the BASE
device tree's /__symbols__ node and patching `target` with that node's phandle.

Therefore: if we replace the base DTB in vendor_boot with OUR tree, ABL will try
to resolve 114 labels against OUR /__symbols__. Any label we do not export
cannot be resolved.

This script measures exactly that gap, per dtbo entry, and tells us whether the
swap is viable.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fdt import FDT, load_entries

WS = r'H:\WorkSpace\PJA110-Mainline'


def labels(node_props):
    """Extract the label names from a __symbols__ node's property names."""
    return set(node_props.keys())


def fixup_labels(props):
    """__fixups__ property NAMES are the labels being referenced."""
    return set(props.keys())


ours_f = FDT(open(os.path.join(WS, 'dts', 'sm8550-oneplus-xigua-16G.dtb'), 'rb').read())
ours = ours_f.nodes()
our_syms = labels(ours.get('/__symbols__', {}))

# entry 0 of the dtb section == the vendor base tree for THIS device
import struct
v = open(os.path.join(WS, 'backup', 'vendor_boot_a.img'), 'rb').read()
hsize, dtbsize = struct.unpack_from('<2I', v, 28+2048+4+16)
vrsize = struct.unpack_from('<I', v, 24)[0]
dtb_off = (((hsize+4095)//4096)*4096 + vrsize + 4095)//4096*4096
e0 = struct.unpack_from('>I', v, dtb_off+4)[0]
vendor = FDT(v[dtb_off:dtb_off+e0]).nodes()
vendor_syms = labels(vendor.get('/__symbols__', {}))

print('=' * 74)
print('BASE TREE LABEL INVENTORY')
print('=' * 74)
print('  vendor base DTB (vendor_boot entry0) __symbols__ : %d labels' % len(vendor_syms))
print('  OUR DTB                            __symbols__ : %d labels' % len(our_syms))
print('  our DTB has __symbols__ node                     : %s' % ('/__symbols__' in ours))

entries, _ = load_entries(os.path.join(WS, 'dtbo-A14.img'))

print()
print('=' * 74)
print('FIXUP RESOLUTION: which dtbo fragments could still be applied on our tree?')
print('=' * 74)
for label, sub in entries:
    f = FDT(sub)
    n = f.nodes()
    fx = fixup_labels(n.get('/__fixups__', {}))
    if not fx:
        print('  %-8s no __fixups__' % label)
        continue
    resolvable = fx & our_syms
    missing = fx - our_syms
    print('  %-8s fixups=%-4d resolvable-with-our-symbols=%-4d missing=%-4d (%.0f%% resolvable)'
          % (label, len(fx), len(resolvable), len(missing),
             100.0*len(resolvable)/len(fx)))
    if missing:
        print('           missing sample: %s' % sorted(missing)[:10])

print()
print('=' * 74)
print('VERDICT')
print('=' * 74)
e1 = FDT(entries[1][1]).nodes()
fx1 = fixup_labels(e1.get('/__fixups__', {}))
cov = len(fx1 & our_syms) / len(fx1) * 100
print('  The dtbo for this device needs %d labels.' % len(fx1))
print('  Our DTB exports %d of them -> %.1f%% coverage.' % (len(fx1 & our_syms), cov))
print()
if cov < 100:
    print('  => ABL would have UNRESOLVED fragments when applying the vendor dtbo')
    print('     on top of our tree. Behaviour on failure is unknown (skip vs abort).')
    print()
    print('  Two ways forward:')
    print('    (i)  give our DTB a __symbols__ that exports every label the dtbo')
    print('         needs, so all fragments resolve (adds nodes it may then modify)')
    print('    (ii) bypass the dtbo entirely -- see next section')
else:
    print('  => all fragments resolve; the swap is viable.')

"""Upload one local file through the test-only NCM receiver and verify it."""
import argparse
import hashlib
import json
import socket
from pathlib import Path

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('file')
parser.add_argument('--output', required=True)
args = parser.parse_args()
file = (root / args.file).resolve()
out = (root / args.output).resolve()
if root not in file.parents or root not in out.parents:
    parser.error('file and output must stay in workspace')
out.mkdir(parents=True, exist_ok=True)
data = file.read_bytes()
expected = hashlib.sha256(data).hexdigest()
network = json.loads((root / 'out/usb-ncm-20261013/windows-network.json').read_text(encoding='utf-8-sig'))
source = next(item['IPAddress'] for item in network['Address'] if item['IPAddress'].startswith('169.254.'))
with socket.create_connection(('169.254.42.1', 9000), timeout=20, source_address=(source, 0)) as client:
    client.sendall(f'{len(data)}\n'.encode() + data)
    client.shutdown(socket.SHUT_WR)
    response = bytearray()
    while len(response) < 256:
        part = client.recv(256)
        if not part:
            break
        response.extend(part)
actual = response.decode().split()[0] if response else ''
result = dict(file=str(file), phone_path='/tmp/ncm-www/uploaded.bin', bytes=len(data),
              expected_sha256=expected, actual_sha256=actual, passed=expected == actual)
(out / 'result.json').write_text(json.dumps(result, indent=2)+'\n')
print(f'Uploaded {file.name}: {len(data)} bytes, SHA256 match={result["passed"]}')
raise SystemExit(0 if result['passed'] else 1)

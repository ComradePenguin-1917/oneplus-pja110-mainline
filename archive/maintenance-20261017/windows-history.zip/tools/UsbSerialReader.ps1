function Initialize-UsbSerialReaderType {
    if (-not ('UsbSerialContinuousReader' -as [type])) {
        $references=@(Get-ChildItem -LiteralPath (Join-Path $PSHOME 'ref') -Filter '*.dll' | ForEach-Object {$_.FullName})
        $references += [IO.Ports.SerialPort].Assembly.Location
        Add-Type -Path (Join-Path $PSScriptRoot 'UsbSerialContinuousReader.cs') -ReferencedAssemblies $references
    }
}

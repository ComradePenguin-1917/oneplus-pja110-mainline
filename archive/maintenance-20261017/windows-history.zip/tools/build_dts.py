#!/usr/bin/env python3
"""Compile a board DTS the way the kernel does: cpp -> dtc.

dtc alone cannot handle #include or the C preprocessor macros used all over
qcom DTS files, so we run the host C preprocessor first (gcc -E) exactly like
scripts/Makefile.lib does.

Usage:
    python build_dts.py                          # build our xigua DTS
    python build_dts.py --dts path/to/foo.dts
    python build_dts.py --keep-pre               # keep the preprocessed file
"""
import argparse
import os
import shutil
import subprocess
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
LINUX = os.path.join(WS, 'linux')
DTC = r'D:\msys64\ucrt64\bin\dtc.exe'
CPP = shutil.which('gcc') or r'D:\msys64\ucrt64\bin\gcc.exe'


def run(cmd):
    return subprocess.run(cmd, capture_output=True, text=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dts', default=os.path.join(WS, 'dts', 'sm8550-oneplus-xigua.dts'))
    ap.add_argument('--out', default=None)
    ap.add_argument('--keep-pre', action='store_true')
    args = ap.parse_args()

    for p, what in ((DTC, 'dtc'), (CPP, 'cpp/gcc')):
        if not os.path.exists(p):
            sys.exit('%s not found at %s' % (what, p))
    if not os.path.isdir(LINUX):
        sys.exit('kernel tree not found at %s (sparse clone needed)' % LINUX)

    out = args.out or args.dts.replace('.dts', '.dtb')
    pre = args.dts.replace('.dts', '.pre.dts')

    cpp_cmd = [
        CPP, '-E', '-nostdinc',
        '-undef', '-D__DTS__',
        '-I', LINUX + '/scripts/dtc/include-prefixes',
        '-I', os.path.dirname(os.path.abspath(args.dts)),
        '-I', LINUX + '/include',
        '-I', LINUX + '/arch/arm64/boot/dts',
        '-I', LINUX + '/arch/arm64/boot/dts/qcom',
        '-x', 'assembler-with-cpp',
        '-o', pre, args.dts,
    ]
    r = run(cpp_cmd)
    if r.returncode != 0:
        print('--- cpp FAILED ---')
        print(r.stderr[:4000])
        return r.returncode

    dtc_cmd = [
        DTC, '-I', 'dts', '-O', 'dtb', '-o', out,
        # -@ emits the __symbols__ node from the DTS labels. This device's ABL
        # looks for the labels "qcom_tzlog" and "arch_timer" before applying a
        # DTBO, so without -@ the workaround in the board DTS would be a no-op.
        '-@',
        '-Wno-unique_unit_address', '-Wno-unit_address_vs_reg',
        '-Wno-graph_child_address', '-Wno-simple_bus_reg',
        '-Wno-pci_bridge', '-Wno-pci_device_bus_num',
        pre,
    ]
    r2 = run(dtc_cmd)
    if r2.stdout.strip():
        print(r2.stdout[:3000])
    if r2.stderr.strip():
        print(r2.stderr[:6000])

    if r2.returncode == 0 and os.path.exists(out):
        print('OK  %s  (%d bytes)' % (out, os.path.getsize(out)))
    else:
        print('FAILED (dtc exit %d)' % r2.returncode)

    if not args.keep_pre and os.path.exists(pre):
        os.remove(pre)
    return r2.returncode


if __name__ == '__main__':
    sys.exit(main())

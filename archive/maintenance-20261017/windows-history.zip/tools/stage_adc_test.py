"""Stage a bounded ADC install script on native A; never invoke sudo."""
from pathlib import Path
import hashlib
import json
import subprocess
from prepare_native_install import SSH
out = Path('out/native-install-20261017/adc-gen3')
args = SSH[:]
args[-1] = 'penguin@172.16.42.1'
args = [x if not x.startswith('UserKnownHostsFile=') else
        'UserKnownHostsFile=out/native-install-20261017/known_hosts' for x in args]
def run(cmd, data=None):
    p = subprocess.run(args + [cmd], input=data, capture_output=True, timeout=180)
    print(p.stdout.decode(errors='replace'), end='')
    print(p.stderr.decode(errors='replace'), end='')
    p.check_returncode()
    return p.stdout
m = json.loads((out / 'vendor-manifest.json').read_text())
run('umask 077; mkdir -p /home/penguin/adc-test; df -k /home/penguin')
for name in ('qcom-spmi-adc5-gen3.ko', 'vendor_boot_a-adc.img'):
    data = (out / name).read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    result = run('cat > /home/penguin/adc-test/' + name + ' && sha256sum /home/penguin/adc-test/' + name, data)
    assert result.decode().split()[0] == digest
module_sha = hashlib.sha256((out / 'qcom-spmi-adc5-gen3.ko').read_bytes()).hexdigest()
script = '''#!/bin/sh
set -eu
cd /home/penguin/adc-test
test "$(uname -r)" = 6.14.0-oneplus-xigua
test "$(sed -n 's/^PARTNAME=//p' /sys/class/block/sde24/uevent)" = vendor_boot_a
echo "@MODULE@  qcom-spmi-adc5-gen3.ko" | sha256sum -c -
echo "@CANDIDATE@  vendor_boot_a-adc.img" | sha256sum -c -
test "$(sha256sum /dev/sde24 | cut -d ' ' -f 1)" = @SOURCE@
modprobe qcom_vadc_common
if [ ! -d /sys/module/qcom_spmi_adc5_gen3 ]; then
    insmod ./qcom-spmi-adc5-gen3.ko
fi
test -d /sys/module/qcom_spmi_adc5_gen3
test ! -e vendor_boot_a-before.img
dd if=/dev/sde24 of=vendor_boot_a-before.img bs=1048576
echo "@SOURCE@  vendor_boot_a-before.img" | sha256sum -c -
install -D -m 644 qcom-spmi-adc5-gen3.ko /usr/local/lib/pja110/qcom-spmi-adc5-gen3.ko
cat > /etc/systemd/system/pja110-adc-test.service <<'UNIT'
[Unit]
Description=PJA110 upstream ADC5 Gen3 temperature test
After=systemd-modules-load.service
[Service]
Type=oneshot
ExecStart=/sbin/modprobe qcom_vadc_common
ExecStart=/sbin/insmod /usr/local/lib/pja110/qcom-spmi-adc5-gen3.ko
RemainAfterExit=yes
[Install]
WantedBy=multi-user.target
UNIT
systemctl enable pja110-adc-test.service
sync
dd if=vendor_boot_a-adc.img of=/dev/sde24 bs=1048576 conv=fsync
test "$(sha256sum /dev/sde24 | cut -d ' ' -f 1)" = @CANDIDATE@
sync
echo 'ADC_VENDOR_WRITE_VERIFIED; reboot not requested; B untouched'
'''.replace('@MODULE@', module_sha).replace('@CANDIDATE@', m['candidate_sha256']).replace('@SOURCE@', m['source_sha256'])
(out / 'install-adc-test.sh').write_bytes(script.encode())
run('cat > /home/penguin/install-adc-test.sh', script.encode())
run('sh -n /home/penguin/install-adc-test.sh; cat /sys/class/power_supply/bq28z610-0/capacity')
print('Staged; sudo/install/reboot not executed.')

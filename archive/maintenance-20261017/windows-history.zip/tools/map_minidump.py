#!/usr/bin/env python3
"""The stack is now identifiable. Map it fully before deciding anything.

Confirmed from the running device:
    /proc/vmkmsg is implemented by  qcom_ddump_vmkmsg_read  [dmesg_dumper]
    /soc/dmesg-dump is a bound platform device   soc:dmesg-dump
    related vendor modules present:
        dmesg_dumper, minidump, qcom_ramdump, qcom_va_minidump,
        memory_dump_v2, microdump_collector, ordump, dump_device_info

So Qualcomm ships a whole crash-log family here. The question that decides
everything: does ANY of it persist a kernel log somewhere that we can read after
our kernel dies?

/vmkmsg BLOCKS on read, which means it is a synchronising channel to another VM,
not a file. That is consistent with "dmesg dumper hands the log to ABL".

New angle worth checking, because it changes the picture: `qcom_ramdump` and
`qcom_va_minidump` are the mechanisms behind the Minidump the ABL log reported as
ON. If a minidump region is written on crash and remains in RAM, then entering
9008 might still find it -- and that is exactly your original idea.

So: find the minidump regions in the device tree and see where they live.
"""
import os
import struct
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
sys.path.insert(0, os.path.join(WS, 'tools'))
from fdt import FDT


def dec(v):
    return v.rstrip(b'\0').decode('ascii', 'replace')


def regs(v):
    return [struct.unpack_from('>QQ', v, i) for i in range(0, len(v) - 15, 16)]


live = FDT(open(os.path.join(WS, 'live-from-device.dtb'), 'rb').read()).nodes()

print('=' * 78)
print('1) ALL MINIDUMP / DUMP REGIONS IN THE LIVE TREE')
print('=' * 78)
keys = ('minidump', 'md_', 'ramdump', 'microdump', 'mem_dump', 'dump')
seen = set()
for p in sorted(live):
    leaf = p.split('/')[-1].lower()
    if not any(k in leaf for k in keys):
        continue
    if p in seen:
        continue
    seen.add(p)
    props = live[p]
    r = props.get('reg')
    c = props.get('compatible')
    info = ''
    if r:
        info = '  reg: ' + ' '.join('0x%x+0x%x' % x for x in regs(r))
    print('  %s' % p)
    if c:
        print('      compatible: %s' % dec(c).replace('\0', ' | '))
    if info:
        print('     %s' % info)
    for k in ('qcom,dump-size', 'qcom,dump-id', 'size', 'label', 'shared-buffer'):
        if k in props:
            v = props[k]
            if len(v) == 4:
                print('      %-16s 0x%x' % (k, struct.unpack('>I', v)[0]))
            elif len(v) <= 30:
                print('      %-16s %r' % (k, dec(v)))

print()
print('=' * 78)
print('2) RESERVED-MEMORY ENTRIES FOR DUMP/MINIDUMP')
print('=' * 78)
for p in sorted(live):
    if not p.startswith('/reserved-memory/') or p.count('/') != 2:
        continue
    if not any(k in p.lower() for k in keys):
        continue
    props = live[p]
    r = props.get('reg')
    print('  %-56s %s' % (p.split('/')[-1][:56],
                          (' '.join('0x%x+0x%x' % x for x in regs(r)) if r else '(no reg)')))

print()
print('=' * 78)
print('3) ARE THOSE REGIONS IN OUR DTB TOO?')
print('=' * 78)
ours = FDT(open(os.path.join(WS, 'dts', 'sm8550-oneplus-xigua-16G.dtb'), 'rb').read()).nodes()
for p in sorted(ours):
    if not p.startswith('/reserved-memory/'):
        continue
    if any(k in p.lower() for k in ('minidump', 'md_', 'dump', 'ramdump')):
        r = ours[p].get('reg')
        print('  %-56s %s' % (p.split('/')[-1][:56],
                              (' '.join('0x%x+0x%x' % x for x in regs(r)) if r else '(no reg)')))

print()
print('=' * 78)
print('4) THE DECISIVE QUESTION FOR THE 9008 IDEA')
print('=' * 78)
print('  For 9008 to read our kernel log, ALL of these must hold:')
print('    a) our kernel wrote the log somewhere in DRAM')
print('    b) entering 9008 does NOT retrain/reinitialise DDR')
print('    c) the firehose programmer for SM8550 allows peek/memorydump')
print('    d) we can obtain that programmer')
print()
print('  (b) is the crux. Normally 9008 entry re-runs the PBL, which re-initialises')
print('  DDR. If that happens, DRAM contents are lost and the channel is dead.')
print()
print('  BUT there is a variant that avoids (b): Qualcomm crash handlers can put the')
print('  log into a MINIDUMP region that the bootloader then reads. The ABL log')
print('  said "Minidump : ON", and minidump regions are listed above. If a minidump')
print('  is written to FLASH or to a region ABL preserves, it survives a full reset')
print('  and we could read it from Android or from 9008 without DDR concerns.')
print()
print('  So the most valuable next probe is: identify where minidump data is')
print('  actually stored, and whether any of it is in flash.')

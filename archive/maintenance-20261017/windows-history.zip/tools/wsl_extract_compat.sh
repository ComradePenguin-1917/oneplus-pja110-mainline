#!/bin/bash
# Extract the exact mainline `compatible` strings for the drivers we must bind.
# Never guess these: a wrong string silently fails to bind and looks like a
# kernel bug.
set -uo pipefail
TREE="$HOME/workspace/PJA110-Mainline/linux"
cd "$TREE"

check() {
    local name="$1" file="$2"
    printf '%-22s ' "$name"
    if [ -f "$file" ]; then
        grep -ohE '"qcom,[a-z0-9-]+"|"snps,dwc3"|"arm,psci-1.0"' "$file" | sort -u | tr '\n' ' '
        echo
    else
        echo "(MISSING FILE: $file)"
    fi
}

echo "############ exact match strings from the kernel we built ############"
check "GCC sm8550"        drivers/clk/qcom/gcc-sm8550.c
check "TLMM sm8550"       drivers/pinctrl/qcom/pinctrl-sm8550.c
check "UFS host"          drivers/ufs/host/ufs-qcom.c
check "QMP UFS PHY"       drivers/phy/qualcomm/phy-qcom-qmp-ufs.c
check "dwc3-qcom wrapper" drivers/usb/dwc3/dwc3-qcom.c
check "dwc3 core"         drivers/usb/dwc3/core.c
check "QMP combo PHY"     drivers/phy/qualcomm/phy-qcom-qmp-combo.c
check "SNPS eUSB2 PHY"    drivers/phy/qualcomm/phy-qcom-snps-eusb2.c
check "eUSB2 repeater"    drivers/phy/qualcomm/phy-qcom-eusb2-repeater.c
check "GENI serial"       drivers/tty/serial/qcom_geni_serial.c
check "QCOM SCM"          drivers/firmware/qcom/qcom_scm.c
check "LLCC"              drivers/soc/qcom/llcc-qcom.c
check "TSENS"             drivers/thermal/qcom/tsens.c
check "RPMH RSC"          drivers/soc/qcom/rpmh-rsc.c
check "SMEM"              drivers/soc/qcom/smem.c
check "SPMI pmic-arb"     drivers/spmi/spmi-pmic-arb.c
check "rpmh regulators"   drivers/regulator/qcom-rpmh-regulator.c
check "interconnect"      drivers/interconnect/qcom/sm8550.c
check "pdc"               drivers/irqchip/qcom-pdc.c
check "smmu"              drivers/iommu/arm/arm-smmu/arm-smmu-qcom.c

echo
echo "############ interconnect driver: which compatibles? ############"
grep -ohE '"qcom,sm8550-[a-z0-9-]+"' drivers/interconnect/qcom/sm8550.c 2>/dev/null | sort -u | head -30

echo
echo "############ confirmed: is there a sm8550 interconnect at all? ############"
ls drivers/interconnect/qcom/ | grep -i 8550

echo
echo "############ sm8550 pinctrl: does the driver list a kalama fallback? ############"
grep -nE 'kalama|sm8550' drivers/pinctrl/qcom/pinctrl-sm8550.c | head

echo
echo "############ rpmh regulator compatibles we might need ############"
grep -ohE '"qcom,pm8550[a-z0-9-]*"|"qcom,rpmh-regulator[a-z0-9-]*"' \
    drivers/regulator/qcom-rpmh-regulator.c 2>/dev/null | sort -u | head -20

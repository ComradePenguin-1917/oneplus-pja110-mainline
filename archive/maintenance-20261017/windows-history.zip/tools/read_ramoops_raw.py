#!/usr/bin/env python3
"""Why is pstore still empty even with the correct address?

Possibilities:
  A) our kernel never wrote anything there (it died before pstore/ramoops init,
     which happens quite early but after console setup)
  B) our kernel did write, but Android's ramoops driver CLEARS the zone on init
     unless the data looks like a valid pstore record
  C) our kernel did write, and Android erased the whole window before use
  D) our DTB's ramoops node was never used, because our kernel died before it
     could parse the device tree

There is one way to tell (B) from (A)/(C)/(D): look at the raw RAM contents and
look for the pstore record signature. pstore/ramoops stores each record with a
signature, and for console records the text is plainly visible.

Approach: as root, read the ramoops window and search for our own banner strings.
"/init RAN", "[initramfs]" or a kernel banner like "Linux version 6.14" would
prove our kernel reached the point of writing to ramoops at all.
"""
import os
import shutil
import subprocess
import sys

ADB = shutil.which('adb') or r'C:\platform-tools\adb.exe'
WS = r'H:\WorkSpace\PJA110-Mainline'
SERIAL = 'bc7a542e'

ADDR = 51482722304           # 0xBFC9C0000
SIZE = 2359296               # 0x240000


def root(cmd, timeout=600):
    r = subprocess.run([ADB, '-s', SERIAL, 'shell', "su -c '%s'" % cmd],
                       capture_output=True, timeout=timeout)
    return ((r.stdout or b'') + (r.stderr or b'')).decode('utf-8', 'replace')


print('=' * 78)
print('1) can we read the ramoops window at all?')
print('=' * 78)
print('  /dev/mem present : %s' % root('ls -l /dev/mem 2>&1').strip()[:120])
print('  /dev/mem perms   : %s' % root('ls -la /dev/mem 2>&1').strip()[:120])

# dd from /dev/mem at a huge offset needs the offset in bytes; busybox dd may not
# handle >2GB offsets, so try and fall back to two 32-bit halves via skip in blocks
out = '/data/local/tmp/ramoops.bin'
cmd = ('dd if=/dev/mem of=%s bs=4096 skip=%d count=%d 2>&1; chmod 644 %s'
       % (out, ADDR // 4096, SIZE // 4096, out))
r = root(cmd)
print('  dd result: %s' % r.strip()[:200])

# does the file have content?
sz = root('stat -c %%s %s 2>/dev/null' % out).strip()
print('  dumped size: %s bytes' % sz)

local = os.path.join(WS, 'out', 'ramoops-raw.bin')
if sz and sz.isdigit() and int(sz) > 0:
    subprocess.run([ADB, '-s', SERIAL, 'pull', out, local], capture_output=True, timeout=900)
    if os.path.exists(local):
        data = open(local, 'rb').read()
        print('  pulled %d bytes' % len(data))
        print()
        print('=' * 78)
        print('2) what is in there?')
        print('=' * 78)
        # non-zero fraction tells us whether it was wiped
        nz = sum(1 for c in data[:1 << 20] if c)
        print('  non-zero bytes in first 1 MiB: %d' % nz)
        # printable strings
        import re
        strs = re.findall(rb'[\x20-\x7e]{8,}', data)
        print('  printable strings: %d' % len(strs))
        for s in strs[:40]:
            print('    %s' % s.decode('ascii', 'replace')[:110])
        print()
        print('  searching for our own markers:')
        for probe in (b'initramfs', b'/init RAN', b'Linux version 6.14',
                      b'6.14.0', b'xigua', b'ramoops', b'Kernel panic'):
            print('    %-22s %s' % (probe.decode(), 'FOUND' if probe in data else '-'))
        root('rm -f %s' % out)
else:
    print('  no dump produced; /dev/mem is probably restricted')

print()
print('=' * 78)
print('3) is Android clearing the zone?  (record signature check)')
print('=' * 78)
print('  a pstore/ramoops zone that was written and then wiped would read as all')
print('  zeros or as random stale RAM. A zone never written also reads that way,')
print('  so compare with what a KNOWN-GOOD write looks like: force one.')
print()
print('  android may expose the zone through debugfs instead:')
print('   ', root('ls /sys/kernel/debug/pstore 2>&1').strip()[:200])
print('   ', root('cat /sys/module/ramoops/parameters/dump_oops 2>&1').strip()[:80])
print()
print('  also check whether Android itself has anything recorded (it would if a')
print('  panic or oops ever happened under it):')
print('   ', root('ls -la /sys/fs/pstore/ 2>&1').strip()[:300])

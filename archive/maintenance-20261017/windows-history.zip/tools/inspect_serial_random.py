from pathlib import Path
import re, base64, hashlib, sys
p=Path(sys.argv[1] if len(sys.argv)>1 else 'out/usb-serial-reliability-fullspeed-random-20261013/transcript-Async.txt')
t=p.read_text()
for m in re.finditer(r'(?s)(?:^|\n)(USB_\d+_\d+)_BEGIN\n(.*?)\n\1_END(?:\n|$)',t):
    payload=m[2]
    bad=re.findall(r'[^A-Za-z0-9+/=\s]',payload)
    print(m[1], 'chars',len(payload),'bad',bad[:15],'tail',repr(payload[-160:]))
    try:
        d=base64.b64decode(payload,validate=False)
        print('decoded',len(d),'sha',hashlib.sha256(d).hexdigest())
    except Exception as e:
        print(type(e).__name__,str(e))

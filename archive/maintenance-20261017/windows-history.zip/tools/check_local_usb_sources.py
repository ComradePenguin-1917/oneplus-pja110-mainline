"""Read the actual WSL build tree and compare Git blob IDs without changing it."""
import hashlib
import json
import shutil
from pathlib import Path

workspace = Path('/mnt/h/workspace/PJA110-Mainline')
output = workspace / 'out/aston-usb-comparison-20261013'
source = Path.home() / 'workspace/PJA110-Mainline/linux'
trees = {name: json.loads((output / f'{name}-tree.json').read_text(encoding='utf-8-sig'))
         for name in ('vanilla', 'aston')}
records = []
for path in sorted(set(trees['vanilla']) | set(trees['aston'])):
    file = source / path
    data = file.read_bytes() if file.exists() else None
    blob = (hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
            if data is not None else None)
    if blob != trees['vanilla'].get(path) or blob != trees['aston'].get(path):
        records.append(dict(path=path, local=blob, vanilla=trees['vanilla'].get(path),
                            aston=trees['aston'].get(path)))
        if data is not None:
            dest = output / 'local' / path
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
related = json.loads((output / 'related-paths.json').read_text(encoding='utf-8-sig'))
for path in related + ['Makefile', '.config', 'arch/arm64/boot/dts/qcom/sm8550.dtsi',
             'arch/arm64/boot/dts/qcom/pm8550b.dtsi',
             'arch/arm64/boot/dts/qcom/sm8550-oneplus-xigua.dts']:
    file = source / path
    if file.exists():
        dest = output / 'local' / path
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(file, dest)
references = []
for file in (source / 'drivers/usb').rglob('*'):
    if file.is_file() and file.suffix in ('.c', '.h'):
        for line in file.read_text(errors='replace').splitlines():
            if '#include' in line and 'u_f.h' in line:
                references.append(f'{file.relative_to(source)}: {line}')
(output / 'u_f-header-includes.txt').write_text('\n'.join(references) + '\n')
(output / 'local-comparison.json').write_text(json.dumps(records, indent=2) + '\n')
print(f'Checked {len(set(trees["vanilla"]) | set(trees["aston"]))} USB/Qualcomm PHY files')
print(f'Local build version: {(source / "Makefile").read_text().splitlines()[1:5]}')
for record in records:
    print(record['path'], 'local=vanilla', record['local'] == record['vanilla'],
          'local=aston', record['local'] == record['aston'])

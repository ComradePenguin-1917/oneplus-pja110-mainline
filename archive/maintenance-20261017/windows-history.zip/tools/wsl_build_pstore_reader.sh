#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
WIN=/mnt/h/workspace/PJA110-Mainline
PREFIX="$ROOT/toolchain/gcc-12-aarch64"
export PATH="$PREFIX/usr/bin:$PATH"
export LD_LIBRARY_PATH="$PREFIX/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
OUT="$WIN/out/stock-pstore-control-20261012"
mkdir -p "$OUT"
aarch64-linux-gnu-gcc -Os -nostdlib -static -ffreestanding -fno-builtin -fno-stack-protector -fno-unwind-tables -fno-asynchronous-unwind-tables -Wl,--build-id=none,-e,_start "$WIN/tools/pstore_early_reader.c" -o "$OUT/early-reader"
aarch64-linux-gnu-readelf -h -l "$OUT/early-reader" > "$OUT/reader-elf.txt"
aarch64-linux-gnu-objdump -d "$OUT/early-reader" > "$OUT/reader-disassembly.txt"
test -z "$(aarch64-linux-gnu-nm -u "$OUT/early-reader")"
sha256sum "$OUT/early-reader"

/* Read-only sampling through the existing MSM debugfs snapshot interface. */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

static double mono(void) {
 struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t);
 return t.tv_sec+t.tv_nsec/1e9;
}
int main(int argc,char **argv) {
 int count=argc>1?atoi(argv[1]):300;
 if(count<1 || count>4000)return 2;
 char *buf=malloc(1024*1024);
 if(!buf)return 2;
 puts("before,after,snapshot_time,rd_frame,rd_line,wr_line,out_line,intf_frame");
 for(int i=0;i<count;i++) {
  double start=mono();
  FILE *f=fopen("/sys/kernel/debug/dri/0/kms","r");
  if(!f){perror("kms");return 1;}
  size_t len=fread(buf,1,1024*1024-1,f);
  int bad=ferror(f);fclose(f);double end=mono();
  if(bad){perror("read");return 1;}
  buf[len]=0;
  char *p=strstr(buf,"====================intf_1================");
  if(!p){fprintf(stderr,"missing intf1\n");return 1;}
  unsigned rd=0,wr=0,out=0,frame=0,a,b,c,d;
  char *line=strstr(p,"\n0x290 : ");
  if(!line || sscanf(line,"\n0x290 : %x %x %x %x",&a,&b,&c,&d)!=4)return 1;
  rd=c;
  line=strstr(p,"\n0x2a0 : ");
  if(!line || sscanf(line,"\n0x2a0 : %x %x %x %x",&a,&b,&c,&d)!=4)return 1;
  out=d;
  line=strstr(p,"\n0x2b0 : ");
  if(!line || sscanf(line,"\n0x2b0 : %x",&a)!=1)return 1;
  wr=a;
  line=strstr(p,"\n0xa0 : ");
  if(!line || sscanf(line,"\n0xa0 : %x %x %x %x",&a,&b,&c,&d)!=4)return 1;
  frame=d;
  double snap=-1;char *ts=strstr(buf,"\ntime: ");
  if(ts)sscanf(ts,"\ntime: %lf",&snap);
  printf("%.9f,%.9f,%.9f,%u,%u,%u,%u,%u\n",start,end,snap,rd>>16,rd&65535,wr&65535,out&65535,frame);
  struct timespec pause={0,100000};nanosleep(&pause,NULL);
 }
 free(buf);return 0;
}

# Authenticate directly to phone sudo; no password is recorded or stored.
$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path -Parent $PSScriptRoot
$sshBinary = 'C:/Windows/System32/OpenSSH/ssh.exe'
$sshArgs = @('-F', 'none', '-tt', '-i', "$taskRoot/out/usb-ncm-20261013/ssh/client_key_host",
    '-o', 'BatchMode=yes', '-o', 'IdentitiesOnly=yes', '-o', 'StrictHostKeyChecking=yes',
    '-o', "UserKnownHostsFile=$taskRoot/out/native-install-20261017/known_hosts",
    '-o', 'ConnectTimeout=6', 'penguin@172.16.42.1')
Write-Host 'Enter the phone penguin password. Installs the Wi-Fi A vendor_boot candidate and reboots.'
& $sshBinary @sshArgs 'sudo /bin/sh /home/penguin/wifi-bringup/install.sh'
$installExit = $LASTEXITCODE
if ($installExit -notin @(0, 255)) { throw "Phone installer exited $installExit; inspect its output." }
Write-Host 'After reboot, the agent can read /home/penguin/wifi-bringup/boot-probe.txt.'

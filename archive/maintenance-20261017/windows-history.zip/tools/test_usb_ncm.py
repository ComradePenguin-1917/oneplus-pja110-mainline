"""Validate phone NCM TCP transfers with exact lengths and SHA256."""
import argparse
import hashlib
import http.client
import json
import secrets
import socket
import time
from pathlib import Path

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--rounds', type=int, default=10)
parser.add_argument('--output', default='out/usb-ncm-20261013/transfer-test')
parser.add_argument('--phone', default='169.254.42.1')
parser.add_argument('--download-sha256', required=True)
args = parser.parse_args()
out = (root / args.output).resolve()
if root not in out.parents or not 1 <= args.rounds <= 100:
    parser.error('invalid output or rounds')
out.mkdir(parents=True, exist_ok=True)
if (out / 'result.json').exists():
    parser.error('use a new output directory to preserve evidence')
network = json.loads((root / 'out/usb-ncm-20261013/windows-network.json').read_text(encoding='utf-8-sig'))
source = next(item['IPAddress'] for item in network['Address'] if item['IPAddress'].startswith('169.254.'))
records = []
def download(path):
    connection = http.client.HTTPConnection(args.phone, 8080, timeout=20, source_address=(source, 0))
    try:
        connection.request('GET', path)
        response = connection.getresponse()
        if response.status != 200:
            raise RuntimeError(f'HTTP status {response.status}')
        return response.read()
    finally:
        connection.close()
try:
    for r in range(1, args.rounds + 1):
        start = time.monotonic()
        data = download('/random.bin')
        digest = hashlib.sha256(data).hexdigest()
        passed = len(data) == 4194304 and digest == args.download_sha256
        records.append(dict(round=r, direction='phone-to-host', bytes=len(data), passed=passed,
                            seconds=time.monotonic()-start, expected_sha256=args.download_sha256, actual_sha256=digest))
        assert passed, 'download integrity failed'
        for n in (65536, 1048576, 4194304):
            data = secrets.token_bytes(n)
            expected = hashlib.sha256(data).hexdigest()
            start = time.monotonic()
            with socket.create_connection((args.phone, 9000), timeout=20, source_address=(source, 0)) as client:
                client.sendall(f'{n}\n'.encode() + data)
                client.shutdown(socket.SHUT_WR)
                response = bytearray()
                while len(response) < 256:
                    part = client.recv(256)
                    if not part:
                        break
                    response.extend(part)
            actual = response.decode().split()[0] if response else ''
            returned = download('/uploaded.bin')
            returned_hash = hashlib.sha256(returned).hexdigest()
            passed = actual == expected and len(returned) == n and returned == data and returned_hash == expected
            records.append(dict(round=r, direction='host-to-phone-and-readback', bytes=n, passed=passed,
                                seconds=time.monotonic()-start, expected_sha256=expected,
                                phone_sha256=actual, readback_sha256=returned_hash, readback_bytes=len(returned)))
            assert passed, 'upload or readback integrity failed'
        print(f'NCM round {r} passed', flush=True)
finally:
    result = dict(all_passed=len(records) == args.rounds*4 and all(x['passed'] for x in records),
                  source_address=source, phone_address=args.phone, expected_checks=args.rounds*4,
                  completed_checks=len(records), checks=records)
    (out / 'result.json').write_text(json.dumps(result, indent=2)+'\n')
print('All passed:', result['all_passed'])
raise SystemExit(0 if result['all_passed'] else 1)

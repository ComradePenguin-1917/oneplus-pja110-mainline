"""Capture physical keys or test bounded screen toggles over existing SSH."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/buttons-20261013'
KEYS=ROOT/'out/usb-ncm-20261013/ssh'
SSH=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(KEYS/'client_key_host'),
     '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
     '-o',f'UserKnownHostsFile={KEYS/"known_hosts"}','-o','ConnectTimeout=5',
     '-o','ServerAliveInterval=5','root@169.254.42.1']
mode=sys.argv[1]
assert mode in ('capture','policy')
if mode == 'policy':
    raise SystemExit('Custom power-key policy is retired at user request; use an existing desktop/power manager. Historical tests remain archived.')
def remote(cmd,data=None):
    p=subprocess.run(SSH+[cmd],input=data,capture_output=True,timeout=30)
    (OUT/'last-stderr.txt').write_bytes(p.stderr);p.check_returncode();return p.stdout
assert b'#14 SMP' in remote('uname -a')
data=(OUT/'button-test').read_bytes()
assert remote('cat > /tmp/button-test; chmod 700 /tmp/button-test; sha256sum /tmp/button-test',data).decode().split()[0]==hashlib.sha256(data).hexdigest()
with (OUT/f'{mode}-events.txt').open('wb') as log:
    p=subprocess.Popen(SSH+[f'/tmp/button-test --{mode}'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    for line in p.stdout:
        log.write(line);log.flush();print(line.decode(errors='replace'),end='',flush=True)
    rc=p.wait(timeout=10)
(OUT/f'{mode}-dmesg.txt').write_bytes(remote('dmesg'))
if rc:raise SystemExit(rc)
print(f'PASS: {mode} completed; evaluate recorded press/release pairs and user observations',flush=True)

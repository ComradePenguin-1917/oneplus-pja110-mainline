#!/bin/bash
# Fix applet symlink creation: the aarch64 busybox CANNOT be executed on the
# x86 host, so `busybox --list` always fails and we ended up with 0 applets
# (which means /bin/sh would not exist and the kernel could not run /init).
#
# Solution: ask busybox's own build system for the applet list, or fall back to
# extracting the names from the binary. We also create a few hard requirements
# unconditionally (sh, mount, ...) because /init depends on them.
set -uo pipefail

ROOT="$HOME/workspace/PJA110-Mainline"
WORK="$ROOT/initramfs"
TREE="$WORK/tree"
BB="$WORK/dl/busybox-aarch64-static"
SRC="$WORK/dl/busybox-1.36.1"

echo "=== 1) get applet list without executing the aarch64 binary ==="
APPLETS=""

# (a) busybox ships a generated table: include/applets.h  -> IF_XXX(APPLET(...))
if [ -f "$SRC/include/applets.h" ]; then
    APPLETS=$(grep -oP 'IF_\w+\(\s*APPLET_NO\w*\(\s*\K[a-zA-Z0-9_]+' "$SRC/include/applets.h" 2>/dev/null | sort -u)
    # older/newer format variants
    if [ -z "$APPLETS" ]; then
        APPLETS=$(sed -n 's/.*APPLET[_A-Z]*(\([a-zA-Z0-9_]*\).*/\1/p' "$SRC/include/applets.h" | sort -u)
    fi
fi
echo "  from applets.h: $(echo "$APPLETS" | grep -c . ) names"

# (b) fallback: the .config records which applets were built
if [ -z "$APPLETS" ] && [ -f "$SRC/.config" ]; then
    APPLETS=$(sed -n 's/^CONFIG_\([A-Z0-9_]*\)=y$/\1/p' "$SRC/.config" \
              | tr 'A-Z' 'a-z' | sort -u)
    echo "  from .config   : $(echo "$APPLETS" | grep -c . ) names"
fi

echo
echo "=== 2) which of OUR needed applets are available? ==="
NEED="sh mount umount mkdir rmdir ls cat echo sleep ip ifconfig telnetd
udhcpd dd dmesg grep sed awk uname setsid pwd ps free df
mknod chmod ln sync hostname more vi cut tr head tail wc
printf test true false kill env printenv"
FOUND=""
MISSING=""
for a in $NEED; do
    if echo "$APPLETS" | grep -qx "$a"; then
        FOUND="$FOUND $a"
    else
        MISSING="$MISSING $a"
    fi
done
echo "  found  :$FOUND"
echo "  missing:$MISSING"

echo
echo "=== 3) create the symlinks ==="
rm -f "$TREE"/bin/*
cp "$BB" "$TREE/bin/busybox"
chmod 755 "$TREE/bin/busybox"
n=0
for a in $FOUND; do
    ln -sf busybox "$TREE/bin/$a"
    n=$((n+1))
done
echo "  linked $n applets"

# hard requirement: /init is #!/bin/sh
if [ ! -e "$TREE/bin/sh" ]; then
    ln -sf busybox "$TREE/bin/sh"
    echo "  forced /bin/sh (init depends on it)"
fi

echo
echo "=== 4) sanity: /bin/sh resolves and is the busybox binary ==="
ls -l "$TREE/bin/sh"
readlink -f "$TREE/bin/sh"

echo
echo "=== 5) repack ==="
cd "$TREE"
find . -print0 | cpio --null -o --format=newc 2>/dev/null | gzip -9 > "$WORK/initramfs.cpio.gz"
zcat "$WORK/initramfs.cpio.gz" > /tmp/z.cpio
LIST=$(cpio -t < /tmp/z.cpio 2>/dev/null)
echo "  total entries   : $(echo "$LIST" | wc -l)"
echo "  has init        : $(echo "$LIST" | grep -cx 'init')"
echo "  has bin/busybox : $(echo "$LIST" | grep -cx 'bin/busybox')"
echo "  has bin/sh      : $(echo "$LIST" | grep -cx 'bin/sh')"
echo "  size            : $(stat -c%s "$WORK/initramfs.cpio.gz")"
echo
echo "  bin/ contents:"
echo "$LIST" | grep '^bin/' | tr '\n' ' '
echo
rm -f /tmp/z.cpio

cp "$WORK/initramfs.cpio.gz" /mnt/h/WorkSpace/PJA110-Mainline/initramfs/
echo
echo "packed and copied"

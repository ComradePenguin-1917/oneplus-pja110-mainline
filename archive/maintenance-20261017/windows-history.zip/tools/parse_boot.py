#!/usr/bin/env python3
"""Parse an Android boot image (header v3/v4) and dump its layout.

vendor boot-A14.img is our ground truth for how OnePlus/OPPO pack header v4 on
this device, so reverse it before writing our own packer.

boot_img_hdr_v3/v4 (little endian):
  off  0  u8  magic[8]        "ANDROID!"
  off  8  u32 kernel_size
  off 12  u32 ramdisk_size
  off 16  u32 os_version
  off 20  u32 header_size
  off 24  u32 reserved[4]
  off 40  u32 header_version
  off 44  u8  cmdline[1536]
  off1580 u32 signature_size        (v4 only)

Sections start at page_size (4096) and are each padded to 4096:
  kernel, ramdisk, [boot_signature (v4)], [dtb (v2+)]

Usage:
    python parse_boot.py boot-A14.img
"""
import gzip
import os
import struct
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
PAGE = 4096


def decode_os_version(v):
    """os_version = major<<25 | minor<<18 | (year-2000)<<11 | month<<4."""
    return {
        'raw': '0x%08x' % v,
        'major': (v >> 25) & 0x7F,
        'minor': (v >> 18) & 0x7F,
        'year': 2000 + ((v >> 11) & 0x7F),
        'month': (v >> 4) & 0x0F,
    }


def sniff(first, buf=None, offset=None):
    if first[:2] == b'\x1f\x8b':
        return 'GZIP'
    if first[:4] == b'\x04\x22\x4d\x18':
        return 'LZ4'
    if first[:2] == b'\xfd7':
        return 'XZ'
    if first[:4] == b'\xd0\x0d\xfe\xed':
        return 'raw FDT'
    # arm64 Image: code0 is a branch; look for the "ARM\x64" magic at +56
    if buf is not None and offset is not None:
        if buf[offset + 56:offset + 60] == b'ARM\x64':
            return 'raw arm64 Image'
    return 'unknown'


def parse(path):
    b = open(path, 'rb').read()
    print('=== %s (%d bytes) ===' % (os.path.basename(path), len(b)))
    print('  raw header[0:64] = %s' % b[:64].hex())
    magic = b[:8]
    print('  magic           = %r' % magic)
    if magic != b'ANDROID!':
        print('  not a boot image')
        return

    kernel_size, ramdisk_size, os_version, header_size = struct.unpack_from('<4I', b, 8)
    reserved = struct.unpack_from('<4I', b, 24)
    (header_version,) = struct.unpack_from('<I', b, 40)
    cmdline = b[44:44 + 1536].rstrip(b'\0')

    print('  kernel_size     = %d (%.2f MiB)' % (kernel_size, kernel_size / 2**20))
    print('  ramdisk_size    = %d (%.2f MiB)' % (ramdisk_size, ramdisk_size / 2**20))
    print('  os_version      = %s' % decode_os_version(os_version))
    print('  header_size     = %d' % header_size)
    print('  reserved        = %s' % ['0x%x' % x for x in reserved])
    print('  header_version  = %d' % header_version)
    print('  cmdline         = %r' % cmdline.decode('utf-8', 'replace'))

    sig_size = 0
    if header_version >= 4:
        (sig_size,) = struct.unpack_from('<I', b, 1580)
        print('  signature_size  = %d' % sig_size)

    print()
    print('  sections (page = %d):' % PAGE)
    off = PAGE                      # sections begin after the first page
    for name, size in (('kernel', kernel_size), ('ramdisk', ramdisk_size)):
        if size == 0:
            print('    %-14s size=0  (absent)' % name)
            continue
        start = (off + PAGE - 1) // PAGE * PAGE
        first = b[start:start + 8]
        kind = sniff(first, b, start)
        print('    %-14s offset=0x%08x  size=%-10d (%.2f MiB)  -> %s'
              % (name, start, size, size / 2**20, kind))
        print('                   first bytes = %r' % first)
        if kind == 'GZIP':
            try:
                d = gzip.decompress(b[start:start + size])
                print('                   decompressed = %d bytes (%.2f MiB)'
                      % (len(d), len(d) / 2**20))
                fdt = d.find(b'\xd0\x0d\xfe\xed')
                print('                   FDT inside   = %s'
                      % ('0x%x' % fdt if fdt >= 0 else 'none'))
                if fdt >= 0:
                    sz = struct.unpack_from('>I', d, fdt + 4)[0]
                    print('                   FDT size     = %d' % sz)
                    if b'ARM\x64' in d[:0x10000] or d[56:60] == b'ARM\x64':
                        print('                   -> kernel is Image.gz + appended DTB')
            except Exception as e:
                print('                   gzip failed: %s' % e)
        elif kind == 'raw arm64 Image':
            # appended DTB sits after the Image text; report Image size field
            (image_size,) = struct.unpack_from('<Q', b, start + 16)
            print('                   arm64 Image size field = %d (%.2f MiB)'
                  % (image_size, image_size / 2**20))
            dtb_at = start + image_size
            print('                   DTB right after Image? %s'
                  % (b[dtb_at:dtb_at + 4] == b'\xd0\x0d\xfe\xed'))
            if b[dtb_at:dtb_at + 4] == b'\xd0\x0d\xfe\xed':
                sz = struct.unpack_from('>I', b, dtb_at + 4)[0]
                print('                   DTB size = %d' % sz)
        off = start + size

    if sig_size:
        start = (off + PAGE - 1) // PAGE * PAGE
        print('    %-14s offset=0x%08x  size=%d' % ('boot_signature', start, sig_size))
        off = start + sig_size

    tail_start = (off + PAGE - 1) // PAGE * PAGE
    print()
    print('  tail after last section (0x%x): first bytes %r'
          % (tail_start, b[tail_start:tail_start + 8]))
    fdt = b.find(b'\xd0\x0d\xfe\xed', tail_start)
    print('  FDT in tail: %s' % ('0x%x' % fdt if fdt >= 0 else 'no'))

    # Show where every FDT magic lives in the whole image (sanity)
    hits = []
    i = 0
    while len(hits) < 12:
        i = b.find(b'\xd0\x0d\xfe\xed', i)
        if i < 0:
            break
        hits.append(i)
        i += 4
    print('  all FDT magic offsets in image: %s'
          % (['0x%x' % h for h in hits] or 'none'))


if __name__ == '__main__':
    for p in sys.argv[1:]:
        parse(p if os.path.isabs(p) else os.path.join(WS, p))
        print()

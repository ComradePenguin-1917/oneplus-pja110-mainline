#!/bin/bash
set -euo pipefail
TREE="$HOME/workspace/PJA110-Mainline/linux"
OUT=/mnt/h/workspace/PJA110-Mainline/out/boot-chain-audit-20261012/source
mkdir -p "$OUT"
cd "$TREE"
python3 - "$OUT" <<'PY'
from pathlib import Path
import sys
out = Path(sys.argv[1])
files = [
 'arch/arm64/boot/dts/qcom/sm8550.dtsi',
 'arch/arm64/Kconfig', 'arch/arm64/kernel/head.S',
 'drivers/usb/dwc3/drd.c', 'drivers/usb/dwc3/core.c',
 'drivers/usb/dwc3/dwc3-qcom.c',
 'drivers/phy/qualcomm/phy-qcom-qmp-combo.c',
 'drivers/soc/qcom/pmic_glink.c', 'drivers/usb/typec/ucsi/ucsi_glink.c',
 'drivers/of/fdt.c', 'init/initramfs.c',
 'Documentation/arch/arm64/booting.rst',
 'Documentation/devicetree/bindings/usb/snps,dwc3.yaml',
 'Documentation/devicetree/bindings/usb/qcom,dwc3.yaml',
]
for name in files:
    p = Path(name)
    if p.exists():
        dest = out / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(p.read_bytes())
        print(name)
PY

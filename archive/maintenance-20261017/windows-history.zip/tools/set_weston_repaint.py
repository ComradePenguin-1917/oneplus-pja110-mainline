"""Change only upstream Weston's repaint window in the temporary RAM session."""
import argparse
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('milliseconds', type=int, choices=(1, 7))
args = parser.parse_args()
keys = ROOT / 'out/usb-ncm-20261013/ssh'
ssh = ['C:/Windows/System32/OpenSSH/ssh.exe', '-F', 'none', '-T',
       '-i', str(keys / 'client_key_host'), '-o', 'BatchMode=yes',
       '-o', 'IdentitiesOnly=yes', '-o', 'StrictHostKeyChecking=yes',
       '-o', f'UserKnownHostsFile={keys / "known_hosts"}',
       '-o', 'ConnectTimeout=5', 'root@169.254.42.1']
out = ROOT / 'out/display-timing-20261014/runtime' / f'repaint{args.milliseconds}'
out.mkdir(parents=True, exist_ok=True)
script = f'''set -e
cfg=/tmp/ubuntu-ram/etc/weston/weston.ini
test -f "$cfg"
test -e /tmp/ubuntu-ram/usr/bin/weston
test -f "$cfg.timing-original" || cp "$cfg" "$cfg.timing-original"
killall -TERM weston-simple-egl 2>/dev/null || true
killall -TERM weston 2>/dev/null || true
sleep 2
sed '/^repaint-window=/d; /^\[core\]/a repaint-window={args.milliseconds}' "$cfg.timing-original" > "$cfg"
cat "$cfg"
'''
p = subprocess.run(ssh + [script], capture_output=True, timeout=15)
(out / 'configuration.txt').write_bytes(p.stdout + p.stderr)
p.check_returncode()
subprocess.run(['python', str(ROOT / 'tools/run_ubuntu_weston.py'),
                '--linear', '--compose', '--capture'], check=True)
subprocess.run(ssh + ['sleep 3'], check=True, timeout=10)
subprocess.run(['python', str(ROOT / 'tools/ubuntu_weston_clients.py'),
                '--linear', '--fullscreen-bars'], check=True)
p = subprocess.run(ssh + ['sleep 2; cat /tmp/ubuntu-ram/run/weston.log; ps'],
                   capture_output=True, timeout=15)
(out / 'launch-state.txt').write_bytes(p.stdout + p.stderr)
p.check_returncode()
assert f'Output repaint window is {args.milliseconds} ms maximum.'.encode() in p.stdout
assert b'/usr/bin/weston-simple-egl -f -o -v' in p.stdout
print(f'Confirmed Weston repaint window {args.milliseconds} ms and fullscreen animation; no partition writes')

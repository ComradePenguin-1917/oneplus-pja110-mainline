"""Configure reproducible systemd services in the fully installed RAM Ubuntu."""
import subprocess,tarfile,io
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];out=ROOT/'out/ubuntu-systemd-20261014'
keys=ROOT/'out/usb-ncm-20261013/ssh'
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(keys/'client_key_host'),
 '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
 '-o',f'UserKnownHostsFile={keys/"known_hosts"}','-o','ConnectTimeout=5','root@169.254.42.1']
def run(cmd,data=None):
 p=subprocess.run(ssh+[cmd],input=data,capture_output=True,timeout=60)
 (out/'last-stderr.txt').write_bytes(p.stderr);p.check_returncode();return p.stdout
files={
'etc/hostname':'pja110-ubuntu\n',
'etc/fstab':'# RAM-root bring-up: no persistent partitions mounted.\n',
'etc/systemd/journald.conf.d/pja.conf':'[Journal]\nStorage=volatile\nRuntimeMaxUse=32M\n',
'etc/ssh/sshd_config_pja':'''Port 2222
ListenAddress 169.254.42.1
HostKey /etc/ssh/ssh_host_ed25519_key
PermitRootLogin prohibit-password
PasswordAuthentication no
KbdInteractiveAuthentication no
PubkeyAuthentication yes
UsePAM no
StrictModes yes
AuthorizedKeysFile .ssh/authorized_keys
Subsystem sftp /usr/lib/openssh/sftp-server
''',
'etc/systemd/system/pja-ssh.service':'''[Unit]
Description=PJA110 key-only SSH
After=pja-usb-network.service
Requires=pja-usb-network.service
[Service]
Type=simple
RuntimeDirectory=sshd
ExecStart=/usr/sbin/sshd -D -e -f /etc/ssh/sshd_config_pja
Restart=on-failure
[Install]
WantedBy=multi-user.target
''',
'etc/systemd/system/pja-debug-ssh.service':'''[Unit]
Description=Preserved PJA110 debug SSH identity
After=pja-usb-network.service
Requires=pja-usb-network.service
[Service]
Type=simple
ExecStart=/usr/local/sbin/dropbearmulti dropbear -F -E -s -p 169.254.42.1:22 -r /etc/dropbear/host-ed25519
Restart=on-failure
[Install]
WantedBy=multi-user.target
''',
'etc/systemd/system/pja-usb-network.service':'''[Unit]
Description=PJA110 early USB NCM network
After=systemd-udevd.service
Before=pja-ssh.service pja-debug-ssh.service
ConditionVirtualization=!container
[Service]
Type=oneshot
ExecStart=/usr/local/sbin/pja-usb-network
RemainAfterExit=yes
[Install]
WantedBy=multi-user.target
''',
'etc/systemd/system/pja-weston.service':'''[Unit]
Description=PJA110 Weston diagnostic desktop
After=systemd-udev-settle.service pja-usb-network.service
Wants=systemd-udev-settle.service
ConditionVirtualization=!container
[Service]
Type=simple
RuntimeDirectory=pja-weston
RuntimeDirectoryMode=0700
Environment=XDG_RUNTIME_DIR=/run/pja-weston
Environment=LIBSEAT_BACKEND=seatd
Environment=SEATD_VTBOUND=0
Environment=MESA_LOADER_DRIVER_OVERRIDE=msm
Environment=FD_MESA_DEBUG=noubwc,notile
Environment=WESTON_FORCE_RENDERER=1
ExecStartPre=/bin/sh -c 'echo 1024 > /sys/class/backlight/ae94000.dsi.0/brightness'
ExecStart=/usr/bin/seatd-launch -- /usr/bin/weston --backend=drm-backend.so --config=/etc/weston/weston.ini --socket=wayland-0 --idle-time=0
Restart=on-failure
[Install]
WantedBy=graphical.target
''',
'etc/weston/weston.ini':'''[core]
idle-time=0
xwayland=false
[shell]
background-color=0xff304050
panel-position=top
locking=false
[output]
name=DSI-1
mode=preferred
transform=normal
''',
'etc/systemd/system/pja-ready.service':'''[Unit]
Description=Record successful systemd PID1 boot
After=multi-user.target
[Service]
Type=oneshot
ExecStart=/bin/sh -c 'cat /proc/1/comm > /run/pja-pid1; cat /etc/os-release > /run/pja-os-release'
[Install]
WantedBy=multi-user.target
''',
}
original=(ROOT/'tools/debug_ncm_init.sh').read_text()
start=original.index('G=/sys/kernel/config/usb_gadget/g1')
end=original.index('serial_shell()')
usb=original[start:end]
# Reuse proven gadget function; tolerate existing early-init configuration.
files['usr/local/sbin/pja-usb-network']='''#!/bin/sh
set -eu
log() { echo "[pja-usb] $*"; }
mountpoint -q /sys/kernel/config || mount -t configfs none /sys/kernel/config
'''+usb+'''
if [ -s "$G/UDC" ]; then
 iface=$(cat "$G/functions/ncm.usb0/ifname")
 ip link set lo up
 ip addr replace 169.254.42.1/16 dev "$iface"
 ip addr replace 172.16.42.1/24 dev "$iface"
 ip link set "$iface" up
else
 setup_usb
fi
'''
bio=io.BytesIO()
with tarfile.open(fileobj=bio,mode='w') as tar:
 for name,text in files.items():
  data=text.encode();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o755 if name.startswith('usr/local/sbin') else 0o644
  tar.addfile(info,io.BytesIO(data))
run('cat > /tmp/ubuntu-systemd-config.tar; tar -xf /tmp/ubuntu-systemd-config.tar -C /tmp/ubuntu-systemd',bio.getvalue())
script='''set -e
r=/tmp/ubuntu-systemd
test -e /tmp/ubuntu-systemd-install.done
mkdir -p "$r/root/.ssh" "$r/etc/dropbear" "$r/usr/local/sbin"
cp /root/.ssh/authorized_keys "$r/root/.ssh/authorized_keys"
cp /etc/dropbear/host-ed25519 "$r/etc/dropbear/host-ed25519"
cp /sbin/dropbearmulti "$r/usr/local/sbin/dropbearmulti"
chmod 700 "$r/root/.ssh" "$r/etc/dropbear"
chmod 600 "$r/root/.ssh/authorized_keys" "$r/etc/dropbear/host-ed25519"
chmod 755 "$r/usr/local/sbin/dropbearmulti"
cp -a /lib/modules "$r/lib/"
cp -a /lib/firmware "$r/lib/"
chroot "$r" /usr/sbin/usermod -p '*' root
mkdir -p "$r/run/sshd"
chroot "$r" /usr/sbin/sshd -t -f /etc/ssh/sshd_config_pja
chroot "$r" /usr/bin/systemctl disable ssh.socket ssh.service seatd.service
chroot "$r" /usr/bin/systemctl mask systemd-networkd.service systemd-networkd.socket systemd-networkd-wait-online.service systemd-resolved.service
chroot "$r" /usr/bin/systemctl enable pja-usb-network.service pja-debug-ssh.service pja-ssh.service pja-weston.service pja-ready.service
chroot "$r" /usr/bin/systemctl set-default graphical.target
rm -f "$r/usr/sbin/policy-rc.d"
chroot "$r" /usr/bin/systemd-analyze verify /etc/systemd/system/pja-usb-network.service /etc/systemd/system/pja-debug-ssh.service /etc/systemd/system/pja-ssh.service /etc/systemd/system/pja-weston.service /etc/systemd/system/pja-ready.service
chroot "$r" /usr/bin/dpkg --audit
chroot "$r" /usr/bin/dpkg-query -W -f='${binary:Package}\t${Version}\t${db:Status-Abbrev}\n'
'''
result=run(script);(out/'configured-packages.txt').write_bytes(result)
pub=run('cat /tmp/ubuntu-systemd/etc/ssh/ssh_host_ed25519_key.pub').decode().split()
assert pub[0]=='ssh-ed25519'
(out/'known_hosts').write_text('[169.254.42.1]:2222 '+pub[0]+' '+pub[1]+'\n')
print('Configured standard systemd USB/SSH/Weston services; preserved debug SSH identity; package audit clean')

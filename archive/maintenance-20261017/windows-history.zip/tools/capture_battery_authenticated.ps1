# Wait for a short SSH window, then use ordinary interactive sudo authentication.
# Password goes directly to phone sudo; it is not saved in the host log.
$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path -Parent $PSScriptRoot
$sshBinary = 'C:/Windows/System32/OpenSSH/ssh.exe'
$sshArgs = @('-F', 'none', '-i', "$taskRoot/out/usb-ncm-20261013/ssh/client_key_host",
    '-o', 'BatchMode=yes', '-o', 'IdentitiesOnly=yes', '-o', 'StrictHostKeyChecking=yes',
    '-o', "UserKnownHostsFile=$taskRoot/out/native-install-20261016/first-native-boot/known_hosts",
    '-o', 'ConnectTimeout=2', '-o', 'ConnectionAttempts=1', 'penguin@172.16.42.1')
$collector = Join-Path $PSScriptRoot 'collect_battery_privileged_readonly.sh'
$resultDir = Join-Path $taskRoot ('out/battery-bringup-20261016/authenticated-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $resultDir -Force | Out-Null
$deadline = (Get-Date).AddMinutes(5)
$staged = $false
Write-Host 'Waiting for phone SSH. Keep USB connected. No reboot will be requested.'
while ((Get-Date) -lt $deadline) {
    # A fixed command; the transferred file is an ordinary user-owned script.
    # PowerShell may append a CRLF after the final LF. Remove CR on receipt,
    # including the otherwise executable standalone CR at the end of the script.
    Get-Content -Raw -LiteralPath $collector | & $sshBinary @sshArgs 'umask 077; tr -d "\015" > /home/penguin/battery-readonly.sh' 2>$null
    if ($LASTEXITCODE -eq 0) { $staged = $true; break }
    Start-Sleep -Seconds 2
}
if (-not $staged) { throw 'No SSH window in five minutes; no privileged action performed.' }
Write-Host 'Enter the phone penguin password at the sudo prompt. It is not recorded.'
& $sshBinary '-tt' @sshArgs 'sudo /bin/sh /home/penguin/battery-readonly.sh' |
    Tee-Object -FilePath (Join-Path $resultDir 'capture.txt')
$captureExit = $LASTEXITCODE
Write-Host "Capture saved in $resultDir"
if ($captureExit -ne 0) { throw "Capture ended with SSH exit $captureExit; partial output is saved." }
if (-not (Select-String -LiteralPath (Join-Path $resultDir 'capture.txt') -SimpleMatch 'END_PRIVILEGED_READONLY' -Quiet)) {
    throw 'Capture incomplete; inspect saved partial output.'
}

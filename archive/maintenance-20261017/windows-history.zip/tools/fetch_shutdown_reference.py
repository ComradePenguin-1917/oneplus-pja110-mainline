"""Fetch pinned upstream/Aston shutdown implementations for source comparison."""
import urllib.request,hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
out=ROOT/'out/drm-shutdown-20261014/reference';out.mkdir(parents=True,exist_ok=True)
repos={'upstream-v6.18':('torvalds/linux','v6.18'),
 'aston':('jiganomegsdfdf/aston-mainline','5d5c840896bb49291ae4578acefd5a3ec65524f6')}
records=[]
for label,(repo,ref) in repos.items():
 for name in ('adreno/adreno_device.c','msm_kms.c','msm_atomic.c'):
  url=f'https://raw.githubusercontent.com/{repo}/{ref}/drivers/gpu/drm/msm/{name}'
  target=out/label/name;target.parent.mkdir(parents=True,exist_ok=True)
  data=target.read_bytes() if target.exists() else urllib.request.urlopen(url,timeout=30).read()
  target.write_bytes(data)
  records.append({'path':str(target.relative_to(out)),'url':url,'sha256':hashlib.sha256(data).hexdigest()})
(out/'manifest.json').write_text(json.dumps(records,indent=2)+'\n')
print('Saved pinned upstream and Aston shutdown source references')

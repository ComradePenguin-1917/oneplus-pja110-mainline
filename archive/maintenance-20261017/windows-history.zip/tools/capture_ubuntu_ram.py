"""Capture RAM Ubuntu/Weston evidence without private keys or partition writes."""
import subprocess,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'out/ubuntu-ram-20261014'
KEYS=ROOT/'out/usb-ncm-20261013/ssh'
SSH=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(KEYS/'client_key_host'),
 '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
 '-o',f'UserKnownHostsFile={KEYS/"known_hosts"}','-o','ConnectTimeout=5','root@169.254.42.1']
for name,cmd in {
 'weston-final.log':'cat /tmp/ubuntu-ram/run/weston.log',
 'drm-final.txt':'cat /sys/kernel/debug/dri/0/state; cat /sys/kernel/debug/dri/0/framebuffer',
 'ubuntu-final.txt':'chroot /tmp/ubuntu-ram /bin/sh -c "cat /etc/os-release; uname -a; id; weston --version"; cat /proc/sys/kernel/random/boot_id; cat /proc/mounts; cat /proc/meminfo | head -n 4; cat /sys/module/synaptics_aston/parameters/report_rate_code; pidof weston weston-terminal weston-simple-touch sshd',
 'gpu-final.txt':'chroot /tmp/ubuntu-ram /usr/local/bin/gpu-probe; dmesg',
 'client-logs.txt':'cat /tmp/weston-terminal.log; cat /tmp/weston-simple-touch.log; cat /tmp/weston-fullscreen-bar.log',
}.items():
 p=subprocess.run(SSH+[cmd],capture_output=True,timeout=30);p.check_returncode();(OUT/name).write_bytes(p.stdout+p.stderr)
m=json.loads((OUT/'deployment-result.json').read_text())
m.update(weston_not_yet_started=False,weston_drm_running=True,weston_gl_renderer='FD740',
 mode='1240x2772@60Hz',libinput_touchscreen_detected=True,terminal_pty_fixed=True,
 user_observed_desktop_visible=True,dynamic_fixed_band_corruption_unresolved=True,
 linear_buffers_did_not_fix=True,disable_overlays_did_not_fix=True,
 fullscreen_motion_did_not_fix=True,weston_capture_has_no_noise_band=True,
 graphical_stability_passed=False,phone_partitions_written=False)
(OUT/'deployment-result.json').write_text(json.dumps(m,indent=2)+'\n')
print('PASS: RAM Ubuntu/Weston evidence saved; dynamic display issue explicitly remains unresolved')

#!/usr/bin/env python3
"""Will "prepend a mainline compatible" actually work? Check driver requirements.

Prepending a compatible only makes a driver BIND. For probe() to succeed the node
must also carry the properties that driver reads. The vendor clock controller,
for instance, must have #clock-cells, reg, and any required clocks.

This checks the bring-up-critical nodes against what the mainline drivers
actually require, read from the kernel source.
"""
import os
import re
import struct
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fdt import FDT

WS = r'H:\WorkSpace\PJA110-Mainline'
KT = os.path.join(WS, 'linux')


def dec(v):
    return v.rstrip(b'\0').decode('ascii', 'replace')


v = open(os.path.join(WS, 'backup', 'vendor_boot_b.img'), 'rb').read()
hsize, dtbsize = struct.unpack_from('<2I', v, 28+2048+4+16)
vrsize = struct.unpack_from('<I', v, 24)[0]
dtb_off = (((hsize+4095)//4096)*4096 + vrsize + 4095)//4096*4096
e0 = struct.unpack_from('>I', v, dtb_off+4)[0]
base = FDT(v[dtb_off:dtb_off+e0]).nodes()


def props_of(path):
    """Properties of a node, following the /__symbols__ indirection if needed."""
    return base.get(path, {})


def show(path, label, required=()):
    print('--- %s' % label)
    print('    path: %s' % path)
    p = props_of(path)
    if not p:
        print('    NODE NOT FOUND')
        return
    keys = sorted(p)
    print('    properties (%d): %s' % (len(keys), ', '.join(keys[:14])))
    missing = [r for r in required if r not in p]
    present = [r for r in required if r in p]
    if present:
        for r in present:
            val = p[r]
            shown = dec(val) if len(val) < 40 and any(32 <= c < 127 for c in val) else val.hex()[:40]
            print('      HAVE %-22s %s' % (r, shown))
    if missing:
        print('      MISSING: %s' % ', '.join(missing))
    return missing


print('=' * 78)
print('BRING-UP NODES: do they satisfy the MAINLINE drivers?')
print('=' * 78)

# GCC: mainline gcc-sm8550 needs reg, #clock-cells, #reset-cells, clocks
show('/soc/clock-controller@100000', 'GCC (vendor: qcom,kalama-gcc-v2)',
     required=('#clock-cells', '#reset-cells', 'reg'))

print()
show('/soc/pinctrl@f000000', 'TLMM pinctrl (vendor: qcom,kalama-pinctrl-v2)',
     required=('reg', 'gpio-controller', '#gpio-cells', 'interrupt-controller'))

print()
show('/soc/ufshc@1d84000', 'UFS host (vendor: qcom,ufshc)',
     required=('reg', 'interrupts', 'clocks', 'clock-names', 'phys'))

print()
show('/soc/ufsphy_mem@1d80000', 'UFS PHY (vendor: qcom,ufs-phy-qmp-v4-kalama)',
     required=('reg', 'clocks', 'clock-names', '#phy-cells'))

print()
show('/soc/ssusb@a600000', 'USB dwc3 wrapper (vendor: qcom,dwc-usb3-msm)',
     required=('reg', 'interrupts', 'clocks', 'clock-names'))

print()
show('/soc/ssusb@a600000/dwc3@a600000', 'dwc3 core (vendor: snps,dwc3)',
     required=('reg', 'interrupts', 'snps,dis_u2_susphy_quirk'))

print()
print('=' * 78)
print('WHAT MAINLINE gcc-sm8550 REQUIRES (from source)')
print('=' * 78)
for f, pat in (
    ('drivers/clk/qcom/gcc-sm8550.c', r'of_clk_get|#clock-cells|qcom_cc_probe'),
    ('drivers/pinctrl/qcom/pinctrl-sm8550.c', r'msm_pinctrl_probe|#gpio-cells'),
):
    out = subprocess.run('grep -nE "%s" %s | head -6' % (pat, f),
                         shell=True, capture_output=True, text=True, cwd=KT).stdout
    print('--- %s' % f)
    for line in out.splitlines():
        print('    %s' % line[:110])

print()
print('=' * 78)
print('INTERPRETATION')
print('=' * 78)
print('  NOTE: vendor and mainline nodes often carry the SAME property names but')
print('  with DIFFERENT semantics (clock IDs, phandles, interconnect paths).')
print('  A compatible prepend makes the driver bind; whether probe() succeeds')
print('  depends on those deeper details, which cannot be judged by property')
print('  names alone.')
print()
print('  That is the honest limit of static analysis here. The decisive test is')
print('  a real boot, and we now have a safe way to run one:')
print('     - write vendor_boot_b    (proven safe, rollback = set_active a)')
print('     - boot slot B, read the console/bootloader log')
print('     - reflash stock on failure')

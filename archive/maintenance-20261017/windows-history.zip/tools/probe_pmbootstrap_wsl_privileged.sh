#!/bin/bash
# Run manually with sudo. Uses only a newly created temporary image, never phone disks.
set -euo pipefail
if [ "$(id -u)" != 0 ]; then
 echo 'Run: sudo bash /mnt/h/workspace/PJA110-Mainline/tools/probe_pmbootstrap_wsl_privileged.sh'
 exit 1
fi
for tool in kpartx losetup dmsetup parted mkfs.ext4 mount umount unshare; do
 command -v "$tool" >/dev/null || { echo "Missing dependency: $tool"; exit 1; }
done
task_dir=$(mktemp -d /tmp/pja-pmbootstrap-probe.XXXXXX)
image="$task_dir/probe.img"
mount_dir="$task_dir/mnt"
loop_device=''
mapped=0
mounted=0
cleanup() {
 set +e
 if [ "$mounted" = 1 ]; then umount "$mount_dir" || return; fi
 if [ "$mapped" = 1 ]; then kpartx -d "$loop_device" || return; fi
 if [ -n "$loop_device" ]; then losetup -d "$loop_device" || return; fi
 rm -f -- "$image"
 rmdir -- "$mount_dir" "$task_dir"
}
trap cleanup EXIT
mkdir "$mount_dir"
echo 'Checking kernel device-mapper and mount namespaces'
dmsetup version
unshare --mount --propagation private /bin/true
truncate -s 128M "$image"
loop_device=$(losetup --find --show --sector-size 4096 "$image")
[[ "$loop_device" =~ ^/dev/loop[0-9]+$ ]]
backing=$(losetup --noheadings --output BACK-FILE "$loop_device")
test "$(readlink -f "$backing")" = "$(readlink -f "$image")"
echo "Temporary image attached as $loop_device"
parted -s "$loop_device" mklabel gpt mkpart rootfs ext4 1MiB 100%
mapper_name=$(kpartx -l "$loop_device" | awk 'NR==1 { print $1 }')
[[ "$mapper_name" =~ ^loop[0-9]+p1$ ]]
# Mark cleanup before creation, so partially successful kpartx is cleaned too.
mapped=1
kpartx -asv "$loop_device"
test -b "/dev/mapper/$mapper_name"
mkfs.ext4 -q -F "/dev/mapper/$mapper_name"
mount "/dev/mapper/$mapper_name" "$mount_dir"
mounted=1
printf 'pmbootstrap WSL temporary image test\n' > "$mount_dir/probe.txt"
sync "$mount_dir/probe.txt"
grep -q 'temporary image test' "$mount_dir/probe.txt"
umount "$mount_dir"
mounted=0
kpartx -d "$loop_device"
mapped=0
losetup -d "$loop_device"
loop_device=''
echo 'PASS: mount namespace, 4096-byte loop device, GPT/kpartx mapping, ext4 mount and cleanup'

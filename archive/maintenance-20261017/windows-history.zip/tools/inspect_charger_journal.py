﻿from pathlib import Path
import struct
for p in Path('out/native-install-20261017/charger-a-logs/var/log/journal').rglob('system*.journal'):
 b=p.read_bytes(); pos=struct.unpack_from('<Q',b,88)[0]; print(p.name,'flags',b[8:16].hex(),'header',pos)
 counts={}; examples=[]
 while pos+16<=len(b):
  typ,flags,size=struct.unpack_from('<BB6xQ',b,pos)
  if size<16 or pos+size>len(b):break
  counts[(typ,flags)]=counts.get((typ,flags),0)+1
  if typ==1 and len(examples)<4:examples.append((pos,size,flags,b[pos+64:pos+110].hex()))
  pos+=(size+7)&~7
 print(counts,examples)

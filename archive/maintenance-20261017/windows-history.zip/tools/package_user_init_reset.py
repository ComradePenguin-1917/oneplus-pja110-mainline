"""Replace only /init in both actual baseline archives; preserve kernel code."""
from pathlib import Path
import gzip
import hashlib
import json
import shutil
import struct
import sys
from bootimg import BootImage
from build_init_marker_test import parse_cpio, make_entry, lz4

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT/'out/avb-fixup-control-20261012'
UDC_STATUS = '--udc-status' in sys.argv
SYSFS_STATUS = '--sysfs-status' in sys.argv
UDC_ONLY = '--udc-only' in sys.argv
DWC_BOUND = '--dwc-bound' in sys.argv
QCOM_BOUND = '--qcom-bound' in sys.argv
HSPHY_BOUND = '--hsphy-bound' in sys.argv
DWC_PRESENT = '--dwc-present' in sys.argv
DWC_WAIT = '--dwc-wait' in sys.argv
DWC_DEFERRED = '--dwc-deferred' in sys.argv
DWC_CORE_ERROR = '--dwc-core-error' in sys.argv
DWC_CORE_TIMEOUT = '--dwc-core-timeout' in sys.argv
DWC_TIMEOUT_EARLY = '--dwc-core-timeout-early' in sys.argv
DWC_SOFT_RESET_ERROR = '--dwc-soft-reset-error' in sys.argv
modes = [(UDC_STATUS, 'udc-status'), (SYSFS_STATUS, 'sysfs-status'), (UDC_ONLY, 'udc-only'), (DWC_BOUND, 'dwc-bound'), (QCOM_BOUND, 'qcom-bound'), (HSPHY_BOUND, 'hsphy-bound'), (DWC_PRESENT, 'dwc-present'), (DWC_WAIT, 'dwc-wait'), (DWC_DEFERRED, 'dwc-deferred'), (DWC_CORE_ERROR, 'dwc-core-error'), (DWC_CORE_TIMEOUT, 'dwc-core-timeout'), (DWC_TIMEOUT_EARLY, 'dwc-core-timeout-early'), (DWC_SOFT_RESET_ERROR, 'dwc-soft-reset-error')]
chosen = [name for enabled, name in modes if enabled]
assert len(chosen) <= 1
AFTER_USB = '--after-usb' in sys.argv or bool(chosen)
mode = chosen[0] if chosen else 'after-usb' if AFTER_USB else 'reset'
OUT = ROOT / f'out/user-init-{mode}-probe-20261012'
OUT.mkdir(exist_ok=True)
NATIVE = ROOT/'out/user-init-reset-probe-20261012'
symbols = {p[2]: int(p[0], 16) for line in (ROOT/'out/kernel-entry-probe-20261012/kernel-symbols.txt').read_text().splitlines() if len(p := line.split()) == 3}
numbers = (NATIVE/'syscall-numbers.txt').read_text()
for name, value in [('getpid', 172), ('nanosleep', 101), ('reboot', 142)]:
    assert f'#define __NR_{name} {value}' in numbers
code = (NATIVE/'probe.bin').read_bytes()
assert len(code) == 88
size = 4096 + len(code)
header = struct.pack('<16sHHIQQQIHHHHHH', b'\x7fELF\x02\x01\x01'+b'\0'*9, 2, 183, 1, 0x401000, 64, 0, 0, 64, 56, 1, 0, 0, 0)
ph = struct.pack('<IIQQQQQQ', 1, 5, 0, 0x400000, 0x400000, size, size, 4096)
elf = (header+ph).ljust(4096, b'\0') + code
(OUT/'native-init').write_bytes(elf)
helpers = {}
if AFTER_USB:
    assert struct.unpack_from('<I', code, 20)[0] == 0xd2800469, 'expected mov x9,#35'
    short_code = bytearray(code)
    struct.pack_into('<I', short_code, 20, 0xd28000a9)  # mov x9,#5
    helpers = {'sbin/probe-usb-ok': (header+ph).ljust(4096, b'\0')+short_code,
               'sbin/probe-usb-fail': elf}
    if UDC_STATUS or DWC_WAIT or DWC_DEFERRED or DWC_CORE_ERROR or DWC_CORE_TIMEOUT or DWC_TIMEOUT_EARLY or DWC_SOFT_RESET_ERROR:
        sysfs_fail_code = bytearray(code)
        struct.pack_into('<I', sysfs_fail_code, 20, 0xd2800829)  # mov x9,#65
        helpers['sbin/probe-sysfs-fail'] = (header+ph).ljust(4096, b'\0')+sysfs_fail_code
    for name, data in helpers.items():
        (OUT/name.rsplit('/', 1)[1]).write_bytes(data)

def replace_init(raw):
    entries = parse_cpio(raw)
    count = 0
    result = bytearray()
    assert not any(n.removeprefix('./') in helpers for f, n, d in entries)
    next_inode = max(f[0] for f, n, d in entries) + 1
    replacement = elf
    if AFTER_USB:
        original_script = next(d for f, n, d in entries if n.removeprefix('./') == 'init')
        assert original_script == (ROOT/'initramfs/init').read_bytes()
        assert original_script.startswith(b'#!/bin/sh\n')
        cut = original_script.index(b'if [ -n "$BOUND" ]; then')
        assert b'for f in ecm rndis ncm;' in original_script[:cut]
        replacement = original_script[:cut] + b'if [ -n "$BOUND" ]; then\n    exec /sbin/probe-usb-ok\nelse\n    exec /sbin/probe-usb-fail\nfi\nwhile :; do :; done\n'
        if UDC_STATUS:
            replacement = original_script[:cut] + b'if [ ! -d /sys/class ]; then\n    exec /sbin/probe-sysfs-fail\nfi\nif find_udc >/dev/null; then\n    exec /sbin/probe-usb-ok\nelse\n    exec /sbin/probe-usb-fail\nfi\nwhile :; do :; done\n'
        if SYSFS_STATUS:
            replacement = original_script[:cut] + b'if [ -d /sys/class ]; then\n    exec /sbin/probe-usb-ok\nelse\n    exec /sbin/probe-usb-fail\nfi\nwhile :; do :; done\n'
        if UDC_ONLY:
            replacement = original_script[:cut] + b'if find_udc >/dev/null; then\n    exec /sbin/probe-usb-ok\nelse\n    exec /sbin/probe-usb-fail\nfi\nwhile :; do :; done\n'
        if DWC_BOUND or QCOM_BOUND or HSPHY_BOUND:
            address = b'88e3000' if HSPHY_BOUND else b'a6f8800' if QCOM_BOUND else b'a600000'
            replacement = original_script[:cut] + b'for device in /sys/bus/platform/devices/*' + address + b'*; do\n    if [ -L "$device/driver" ]; then\n        exec /sbin/probe-usb-ok\n    fi\ndone\nexec /sbin/probe-usb-fail\nwhile :; do :; done\n'
        if DWC_PRESENT:
            replacement = original_script[:cut] + b'for device in /sys/bus/platform/devices/*a600000*; do\n    if [ -d "$device" ]; then\n        exec /sbin/probe-usb-ok\n    fi\ndone\nexec /sbin/probe-usb-fail\nwhile :; do :; done\n'
        if DWC_WAIT:
            replacement = original_script[:cut] + b'for device in /sys/bus/platform/devices/*a600000*; do\n    if [ -r "$device/waiting_for_supplier" ] && IFS= read -r waiting < "$device/waiting_for_supplier"; then\n        case "$waiting" in\n            1) exec /sbin/probe-usb-ok ;;\n            0) exec /sbin/probe-usb-fail ;;\n        esac\n    fi\ndone\nexec /sbin/probe-sysfs-fail\nwhile :; do :; done\n'
        if DWC_DEFERRED:
            replacement = original_script[:cut] + b'mkdir -p /sys/kernel/debug\nmount -t debugfs none /sys/kernel/debug 2>/dev/null\nif cat /sys/kernel/debug/devices_deferred > /tmp/probe-deferred 2>/dev/null; then\n    while IFS= read -r deferred_line; do\n        case "$deferred_line" in\n            *a600000*) exec /sbin/probe-usb-ok ;;\n        esac\n    done < /tmp/probe-deferred\n    exec /sbin/probe-usb-fail\nfi\nexec /sbin/probe-sysfs-fail\nwhile :; do :; done\n'
        if DWC_CORE_ERROR or DWC_SOFT_RESET_ERROR:
            replacement = original_script[:cut] + b'if dmesg > /tmp/probe-kernel-log 2>/dev/null; then\n    while IFS= read -r kernel_line; do\n        case "$kernel_line" in\n            *a600000*"failed to initialize core"*) exec /sbin/probe-usb-ok ;;\n        esac\n    done < /tmp/probe-kernel-log\n    exec /sbin/probe-usb-fail\nfi\nexec /sbin/probe-sysfs-fail\nwhile :; do :; done\n'
            if DWC_SOFT_RESET_ERROR:
                before_loop = original_script.index(b'for f in ecm rndis ncm;')
                snapshot = b'probe_log_readable=0\nif dmesg > /tmp/probe-kernel-log 2>/dev/null; then\n    probe_log_readable=1\nfi\n'
                decision = replacement[cut:].replace(b'if dmesg > /tmp/probe-kernel-log 2>/dev/null; then', b'if [ "$probe_log_readable" = 1 ]; then', 1)
                decision = decision.replace(b'failed to initialize core', b'DWC3 controller soft reset failed.')
                replacement = original_script[:before_loop] + snapshot + original_script[before_loop:cut] + decision
        if DWC_CORE_TIMEOUT or DWC_TIMEOUT_EARLY:
            replacement = original_script[:cut] + b'other_core_error=0\nif dmesg > /tmp/probe-kernel-log 2>/dev/null; then\n    while IFS= read -r kernel_line; do\n        case "$kernel_line" in\n            *a600000*"failed to initialize core"*)\n                case "$kernel_line" in\n                    *"error -ETIMEDOUT:"*|*"error -110:"*) exec /sbin/probe-usb-ok ;;\n                    *"error "*) other_core_error=1 ;;\n                esac ;;\n        esac\n    done < /tmp/probe-kernel-log\n    if [ "$other_core_error" = 1 ]; then\n        exec /sbin/probe-usb-fail\n    fi\nfi\nexec /sbin/probe-sysfs-fail\nwhile :; do :; done\n'
            if DWC_TIMEOUT_EARLY:
                before_loop = original_script.index(b'for f in ecm rndis ncm;')
                snapshot = b'probe_log_readable=0\nif dmesg > /tmp/probe-kernel-log 2>/dev/null; then\n    probe_log_readable=1\nfi\n'
                decision = replacement[cut:].replace(b'if dmesg > /tmp/probe-kernel-log 2>/dev/null; then', b'if [ "$probe_log_readable" = 1 ]; then', 1)
                replacement = original_script[:before_loop] + snapshot + original_script[before_loop:cut] + decision
                assert replacement[:before_loop] == original_script[:before_loop]
                assert replacement[before_loop+len(snapshot):before_loop+len(snapshot)+cut-before_loop] == original_script[before_loop:cut]
        (OUT/'init-probe.sh').write_bytes(replacement)
    for fields, name, data in entries:
        if name == 'TRAILER!!!':
            for helper_name, helper_data in helpers.items():
                helper_fields = [next_inode, 0o100755, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0]
                result += make_entry(helper_fields, helper_name, helper_data)
                next_inode += 1
        if name.removeprefix('./') == 'init':
            count += 1
            fields = list(fields)
            fields[1] = 0o100755
            data = replacement
        result += make_entry(fields, name, data)
    assert count == 1
    checked = parse_cpio(bytes(result))
    assert len(checked) == len(entries) + len(helpers)
    checked_map = {n: (f, d) for f, n, d in checked}
    for oldf, oldn, oldd in entries:
        f, d = checked_map[oldn]
        n = oldn
        assert n == oldn
        assert d == (replacement if n.removeprefix('./') == 'init' else oldd)
        expected_fields = list(oldf)
        if n.removeprefix('./') == 'init':
            expected_fields[1] = 0o100755
            expected_fields[6] = len(replacement)
        assert f == expected_fields
    for n, d in helpers.items():
        assert checked_map[n][1] == d and checked_map[n][0][1] == 0o100755
    return bytes(result)

boot = BootImage.parse(str(BASE/'boot-xigua-r1.img'))
original = boot.kernel
assert hashlib.sha256(original).hexdigest() == 'd8ade08069b8440b349f4b4aeb430dd6e9057eca08c94a8268e3708a83e53425'
offset = symbols['__initramfs_start'] - symbols['_text']
size_offset = symbols['__initramfs_size'] - symbols['_text']
old_size = struct.unpack_from('<Q', original, size_offset)[0]
rebuilt = replace_init(gzip.decompress(original[offset:offset+old_size]))
compressed = gzip.compress(rebuilt, compresslevel=9, mtime=0)
assert len(compressed) <= old_size
image = bytearray(original)
image[offset:offset+old_size] = compressed.ljust(old_size, b'\0')
struct.pack_into('<Q', image, size_offset, len(compressed))
assert image[:64] == original[:64] and len(image) == len(original)
assert image[:offset] == original[:offset]
assert image[offset+old_size:size_offset] == original[offset+old_size:size_offset]
assert image[size_offset+8:] == original[size_offset+8:]
assert gzip.decompress(image[offset:offset+len(compressed)]) == rebuilt
(OUT/'Image-probe').write_bytes(image)
boot.kernel = bytes(image)
(OUT/'boot-xigua-r1.img').write_bytes(boot.pack(cmdline=boot.cmdline.decode()))
assert BootImage.parse(str(OUT/'boot-xigua-r1.img')).kernel == image

old_init = (BASE/'init_boot_b-xigua-r1.img').read_bytes()
old_ramdisk_size = struct.unpack_from('<I', old_init, 12)[0]
external_cpio = replace_init(lz4(['-d', '-l', '-c'], old_init[4096:4096+old_ramdisk_size]))
external = lz4(['-z', '-l', '-12', '-c'], external_cpio)
end = 4096 + ((old_ramdisk_size+4095)//4096)*4096
assert len(external) <= end-4096
assert lz4(['-d', '-l', '-c'], external) == external_cpio
new_init = bytearray(old_init)
struct.pack_into('<I', new_init, 12, len(external))
new_init[4096:end] = external.ljust(end-4096, b'\0')
assert new_init[end:] == old_init[end:] and len(new_init) == len(old_init)
(OUT/'init_boot_b-xigua-r1.img').write_bytes(new_init)
known = json.loads((BASE/'manifest.json').read_text())
for name in ('vendor_boot_b-xigua-r1.img', 'dtbo_b-avb-noop.img'):
    assert hashlib.sha256((BASE/name).read_bytes()).hexdigest() == known['files'][name]['sha256']
    shutil.copyfile(BASE/name, OUT/name)
manifest = {'experiment': 'native PID1 at EL0: getpid, nanosleep 35 seconds, reboot syscall',
    'kernel_instruction_bytes_unchanged': True, 'only_init_file_replaced_in_both_archives': True,
    'embedded_archive_offset': offset, 'embedded_size_field_offset': size_offset,
    'embedded_compressed_bytes_before': old_size, 'embedded_compressed_bytes_after': len(compressed),
    'phone_execution_confirmed': False, 'native_init_sha256': hashlib.sha256(elf).hexdigest(),
    'files': {n: {'bytes': (OUT/n).stat().st_size, 'sha256': hashlib.sha256((OUT/n).read_bytes()).hexdigest()}
        for n in ('boot-xigua-r1.img', 'vendor_boot_b-xigua-r1.img', 'init_boot_b-xigua-r1.img', 'dtbo_b-avb-noop.img')}}
if AFTER_USB:
    manifest['experiment'] = 'original shell init through USB attempts, then PID1 helper reset: BOUND 5 seconds, unbound 35 seconds'
    manifest['script_prefix_through_usb_attempts_preserved'] = True
    manifest['added_helper_paths'] = list(helpers)
    manifest['result_delay_seconds'] = {'BOUND_nonempty': 5, 'BOUND_empty': 35}
if UDC_STATUS:
    manifest['experiment'] = 'original shell init after USB attempts: UDC present reset after 5 seconds, absent after 35 seconds'
    manifest['result_delay_seconds'] = {'UDC_present': 5, 'UDC_absent_with_sysfs_class_present': 35, 'sysfs_class_missing': 65}
if SYSFS_STATUS:
    manifest['experiment'] = 'original shell init after USB attempts: sysfs class directory visible 5 seconds, missing 35 seconds'
    manifest['result_delay_seconds'] = {'sysfs_class_visible': 5, 'sysfs_class_missing': 35}
if UDC_ONLY:
    manifest['experiment'] = 'original shell init after USB attempts: find_udc success 5 seconds, failure 35 seconds'
    manifest['result_delay_seconds'] = {'find_udc_success': 5, 'find_udc_failure': 35}
if DWC_BOUND:
    manifest['experiment'] = 'DWC3 platform device driver symlink check after original USB loop'
    manifest['result_delay_seconds'] = {'dwc3_driver_symlink_found': 5, 'dwc3_driver_symlink_not_found': 35}
if QCOM_BOUND:
    manifest['experiment'] = 'Qualcomm USB parent platform driver symlink check after original USB loop'
    manifest['result_delay_seconds'] = {'qcom_usb_driver_symlink_found': 5, 'qcom_usb_driver_symlink_not_found': 35}
if HSPHY_BOUND:
    from fdt import FDT
    vendor = (BASE/'vendor_boot_b-xigua-r1.img').read_bytes()
    align = lambda n: (n+4095)//4096*4096
    dt_offset = align(align(struct.unpack_from('<I', vendor, 2096)[0])+struct.unpack_from('<I', vendor, 24)[0])
    nodes = FDT(vendor[dt_offset:]).nodes()
    phy_node = nodes['/soc@0/phy@88e3000']
    assert nodes['/soc@0/usb@a6f8800/usb@a600000']['phys'] == phy_node['phandle']
    assert phy_node['compatible'] == b'qcom,sm8550-snps-eusb2-phy\0'
    manifest['experiment'] = 'DWC3 actual USB2 PHY platform driver symlink check after original USB loop'
    manifest['phy_target_verified_against_actual_vendor_boot_dtb'] = True
    manifest['result_delay_seconds'] = {'usb2_phy_driver_symlink_found': 5, 'usb2_phy_driver_symlink_not_found': 35}
if DWC_PRESENT:
    manifest['experiment'] = 'DWC3 platform device directory presence check after original USB loop'
    manifest['result_delay_seconds'] = {'dwc3_device_directory_found': 5, 'dwc3_device_directory_not_found': 35}
if DWC_WAIT:
    manifest['experiment'] = 'DWC3 waiting_for_supplier attribute value after original USB loop'
    manifest['result_delay_seconds'] = {'waiting_for_supplier_1': 5, 'waiting_for_supplier_0': 35, 'attribute_unavailable_or_unexpected': 65}
if DWC_DEFERRED:
    manifest['experiment'] = 'DWC3 address in readable debugfs devices_deferred snapshot after original USB loop'
    manifest['result_delay_seconds'] = {'dwc3_in_deferred_snapshot': 5, 'readable_snapshot_without_dwc3': 35, 'snapshot_read_failed': 65}
if DWC_CORE_ERROR:
    manifest['experiment'] = 'DWC3 failed to initialize core message in readable mainline dmesg snapshot'
    manifest['result_delay_seconds'] = {'core_init_error_message_found': 5, 'readable_dmesg_without_target_message': 35, 'dmesg_read_failed': 65}
if DWC_SOFT_RESET_ERROR:
    manifest['experiment'] = 'DWC3 controller soft reset failed message in dmesg snapshot before USB loop'
    manifest['snapshot_taken_before_original_usb_loop'] = True
    manifest['result_delay_seconds'] = {'controller_soft_reset_error_found': 5, 'readable_snapshot_without_target_message': 35, 'dmesg_read_failed': 65}
if DWC_CORE_TIMEOUT or DWC_TIMEOUT_EARLY:
    manifest['experiment'] = 'DWC3 core init error log ETIMEDOUT versus another error'
    manifest['result_delay_seconds'] = {'target_error_ETIMEDOUT': 5, 'target_message_with_another_error': 35, 'target_message_unavailable_or_read_failed': 65}
    if DWC_TIMEOUT_EARLY:
        manifest['experiment'] += '; dmesg snapshot taken before original USB loop'
        manifest['snapshot_taken_before_original_usb_loop'] = True
(OUT/'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
print(json.dumps(manifest, indent=2))

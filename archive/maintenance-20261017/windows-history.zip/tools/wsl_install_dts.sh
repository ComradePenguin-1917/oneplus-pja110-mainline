#!/bin/bash
# Install our board DTS into the kernel tree and register it in the Makefile.
set -euo pipefail

ROOT="$HOME/workspace/PJA110-Mainline"
TREE="$ROOT/linux"
QDTS="$TREE/arch/arm64/boot/dts/qcom"
SRC_WIN="/mnt/h/WorkSpace/PJA110-Mainline/dts"

echo "=== copying DTS files from the Windows working tree ==="
for f in sm8550-oneplus-xigua.dts sm8550-oneplus-xigua-16G.dts; do
    if [ ! -f "$SRC_WIN/$f" ]; then
        echo "  MISSING $SRC_WIN/$f"; exit 1
    fi
    cp "$SRC_WIN/$f" "$QDTS/$f"
    echo "  copied $f ($(wc -l < "$QDTS/$f") lines)"
done

echo
echo "=== registering in $QDTS/Makefile ==="
MK="$QDTS/Makefile"
if grep -q 'sm8550-oneplus-xigua' "$MK"; then
    echo "  already registered"
else
    # append next to the other sm8550 boards, keeping the file's tab style
    if grep -q 'sm8550-samsung-q5q.dtb' "$MK"; then
        sed -i 's|^\(dtb-\$(CONFIG_ARCH_QCOM)\s*+= sm8550-qrd\.dtb\)|\1\ndtb-$(CONFIG_ARCH_QCOM)\t+= sm8550-oneplus-xigua.dtb\ndtb-$(CONFIG_ARCH_QCOM)\t+= sm8550-oneplus-xigua-16G.dtb|' "$MK"
    else
        printf 'dtb-$(CONFIG_ARCH_QCOM)\t+= sm8550-oneplus-xigua.dtb\ndtb-$(CONFIG_ARCH_QCOM)\t+= sm8550-oneplus-xigua-16G.dtb\n' >> "$MK"
    fi
    echo "  added 2 dtb lines"
fi

echo
echo "=== verify ==="
grep -n 'sm8550-oneplus-xigua' "$MK"
echo
echo "=== does the DTB target resolve? (dry run) ==="
echo "  files in place:"
ls -l "$QDTS"/sm8550-oneplus-xigua*.dts

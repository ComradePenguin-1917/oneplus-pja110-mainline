#!/bin/sh
trap '' HUP
sleep 3
cd /sys/kernel/config/usb_gadget/g1 || exit 1
controller=$(cat UDC)
[ -n "$controller" ] || exit 1
printf '\n' > UDC || exit 1
sleep 1
echo "$controller" > UDC || exit 1
echo PJA_LOOPBACK_REBOUND

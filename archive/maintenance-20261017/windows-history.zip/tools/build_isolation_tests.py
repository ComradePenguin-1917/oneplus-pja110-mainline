#!/usr/bin/env python3
"""ISOLATE the failure: is it OUR KERNEL, or OUR DEVICE TREE?

Everything tested so far changed both at once, so neither is exonerated:

  attempt A (earlier): our kernel + VENDOR tree + dtbo present  -> failed
  attempt B (latest):  our kernel + OUR tree    + dtbo erased   -> failed

The stock kernel boots on this device (proven: slot B with stock images reaches
Android). So the next step is to change ONE variable at a time, using the stock
kernel as the known-good reference:

  test 1 (control)  : STOCK kernel + STOCK tree          -> expect: boots (done)
  test 2            : STOCK kernel + OUR tree as entry0  -> isolates the TREE
  test 3            : OUR kernel   + STOCK tree          -> isolates the KERNEL

If test 2 boots, our device tree is fine and the kernel is the blocker.
If test 2 fails, our tree breaks the stock kernel, so the tree is implicated.
Test 3 then separates "our kernel cannot boot on this SoC at all" from anything
tree-related.

Why the stock kernel is the right reference: it is a known-good arm64 kernel from
the same vendor, so if it fails with our tree, the fault is provably in the tree,
not in "mainline kernels in general".

This script builds test 2 and test 3.

IMPORTANT for test 3: the stock kernel needs a device tree, and with dtbo erased
its only source is vendor_boot entry0. So test 3 uses the STOCK vendor_boot tree
AND the stock cmdline, i.e. vendor_boot_b stays stock.
"""
import hashlib
import os
import struct
import subprocess
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
WSL_WS = '/mnt/h/WorkSpace/PJA110-Mainline'
PAGE = 4096


def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''):
            h.update(c)
    return h.hexdigest()


def make_vendor_boot(src, dtb_path, out):
    """Put `dtb_path` into entry0 of `src`, keeping everything else identical."""
    v = bytearray(open(src, 'rb').read())
    hsize, dtbsize = struct.unpack_from('<2I', v, 28 + 2048 + 4 + 16)
    vrsize = struct.unpack_from('<I', v, 24)[0]
    dtb_off = (((hsize + PAGE - 1)//PAGE)*PAGE + vrsize + PAGE - 1)//PAGE*PAGE
    slot = struct.unpack_from('>I', v, dtb_off + 4)[0]
    dtb = open(dtb_path, 'rb').read()
    if len(dtb) > slot:
        raise SystemExit('dtb %d > slot %d' % (len(dtb), slot))
    padded = bytearray(dtb) + b'\0' * (slot - len(dtb))
    struct.pack_into('>I', padded, 4, slot)
    orig = bytes(v)
    v[dtb_off:dtb_off + slot] = bytes(padded)
    w = bytes(v)
    assert w[:dtb_off] == orig[:dtb_off]
    assert w[dtb_off + slot:] == orig[dtb_off + slot:]
    open(out, 'wb').write(w)
    return dtb_off, slot, len(dtb)


print('=' * 78)
print('TEST 2: STOCK kernel + OUR device tree  (isolates the TREE)')
print('=' * 78)
src_vb = os.path.join(WS, 'backup', 'vendor_boot_b.img')
our_dtb = os.path.join(WS, 'dts', 'sm8550-oneplus-xigua-16G.dtb')
t2_vb = os.path.join(WS, 'out', 't2-vendor_boot_b-stocktree-ourdtb.img')
off, slot, dlen = make_vendor_boot(src_vb, our_dtb, t2_vb)
print('  vendor_boot: entry0 @0x%x slot=%d, our dtb %d bytes' % (off, slot, dlen))
print('  sha256: %s' % sha(t2_vb)[:32])

# stock kernel payload from the OTA image
stock_k = os.path.join(WS, 'out', 'stock-kernel.bin')
if not os.path.exists(stock_k):
    b = open(os.path.join(WS, 'boot-A14.img'), 'rb').read()
    ks = struct.unpack_from('<I', b, 8)[0]
    open(stock_k, 'wb').write(b[4096:4096 + ks])
print('  stock kernel: %d bytes' % os.path.getsize(stock_k))

t2_boot = os.path.join(WS, 'out', 't2-boot_b-stock.img')
cmd = ('cd %s && python3 tools/bootimg.py pack --kernel out/stock-kernel.bin '
       '--stock boot-A14.img -o out/t2-boot_b-stock.img' % WSL_WS)
r = subprocess.run(['wsl.exe', '-d', 'Ubuntu-22.04', '--', 'bash', '-lc', cmd],
                   capture_output=True)
for line in (r.stdout or b'').decode('utf-8', 'replace').splitlines():
    if 'wrote' in line or 'PASS' in line:
        print('  %s' % line.strip()[:90])
print('  sha256: %s' % sha(t2_boot)[:32])

print()
print('=' * 78)
print('TEST 3: OUR kernel + STOCK tree  (isolates the KERNEL)')
print('=' * 78)
print('  vendor_boot_b stays STOCK, so the kernel gets the vendor tree, and with')
print('  the dtbo erased there are no overlays.')
t3_boot = os.path.join(WS, 'out', 'boot_b-poweroff.img')
print('  boot_b: %s' % os.path.basename(t3_boot))
print('  sha256: %s' % sha(t3_boot)[:32])

print()
print('=' * 78)
print('MATRIX')
print('=' * 78)
print('  %-10s %-22s %-22s %s' % ('test', 'kernel', 'tree (vendor_boot entry0)', 'dtbo'))
print('  %-10s %-22s %-22s %s' % ('control', 'STOCK', 'STOCK', 'stock  -> boots (proven)'))
print('  %-10s %-22s %-22s %s' % ('test 2', 'STOCK', 'OURS', 'erased'))
print('  %-10s %-22s %-22s %s' % ('test 3', 'OURS', 'STOCK', 'erased'))
print('  %-10s %-22s %-22s %s' % ('earlier', 'OURS', 'OURS', 'erased  -> failed'))
print()
print('  interpretation:')
print('    test 2 boots -> our TREE is fine')
print('    test 2 fails -> our TREE breaks even the stock kernel')
print('    test 3 boots -> only the TREE was the problem')
print('    test 3 fails -> OUR KERNEL cannot boot on this SoC, independent of tree')
print()
print('  recommended order: test 2 first (cheapest to interpret, stock kernel is')
print('  known-good, and any failure is unambiguous evidence about the tree).')

"""Extract the proven ACM initramfs for a minimal diagnostic kernel rebuild."""
from pathlib import Path
import gzip
import struct
from bootimg import BootImage

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'out/user-init-usb-serial-diag-20261013'
OUT.mkdir(exist_ok=True)
symbols = {p[2]: int(p[0], 16) for line in (ROOT/'out/kernel-entry-probe-20261012/kernel-symbols.txt').read_text().splitlines() if len(p:=line.split()) == 3}
image = BootImage.parse(str(ROOT/'out/user-init-usb-serial-shell-20261013/boot-xigua-r1.img')).kernel
offset = symbols['__initramfs_start'] - symbols['_text']
size_offset = symbols['__initramfs_size'] - symbols['_text']
size = struct.unpack_from('<Q', image, size_offset)[0]
archive = image[offset:offset+size]
assert b'PJA110-ACM' in gzip.decompress(archive)
(OUT/'initramfs.cpio.gz').write_bytes(archive)
print('PASS: extracted the actual proven ACM initramfs; no phone writes')

"""One controlled A activation from B after ADC diagnosis."""
from pathlib import Path
import subprocess
from prepare_native_install import SSH
cmd = '''set -eu
test -z "$(losetup -a)"
test "$(sha256sum /dev/disk/by-partlabel/vendor_boot_a | cut -d ' ' -f 1)" = 9cbff73044d6bed2d424298b3f1894b786715e185e099121ab55f645934c278d
/tmp/qbootctl -n 1
/tmp/qbootctl -s 0
sync
/tmp/qbootctl -a
/tmp/qbootctl -b 0
reboot -f
'''
p = subprocess.run(SSH + [cmd], capture_output=True, timeout=25)
Path('out/native-install-20261017/adc-gen3/activate-a.txt').write_bytes(p.stdout + p.stderr)
print(p.stdout.decode(errors='replace'))
print(p.stderr.decode(errors='replace'))
print('SSH exit', p.returncode, '; verify recovery separately')

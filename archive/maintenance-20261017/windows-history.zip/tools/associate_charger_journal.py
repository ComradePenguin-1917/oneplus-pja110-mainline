﻿from pathlib import Path
import struct,json
rows=[]
for p in Path('out/native-install-20261017/charger-a-logs/var/log/journal').rglob('system*.journal'):
 b=p.read_bytes();pos=struct.unpack_from('<Q',b,88)[0];data={};entries=[]
 while pos+16<=len(b):
  typ,flags,size=struct.unpack_from('<BB6xQ',b,pos)
  if size<16 or pos+size>len(b):break
  if typ==1 and flags==0:data[pos]=b[pos+72:pos+size].decode(errors='replace')
  if typ==3:
   seq,real,mono=struct.unpack_from('<QQQ',b,pos+16);boot=b[pos+40:pos+56].hex()
   offsets=[struct.unpack_from('<I',b,x)[0] for x in range(pos+64,pos+size,4)]
   entries.append((seq,real,mono,boot,offsets))
  pos+=(size+7)&~7
 for seq,real,mono,boot,offsets in entries:
  fields=[data.get(o,'') for o in offsets];msg=next((v[8:] for v in fields if v.startswith('MESSAGE=')),None)
  if msg:rows.append(dict(boot=boot,seconds=mono/1e6,message=msg))
rows.sort(key=lambda x:(x['boot'],x['seconds']))
Path('out/native-install-20261017/charger-journal-entries.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
for boot in sorted(set(r['boot'] for r in rows)):
 subset=[r for r in rows if r['boot']==boot];print('BOOT',boot,'range',subset[0]['seconds'],subset[-1]['seconds'])
 for r in subset:
  if any(k in r['message'].lower() for k in ['adsp','pmic_glink','pmic-glink','charger','poweroff requested','powering down','critical','battmgr','failed to initialize pdr']):print(round(r['seconds'],3),r['message'])

"""Paired ABL control: change only vendor_boot back to the OEM base tree."""
from pathlib import Path
import json
import subprocess
import time
import run_r1_flash_test as run

ROOT = Path(__file__).resolve().parents[1]
run.OUT = ROOT / 'out/stock-base-overlay-experiment-20261012'
run.OUT.mkdir(exist_ok=True)
assert not (run.OUT / 'flashed-at.txt').exists(), 'Preserve prior evidence'
previous = ROOT / 'out/avb-empty-experiment-20261012'
manifest = json.loads((ROOT / 'out/avb-empty-control-20261012/manifest.json').read_text())
status, current = run.state('paired-preflight')
assert status == ['_a', '1'], status
before = json.loads((previous / 'preflight.json').read_text())['partition_hashes_before']
assert all(current[p] == before[p] for p in current if p.endswith('_a'))
for part, filename in [('vendor_boot_b', 'vendor_boot_b-xigua-r1.img'),
                       ('init_boot_b', 'init_boot_b-xigua-r1.img'),
                       ('dtbo_b', 'dtbo_b-avb-noop.img')]:
    assert current[part] == manifest['files'][filename]['sha256'], part
n = manifest['files']['boot-xigua-r1.img']['bytes']
assert run.adb(f'head -c {n} /dev/block/by-name/boot_b | sha256sum').decode().split()[0] == manifest['files']['boot-xigua-r1.img']['sha256']
source = ROOT / 'backup/vendor_boot_b.img'
assert run.sha(source) == before['vendor_boot_b']
(run.OUT / 'preflight.json').write_text(json.dumps({'partition_hashes_before': current,
    'single_changed_partition': 'vendor_boot_b', 'control_sha256': run.sha(source),
    'restore_reference': str(previous / 'preflight.json')}, indent=2), encoding='utf-8')
subprocess.run([run.ADB, '-s', run.SERIAL, 'reboot', 'bootloader'], check=True, timeout=30)
run.fb([['flash', 'vendor_boot_b', source], ['set_active', 'b'], ['reboot']], 'flash')
(run.OUT / 'flashed-at.txt').write_text(time.strftime('%Y-%m-%dT%H:%M:%S%z'))

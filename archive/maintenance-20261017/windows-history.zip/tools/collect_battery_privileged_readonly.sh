#!/bin/sh
# Root visibility only. No mounts, register dumps, bus probes or service changes.
set -u
test "$(id -u)" = 0 || exit 1
echo BEGIN_PRIVILEGED_READONLY
cat /proc/sys/kernel/random/boot_id /proc/uptime
uname -r
echo POWER_SUPPLIES
for p in /sys/class/power_supply/*; do
    test ! -r "$p/uevent" || cat "$p/uevent"
done
echo DEBUG_INTERFACE_NAMES_ONLY
for p in /sys/kernel/debug/qcom_smem /sys/kernel/debug/smem /sys/kernel/debug/regmap; do
    if test -d "$p"; then
        ls -ld "$p"
        # Enumerate interface names, never read the hardware register dump.
        find "$p" -maxdepth 2 -type f -print
    else
        echo "ABSENT $p"
    fi
done
echo PMIC_CHILDREN
for p in /sys/bus/spmi/devices/*; do
    test -d "$p" || continue
    echo "SPMI $p"
    if test -L "$p/driver"; then readlink -f "$p/driver"; else echo NO_BOUND_DRIVER; fi
    resolved=$(readlink -f "$p")
    find "$resolved" -maxdepth 2 -name uevent -type f | while IFS= read -r f; do
        echo "DEVICE $f"
        cat "$f"
    done
done
echo CURRENT_DEFERRED_PROBES
test ! -r /sys/kernel/debug/devices_deferred || cat /sys/kernel/debug/devices_deferred
echo CURRENT_GLINK
ls -l /sys/bus/platform/devices/pmic-glink/driver /sys/bus/auxiliary/devices/pmic_glink* /sys/bus/rpmsg/devices 2>&1
echo KERNEL_SELECTED_LOG
timeout 5 journalctl -b -k --no-pager -n 800 2>&1 |
    grep -Ei 'pmic|bq27|bq28|charger|remoteproc|adsp|smem|spmi|glink|battery'
echo POWER_SELECTED_LOG
timeout 4 journalctl -b --no-pager -n 60 -u upower.service -u systemd-logind.service 2>&1
echo END_PRIVILEGED_READONLY

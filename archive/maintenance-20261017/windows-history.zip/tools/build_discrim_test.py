#!/usr/bin/env python3
"""The clean, mutually-exclusive discrimination test.

Question: with the dtbo erased, does ABL use a DTB appended to the kernel Image,
or does it still build the tree from vendor_boot in flash?

Design that CANNOT be misread
-----------------------------
Both candidate trees are the VENDOR's own base tree, so the phone boots healthily
either way and we can always read the answer. Each carries a DIFFERENT inert
top-level node:

    vendor_boot_b  (in flash, my earlier proven injection)
        -> has /xigua-vbtest
    appended DTB   (in the boot image we are about to fastboot boot)
        -> has /xigua-append-test

Active slot = b, and dtbo_b is ERASED, so no overlay runs and nothing can rewrite
the tree afterwards.

    outcome                          meaning
    -----------------------------    ----------------------------------------
    /xigua-append-test present   ->  the appended DTB WON  (hypothesis B)
    /xigua-vbtest present        ->  vendor_boot won        (hypothesis A)

Both nodes are inert: no compatible, no reg, no properties, so of_platform never
creates a device for them and they cannot affect behaviour.
"""
import os
import struct
import subprocess
import sys

sys.path.insert(0, os.path.join(r'H:\WorkSpace\PJA110-Mainline', 'tools'))
from fdt import FDT
from fdtwrite import parse, serialise, Node, walk

WS = r'H:\WorkSpace\PJA110-Mainline'
WSL_WS = '/mnt/h/WorkSpace/PJA110-Mainline'
APPEND_NODE = 'xigua-append-test'
VB_NODE = 'xigua-vbtest'

# ---- 1) extract the pristine vendor base tree (entry0 of vendor_boot_b) ----
v = open(os.path.join(WS, 'backup', 'vendor_boot_b.img'), 'rb').read()
hsize, dtbsize = struct.unpack_from('<2I', v, 28 + 2048 + 4 + 16)
vrsize = struct.unpack_from('<I', v, 24)[0]
dtb_off = (((hsize + 4095) // 4096) * 4096 + vrsize + 4095) // 4096 * 4096
e0 = struct.unpack_from('>I', v, dtb_off + 4)[0]
base_blob = v[dtb_off:dtb_off + e0]

print('=== candidate trees ===')
print('  vendor_boot_b entry0 (flash) : %d bytes' % len(base_blob))

root, rsvmap = parse(base_blob)
before = set(p for p, _n in walk(root))
print('  nodes                        : %d' % len(before))
print('  already has /%s      : %s' % (VB_NODE, '/' + VB_NODE in before))

# ---- 2) add the competing marker to the appended copy ----
if '/' + APPEND_NODE not in before:
    root.children.append(Node(APPEND_NODE))
marked = serialise(root, rsvmap)

after = set(p for p, _n in walk(parse(marked)[0]))
print()
print('=== appended DTB ===')
print('  size          : %d' % len(marked))
print('  nodes         : %d -> %d' % (len(before), len(after)))
print('  /%s : %s' % (APPEND_NODE, '/' + APPEND_NODE in after))
print('  extra         : %s' % sorted(after - before))

f = FDT(marked)
syms = set(f.nodes().get('/__symbols__', {}))
print('  __symbols__   : %d labels' % len(syms))
print('  qcom_tzlog    : %s   arch_timer: %s'
      % ('qcom_tzlog' in syms, 'arch_timer' in syms))

p_dtb = os.path.join(WS, 'out', 'vendorbase-marked.dtb')
open(p_dtb, 'wb').write(marked)

# ---- 3) pack: STOCK kernel + marked vendor base tree ----
stock = os.path.join(WS, 'out', 'stock-kernel.bin')
if not os.path.exists(stock):
    b = open(os.path.join(WS, 'boot-A14.img'), 'rb').read()
    ks = struct.unpack_from('<I', b, 8)[0]
    open(stock, 'wb').write(b[4096:4096 + ks])
    print()
    print('  extracted stock kernel: %d bytes' % ks)

combined = os.path.join(WS, 'out', 'discrim-kernel.bin')
open(combined, 'wb').write(open(stock, 'rb').read() + marked)
print()
print('=== combined payload ===')
print('  stock kernel %d + marked dtb %d = %d'
      % (os.path.getsize(stock), len(marked), os.path.getsize(combined)))

out_img = os.path.join(WS, 'out', 'discrim.img')
cmd = ('cd %s && python3 tools/bootimg.py pack --kernel out/discrim-kernel.bin '
       '--stock boot-A14.img -o out/discrim.img' % WSL_WS)
r = subprocess.run(['wsl.exe', '-d', 'Ubuntu-22.04', '--', 'bash', '-lc', cmd],
                   capture_output=True)
for line in (r.stdout or b'').decode('utf-8', 'replace').splitlines():
    if line.strip() and 'localh' not in line and 'N/e' not in line:
        print('  %s' % line.strip()[:100])

print()
print('=== readiness check ===')
ok = True
if not os.path.exists(out_img):
    print('  boot image MISSING'); ok = False
else:
    b = open(out_img, 'rb').read()
    ksize = struct.unpack_from('<I', b, 8)[0]
    k = b[4096:4096 + ksize]
    has = k.find(marked)
    print('  boot image    : %d bytes' % len(b))
    print('  kernel field  : %d bytes' % ksize)
    print('  marked DTB at : %s' % ('0x%x' % has if has >= 0 else 'NOT FOUND'))
    print('  marker in img : %s' % (b'xigua-append-test' in k))
    if b'xigua-append-test' not in k:
        ok = False

print()
print('  vendor_boot_b currently carries: %s' % VB_NODE)
print('  (it was written earlier and keeps its backup; restore with')
print('   fastboot flash vendor_boot_b vendor_boot-A14.img)')
print()
print('READY: %s' % ok)
sys.exit(0 if ok else 1)

"""Enable only S3910 SPI transport on the proven visible #14 display DT."""
import hashlib
import json
import struct
from pathlib import Path
from fdt import FDT
from fdtwrite import parse, serialise, walk

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'out/display-port-20261013'
OUT = ROOT / 'out/touch-port-20261013'
OUT.mkdir(exist_ok=True)
assert json.loads((BASE/'manifest.json').read_text())['screen_output_confirmed']
source = (BASE/'vendor_boot_b-xigua-r1.img').read_bytes()
align = lambda n: (n+4095)//4096*4096
off = align(align(struct.unpack_from('<I',source,2096)[0])+struct.unpack_from('<I',source,24)[0])
size = struct.unpack_from('>I', source, off+4)[0]
original = source[off:off+size]
tree, reservations = parse(original)
nodes = dict(walk(tree))
u32 = lambda *v: struct.pack('>'+'I'*len(v), *v)
string = lambda s: s.encode()+b'\0'
spi_path = '/soc@0/geniqup@ac0000/spi@a90000'
spi = nodes[spi_path]
tlmm_path = '/soc@0/pinctrl@f100000'
tlmm = nodes[tlmm_path]
next_handle = max(int.from_bytes(n.props['phandle'],'big') for n in nodes.values() if 'phandle' in n.props)+1
def handle(n):
    global next_handle
    if 'phandle' not in n.props:
        n.set('phandle',u32(next_handle));next_handle+=1
    return n.props['phandle']

spi.set('status', string('okay'))
pins = tlmm.child('pja110-touch-control-state')
pins.set('pins', string('gpio10')+string('gpio24'))
pins.set('function', string('gpio'))
pins.set('drive-strength', u32(8))
pins.set('bias-disable', b'')
irq = tlmm.child('pja110-touch-irq-state')
irq.set('pins', string('gpio25'))
irq.set('function', string('gpio'))
irq.set('drive-strength', u32(8))
irq.set('bias-pull-up', b'')
irq.set('input-enable', b'')
touch = spi.child('touchscreen@0')
touch.set('compatible', string('oneplus,pja110-s3910-probe'))
touch.set('reg', u32(0))
touch.set('spi-max-frequency', u32(1000000))
touch.set('pinctrl-names', string('default'))
touch.set('pinctrl-0', handle(pins)+handle(irq))
vdd = next(n for n in nodes.values() if n.props.get('regulator-name') == string('vreg_l4b_1p8'))
touch.set('vdd-supply', handle(vdd))
for name, pin, flags in [('reset',24,1),('avdd',10,0),('attn',25,1)]:
    touch.set(name+'-gpios',handle(tlmm)+u32(pin,flags))
raw = serialise(tree,reservations)
assert len(raw) <= size
padded = bytearray(raw).ljust(size,b'\0')
struct.pack_into('>I',padded,4,size)
before,after = FDT(original).nodes(),FDT(padded).nodes()
delta = []
for path in before.keys()|after.keys():
    for key in before.get(path,{}).keys()|after.get(path,{}).keys():
        a,b=before.get(path,{}).get(key),after.get(path,{}).get(key)
        if a!=b:
            assert (path==spi_path and key=='status') or path.startswith(spi_path+'/touchscreen@0') or path.startswith(tlmm_path+'/pja110-touch-'),(path,key)
            delta.append({'node':path,'property':key,'before':a.hex() if a is not None else None,'after':b.hex() if b is not None else None})
result = bytearray(source)
result[off:off+size] = padded
assert result[:off]==source[:off] and result[off+size:]==source[off+size:]
(OUT/'vendor_boot_b-touch.img').write_bytes(result)
(OUT/'touch.dtb').write_bytes(padded)
files = ['vendor_boot_b-touch.img','spi-geni-qcom.ko','mainline_touch_probe.ko']
manifest = {'baseline':'visible #14 display with automatic SSH','only_vendor_boot_b_flash':True,
            'boot_kernel_unchanged':True,'display_usb_ufs_memory_unchanged':True,
            'diagnostic_only_no_input_yet':True,'no_touch_firmware_flash_commands':True,
            'baseline_hashes':json.loads((BASE/'device-after.json').read_text()),'dt_delta':delta,
            'files':{n:{'bytes':(OUT/n).stat().st_size,'sha256':hashlib.sha256((OUT/n).read_bytes()).hexdigest()} for n in files}}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(f'PASS: {len(delta)} touch-only properties; display/USB/UFS/memory and boot unchanged')

from pathlib import Path

r = Path.home()/'workspace/PJA110-Mainline/pmbootstrap-work/chroot_rootfs_oneplus-xigua'
for folder, pattern in [('usr/bin', 'ph*'), ('usr/bin', 'seat*'), ('usr/libexec', '*ph*'),
                        ('usr/share/wayland-sessions', '*')]:
    print(folder, [p.name for p in (r/folder).glob(pattern)])
for name in ['etc/greetd/config.toml', 'usr/share/wayland-sessions/phosh.desktop',
             'usr/bin/phosh-session', 'usr/libexec/phosh', 'usr/lib/systemd/system/phosh.service',
             'etc/phosh/phoc.ini', 'usr/share/phosh/phoc.ini']:
    p = r/name
    if p.is_file():
        print('\nFILE:', name)
        data = p.read_bytes()
        if data[:4] != b'\x7fELF':
            print(data.decode(errors='replace')[:11000])

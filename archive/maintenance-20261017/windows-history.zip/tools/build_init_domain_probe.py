"""PID1 witness: set the UTS domainname, then exec the preserved factory init."""
import hashlib
import pathlib
import struct

from capstone import Cs, CS_ARCH_ARM64, CS_MODE_ARM
from build_init_marker_test import parse_cpio, make_entry, lz4
from build_native_init_probe import movz

ROOT=pathlib.Path(__file__).resolve().parents[1]
OUT=ROOT/'out/init-experiment-20261012'
MARK=b'pja110-init-executed'

def adr(reg, delta):
    return 0x10000000 | ((delta&3)<<29) | (((delta>>2)&0x7ffff)<<5) | reg

def main():
    # Keep argv/envp in x20/x21 across syscalls; initial arm64 stack starts argc.
    words=[0x910003F3,0xF9400264,0x91002261,0x8B040C22,0x91002042,
           0xAA0103F4,0xAA0203F5,0,movz(1,len(MARK),wide=True),movz(8,162,wide=True),
           0xD4000001,0,0xAA1403E1,0xAA1503E2,movz(8,221,wide=True),0xD4000001,
           0x4B0003E0,movz(8,93,wide=True),0xD4000001,0x14000000]
    stringoff=len(words)*4
    pathoff=stringoff+len(MARK)+1
    words[7]=adr(0,stringoff-7*4)
    words[11]=adr(0,pathoff-11*4)
    code=b''.join(struct.pack('<I',w) for w in words)
    ins=list(Cs(CS_ARCH_ARM64,CS_MODE_ARM).disasm(code,0x401000))
    assert len(ins)==len(words)
    assert ins[3].op_str=='x2, x1, x4, lsl #3'
    assert ins[7].op_str=='x0, #0x%x'%(0x401000+stringoff)
    assert ins[11].op_str=='x0, #0x%x'%(0x401000+pathoff)
    listing='\n'.join('%x: %s %s'%(i.address,i.mnemonic,i.op_str) for i in ins)
    print(listing)
    (OUT/'domain-probe-disassembly.txt').write_text(listing+'\n')
    payload=code+MARK+b'\0/init.real\0'
    size=4096+len(payload)
    header=struct.pack('<16sHHIQQQIHHHHHH',b'\x7fELF\x02\x01\x01'+b'\0'*9,
                       2,183,1,0x401000,64,0,0,64,56,1,0,0,0)
    ph=struct.pack('<IIQQQQQQ',1,5,0,0x400000,0x400000,size,size,4096)
    elf=(header+ph).ljust(4096,b'\0')+payload
    (OUT/'domain-init').write_bytes(elf)
    stock=(ROOT/'backup/init_boot_b.img').read_bytes()
    oldsize=struct.unpack_from('<I',stock,12)[0]
    entries=parse_cpio(lz4(['-d','-l','-c'],stock[4096:4096+oldsize]))
    assert not any(n=='init.real' for f,n,d in entries)
    rebuilt=bytearray()
    nextino=max(f[0] for f,n,d in entries)+1
    for fields,name,data in entries:
        if name=='init':
            rebuilt+=make_entry(fields,'init.real',data)
            newfields=list(fields)
            newfields[0]=nextino
            newfields[1]=0o100755
            rebuilt+=make_entry(newfields,'init',elf)
        else:
            rebuilt+=make_entry(fields,name,data)
    verified=parse_cpio(bytes(rebuilt))
    assert verified[-1][1]=='TRAILER!!!'
    orig={n:d for f,n,d in entries}
    result={n:d for f,n,d in verified}
    assert len(result)==len(orig)+1
    assert result['init']==elf and result['init.real']==orig['init']
    assert all(result[n]==d for n,d in orig.items() if n!='init')
    compressed=lz4(['-z','-l','-12','-c'],bytes(rebuilt))
    end=4096+((oldsize+4095)//4096)*4096
    assert len(compressed)<=end-4096, (len(compressed),end-4096)
    assert lz4(['-d','-l','-c'],compressed)==rebuilt
    image=bytearray(stock)
    struct.pack_into('<I',image,12,len(compressed))
    image[4096:end]=compressed+b'\0'*(end-4096-len(compressed))
    assert image[end:]==stock[end:] and len(image)==len(stock)
    (OUT/'init_boot_b-domain.img').write_bytes(image)
    print('Compressed:',len(compressed),'page allocation:',end-4096)
    print('Image SHA256:',hashlib.sha256(image).hexdigest())
    print('Verified original init.real byte-for-byte, all other files unchanged.')
    # Android denies shell reads of /proc/sys/kernel/domainname. uname(2)
    # exposes the same UTS field without depending on that procfs permission.
    readerwords=[0xD10803FF,0x910003E0,movz(8,160,wide=True),0xD4000001,
                 movz(0,1,wide=True),0x910517E1,movz(2,65,wide=True),
                 movz(8,64,wide=True),0xD4000001,movz(0,0,wide=True),
                 movz(8,93,wide=True),0xD4000001]
    readercode=b''.join(struct.pack('<I',w) for w in readerwords)
    decoded=list(Cs(CS_ARCH_ARM64,CS_MODE_ARM).disasm(readercode,0x401000))
    assert decoded[0].op_str=='sp, sp, #0x200'
    assert decoded[5].op_str=='x1, sp, #0x145'
    readersize=4096+len(readercode)
    readerph=struct.pack('<IIQQQQQQ',1,5,0,0x400000,0x400000,readersize,readersize,4096)
    (OUT/'read-domain').write_bytes((header+readerph).ljust(4096,b'\0')+readercode)

if __name__=='__main__':
    main()

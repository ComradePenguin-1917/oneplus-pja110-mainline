"""Build a static arm64 PID1 probe, with disassembly and CPIO round-trip checks."""
import hashlib
import pathlib
import struct
import subprocess

from capstone import Cs, CS_ARCH_ARM64, CS_MODE_ARM
from build_init_marker_test import parse_cpio, make_entry, lz4

ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT = ROOT / 'out/init-experiment-20261012'
OUT.mkdir(exist_ok=True)

def movz(reg, value, shift=0, wide=False):
    return (0xD2800000 if wide else 0x52800000) | ((shift//16)<<21) | (value<<5) | reg

def movk(reg, value):
    return 0x72A00000 | (value<<5) | reg

def main():
    # arm64 __NR_reboot=142; reboot(magic1, magic2, RESTART2, "bootloader").
    # If denied in an unprivileged Android shell, exit with positive errno.
    words = [movz(0,0xDEAD), movk(0,0xFEE1),
             movz(1,0x1969), movk(1,0x2812),
             movz(2,0xC3D4), movk(2,0xA1B2),
             0x100000E3, movz(8,142,wide=True), 0xD4000001,
             0x4B0003E0, movz(8,93,wide=True), 0xD4000001, 0x14000000]
    code = b''.join(struct.pack('<I',w) for w in words)
    base, entry = 0x400000, 0x401000
    instructions = list(Cs(CS_ARCH_ARM64,CS_MODE_ARM).disasm(code,entry))
    assert len(instructions)==len(words)
    assert instructions[6].mnemonic=='adr' and instructions[6].op_str=='x3, #0x401034'
    listing = '\n'.join('%x: %s %s'%(i.address,i.mnemonic,i.op_str) for i in instructions)
    print(listing)
    (OUT/'native-init-disassembly.txt').write_text(listing+'\n',encoding='utf-8')
    payload = code+b'bootloader\0'
    size=4096+len(payload)
    ident=b'\x7fELF\x02\x01\x01'+b'\0'*9
    header=struct.pack('<16sHHIQQQIHHHHHH',ident,2,183,1,entry,64,0,0,64,56,1,0,0,0)
    ph=struct.pack('<IIQQQQQQ',1,5,0,base,base,size,size,4096)
    elf=(header+ph).ljust(4096,b'\0')+payload
    assert elf[4096+52:]==b'bootloader\0'
    (OUT/'native-init').write_bytes(elf)
    stock=(ROOT/'backup/init_boot_b.img').read_bytes()
    oldsize=struct.unpack_from('<I',stock,12)[0]
    entries=parse_cpio(lz4(['-d','-l','-c'],stock[4096:4096+oldsize]))
    rebuilt=bytearray()
    changed=0
    for fields,name,data in entries:
        if name=='init':
            fields=list(fields)
            fields[1]=0o100755
            data=elf
            changed+=1
        rebuilt+=make_entry(fields,name,data)
    assert changed==1
    verified=parse_cpio(bytes(rebuilt))
    assert len(verified)==len(entries) and verified[-1][1]=='TRAILER!!!'
    for (_,oldname,olddata),(fields,name,data) in zip(entries,verified):
        assert name==oldname
        assert data==(elf if name=='init' else olddata)
        if name=='init': assert fields[1]==0o100755
    compressed=lz4(['-z','-l','-12','-c'],bytes(rebuilt))
    assert len(compressed)<oldsize
    assert lz4(['-d','-l','-c'],compressed)==rebuilt
    image=bytearray(stock)
    end=4096+((oldsize+4095)//4096)*4096
    struct.pack_into('<I',image,12,len(compressed))
    image[4096:end]=compressed+b'\0'*(end-4096-len(compressed))
    assert image[end:]==stock[end:] and len(image)==len(stock)
    (OUT/'init_boot_b-native.img').write_bytes(image)
    (OUT/'native-init.cpio').write_bytes(rebuilt)
    print('Native ELF SHA256:',hashlib.sha256(elf).hexdigest())
    print('init_boot SHA256:',hashlib.sha256(image).hexdigest())
    print('CPIO verified: only /init changed, remaining files byte-identical.')

if __name__=='__main__':
    main()

"""Capture brief native SSH windows; read-only phone access, stream to host."""
from pathlib import Path
import json
import queue
import subprocess
import threading
import time
import sys

ROOT = Path(__file__).resolve().parents[1]
scope = {'__file__': str(ROOT / 'tools/check_battery_runtime.py')}
exec((ROOT / 'tools/check_battery_runtime.py').read_text().split('state = run(')[0], scope)
ssh = scope['SSH'][:]
ssh[ssh.index('ConnectTimeout=6')] = 'ConnectTimeout=2'
ssh[-1:-1] = ['-o', 'ConnectionAttempts=1', '-o', 'ServerAliveInterval=3',
              '-o', 'ServerAliveCountMax=1']
out = ROOT / 'out/battery-bringup-20261016' / ('connection-window-' + time.strftime('%Y%m%d-%H%M%S'))
out.mkdir(parents=True)
command = r'''
echo BEGIN_SNAPSHOT
cat /proc/sys/kernel/random/boot_id /proc/uptime
uname -r
for p in /sys/class/power_supply/*; do
 test -e "$p/uevent" || continue
 echo SUPPLY "$p"
 cat "$p/uevent"
 readlink -f "$p/device/driver"
done
echo GAUGE_DONE
for p in /sys/class/remoteproc/*; do
 test -e "$p/state" || continue
 echo REMOTEPROC "$p"
 cat "$p/name" "$p/state"
done
echo MODULES
cat /proc/modules | grep -E 'bq27|battmgr|q6v5|glink|pd_mapper'
echo CURRENT_BOOT_LOG
timeout 4 journalctl -b --no-pager -n 35 -u upower.service -u systemd-logind.service 2>&1
echo PREVIOUS_BOOT_LOG
timeout 4 journalctl -b -1 --no-pager -n 35 -u upower.service -u systemd-logind.service 2>&1
echo KERNEL_LOG
timeout 4 journalctl -b -k --no-pager -n 150 2>&1 | grep -Ei 'battery|bq27|bq28|adsp|remoteproc|charger|voltage|power|pm8550'
echo END_SNAPSHOT
'''
details = '--details' in sys.argv[1:]
access = '--access' in sys.argv[1:]
if details:
    command = r'''
echo BEGIN_INTERFACES
cat /proc/sys/kernel/random/boot_id /proc/uptime
echo POWER_SUPPLIES
ls -l /sys/class/power_supply
echo REMOTEPROC
ls -ld /sys/class/remoteproc /sys/class/remoteproc/* 2>&1
echo PMIC_DEVICES
for p in /sys/bus/spmi/devices/*; do
 test -d "$p" || continue
 echo DEVICE "$p"
 cat "$p/uevent" 2>/dev/null
 readlink -f "$p/driver"
 for f in "$p"/of_node/compatible "$p"/of_node/reg; do
  test -r "$f" && od -An -tx1 "$f"
 done
done
echo CHARGER_INTERFACES
ls -l /sys/bus/auxiliary/devices/pmic_glink* /sys/bus/rpmsg/devices /sys/kernel/debug/qcom_smem /sys/kernel/debug/regmap 2>&1
echo FIRMWARE
for p in /lib/firmware/qcom/sm8550/xigua/adsp.mdt /usr/lib/firmware/qcom/sm8550/xigua/adsp.mdt; do
 test ! -e "$p" || ls -l "$p"
done
echo REMOTEPROC_DT
for p in /sys/firmware/devicetree/base/soc@0/remoteproc@6800000/status; do
 test ! -r "$p" || cat "$p"
done
echo KERNEL_BOOT_LOG
timeout 5 journalctl -b -k --no-pager -g 'pm8550|PMIC|bq27|bq28|remoteproc|adsp|charger|power.supply' -n 80 2>&1
echo END_INTERFACES
'''
if access:
    command = r'''
echo BEGIN_ACCESS
cat /proc/sys/kernel/random/boot_id /proc/uptime
id
echo SUDO_POLICY
command -v sudo
timeout 3 sudo -n -l 2>&1
echo DEBUGFS_MOUNT
grep ' /sys/kernel/debug ' /proc/mounts
ls -ld /sys/kernel/debug /sys/kernel/debug/qcom_smem /sys/kernel/debug/regmap 2>&1
echo POWER_STATE
cat /sys/class/power_supply/bq28z610-0/uevent
echo END_ACCESS
'''
deadline = time.monotonic() + (45 if details or access else 100)
attempts = []
successes = 0
print('Host capture directory: ' + str(out), flush=True)
while time.monotonic() < deadline and successes < (1 if details or access else 2):
    number = len(attempts) + 1
    path = out / f'attempt-{number:02d}.txt'
    proc = subprocess.Popen(ssh + [command], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    chunks = queue.Queue()
    def reader(stream):
        try:
            for line in iter(stream.readline, b''):
                chunks.put(line)
        finally:
            chunks.put(None)
    thread = threading.Thread(target=reader, args=(proc.stdout,), daemon=True)
    thread.start()
    start = time.monotonic()
    received = bytearray()
    done = False
    with path.open('wb') as handle:
        while not done:
            if time.monotonic() - start > 22 or time.monotonic() > deadline:
                proc.kill()
            try:
                line = chunks.get(timeout=0.5)
            except queue.Empty:
                continue
            if line is None:
                done = True
            else:
                received.extend(line)
                handle.write(line)
                handle.flush()
    proc.wait()
    marker = b'END_ACCESS' if access else b'END_INTERFACES' if details else b'GAUGE_DONE'
    useful = marker in received
    attempts.append({'attempt': number, 'exit': proc.returncode,
                     'bytes': len(received), 'gauge_captured': useful,
                     'complete': (marker if details or access else b'END_SNAPSHOT') in received})
    if useful:
        successes += 1
        print(received.decode(errors='replace'), flush=True)
    elif number == 1 or number % 5 == 0:
        print(f'Attempt {number}: no snapshot; still waiting for SSH', flush=True)
    (out / 'result.json').write_text(json.dumps(attempts, indent=2) + '\n')
    time.sleep(min(6 if useful else 2, max(0, deadline-time.monotonic())))
print(f'Finished: {successes} snapshots, {len(attempts)} attempts; phone unmodified', flush=True)

"""Stage a single clean boot with existing ath12k BOOT/QMI diagnostics."""
from pathlib import Path
import subprocess
from prepare_native_install import SSH

out = Path('out/wifi-bringup-20261017')
args = SSH[:]
args[-1] = 'penguin@172.16.42.1'
args = [x if not x.startswith('UserKnownHostsFile=') else
        'UserKnownHostsFile=out/native-install-20261017/known_hosts' for x in args]
remote = '/home/penguin/wifi-bringup/clean-boot'
collect = '''#!/bin/sh
set -eu
dir=/home/penguin/wifi-bringup/clean-boot
sleep 45
{
 date; cat /proc/sys/kernel/random/boot_id
 ip -brief link
 nmcli -t -f DEVICE,TYPE,STATE device
 journalctl -b -k --no-pager
} > "$dir/result.txt" 2>&1
chmod 644 "$dir/result.txt"
if [ -w /sys/module/ath12k/parameters/debug_mask ]; then
 echo 0 > /sys/module/ath12k/parameters/debug_mask
fi
conf=/etc/modprobe.d/pja110-wifi-oneboot.conf
if [ -f "$conf" ] && cmp -s "$conf" "$dir/debug.conf"; then rm "$conf"; fi
touch "$dir/complete"
'''
service = '''[Unit]
Description=One clean boot of WCN7850 with BOOT and QMI logs
After=NetworkManager.service
ConditionPathExists=!/home/penguin/wifi-bringup/clean-boot/complete

[Service]
Type=oneshot
ExecStart=/usr/local/libexec/pja110-wifi-clean-boot
TimeoutStartSec=80

[Install]
WantedBy=multi-user.target
'''
install = '''#!/bin/sh
set -eu
test "$(id -u)" = 0
test "$(uname -r)" = 6.14.0-oneplus-xigua
cd /home/penguin/wifi-bringup/clean-boot
test ! -e complete
dest=/usr/lib/firmware/ath12k/WCN7850/hw2.0
test "$(sha256sum "$dest/board.bin" | cut -d ' ' -f 1)" = 39de9b864cd5054a8f5b60a415052b244aa50ccde0104da3f8f9ab0c6a4021bb
test "$(sha256sum "$dest/regdb.bin" | cut -d ' ' -f 1)" = a37849f717efd5974f88adf9f061f72387e5cff79eba867d12f404e09276ab9f
conf=/etc/modprobe.d/pja110-wifi-oneboot.conf
if [ -e "$conf" ] && ! cmp -s "$conf" debug.conf; then
 echo 'Different diagnostic config exists; not overwritten'; exit 1
fi
install -D -m 644 debug.conf "$conf"
install -D -m 755 collect.sh /usr/local/libexec/pja110-wifi-clean-boot
install -D -m 644 pja110-wifi-clean-boot.service /etc/systemd/system/pja110-wifi-clean-boot.service
systemctl daemon-reload
systemctl enable pja110-wifi-clean-boot.service
sync
echo 'Rebooting once; no ath12k hot reload; logs collected automatically after boot'
systemctl reboot
'''
files = {'collect.sh': collect, 'pja110-wifi-clean-boot.service': service,
         'install.sh': install, 'debug.conf': 'options ath12k debug_mask=0x60\n'}
subprocess.run(args + ['mkdir -p ' + remote], check=True, timeout=20)
for name, data in files.items():
    (out / ('clean-boot-' + name)).write_bytes(data.encode())
    p = subprocess.run(args + [f'cat > {remote}/{name}'], input=data.encode(), capture_output=True, timeout=20)
    p.check_returncode()
p = subprocess.run(args + [f'sh -n {remote}/install.sh; sh -n {remote}/collect.sh; sudo -n true'], capture_output=True, timeout=15)
print(p.stdout.decode(errors='replace'))
print(p.stderr.decode(errors='replace'))
print('One-shot diagnostics staged; noninteractive sudo:', p.returncode == 0)

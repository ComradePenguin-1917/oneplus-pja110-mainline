"""Inspect services over a VM-only serial debug shell, with an ephemeral disk overlay."""
from pathlib import Path
import subprocess
import time
from pmos_image_info import inspect_image

out = Path('/mnt/h/workspace/PJA110-Mainline/out/postmarketos-bootchain-20261015')
export = Path('/tmp/postmarketOS-export')
image_info = inspect_image(export/'oneplus-xigua.img')
out = out / image_info['root_uuid']
out.mkdir(parents=True, exist_ok=True)
import json
(out/'image-info.json').write_text(json.dumps(image_info, indent=2)+'\n')
cmdline = ('console=ttyAMA0 earlycon=pl011,0x9000000 loglevel=4 '
           f'root=UUID={image_info["root_uuid"]} rw '
           'systemd.unit=multi-user.target systemd.debug_shell=ttyAMA0 '
           'systemd.mask=serial-getty@ttyAMA0.service '
           'systemd.mask=systemd-firstboot.service '
           'systemd.log_target=console')
args = ['qemu-system-aarch64', '-machine', 'virt', '-accel', 'tcg', '-cpu', 'max',
        '-smp', '2', '-m', '2048', '-display', 'none', '-serial', 'stdio',
        '-monitor', 'none', '-no-reboot', '-kernel', str(export/'vmlinuz'),
        '-initrd', str(export/'initramfs'), '-append', cmdline,
        '-drive', f'if=none,id=pmos,file={export}/oneplus-xigua.img,format=raw,snapshot=on',
        '-device', 'virtio-blk-pci,drive=pmos,logical_block_size=4096,physical_block_size=4096',
        '-nic', 'none']
log = out/'qemu-services.log'
with log.open('wb') as stream:
    proc = subprocess.Popen(args, stdin=subprocess.PIPE, stdout=stream, stderr=subprocess.STDOUT)
    try:
        for _ in range(90):
            time.sleep(1)
            if proc.poll() is not None:
                raise RuntimeError(f'VM exited before serial shell: {proc.returncode}')
            if b'/ #' in log.read_bytes() or b'sh-' in log.read_bytes():
                break
        commands = """
export SYSTEMD_COLORS=0 SYSTEMD_PAGER=cat
sleep 35
systemctl start sshd.service NetworkManager.service systemd-logind.service
echo PMOS_SERVICE_CHECK_BEGIN
cat /proc/1/comm
uname -r
findmnt --target /
findmnt --target /boot
systemctl is-active systemd-udevd sshd NetworkManager systemd-logind
systemctl --failed --no-pager
systemctl list-jobs --no-pager
journalctl -b -u postmarketos-zram-swap.service --no-pager -n 35
ls /sys/block/zram0
modinfo zram | head -n 8
cat /sys/block/zram0/comp_algorithm
grep zram_swap_algo /usr/share/deviceinfo/deviceinfo
systemctl is-active postmarketos-zram-swap.service
swapon --show
passwd -S root
journalctl -b -u hkdm.service --no-pager -n 12
echo PMOS_SERVICE_CHECK_END
systemctl poweroff
"""
        # Parse the complete sequence before sleep: a tty may discard queued input
        # when a foreground child exits, losing later separately entered lines.
        command_line = '; '.join(line for line in commands.splitlines() if line.strip())
        proc.stdin.write((command_line + '\n').encode())
        proc.stdin.flush()
        try:
            proc.wait(timeout=230)
        except subprocess.TimeoutExpired:
            proc.terminate()
            proc.wait(timeout=10)
    finally:
        if proc.poll() is None:
            proc.kill()
            proc.wait()
print('QEMU_EXIT=', proc.returncode)
text = log.read_text(errors='replace')
assert proc.returncode == 0 and 'reboot: Power down' in text, 'Clean shutdown not observed'
assert 'PMOS_SERVICE_CHECK_BEGIN\nsystemd' in text and '\nPMOS_SERVICE_CHECK_END' in text
assert '/dev/zram0' in text, 'Automatic zram not observed; inspect log'
print('Log:', log)
start = text.index('PMOS_SERVICE_CHECK_BEGIN\nsystemd')
print(text[start:text.index('PMOS_SERVICE_CHECK_END', start)])

"""Download a pinned pure-Python dependency into workspace, no system install."""
import urllib.request,json,hashlib,zipfile,io
from pathlib import Path
out=Path(__file__).resolve().parents[1]/'out/pmbootstrap-wsl-probe-20261015'
m=json.load(urllib.request.urlopen('https://pypi.org/pypi/tomli/2.2.1/json',timeout=25))
p=next(x for x in m['urls'] if x['filename'].endswith('py3-none-any.whl'))
data=urllib.request.urlopen(p['url'],timeout=25).read()
assert hashlib.sha256(data).hexdigest()==p['digests']['sha256']
dest=out/'python-deps';dest.mkdir(exist_ok=True)
with zipfile.ZipFile(io.BytesIO(data)) as z:
 for name in z.namelist():
  assert not name.startswith('/') and '..' not in Path(name).parts
 z.extractall(dest)
(out/'tomli-source.json').write_text(json.dumps({'version':'2.2.1','url':p['url'],'sha256':p['digests']['sha256'],'system_installed':False},indent=2)+'\n')
print('Pinned tomli extracted only to workspace')

#!/usr/bin/env python3
"""Extract the REAL panel timing/resolution from the live device tree.

My earlier guess (BOE NT37705, 1240x2772) came from scanning dtbo strings for
several candidate panels. The live tree shows the vendor kernel actually uses
AA536_P_3_A0001. Get its true timing values so the driver work targets the
right hardware.
"""
import os
import re
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fdt import FDT

WS = r'H:\WorkSpace\PJA110-Mainline'
f = FDT(open(os.path.join(WS, 'live-from-device.dtb'), 'rb').read())
nodes = f.nodes()


def dec(v):
    return v.rstrip(b'\0').decode('ascii', 'replace')


def u32(v):
    return struct.unpack('>I', v[:4])[0] if len(v) >= 4 else None


TARGET = 'qcom,mdss_dsi_panel_AA536_P_3_A0001_dsc_cmd'

print('=' * 72)
print('Panel timing for %s' % TARGET)
print('=' * 72)
for p, props in sorted(nodes.items()):
    if p.split('/')[-1] != TARGET:
        continue
    print('  node: %s' % p)
    for k in sorted(props):
        v = props[k]
        # decode the timing properties we care about
        if k in ('qcom,mdss-dsi-panel-width', 'qcom,mdss-dsi-panel-height',
                 'qcom,mdss-dsi-h-front-porch', 'qcom,mdss-dsi-h-back-porch',
                 'qcom,mdss-dsi-h-pulse-width', 'qcom,mdss-dsi-v-front-porch',
                 'qcom,mdss-dsi-v-back-porch', 'qcom,mdss-dsi-v-pulse-width',
                 'qcom,mdss-dsi-panel-framerate', 'qcom,mdss-dsi-panel-clockrate',
                 'qcom,mdss-dsi-h-sync-skew', 'qcom,mdss-dsi-h-left-border',
                 'qcom,mdss-dsi-h-right-border', 'qcom,mdss-dsi-v-top-border',
                 'qcom,mdss-dsi-v-bottom-border', 'qcom,mdss-dsi-traffic-mode',
                 'qcom,mdss-dsi-bpp', 'qcom,mdss-dsi-underflow-color',
                 'qcom,mdss-dsi-border-color', 'qcom,mdss-dsi-panel-type',
                 'qcom,mdss-dsi-panel-orientation'):
            print('    %-42s = %s' % (k, u32(v) if u32(v) is not None else dec(v)))
        elif k in ('qcom,mdss-dsi-panel-name', 'qcom,mdss-dsi-panel-model',
                   'qcom,mdss-dsi-panel-phy-timings', 'qcom,mdss-dsi-t-clk-pre',
                   'qcom,mdss-dsi-t-clk-post', 'qcom,mdss-dsi-panel-hdr-enabled'):
            print('    %-42s = %s' % (k, dec(v)))
        elif k.startswith('qcom,mdss-dsc'):
            print('    %-42s = %s' % (k, u32(v) if u32(v) is not None and len(v) == 4 else dec(v)[:60]))

print()
print('=' * 72)
print('Resolution cross-check')
print('=' * 72)
w = h = None
for p, props in nodes.items():
    if p.split('/')[-1] == TARGET:
        if 'qcom,mdss-dsi-panel-width' in props:
            w = u32(props['qcom,mdss-dsi-panel-width'])
        if 'qcom,mdss-dsi-panel-height' in props:
            h = u32(props['qcom,mdss-dsi-panel-height'])
print('  ABL/live tree reports: %s x %s' % (w, h))
print('  my earlier GUESS      : 1240 x 2772  (BOE NT37705)')
print('  -> matches: %s' % (w == 1240 and h == 2772))

print()
print('=' * 72)
print('All panels that existed in the dtbo strings, for contrast')
print('=' * 72)
db = open(os.path.join(WS, 'dtbo-A14.img'), 'rb').read()
for m in sorted(set(re.findall(rb'mdss_dsi_panel_[A-Za-z0-9_]+|dsi_oplus_[a-z0-9_]+', db))):
    print('  %s' % m.decode())

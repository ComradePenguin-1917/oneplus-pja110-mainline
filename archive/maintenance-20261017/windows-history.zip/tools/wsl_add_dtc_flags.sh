#!/bin/bash
# Add DTC_FLAGS_<target> := -@ for our two boards so the ABL-required labels
# (qcom_tzlog, arch_timer) are emitted into the built DTB.
#
# Mechanism confirmed from scripts/Makefile.dtbs:
#     DTC_FLAGS += $(DTC_FLAGS_$(target-stem))
# i.e. a per-target variable named DTC_FLAGS_<dtb-basename> is honoured.
# Precedent in-tree: arch/arm64/boot/dts/nvidia/Makefile and mediatek/Makefile
# use exactly this for -@.
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
QDTS="$ROOT/linux/arch/arm64/boot/dts/qcom"
MK="$QDTS/Makefile"

echo "=== before ==="
grep -n 'sm8550-oneplus-xigua' "$MK"

if grep -q 'DTC_FLAGS_sm8550-oneplus-xigua' "$MK"; then
    echo "already present"
else
    cat >> "$MK" <<'EOF'

# OnePlus Ace 2 Pro (PJA110 / xigua). The ABL on this device refuses to apply a
# DTBO unless the base DTB carries labels named "qcom_tzlog" and "arch_timer",
# so build with -@ to emit __symbols__. Same approach as nvidia/mediatek boards.
DTC_FLAGS_sm8550-oneplus-xigua := -@
DTC_FLAGS_sm8550-oneplus-xigua-16G := -@
EOF
    echo "appended DTC_FLAGS lines"
fi

echo
echo "=== after ==="
grep -n -A1 'DTC_FLAGS_sm8550-oneplus-xigua' "$MK"

echo
echo "=== rebuild the two DTBs ==="
export PATH="$ROOT/toolchain/gcc-12-aarch64/usr/bin:$PATH"
export LD_LIBRARY_PATH="$ROOT/toolchain/gcc-12-aarch64/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
cd "$ROOT/linux"
rm -f arch/arm64/boot/dts/qcom/sm8550-oneplus-xigua*.dtb
make -j"$(nproc)" ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu- dtbs 2>&1 | tail -6

echo
ls -l arch/arm64/boot/dts/qcom/sm8550-oneplus-xigua*.dtb

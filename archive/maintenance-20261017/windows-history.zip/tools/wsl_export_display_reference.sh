#!/bin/bash
set -euo pipefail
TREE="$HOME/workspace/PJA110-Mainline/linux"
OUT=/mnt/h/workspace/PJA110-Mainline/out/display-port-20261013/reference
mkdir -p "$OUT"
for source in drivers/gpu/drm/panel/panel-visionox-vtdr6130.c drivers/gpu/drm/panel/panel-samsung-ams673yd01.c drivers/gpu/drm/panel/panel-samsung-s6e3ha8.c drivers/gpu/drm/msm/dsi/dsi_host.c drivers/gpu/drm/msm/dsi/dsi.c drivers/gpu/drm/msm/dsi/phy/dsi_phy_7nm.c include/drm/drm_mipi_dsi.h include/drm/display/drm_dsc_helper.h include/drm/display/drm_dsc.h drivers/gpu/drm/panel/Kconfig; do
    if [ -f "$TREE/$source" ]; then cp "$TREE/$source" "$OUT/$(basename "$source")"; fi
done
echo 'Exported actual Linux 6.14 display references'

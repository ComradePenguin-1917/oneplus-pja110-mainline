#!/usr/bin/env python3
"""Plan a SURGICAL patch of the vendor base tree.

Strategy
--------
Do not replace the tree. Instead, for each node that mainline needs to drive,
PREPEND the mainline compatible string to that node's `compatible` property.

Why prepending works:
  DT matching walks the compatible list from most-specific to most-general and
  binds the first entry a driver claims. So
      compatible = "qcom,kalama-gcc-v2"        (vendor only)
  becomes
      compatible = "qcom,sm8550-gcc", "qcom,kalama-gcc-v2"
  and mainline's gcc-sm8550 driver binds, while the vendor tree keeps its shape.

Why this is the low-risk route:
  * every node stays where it is -> all 1521 __symbols__ labels survive
  * the vendor dtbo's 168 fixups keep resolving -> overlays still work
  * UFS/PHY/sdhci stay enabled by the overlays -> device still boots
  * only `compatible` payloads change, and only on the handful of nodes we pick

This script produces the worklist: for each bring-up-critical device, the vendor
node, its current compatible list, and the mainline compatible(s) to prepend.
"""
import os
import re
import struct
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fdt import FDT

WS = r'H:\WorkSpace\PJA110-Mainline'
KT = os.path.join(WS, 'linux')


def dec(v):
    return v.rstrip(b'\0').decode('ascii', 'replace')


def compat_list(v):
    return [s for s in dec(v).split('\0') if s]


# ---- vendor base tree ----
v = open(os.path.join(WS, 'backup', 'vendor_boot_b.img'), 'rb').read()
hsize, dtbsize = struct.unpack_from('<2I', v, 28+2048+4+16)
vrsize = struct.unpack_from('<I', v, 24)[0]
dtb_off = (((hsize+4095)//4096)*4096 + vrsize + 4095)//4096*4096
e0 = struct.unpack_from('>I', v, dtb_off+4)[0]
base = FDT(v[dtb_off:dtb_off+e0]).nodes()

# ---- what mainline binds: grep driver match tables ----
def mainline_matches(pattern_file, pattern, limit=8):
    if not os.path.exists(pattern_file):
        return []
    out = subprocess.run('grep -oE \'"qcom,[a-z0-9\\-]+"\' %s | sort -u | head -%d'
                         % (pattern_file, limit),
                         shell=True, capture_output=True, text=True, cwd=KT).stdout
    return [x.strip('"') for x in out.split()]


print('=' * 78)
print('BRING-UP-CRITICAL DEVICES: vendor compatible -> mainline compatible')
print('=' * 78)

# (label, node-name-substring, mainline compatible(s))
TARGETS = [
    ('Clock controller (GCC)', 'gcc',              ['qcom,sm8550-gcc']),
    ('Pinctrl (TLMM)',         'pinctrl@f000000',  ['qcom,sm8550-tlmm']),
    ('UFS host',               'ufshc',            ['qcom,sm8550-ufshc']),
    ('UFS PHY',                'ufsphy',           ['qcom,sm8550-qmp-ufs-phy']),
    ('USB dwc3 wrapper',       'ssusb',            ['qcom,sm8550-dwc3']),
    ('USB dwc3 core',          'dwc3@',            ['snps,dwc3']),
    ('USB QMP combo PHY',      'ssphy',            ['qcom,sm8550-qmp-usb3-dp-phy']),
    ('USB eUSB2 HS PHY',       'hsphy',            ['qcom,sm8550-snps-eusb2-phy']),
    ('GENI serial (console)',  'qup_uart',         ['qcom,geni-debug-uart']),
    ('RPMH RSC',               'rsc@',             ['qcom,rpmh-rsc']),
    ('SMEM',                   'smem',             ['qcom,smem']),
    ('SCM firmware',           'scm',              ['qcom,scm-sm8550']),
    ('SPMI arbiter',           'spmi',             ['qcom,spmi-pmic-arb']),
    ('TLMM/TSENS',             'tsens',            ['qcom,sm8550-tsens']),
    ('Interconnect (NoC)',     'noc',              []),
    ('LLCC',                   'llcc',             ['qcom,sm8550-llcc']),
    ('SDHCI',                  'sdhci',            ['qcom,sdhci-msm-v5']),
    ('ADSP/CDSP PAS',          'remoteproc',       []),
]

found = {}
for label, sub, ml in TARGETS:
    hits = [p for p in base if sub.lower() in p.lower() and p.count('/') <= 4]
    if not hits:
        print('--- %-24s  (no node matching %r)' % (label, sub))
        continue
    for p in sorted(hits)[:2]:
        cl = compat_list(base[p].get('compatible', b''))
        if not cl:
            continue
        already = [c for c in ml if c in cl]
        need = [c for c in ml if c not in cl]
        found[p] = (label, cl, need)
        print('--- %s' % label)
        print('    node       : %s' % p)
        print('    compatible : %s' % ', '.join(cl))
        if already:
            print('    ALREADY OK : %s' % ', '.join(already))
        if need:
            print('    TO PREPEND : %s' % ', '.join(need))
        if not need and not already:
            print('    (no mainline compatible known yet)')

print()
print('=' * 78)
print('SUMMARY')
print('=' * 78)
todo = {p: d for p, d in found.items() if d[2]}
print('  nodes needing a prepended compatible: %d' % len(todo))
print('  total strings to add               : %d' % sum(len(d[2]) for d in todo.values()))
print()
for p, (label, cl, need) in sorted(todo.items()):
    print('    %-46s + %s' % (p[:46], ', '.join(need)))

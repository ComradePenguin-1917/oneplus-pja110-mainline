/* SPDX-License-Identifier: GPL-2.0-only */
/* One-minute evdev capture with RAM-only framebuffer touch markers. */
#include <fcntl.h>
#include <glob.h>
#include <linux/fb.h>
#include <linux/input.h>
#include <poll.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>

static double now(void)
{
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC,&t);
    return t.tv_sec+t.tv_nsec/1e9;
}

int main(int argc, char **argv)
{
    unsigned int seconds=60;
    if(argc==3 && !strcmp(argv[1],"--seconds")) {
        char *end;
        unsigned long parsed=strtoul(argv[2],&end,10);
        if(*end || parsed<10 || parsed>120)return 12;
        seconds=parsed;
    } else if(argc!=1)return 12;
    glob_t paths={0};
    char name[128];
    int input=-1,fb=-1,slot=0,frames=0,max_contacts=0;
    struct input_absinfo ax,ay;
    struct fb_var_screeninfo v;
    struct fb_fix_screeninfo f;
    struct { int active,x,y; } contacts[16]={0};
    uint8_t *map;
    setvbuf(stdout,NULL,_IOLBF,0);
    if(glob("/dev/input/event*",0,NULL,&paths))return 1;
    for(size_t i=0;i<paths.gl_pathc;i++) {
        int candidate=open(paths.gl_pathv[i],O_RDONLY|O_NONBLOCK);
        if(candidate>=0 && ioctl(candidate,EVIOCGNAME(sizeof(name)),name)>=0 &&
           !strcmp(name,"PJA110 Synaptics S3910")) {
            input=candidate;printf("DEVICE %s\n",paths.gl_pathv[i]);break;
        }
        if(candidate>=0)close(candidate);
    }
    globfree(&paths);
    int event_clock=CLOCK_MONOTONIC;
    if(input>=0 && ioctl(input,EVIOCSCLOCKID,&event_clock)) {
        perror("evdev monotonic clock");return 13;
    }
    fb=open("/dev/fb0",O_RDWR);
    if(input<0 || fb<0 || ioctl(input,EVIOCGABS(ABS_MT_POSITION_X),&ax) ||
       ioctl(input,EVIOCGABS(ABS_MT_POSITION_Y),&ay) ||
       ioctl(fb,FBIOGET_VSCREENINFO,&v) || ioctl(fb,FBIOGET_FSCREENINFO,&f)) {
        perror("touch/framebuffer metadata");return 2;
    }
    if(ax.minimum!=0 || ay.minimum!=0 || ax.maximum<=0 || ay.maximum<=0 ||
       v.bits_per_pixel!=32 || v.red.length!=8 || v.green.length!=8 || v.blue.length!=8 ||
       v.red.offset>24 || v.green.offset>24 || v.blue.offset>24 || !v.xres || !v.yres ||
       (uint64_t)(v.xoffset+v.xres)*4>f.line_length ||
       (uint64_t)(v.yoffset+v.yres)*f.line_length>f.smem_len)return 3;
    map=mmap(NULL,f.smem_len,PROT_READ|PROT_WRITE,MAP_SHARED,fb,0);
    if(map==MAP_FAILED) { perror("framebuffer mmap");return 4; }
    printf("READY max_x=%d max_y=%d screen=%ux%u duration=%us\n",ax.maximum,ay.maximum,v.xres,v.yres,seconds);
    double started=now(),last_update=0;
    while(now()-started<seconds) {
        struct pollfd p={.fd=input,.events=POLLIN};
        int ready=poll(&p,1,500);
        if(ready<0) { perror("evdev poll");return 5; }
        if(!ready)continue;
        struct input_event events[256];
        int redraw=0;
        ssize_t count=read(input,events,sizeof(events));
        if(count<=0 || count%sizeof(events[0])) { perror("evdev read");return 6; }
        for(size_t i=0;i<(size_t)count/sizeof(events[0]);i++) {
            struct input_event *e=&events[i];
            if(e->type==EV_SYN && e->code==SYN_DROPPED) {
                fputs("FAIL evdev overflow\n",stderr);return 7;
            }
            if(e->type==EV_ABS) {
                if(e->code==ABS_MT_SLOT)slot=e->value;
                if(slot<0 || slot>=16)return 8;
                if(e->code==ABS_MT_TRACKING_ID)contacts[slot].active=e->value>=0;
                if(e->code==ABS_MT_POSITION_X)contacts[slot].x=e->value;
                if(e->code==ABS_MT_POSITION_Y)contacts[slot].y=e->value;
            }
            if(e->type==EV_SYN && e->code==SYN_REPORT) {
                int active=0;
                /* Kernel event time avoids reader/rendering scheduling jitter. */
                double event_time=e->time.tv_sec+e->time.tv_usec/1e6;
                printf("FRAME %.6f",event_time-started);
                for(int j=0;j<16;j++)if(contacts[j].active) {
                    int raw_x=contacts[j].x,raw_y=contacts[j].y;
                    if(raw_x<0 || raw_x>ax.maximum || raw_y<0 || raw_y>ay.maximum)return 9;
                    int x=(int)((uint64_t)raw_x*(v.xres-1)/ax.maximum);
                    int y=(int)((uint64_t)raw_y*(v.yres-1)/ay.maximum);
                    printf(" slot=%d raw=%d,%d px=%d,%d",j,raw_x,raw_y,x,y);
                    active++;
                    for(int dy=-12;dy<=12;dy++)for(int dx=-12;dx<=12;dx++) {
                        int xx=x+dx,yy=y+dy,d=dx*dx+dy*dy;
                        if(d>144 || xx<0 || yy<0 || xx>=(int)v.xres || yy>=(int)v.yres)continue;
                        uint32_t white=(255u<<v.red.offset)|(255u<<v.green.offset)|(255u<<v.blue.offset);
                        uint32_t *row=(uint32_t *)(map+(yy+v.yoffset)*f.line_length);
                        row[xx+v.xoffset]=d>100?0:white;
                    }
                }
                printf(" active=%d\n",active);
                frames++;
                if(active>max_contacts)max_contacts=active;
                if(active)redraw=1;
            }
        }
        /* Batch updates and cap rendering at 20 Hz so input reads keep up. */
        if(redraw && now()-last_update>=0.05) {
            v.activate=FB_ACTIVATE_NOW;
            if(ioctl(fb,FBIOPAN_DISPLAY,&v)) { perror("framebuffer update");return 10; }
            last_update=now();
        }
    }
    printf("SUMMARY frames=%d max_contacts=%d\n",frames,max_contacts);
    munmap(map,f.smem_len);close(fb);close(input);
    return frames?0:11;
}

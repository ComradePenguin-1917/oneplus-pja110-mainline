#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
OUT=/mnt/h/workspace/PJA110-Mainline/out/debug-ncm-fixed-20261013
export PATH="$ROOT/toolchain/gcc-12-aarch64/usr/bin:$PATH"
export LD_LIBRARY_PATH="$ROOT/toolchain/gcc-12-aarch64/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu-
cd "$ROOT/linux"
bash -n "$OUT/init.sh"
cp .config "$OUT/config.before"
cp initramfs-xigua.cpio.gz "$OUT/build-initramfs.before.cpio.gz"
cp "$OUT/initramfs.cpio.gz" initramfs-xigua.cpio.gz
make -j12 Image 2>&1 | tee "$OUT/build.log"
cmp .config "$OUT/config.before"
cp arch/arm64/boot/Image "$OUT/Image-probe"
cp System.map "$OUT/System.map"
cp .config "$OUT/kernel.config"

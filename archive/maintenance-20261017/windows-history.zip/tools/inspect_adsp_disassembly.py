"""Print annotated address ranges from the offline ADSP charger disassembly."""
from pathlib import Path
import re
import struct
import sys

OUT = Path(__file__).resolve().parents[1] / 'out/battery-bringup-20261016/charger-source'
firmware = OUT / 'firmware/qcom/sm8550/xigua'
header = (firmware / 'adsp.mdt').read_bytes()
segments = []
for i in range(struct.unpack_from('<H', header, 44)[0]):
    ph = struct.unpack_from('<8I', header, 52 + 32 * i)
    file = firmware / f'adsp.b{i:02d}'
    if ph[0] == 1 and file.exists():
        segments.append((ph[2], file.read_bytes()))

def string_at(address):
    for base, data in segments:
        offset = address - base
        if 0 <= offset < len(data):
            end = data.find(b'\0', offset)
            value = data[offset:end] if end >= 0 else b''
            if 4 < len(value) < 400 and all(32 <= c < 127 for c in value):
                return value.decode()
    return None

ranges = [tuple(int(a, 16) for a in item.split(':')) for item in sys.argv[1:]]
for line in (OUT / 'adsp-charger-analysis-only.dis').read_text().splitlines():
    match = re.match(r'^([0-9a-f]+):', line)
    if not match or not any(low <= int(match[1], 16) < high for low, high in ranges):
        continue
    for value in re.findall(r'##0x([0-9a-f]+)', line):
        string = string_at(int(value, 16))
        if string:
            line += ' // ' + string
    print(line)

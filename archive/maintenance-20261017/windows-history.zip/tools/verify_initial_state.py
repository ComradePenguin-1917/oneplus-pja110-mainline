#!/usr/bin/env python3
"""Verify the device is back to the project's STARTING state.

Target state (as measured at the very beginning of this project, before any
experiment):
    boot_a        = 742105c6...   KernelSU-patched (root)
    boot_b        = d9cf0ea6...   stock
    vendor_boot_a = 4b3e8008...   already modified before we began (root/OTA)
    vendor_boot_b = e085f83a...   stock
    dtbo_a        = 30b4002a...   stock
    dtbo_b        = 30b4002a...   stock
    init_boot_a   = 437594f3...   modified
    init_boot_b   = 26609b45...   stock
    active slot   = _a
    slot marked successful

Compare every backed-up partition on the device against the backup that was
taken at the start, byte-for-byte over the stored length, and report any
mismatch.
"""
import hashlib
import os
import shutil
import subprocess
import sys

ADB = shutil.which('adb') or r'C:\platform-tools\adb.exe'
WS = r'H:\WorkSpace\PJA110-Mainline'
BACKUP = os.path.join(WS, 'backup')
SERIAL = 'bc7a542e'

# What the device SHOULD look like at the start of the project.
EXPECTED = {
    'boot_a':        '742105c64ee25752eb9b5e03ad2f06ff1c6449bcd48c8e10c5d985e56a5b3c31',
    'boot_b':        'd9cf0ea60491b5c83689fdc6267858dfff1506154985acfc230e2bc7dbacbbf6',
    'vendor_boot_a': '4b3e8008f176b4495899ed846f22234653b0dbe386773f9959b705f641e10942',
    'vendor_boot_b': 'e085f83adde5e92835dcd51224b66b1fcef2f84c81616ebe6a7903438fc7ec12',
    'dtbo_a':        '30b4002ab717077c873ef8bd0961d35efa449ac2d8e8a9324bbe41dfd16e9795',
    'dtbo_b':        '30b4002ab717077c873ef8bd0961d35efa449ac2d8e8a9324bbe41dfd16e9795',
}


def sh_root(cmd, timeout=600):
    r = subprocess.run([ADB, '-s', SERIAL, 'shell', cmd], capture_output=True, timeout=timeout)
    return ((r.stdout or b'') + (r.stderr or b'')).decode('utf-8', 'replace')


print('=' * 90)
print('PARTITION STATE vs THE PROJECT STARTING STATE')
print('=' * 90)
print('%-16s %-18s %-18s %s' % ('partition', 'on device', 'expected', 'verdict'))
print('-' * 90)

all_ok = True
for part, want in EXPECTED.items():
    out = sh_root("su -c 'sha256sum /dev/block/by-name/%s'" % part)
    got = None
    for line in out.splitlines():
        if part in line:
            got = line.split()[0]
            break
    ok = (got == want)
    if not ok:
        all_ok = False
    print('%-16s %-18s %-18s %s'
          % (part, (got or '?')[:16], want[:16], 'OK' if ok else '*** MISMATCH ***'))

print()
print('=' * 90)
print('ROOT / SLOT STATE')
print('=' * 90)
print('  slot_suffix      : %s' % sh_root('getprop ro.boot.slot_suffix').strip())
print('  boot_completed   : %s' % sh_root('getprop sys.boot_completed').strip())
print('  kernel           : %s' % sh_root('uname -r').strip())
print('  su present       : %s' % sh_root('su -c id').strip()[:80])
print('  verifiedbootstate: %s' % sh_root('getprop ro.boot.verifiedbootstate').strip())

print()
print('=' * 90)
print('OTHER BACKED-UP PARTITIONS (should be untouched)')
print('=' * 90)
for f in sorted(os.listdir(BACKUP)):
    if not f.endswith('.img'):
        continue
    part = f[:-4]
    if part in EXPECTED:
        continue
    local = os.path.join(BACKUP, f)
    want = hashlib.sha256(open(local, 'rb').read()).hexdigest()
    out = sh_root("su -c 'sha256sum /dev/block/by-name/%s'" % part)
    got = None
    for line in out.splitlines():
        if part in line:
            got = line.split()[0]
            break
    if got is None:
        print('  %-18s (no such partition or unreadable)' % part)
        continue
    print('  %-18s %s' % (part, 'OK' if got == want else '*** DIFFERS ***'))

print()
print('=' * 90)
print('SUMMARY')
print('=' * 90)
print('  A slot: KernelSU root  -> boot_a = 742105c6...')
print('  B slot: stock          -> boot_b = d9cf0ea6..., vendor_boot_b = e085f83a..., dtbo_b = 30b4002a...')
print()
if all_ok:
    print('  RESULT: device matches the project starting state.')
else:
    print('  RESULT: some partitions differ -- restore them from backup/.')

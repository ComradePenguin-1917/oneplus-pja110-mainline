#!/bin/bash
set -euo pipefail
ROOT="$HOME/workspace/PJA110-Mainline"
OUT=/mnt/h/workspace/PJA110-Mainline/out/pmbootstrap-wsl-probe-20261015
export PYTHONPATH="$OUT/python-deps${PYTHONPATH:+:$PYTHONPATH}"
cd "$ROOT/pmbootstrap"
python3 pmbootstrap.py --version > "$OUT/pmbootstrap-version.txt" 2>&1
python3 pmbootstrap.py --help > "$OUT/pmbootstrap-help.txt" 2>&1
cat "$OUT/pmbootstrap-version.txt"
grep -R -n -E '2\.46|WSL|is_wsl|kpartx|sudo.*-n' pmb/helpers pmb/config > "$OUT/host-requirements-source.txt" || true
echo 'PASS: pmbootstrap version/help run as normal WSL user'

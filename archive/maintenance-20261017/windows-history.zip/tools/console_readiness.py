#!/usr/bin/env python3
"""CONSOLE READINESS: why might our kernel print nothing even if it boots?

`earlycon` with no arguments does NOT take an address -- it resolves the UART
from the device tree's /chosen/stdout-path. And `console=ttyMSM0` needs the
qcom_geni_serial driver, which needs clocks/pinctrl, i.e. much later.

So if our DTB lacks a usable /chosen/stdout-path, we lose BOTH the early console
and the normal one, and a perfectly healthy kernel looks completely dead.

Check every link in that chain on the artefacts we actually flash.
"""
import os
import struct
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
sys.path.insert(0, os.path.join(WS, 'tools'))
from fdt import FDT


def dec(v):
    return v.rstrip(b'\0').decode('ascii', 'replace')


def regs(v):
    out = []
    for i in range(0, len(v) - 15, 16):
        out.append(struct.unpack_from('>QQ', v, i))
    return out


print('=' * 78)
print('1) OUR DTB: /chosen/stdout-path and the serial0 alias')
print('=' * 78)
ours = FDT(open(os.path.join(WS, 'dts', 'sm8550-oneplus-xigua-16G.dtb'), 'rb').read()).nodes()

chosen = ours.get('/chosen', {})
print('  /chosen properties: %s' % sorted(chosen))
sp = chosen.get('stdout-path') or chosen.get('linux,stdout-path')
print('  stdout-path : %r' % (dec(sp) if sp else '*** ABSENT ***'))
ba = chosen.get('bootargs')
print('  bootargs    : %r' % (dec(ba) if ba else '(none)'))

aliases = ours.get('/aliases', {})
print()
print('  /aliases entries: %d' % len(aliases))
for k in sorted(aliases):
    if 'serial' in k or 'uart' in k:
        print('    %-14s -> %s' % (k, dec(aliases[k])))

print()
print('=' * 78)
print('2) THE UART NODE ITSELF')
print('=' * 78)
uart_nodes = [p for p in ours if 'serial@' in p or 'uart' in p.lower()]
for p in sorted(uart_nodes)[:6]:
    props = ours[p]
    c = props.get('compatible')
    st = props.get('status')
    r = props.get('reg')
    print('  %s' % p)
    print('      compatible: %s' % (dec(c).replace('\0', ' | ') if c else '(none)'))
    print('      status    : %s' % (dec(st) if st else '(none)'))
    if r:
        for b, s in regs(r):
            print('      reg       : 0x%x+0x%x' % (b, s))

print()
print('=' * 78)
print('3) WHAT THE VENDOR TREE DOES (for comparison)')
print('=' * 78)
vend = FDT(open(os.path.join(WS, 'live-from-device.dtb'), 'rb').read()).nodes()
vc = vend.get('/chosen', {})
print('  vendor /chosen: %s' % sorted(vc))
vsp = vc.get('stdout-path') or vc.get('linux,stdout-path')
print('  vendor stdout-path: %r' % (dec(vsp) if vsp else '(absent)'))
va = vend.get('/aliases', {})
for k in sorted(va):
    if 'serial' in k:
        print('    %-14s -> %s' % (k, dec(va[k])))

print()
print('=' * 78)
print('4) KERNEL CONFIG: is the console driver even built in?')
print('=' * 78)
cfg = os.path.join(WS, 'out', 'config-6.14-xigua')
vals = {}
if os.path.exists(cfg):
    for l in open(cfg, encoding='utf-8', errors='replace'):
        l = l.strip()
        if '=' in l and not l.startswith('#'):
            k, v = l.split('=', 1)
            vals[k] = v
        elif l.startswith('# ') and 'is not set' in l:
            vals[l[2:].split(' ')[0]] = 'NOT SET'
else:
    print('  config not found at %s' % cfg)

for k in ('CONFIG_SERIAL_QCOM_GENI', 'CONFIG_SERIAL_QCOM_GENI_CONSOLE',
          'CONFIG_SERIAL_EARLYCON', 'CONFIG_SERIAL_AMBA_PL011',
          'CONFIG_SERIAL_AMBA_PL011_CONSOLE', 'CONFIG_SERIAL_CORE',
          'CONFIG_SERIAL_CORE_CONSOLE', 'CONFIG_TTY', 'CONFIG_VT',
          'CONFIG_PRINTK', 'CONFIG_ARM64_APPENDED_DTB'):
    print('  %-38s %s' % (k, vals.get(k, '(absent)')))

print()
print('=' * 78)
print('5) THE CMDLINE WE PACK')
print('=' * 78)
import subprocess
b = open(os.path.join(WS, 'out', 'boot_b-poweroff.img'), 'rb').read()
print('  boot_b-poweroff.img cmdline: %r' % b[44:44 + 1536].rstrip(b'\0').decode())
print('  vendor_boot cmdline        : %r'
      % open(os.path.join(WS, 'vendor_boot-A14.img'), 'rb').read()[28:28 + 2048].rstrip(b'\0').decode())

print()
print('=' * 78)
print('VERDICT')
print('=' * 78)
if sp:
    print('  our DTB HAS stdout-path = %r' % dec(sp))
    print('  -> earlycon with no argument should resolve the UART')
else:
    print('  *** our DTB has NO stdout-path ***')
    print('  -> bare `earlycon` on the cmdline cannot find a UART, so there is')
    print('     NO early output at all. That alone would make a healthy kernel')
    print('     look completely dead.')
print()
print('  Recommendation: put an EXPLICIT earlycon on the cmdline with the UART')
print('  address, so output does not depend on the device tree at all:')
print('     earlycon=qcom_geni,0xa9c000   (uart7 / serial0 on this board)')

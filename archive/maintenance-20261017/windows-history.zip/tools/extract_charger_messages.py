﻿from pathlib import Path
import struct
out=[]
for p in Path('out/native-install-20261017/charger-a-logs/var/log/journal').rglob('system*.journal'):
 b=p.read_bytes();pos=struct.unpack_from('<Q',b,88)[0];out.append('FILE '+p.name)
 while pos+16<=len(b):
  typ,flags,size=struct.unpack_from('<BB6xQ',b,pos)
  if size<16 or pos+size>len(b):break
  if typ==1 and flags==0:
   payload=b[pos+72:pos+size].decode(errors='replace')
   if payload.startswith('MESSAGE='):out.append(payload[8:])
  pos+=(size+7)&~7
Path('out/native-install-20261017/charger-journal-messages.txt').write_text('\n'.join(out),encoding='utf-8')
for s in out:
 if any(k in s.lower() for k in ['adsp','remoteproc','glink','firmware','charger','panic','fatal','watchdog','reboot','shutdown','q6v5','battery','powering']):print(s)

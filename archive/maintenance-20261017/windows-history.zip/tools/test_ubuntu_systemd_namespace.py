"""Boot installed systemd as namespace PID1 while keeping host debug PID1."""
import subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];out=ROOT/'out/ubuntu-systemd-20261014'
keys=ROOT/'out/usb-ncm-20261013/ssh'
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(keys/'client_key_host'),
 '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
 '-o',f'UserKnownHostsFile={keys/"known_hosts"}','-o','ConnectTimeout=5','root@169.254.42.1']
def run(cmd,data=None,timeout=20):
 p=subprocess.run(ssh+[cmd],input=data,capture_output=True,timeout=timeout)
 (out/'namespace-last-stderr.txt').write_bytes(p.stderr);p.check_returncode();return p.stdout
setup='''set -e
r=/tmp/ubuntu-systemd
sed 's/Port 2222/Port 2223/' "$r/etc/ssh/sshd_config_pja" > "$r/etc/ssh/sshd_config_validation"
cat > "$r/etc/systemd/system/pja-validation-ssh.service" <<'EOF'
[Unit]
Description=Isolated systemd PID1 SSH validation
After=basic.target
[Service]
Type=simple
RuntimeDirectory=sshd
ExecStart=/usr/sbin/sshd -D -e -f /etc/ssh/sshd_config_validation
EOF
cat > "$r/etc/systemd/system/pja-validation.target" <<'EOF'
[Unit]
Description=Isolated systemd boot validation
Requires=basic.target
After=basic.target
Wants=pja-validation-ssh.service
AllowIsolate=yes
EOF
mkdir -p /sys/fs/cgroup
grep -q ' /sys/fs/cgroup cgroup2 ' /proc/mounts || mount -t cgroup2 none /sys/fs/cgroup
mkdir -p /sys/fs/cgroup/pja-validation
'''
run(setup)
script='''#!/bin/sh
set -eu
echo $$ > /sys/fs/cgroup/pja-validation/cgroup.procs
exec chroot /tmp/ubuntu-systemd /usr/bin/unshare --mount --pid --fork --uts --ipc --cgroup --propagation private /bin/sh -c '
mount -t proc proc /proc
mount -t tmpfs -o mode=755 tmpfs /run
mount -t sysfs sysfs /sys
mount -t cgroup2 none /sys/fs/cgroup
exec /usr/bin/env container=pja SYSTEMD_LOG_TARGET=console /sbin/init --unit=pja-validation.target
'
'''
run('cat > /tmp/pja-systemd-namespace.sh; chmod 700 /tmp/pja-systemd-namespace.sh',script.encode())
pid=run('nohup /tmp/pja-systemd-namespace.sh > /tmp/pja-systemd-namespace.log 2>&1 < /dev/null & echo $!')
(out/'namespace-launch.txt').write_bytes(pid)
time.sleep(5)
(out/'namespace-console.txt').write_bytes(run('cat /tmp/pja-systemd-namespace.log'))
known=out/'namespace-known_hosts'
known.write_text((out/'known_hosts').read_text().replace(':2222',':2223'))
client=ssh.copy();client[client.index(str(keys/'known_hosts'))] if False else None
client=[v.replace(str(keys/'known_hosts'),str(known)) for v in client]
client=client[:-1]+['-p','2223',client[-1]]
p=subprocess.run(client+['cat /proc/1/comm; systemctl is-active pja-validation.target pja-validation-ssh.service; systemctl --failed --no-pager; cat /proc/1/cgroup; cat /etc/os-release'],capture_output=True,timeout=20)
(out/'namespace-ssh.txt').write_bytes(p.stdout+p.stderr)
if p.returncode:raise RuntimeError('Isolated systemd SSH did not pass; inspect namespace console')
assert p.stdout.splitlines()[0]==b'systemd'
assert p.stdout.count(b'active\n')>=2
print('PASS: installed Ubuntu systemd is namespace PID1; target and SSH active, debug SSH retained')

"""Stage one OEM snapshot/watchdog pet and automatic module restoration."""
from pathlib import Path
import hashlib, subprocess
from prepare_native_install import SSH
args=SSH[:]; args[-1]='penguin@172.16.42.1'
args=[x if not x.startswith('UserKnownHostsFile=') else 'UserKnownHostsFile=out/native-install-20261017/known_hosts' for x in args]
out=Path('out/native-install-20261017/charger-watchdog-probe')
data=(out/'qcom_battmgr-watchdog.ko').read_bytes(); sha=hashlib.sha256(data).hexdigest()
script='''#!/bin/sh
set -eu
test "$(id -u)" = 0
mkdir /run/pja110-charger-watchdog-lock || exit 1
trap 'rmdir /run/pja110-charger-watchdog-lock' EXIT
cd /home/penguin/charger-watchdog-probe
exec > result.log 2>&1
chmod 644 result.log
test "$(uname -r)" = 6.14.0-oneplus-xigua
test "$(cat /sys/module/qcom_battmgr/parameters/pja110_charger_init)" = N
echo '@SHA@  qcom_battmgr-watchdog.ko' | sha256sum -c -
test -f /usr/local/lib/pja110/qcom_battmgr.ko
sample() {
 cat /proc/sys/kernel/random/boot_id /proc/uptime
 cat /sys/class/power_supply/bq28z610-0/uevent
 cat /sys/class/power_supply/qcom-battmgr-usb/uevent
}
restore() {
 if [ -d /sys/module/qcom_battmgr ]; then rmmod qcom_battmgr || return 1; fi
 insmod /usr/local/lib/pja110/qcom_battmgr.ko pja110_charger_init=0
 echo READONLY_MODULE_RESTORED
}
cleanup() { restore; rmdir /run/pja110-charger-watchdog-lock; }
sample
rmmod qcom_battmgr
trap cleanup EXIT
insmod ./qcom_battmgr-watchdog.ko
for i in $(seq 1 12); do
 result=$(cat /sys/module/qcom_battmgr/parameters/readback_result)
 [ "$result" = -115 ] || break
 sleep 1
done
echo OEM_SNAPSHOT_RESULT=$result
cat /sys/module/qcom_battmgr/parameters/snapshot_size /sys/module/qcom_battmgr/parameters/snapshot
restore
trap 'rmdir /run/pja110-charger-watchdog-lock' EXIT
for i in $(seq 1 6); do sample; sleep 5; done
echo WATCHDOG_ONESHOT_COMPLETE
'''.replace('@SHA@',sha)
(out/'probe.sh').write_bytes(script.encode())
def run(cmd,payload=None):
 p=subprocess.run(args+[cmd],input=payload,capture_output=True,timeout=30)
 print(p.stdout.decode(errors='replace')); print(p.stderr.decode(errors='replace')); p.check_returncode(); return p.stdout
v=run('umask 077; mkdir -p /home/penguin/charger-watchdog-probe; cat > /home/penguin/charger-watchdog-probe/qcom_battmgr-watchdog.ko; sha256sum /home/penguin/charger-watchdog-probe/qcom_battmgr-watchdog.ko',data)
assert v.decode().split()[0]==sha
run('cat > /home/penguin/probe-charger-watchdog.sh',script.encode())
run('sh -n /home/penguin/probe-charger-watchdog.sh')
p=subprocess.run(args+['sudo -n true'],capture_output=True,timeout=15)
print('Noninteractive sudo:',p.returncode==0); print(p.stderr.decode(errors='replace'))

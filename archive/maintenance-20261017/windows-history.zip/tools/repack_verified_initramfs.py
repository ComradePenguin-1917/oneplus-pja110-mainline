"""Install the verified static BusyBox and early console nodes into the archive."""
import gzip
import hashlib
import pathlib
import re
import struct

from build_init_marker_test import parse_cpio, make_entry

ROOT=pathlib.Path(__file__).resolve().parents[1]
OUT=ROOT/'out/rebuild-20261012'

def normalize(name):
    return name[2:] if name.startswith('./') else name

def main():
    source=ROOT/'initramfs/initramfs.cpio.gz'
    if not (OUT/'initramfs-before.cpio.gz').exists():
        (OUT/'initramfs-before.cpio.gz').write_bytes(source.read_bytes())
    entries=parse_cpio(gzip.decompress(source.read_bytes()))
    busybox=(OUT/'busybox').read_bytes()
    assert busybox[:4]==b'\x7fELF' and struct.unpack_from('<H',busybox,18)[0]==183
    phoff=struct.unpack_from('<Q',busybox,32)[0]
    phsize,phnum=struct.unpack_from('<HH',busybox,54)
    assert all(struct.unpack_from('<I',busybox,phoff+i*phsize)[0]!=3 for i in range(phnum))
    existing={normalize(n) for f,n,d in entries}
    applets=set((OUT/'busybox-applets.txt').read_text().split())
    assert all(re.fullmatch(r'[A-Za-z0-9_\[\].+-]+',name) for name in applets)
    required={'sh','mount','ip','telnetd','udhcpd','poweroff','sleep','setsid','uname','basename','cat','tr','ls','rm','mkdir','ln'}
    assert required<=applets, required-applets
    nextino=max(f[0] for f,n,d in entries)+1
    result=bytearray()
    replaced=0
    for fields,name,data in entries:
        if name=='TRAILER!!!':
            for applet in sorted(applets):
                path='bin/'+applet
                if path not in existing:
                    fields_new=[nextino,0o120777,0,0,1,0,0,0,0,0,0,0,0]
                    result+=make_entry(fields_new,path,b'busybox')
                    nextino+=1
            for path,major,minor,mode in [('dev/console',5,1,0o20600),('dev/null',1,3,0o20666)]:
                if path not in existing:
                    fields_new=[nextino,mode,0,0,1,0,0,0,0,major,minor,0,0]
                    result+=make_entry(fields_new,path,b'')
                    nextino+=1
        if normalize(name)=='bin/busybox':
            fields=list(fields)
            fields[1]=0o100755
            data=busybox
            replaced+=1
        result+=make_entry(fields,name,data)
    assert replaced==1
    rebuilt=parse_cpio(bytes(result))
    mapping={normalize(n):(f,d) for f,n,d in rebuilt}
    assert rebuilt[-1][1]=='TRAILER!!!'
    assert mapping['init'][1]==(ROOT/'initramfs/init').read_bytes()
    assert mapping['bin/busybox'][1]==busybox
    assert mapping['bin/sh'][1]==b'busybox'
    for applet in required:
        assert mapping['bin/'+applet][1]==b'busybox', applet
    for path,major,minor in [('dev/console',5,1),('dev/null',1,3)]:
        f,d=mapping[path]
        assert (f[1]&0o170000)==0o20000 and f[9:11]==[major,minor]
    compressed=gzip.compress(bytes(result),compresslevel=9,mtime=0)
    (OUT/'initramfs.cpio.gz').write_bytes(compressed)
    source.write_bytes(compressed)
    print('Verified archive entries:',len(rebuilt))
    print('BusyBox SHA256:',hashlib.sha256(busybox).hexdigest())
    print('Archive SHA256:',hashlib.sha256(compressed).hexdigest())
    print('Early console and null device nodes verified.')

if __name__=='__main__':
    main()

"""Bounded capture using standard trace events in a private trace instance."""
import argparse, subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'out/display-timing-20261014/runtime'
parser=argparse.ArgumentParser()
parser.add_argument('--label', choices=('repaint1', 'repaint7', 'ruler-single'))
args=parser.parse_args()
if args.label:
 OUT=OUT/args.label
OUT.mkdir(parents=True,exist_ok=True)
KEYS=ROOT/'out/usb-ncm-20261013/ssh'
SSH=['C:/Windows/System32/OpenSSH/ssh.exe','-F','none','-T','-i',str(KEYS/'client_key_host'),
 '-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
 '-o',f'UserKnownHostsFile={KEYS/"known_hosts"}','-o','ConnectTimeout=5','root@169.254.42.1']
def read(cmd,timeout=35):
 p=subprocess.run(SSH+[cmd],capture_output=True,timeout=timeout)
 (OUT/'last-stderr.txt').write_bytes(p.stderr)
 p.check_returncode()
 return p.stdout
script='''set -e
root=/sys/kernel/tracing
test -e "$root/available_events"
t=$root/instances/pja_display
mkdir -p "$t"
echo 0 > "$t/tracing_on"
echo 0 > "$t/events/enable"
echo nop > "$t/current_tracer"
echo 2048 > "$t/buffer_size_kb"
echo mono > "$t/trace_clock"
echo > "$t/trace"
for event in dpu_enc_kickoff dpu_enc_prepare_kickoff dpu_enc_trigger_start dpu_enc_trigger_flush dpu_enc_phys_cmd_pp_tx_done dpu_crtc_vblank dpu_crtc_vblank_cb dpu_crtc_complete_flip dpu_enc_underrun_cb dpu_enc_frame_done_timeout dpu_enc_wait_event_timeout tracing_mark_write; do
  test -e "$t/events/dpu/$event/enable"
  echo 1 > "$t/events/dpu/$event/enable"
done
trap 'echo 0 > "$t/tracing_on"; echo 0 > "$t/events/enable"' EXIT
echo 1 > "$t/tracing_on"
sleep 8
echo 0 > "$t/tracing_on"
cat "$t/trace"
'''
(OUT/'frame-events.txt').write_bytes(read(script,25))
(OUT/'trace-buffer-stats.txt').write_bytes(read('cat /sys/kernel/tracing/instances/pja_display/per_cpu/cpu*/stats'))
(OUT/'state.txt').write_bytes(read('uname -a; cat /sys/kernel/debug/dri/0/debug/core_irq; cat /sys/kernel/debug/dri/0/state; dmesg'))
(OUT/'kms-registers.txt').write_bytes(read('cat /sys/kernel/debug/dri/0/kms'))
print('Saved eight-second DPU timing capture; private tracing disabled afterwards')

#!/usr/bin/env python3
"""Verify that slot B is a complete, pristine stock slot.

This matters a lot: if slot B is intact stock, we can test our vendor_boot patch
on slot B ONLY, leaving the working slot A untouched. If the experiment goes
wrong we simply switch the active slot back.

Check every piece of slot B against the OTA package.
"""
import hashlib
import os
import shutil
import subprocess

ADB = shutil.which('adb') or r'C:\platform-tools\adb.exe'
WS = r'H:\WorkSpace\PJA110-Mainline'
SERIAL = 'bc7a542e'

PARTS = ('boot_b', 'vendor_boot_b', 'dtbo_b', 'init_boot_b')
OTA = {
    'boot_b': 'boot-A14.img',
    'vendor_boot_b': 'vendor_boot-A14.img',
    'dtbo_b': 'dtbo-A14.img',
    'init_boot_b': 'init_boot-A14.img',
}


def sha_file(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def dev_hash(part):
    r = subprocess.run([ADB, '-s', SERIAL, 'shell',
                        'su -c "sha256sum /dev/block/by-name/%s"' % part],
                       capture_output=True)
    out = (r.stdout or b'').decode('utf-8', 'replace')
    for line in out.splitlines():
        if part in line:
            return line.split()[0]
    return None


print('=' * 78)
print('SLOT B: is it pristine stock? (compare against the OTA package)')
print('=' * 78)
print('%-16s %-18s %-18s %s' % ('partition', 'on-device', 'OTA package', 'verdict'))
print('-' * 78)

results = {}
for part in PARTS:
    d = dev_hash(part)
    ota_name = OTA[part]
    ota_path = os.path.join(WS, ota_name)
    if not os.path.exists(ota_path):
        print('%-16s %-18s %-18s %s' % (part, (d or '?')[:16], '(no OTA file)', '?'))
        continue
    o = sha_file(ota_path)
    verdict = 'MATCH (pristine)' if d == o else 'differs'
    results[part] = (d, o, d == o)
    print('%-16s %-18s %-18s %s' % (part, (d or '?')[:16], o[:16], verdict))

print()
print('=' * 78)
print('SLOT A (the working slot) for contrast')
print('=' * 78)
for part in ('boot_a', 'vendor_boot_a', 'dtbo_a', 'init_boot_a'):
    d = dev_hash(part)
    ota_name = OTA.get(part.replace('_a', '_b'))
    o = sha_file(os.path.join(WS, ota_name)) if ota_name and os.path.exists(os.path.join(WS, ota_name)) else None
    mark = 'stock' if (o and d == o) else 'MODIFIED'
    print('%-16s %-18s %s' % (part, (d or '?')[:16], mark))

print()
print('=' * 78)
print('CONSEQUENCE')
print('=' * 78)
all_pristine = all(v[2] for v in results.values()) and len(results) == 4
if all_pristine:
    print('  Slot B is a COMPLETE pristine stock slot.')
    print()
    print('  => We can run the vendor_boot experiment on slot B only:')
    print('       1. flash patched image to vendor_boot_b   (slot A untouched)')
    print('       2. fastboot set_active b')
    print('       3. boot; read /sys/firmware/devicetree/base/model')
    print('       4. fastboot set_active a   (instant, complete rollback)')
    print('     A failure costs a slot switch, not a 192 MiB restore.')
else:
    print('  Slot B is NOT fully stock; the safe experiment above would need')
    print('  restoring the OTA images first (all available).')
    for part, (d, o, same) in results.items():
        if not same:
            print('    %s differs -> flash %s to restore' % (part, OTA[part]))

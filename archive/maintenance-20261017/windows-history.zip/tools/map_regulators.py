#!/usr/bin/env python3
"""Map the vendor's PMIC regulator names to the mainline labels used in our DTS.

The live device tree uses vendor names (pm_humu_l17, pm_v6g_l1, pm_v6d_l1,
pm_v6e_l3, pm_v6e_l1, pm_humu_l15, pm_humu_l5). Upstream sm8550.dtsi / our
board DTS use the vreg_* labels. This prints the correspondence for the
regulators that UFS and USB actually reference, using the LIVE device as truth.
"""

# Mapping established from upstream pm8550*/pm8550vs* dtsi (pmic-id -> letter).
#   PM8550   (humu)  SID 1  -> pmic-id "b"  -> vreg_*b_*
#   PM8550VS SID 2 (c) / 3 (d) / 4 (e) / 6 (g) -> vreg_*c/d/e/g_*
#   PM8010   SID 12 (m) / 13 (n) -> vreg_*m_* / vreg_*n_*
PAIRS = [
    # (vendor regulator-name,        our mainline label,          used by)
    ('pm_humu_l17',  'vreg_l17b_2p5',  'ufs_mem_hc vcc-supply'),
    ('pm_v6g_l1',    'vreg_l1g_1p2',   'ufs_mem_hc vccq-supply'),
    ('pm_v6g_l3',    '(not in our DTS)', 'ufs_mem_hc qcom,vddp-ref-clk-supply'),
    ('pm_v6g_s4',    '(not in our DTS)', 'ufs_mem_hc qcom,vccq-parent-supply'),
    ('pm_v6d_l1',    'vreg_l1d_0p88',  'ufs_mem_phy vdda-phy-supply'),
    ('pm_v6e_l3',    'vreg_l3e_1p2',   'ufs_mem_phy vdda-pll-supply'),
    ('pm_v6e_l1',    'vreg_l1e_0p88',  'ufs_mem_phy vdda-qref + usb_1_hsphy vdd'),
    ('pm_humu_l15',  'vreg_l15b_1p8',  'pm8550b_eusb2_repeater vdd18'),
    ('pm_humu_l5',   'vreg_l5b_3p1',   'pm8550b_eusb2_repeater vdd3'),
]

print('%-16s %-20s %s' % ('vendor name', 'our label', 'referenced by'))
print('-' * 78)
for v, m, u in PAIRS:
    print('%-16s %-20s %s' % (v, m, u))

print()
print('NOTES')
print('-----')
print('* vdd-hba-supply resolves to a GCC *GDSC* (gcc_ufs_phy_gdsc), not a PMIC')
print('  regulator. Upstream expresses the same thing as a power-domain via the')
print('  ufs_mem_hc node\'s power-domains; our DTS currently uses vreg_l3g_1p2')
print('  copied from the Ace 3 port -- worth aligning once we can build the kernel.')
print('* pm_v6g_l3 / pm_v6g_s4 are extra supplies the vendor kernel uses for UFS')
print('  reference clock and parent current. Mainline sm8550.dtsi does not declare')
print('  them; harmless to omit for bring-up (UFS still enumerates).')
print('* USB3_GDSC-supply -> gcc_usb30_prim_gdsc, likewise a GDSC.')
print()
print('=== verdict on our DTS values ===')
print('  reset-gpios  = GPIO 210   -> our DTS: <&tlmm 210 ...>   MATCH')
print('  vcc-supply   = pm_humu_l17-> our DTS: vreg_l17b_2p5     MATCH')
print('  vccq-supply  = pm_v6g_l1  -> our DTS: vreg_l1g_1p2      MATCH')
print('  vdda-phy     = pm_v6d_l1  -> our DTS: vreg_l1d_0p88     MATCH')
print('  vdda-pll     = pm_v6e_l3  -> our DTS: vreg_l3e_1p2      MATCH')
print('  hsphy vdd    = pm_v6e_l1  -> our DTS: vreg_l1e_0p88     MATCH')
print('  hsphy vdda12 = pm_v6e_l3  -> our DTS: vreg_l3e_1p2      MATCH')
print('  repeater 18  = pm_humu_l15-> our DTS: vreg_l15b_1p8     MATCH')
print('  repeater 3   = pm_humu_l5 -> our DTS: vreg_l5b_3p1      MATCH')

/* SPDX-License-Identifier: GPL-2.0-only */
#include <errno.h>
#include <fcntl.h>
#include <linux/fb.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <unistd.h>

int main(int argc, char **argv)
{
    int fd = open("/dev/fb0", O_RDWR);
    struct fb_var_screeninfo v;
    struct fb_fix_screeninfo f;
    uint8_t *map;
    const unsigned rgb[6][3] = {{255,0,0},{0,255,0},{0,0,255},{255,255,255},{128,128,128},{0,0,0}};
    if (fd < 0 || ioctl(fd, FBIOGET_VSCREENINFO, &v) || ioctl(fd, FBIOGET_FSCREENINFO, &f)) {
        perror("framebuffer metadata"); return 1;
    }
    if (argc==2 && (!strcmp(argv[1],"--blank") || !strcmp(argv[1],"--unblank"))) {
        int blank = !strcmp(argv[1],"--blank") ? FB_BLANK_POWERDOWN : FB_BLANK_UNBLANK;
        if (ioctl(fd,FBIOBLANK,blank)) { perror("framebuffer blank state");close(fd);return 4; }
        puts(blank == FB_BLANK_POWERDOWN ? "Framebuffer powered down" : "Framebuffer enabled");
        close(fd);return 0;
    } else if (argc==2 && !strcmp(argv[1],"--cycle")) {
        if (ioctl(fd,FBIOBLANK,FB_BLANK_POWERDOWN)) { perror("powerdown"); return 4; }
        usleep(100000);
        if (ioctl(fd,FBIOBLANK,FB_BLANK_UNBLANK)) { perror("unblank"); return 5; }
        puts("Framebuffer disabled and re-enabled for panel initialization");
    } else if (argc!=1) {
        fprintf(stderr,"use no arguments or --cycle, --blank, --unblank\n"); return 6;
    }
    printf("fb0 %ux%u virtual=%ux%u bpp=%u stride=%u memory=%u RGB offsets=%u/%u/%u\n",
           v.xres,v.yres,v.xres_virtual,v.yres_virtual,v.bits_per_pixel,f.line_length,f.smem_len,
           v.red.offset,v.green.offset,v.blue.offset);
    if (v.bits_per_pixel != 32 || v.red.length!=8 || v.green.length!=8 || v.blue.length!=8 ||
        v.red.offset>24 || v.green.offset>24 || v.blue.offset>24 ||
        !v.xres || !v.yres || v.xoffset+v.xres>v.xres_virtual || v.yoffset+v.yres>v.yres_virtual ||
        (uint64_t)(v.xoffset+v.xres)*4>f.line_length ||
        (uint64_t)(v.yoffset+v.yres)*f.line_length>f.smem_len) {
        fprintf(stderr,"Unsupported or unsafe framebuffer layout\n"); return 2;
    }
    map=mmap(NULL,f.smem_len,PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);
    if (map==MAP_FAILED) { perror("framebuffer mmap"); return 3; }
    for (unsigned y=0;y<v.yres;y++) {
        uint32_t *row=(uint32_t *)(map+(y+v.yoffset)*f.line_length);
        for (unsigned x=0;x<v.xres;x++) {
            unsigned band=(uint64_t)x*6/v.xres;
            row[x+v.xoffset]=(rgb[band][0]<<v.red.offset)|(rgb[band][1]<<v.green.offset)|(rgb[band][2]<<v.blue.offset);
        }
    }
    /* Re-submit unchanged mode/pan to trigger an explicit DRM fbdev update. */
    v.activate=FB_ACTIVATE_NOW;
    if (ioctl(fd,FBIOPAN_DISPLAY,&v)) perror("framebuffer pan update");
    if (ioctl(fd,FBIOBLANK,FB_BLANK_UNBLANK)) perror("framebuffer unblank");
    munmap(map,f.smem_len);close(fd);
    puts("Six vertical color bars written to RAM framebuffer");
    return 0;
}

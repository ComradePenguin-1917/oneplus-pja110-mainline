#!/usr/bin/env python3
"""Map the dtbo_a partition and learn the Android DTBO image format.

Why: we established
  * the base device tree comes from vendor_boot's dtb section
  * the dtbo partition is applied as OVERLAYS on top of it
  * our DTB exports only ~9.5% of the labels those overlays need

So if we swap the base tree we must also deal with the overlays. The clean
approach is to supply a dtbo that applies nothing, which requires understanding
the exact container format ABL expects.

The dtbo partition is an Android "dt_table" image:
    magic 0xd7b7ab1e, total_size, header_size, entry_size, entry_count,
    entries (dt_entry: dtb_size, dtb_offset, id, rev, custom[4]),
    then the dtb blobs, each padded to 4 bytes... but vendor variants exist.
Read the real thing.
"""
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fdt import FDT

WS = r'H:\WorkSpace\PJA110-Mainline'

p = os.path.join(WS, 'backup', 'dtbo_a.img')
b = open(p, 'rb').read()
print('=== dtbo_a partition ===')
print('  device-size : %d (%.1f MiB)' % (len(b), len(b)/2**20))

magic = struct.unpack_from('>I', b, 0)[0]
print('  first u32   : 0x%08x' % magic)
print('  dt_table?   : %s' % (magic == 0xD7B7AB1E))

if magic != 0xD7B7AB1E:
    sys.exit('unexpected dtbo partition magic')

total_size, header_size, entry_size, entry_count = struct.unpack_from('>4I', b, 4)
print()
print('  total_size  : %d' % total_size)
print('  header_size : %d' % header_size)
print('  entry_size  : %d' % entry_size)
print('  entry_count : %d' % entry_count)

print()
print('=== entries ===')
entries = []
for i in range(entry_count):
    off = header_size + i * entry_size
    dsize, doff, ident, rev = struct.unpack_from('>4I', b, off)
    custom = b[off+16:off+16+16]
    entries.append((dsize, doff, ident, rev))
    print('  [%d] dtb_size=%-8d offset=%-8d id=0x%08x rev=0x%08x custom=%s'
          % (i, dsize, doff, ident, rev, custom.hex()))

print()
print('=== decode id (msm-id / board-id packing) ===')
for i, (dsize, doff, ident, rev) in enumerate(entries):
    # Android packs id as: (msm_id << 32) | (board_id << 16) | ...
    hi = (ident >> 16) & 0xFFFF
    lo = ident & 0xFFFF
    print('  [%d] id=0x%08x -> hi=0x%x lo=0x%x' % (i, ident, hi, lo))

print()
print('=== the DTBs ===')
for i, (dsize, doff, ident, rev) in enumerate(entries):
    blob = b[doff:doff+dsize]
    ok = blob[:4] == b'\xd0\x0d\xfe\xed'
    print('  [%d] off=%-8d size=%-8d fdt_magic=%s' % (i, doff, dsize, ok))
    if ok:
        f = FDT(blob)
        n = f.nodes()
        root = n.get('/', {})
        frags = [q for q in n if q.count('/') == 1 and q.lstrip('/').startswith('fragment@')]
        fx = n.get('/__fixups__', {})
        sy = n.get('/__symbols__', {})
        print('         nodes=%d fragments=%d __fixups__=%d __symbols__=%d'
              % (len(n), len(frags), len(fx), len(sy)))

print()
print('=== what a minimal/empty dt_table would look like ===')
print('  header (32 bytes): magic, total_size, header_size, entry_size, entry_count')
print('  with entry_count=0 and total_size=header_size, the image is just the header.')
print('  Android mkdtimg accepts an image with 0 entries; the question is whether')
print('  ABL treats that as "no overlays" (good) or "invalid dtbo" (bad).')

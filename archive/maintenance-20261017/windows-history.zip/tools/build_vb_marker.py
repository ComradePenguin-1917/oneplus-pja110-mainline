#!/usr/bin/env python3
"""Build the vendor_boot marker test image using WSL's fdtput.

The Windows fdtput crashed (0xC0000005), so the marker add is delegated to WSL.
Everything else (layout, padding, verification) stays in this script.

Goal of the test image: keep the VENDOR's own base device tree (entry 0 of
vendor_boot's dtb section, the one matching msm-id 0x207 0x20000), add a single
marker property to its root, and leave everything else byte-identical.

If the phone boots with this image and we can read the marker at
/sys/firmware/devicetree/base/xigua-vb-marker, we will have proven:
   1. writing vendor_boot's dtb section is safe and effective
   2. ABL really does use entry 0 as the base tree for this device
   3. overlays still resolve (the tree is otherwise the vendor's), so the boot
      stays healthy
That is exactly the prerequisite for swapping in our own tree.
"""
import hashlib
import os
import struct
import subprocess
import sys

WS = r'H:\WorkSpace\PJA110-Mainline'
WSL_WS = '/mnt/h/WorkSpace/PJA110-Mainline'
PAGE = 4096
SRC = os.path.join(WS, 'backup', 'vendor_boot_a.img')
OUT = os.path.join(WS, 'out', 'vendor_boot_a-marker.img')
WORK = os.path.join(WS, 'out', '_vbmark')
MARK = 'XIGUA_VB_MARKER_5e1d'

os.makedirs(WORK, exist_ok=True)

v = bytearray(open(SRC, 'rb').read())
hsize, dtbsize = struct.unpack_from('<2I', v, 28+2048+4+16)
vrsize = struct.unpack_from('<I', v, 24)[0]
dtb_off = (((hsize+PAGE-1)//PAGE)*PAGE + vrsize + PAGE-1)//PAGE*PAGE
e0_size = struct.unpack_from('>I', v, dtb_off+4)[0]

print('=== source ===')
print('  dtb section @0x%x, entry0 slot = %d bytes' % (dtb_off, e0_size))

# 1) extract entry 0 verbatim into the work dir (Windows side)
p_dtb = os.path.join(WORK, 'entry0.dtb')
open(p_dtb, 'wb').write(bytes(v[dtb_off:dtb_off+e0_size]))

# 2) add the marker via WSL fdtput
wsl_dtb = '%s/out/_vbmark/entry0.dtb' % WSL_WS
cmd = ("cd %s && cp entry0.dtb entry0.orig.dtb && "
       "fdtput -t s entry0.dtb / xigua-vb-marker %s && "
       "echo '--- read back:' && fdtget -t s entry0.dtb / xigua-vb-marker && "
       "echo '--- size:' && stat -c%%s entry0.dtb && "
       "echo '--- orig size:' && stat -c%%s entry0.orig.dtb"
       % ('%s/out/_vbmark' % WSL_WS, MARK))
r = subprocess.run(['wsl.exe', '-d', 'Ubuntu-22.04', '--', 'bash', '-lc', cmd],
                   capture_output=True)
out = (r.stdout or b'').decode('utf-8', 'replace')
err = (r.stderr or b'').decode('utf-8', 'replace')
print('  WSL fdtput output:')
for line in (out + err).splitlines():
    if 'N/e' in line or 'localh' in line:
        continue
    print('    %s' % line.strip())

marked = open(p_dtb, 'rb').read()
print('  marked tree size: %d' % len(marked))
if len(marked) > e0_size:
    sys.exit('marked tree (%d) does not fit the slot (%d)!' % (len(marked), e0_size))

# 3) pad to exactly the slot size
padded = bytearray(marked) + b'\0' * (e0_size - len(marked))
struct.pack_into('>I', padded, 4, e0_size)

# 4) sanity checks
sys.path.insert(0, os.path.join(WS, 'tools'))
from fdt import FDT
f = FDT(bytes(padded))
root = f.nodes()['/']
got = root.get('xigua-vb-marker', b'').rstrip(b'\0').decode()
print('  parses OK: model=%s nodes=%d' % (root.get('model', b'').rstrip(b'\0').decode(), len(f.nodes())))
print('  marker present: %s (%r)' % (got == MARK, got))
if got != MARK:
    sys.exit('marker did not survive the rebuild')

# 5) splice in, changing nothing else
before_header = bytes(v[:dtb_off])
before_tail = bytes(v[dtb_off+e0_size:])
v[dtb_off:dtb_off+e0_size] = bytes(padded)
open(OUT, 'wb').write(bytes(v))
w = open(OUT, 'rb').read()

print()
print('=== verify layout ===')
print('  header+ramdisk untouched : %s' % (w[:dtb_off] == before_header))
print('  after entry0 untouched   : %s' % (w[dtb_off+e0_size:] == before_tail))
print('  size unchanged           : %s' % (len(w) == len(v)))
print('  offsets unchanged        : header_size=%d dtb_off=0x%x' % (hsize, dtb_off))
print('  dtb_size field unchanged : %s' % (struct.unpack_from('<I', w, 28+2048+4+16+4)[0] == dtbsize))

off = dtb_off
for i in range(4):
    total = struct.unpack_from('>I', w, off+4)[0]
    fj = FDT(w[off:off+total])
    rr = fj.nodes()['/']
    extra = ''
    if i == 0:
        extra = '   <== MARKER: %s' % rr.get('xigua-vb-marker', b'').rstrip(b'\0').decode()
    print('  entry%d @0x%06x size=%-7d %s%s' % (
        i, off, total, rr.get('model', b'').rstrip(b'\0').decode()[:36], extra))
    off += total
print('  walk closed: %s' % (off == dtb_off + dtbsize))

print()
print('  original sha256: %s' % hashlib.sha256(open(SRC, 'rb').read()).hexdigest())
print('  patched  sha256: %s' % hashlib.sha256(w).hexdigest())
print()
print('wrote %s' % OUT)
print('NOT FLASHED.')

#!/usr/bin/env python3
"""Generate the final xigua reserved-memory worklist (docs/resmem-worklist.md).

Facts established from the vendor images (all verified with tools/):

  * vendor_boot-A14.img holds 4 base SoC DTBs; their memory maps are IDENTICAL,
    so the map does not vary with RAM size within this firmware version.
  * dtbo-A14.img overlays carry NO reserved-memory fragments -> every
    reservation comes from the base DTB.
  * rmtfs is declared via the QCOM-private `qcom,sharedmem-uio` binding
    (/soc/qcom,rmtfs_sharedmem@0, size 0x280000). The address 0xd4a80000 that
    upstream uses is FREE on xigua and immediately precedes mpss_dsm
    (0xd4d00000), i.e. 0xd4a80000 + 0x280000 == 0xd4d00000. So upstream's
    rmtfs_mem is correct for this device and must NOT be deleted.
  * upstream ta_mem / tz_tags_mem / hyp_tags_mem / hyp_ext_* genuinely do not
    exist here.
"""
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fdt import scan_for_fdt
from resmem import parse as parse_dts

WS = r'H:\WorkSpace\PJA110-Mainline'
UP = os.path.join(WS, 'research', 'upstream', 'sm8550.dtsi')
RMFFS_BASE = 0xd4a80000          # upstream rmtfs_mem base; free on xigua
RMFFS_UP_LABEL = 'rmtfs_mem'


def norm(n):
    n = n.split('@')[0].lower()
    for suf in ('_region', '_mem', 'region', 'mem'):
        if n.endswith(suf):
            n = n[:-len(suf)]
    n = n.replace('-', '_').strip('_')
    return {'gunyah_hyp': 'hyp', 'hwfence_shbuf': 'hwfence',
            'hwfence_shmem': 'hwfence', 'spss_region': 'spss'}.get(n, n)


blob = open(os.path.join(WS, 'vendor_boot-A14.img'), 'rb').read()
_off, _sz, fdt = scan_for_fdt(blob, limit=8)[0]
nodes = fdt.nodes()

vendor = []
for p, props in nodes.items():
    if '/reserved-memory/' not in p + '/' or p.rstrip('/').endswith('/reserved-memory'):
        continue
    leaf = p.split('/')[-1]
    if 'reg' in props and len(props['reg']) == 16:
        b, s = struct.unpack('>QQ', props['reg'])
        if s:
            vendor.append({'name': leaf.split('@')[0], 'base': b, 'size': s})

_blk, up_raw = parse_dts(UP)
upstream = [u for u in up_raw if u['base'] is not None and u['size']]

vb = {v['base']: v for v in vendor}
ub = {u['base']: u for u in upstream}

same, resized, moved, only_up, only_ven, rmtfs_fix = [], [], [], [], [], []
for u in sorted(upstream, key=lambda x: x['base']):
    v = vb.get(u['base'])
    if v:
        (same if v['size'] == u['size'] else resized).append((u, v))
        continue
    if u['label'] == RMFFS_UP_LABEL:
        rmtfs_fix.append(u)          # present on device, just under another binding
        continue
    hit = next((c for c in vendor if norm(c['name']) == norm(u['label'])
                and c['base'] not in ub), None)
    (moved.append((u, hit)) if hit else only_up.append(u))
for v in sorted(vendor, key=lambda x: x['base']):
    if v['base'] not in ub and not any(m[1] is v for m in moved):
        only_ven.append(v)

mib = lambda n: '%.1f' % (n / 2**20)

L = []
A = L.append
A('# xigua (PJA110) reserved-memory 对齐工作清单\n')
A('用于编写 `sm8550-oneplus-xigua.dts`：把**厂商 A14 固件**的内存图和')
A('**上游 `sm8550.dtsi`** 逐项对齐。\n')
A('## 数据来源与匹配规则\n')
A('- 厂商侧：`vendor_boot-A14.img` 内的基础 SoC DTB')
A('  （4 个 DTB——Kalama/KalamaP × v1/v2——内存图**完全一致**）')
A('- 上游侧：`arch/arm64/boot/dts/qcom/sm8550.dtsi`')
A('- 匹配：**先按基址**（`reg` 权威），不中再按规范化节点名判断"搬家"')
A('- ⚠️ 厂商节点名里的地址是**陈旧的**：`mpss_region@89800000` 的实际 `reg` 是 `0x8a800000`。')
A('  **只信 `reg`，不要信节点名。**\n')
A('规模：厂商 **%d** 区 / %.1f MiB · 上游 **%d** 区 / %.1f MiB\n'
  % (len(vendor), sum(v['size'] for v in vendor) / 2**20,
     len(upstream), sum(u['size'] for u in upstream) / 2**20))
A('| 分类 | 数量 | 处理方式 |')
A('| :-- | --: | :-- |')
A('| 基址+大小完全一致 | %d | 不用动 |' % len(same))
A('| 同基址、大小不同 | %d | 覆盖 `reg` 的 size |' % len(resized))
A('| 同名但搬家 | %d | `/delete-node/` + 板级重加 |' % len(moved))
A('| 上游有、本机无 | %d | **`/delete-node/`** |' % len(only_up))
A('| 本机有、上游无 | %d | 板级新增 |' % len(only_ven))
A('| 换 binding 存在（rmtfs） | %d | **保留上游节点** |' % len(rmtfs_fix))
A('')

A('## 1. ⚠️ 必须 `/delete-node/` 的清单（头号风险）\n')
A('这 %d 个区域在上游 `sm8550.dtsi` 里存在，但在 xigua 的 A14 固件里**完全没有**。'
  '板级 DTS 必须删掉，否则内核会去保留一块固件并不认识的内存：\n' % len(only_up))
A('```dts')
for u in sorted(only_up, key=lambda x: x['base']):
    A('/delete-node/ &%s\t/* 0x%x, %s MiB */' % ((u['label'] + ';').ljust(28), u['base'], mib(u['size'])))
A('```\n')
A('> **对比参照**：上游 Sony Xperia 1 V 只删 3 个（`hwfence_shbuf`、`mpss_mem`、`rmtfs_mem`），')
A('> Samsung Z Fold5 只删 5 个。')
A('> **xigua 要删 %d 个，是它们的 2–3 倍** —— 这台机器的固件内存图和通用 SM8550 '
  '差异非常大，**这一节是 bring-up 能否成功的头号风险点**。\n' % len(only_up))
A('其中 `ta_mem`（138 MiB）和 `cdsp_secure_heap_mem`（70 MiB）体量最大，')
A('删错或漏删会直接表现为随机崩溃 / 开机卡死。\n')

if rmtfs_fix:
    A('## 2. rmtfs：**不要删**（容易误判的一项）\n')
    A('xigua 的 rmtfs 不是标准 reserved-memory 节点，而是用高通私有 binding 声明的：\n')
    A('```')
    A('厂商 DTB:  /soc/qcom,rmtfs_sharedmem@0')
    A('              compatible  = "qcom,sharedmem-uio"')
    A('              reg-names   = "rmtfs"')
    A('              qcom,client-id = <1>')
    A('              reg         = <0x0 0x280000>     <-- base 为 0，由 bootloader 填')
    A('')
    A('上游 sm8550.dtsi:  rmtfs_mem: rmtfs-region@d4a80000 {')
    A('              compatible  = "qcom,rmtfs-mem"')
    A('              reg         = <0x0 0xd4a80000 0x0 0x280000>')
    A('              qcom,client-id = <1>')
    A('              qcom,vmid   = <QCOM_SCM_VMID_MSS_MSA>')
    A('           };')
    A('```\n')
    A('**判定它应该保留的依据（已实测）：**')
    A('')
    A('| 检查项 | 结果 |')
    A('| :-- | :-- |')
    A('| 大小是否一致 | ✅ 都是 `0x280000`（2.5 MiB） |')
    A('| `qcom,client-id` | ✅ 都是 `1` |')
    A('| `0xd4a80000` 在 xigua 上是否被占用 | ✅ **空闲**，不与任何厂商区域重叠 |')
    A('| 是否与相邻区域衔接 | ✅ `0xd4a80000 + 0x280000 = 0xd4d00000` = `mpss_dsm` 起点，严丝合缝 |')
    A('')
    A('**结论：保留上游 `rmtfs_mem` 节点不动，不要 `/delete-node/ &rmtfs_mem;`**')
    A('（Sony 那块板子删了它，是因为 Sony 把 rmtfs 挪到了 `0xf8b00000`；xigua 没有挪。）\n')

if resized:
    A('## 3. 同基址、大小要改\n')
    A('| 上游 label | 基址 | 上游大小 | xigua 大小 | 差值 |')
    A('| :-- | --: | --: | --: | --: |')
    for u, v in resized:
        A('| `%s` | 0x%x | %s MiB | **%s MiB** | %+.1f MiB |'
          % (u['label'], u['base'], mib(u['size']), mib(v['size']),
             (v['size'] - u['size']) / 2**20))
    A('')

if moved:
    A('## 4. 搬家（同名不同址）→ 先删后加\n')
    A('| 上游 label | 上游 基址 / 大小 | xigua 节点 | xigua 基址 / 大小 |')
    A('| :-- | :-- | :-- | :-- |')
    for u, v in moved:
        A('| `%s` | 0x%x / %s MiB | `%s` | **0x%x / %s MiB** |'
          % (u['label'], u['base'], mib(u['size']), v['name'], v['base'], mib(v['size'])))
    A('')
    A('> 这 %d 项集中在 `trust_ui_vm_*` 和 `oem_vm_*` 两组（安全 UI / OEM 虚拟机），'
      'xigua 把它们整体前移了约 2 MiB，且 `trust_ui_vm` 缩小了 10 MiB。\n' % len(moved))

if only_ven:
    A('## 5. 本机新增（上游没有）\n')
    A('```dts')
    A('&reserved_memory {')
    for v in sorted(only_ven, key=lambda x: x['base']):
        A('\t%s: %s@%x {\n\t\treg = <0x0 0x%x 0x0 0x%x>;\n\t\tno-map;\n\t};'
          % (v['name'], v['name'], v['base'], v['base'], v['size']))
    A('};')
    A('```\n')

A('## 6. 不用动（基址+大小一致，%d 项）\n' % len(same))
A('| 上游 label | 基址 | 大小 | xigua 节点名 |')
A('| :-- | --: | --: | :-- |')
for u, v in same:
    A('| `%s` | 0x%x | %s MiB | `%s` |' % (u['label'], u['base'], mib(u['size']), v['name']))
A('')

A('## 7. 动态（reusable）区域 —— 不需要写 `reg`\n')
A('厂商 DTB 里还有 **14 个没有 `reg`、带 `reusable`** 的区域（合计约 498 MiB），')
A('由 bootloader 在运行时从内存里切分：\n')
A('| 区域 | 大小 | 备注 |')
A('| :-- | --: | :-- |')
for name, sz, note in [
        ('non_secure_display_region', '164.0', '显示相关，调屏出内存冲突优先查这里'),
        ('secure_cdsp_region', '72.0', ''),
        ('mem_dump_region', '52.0', ''),
        ('demura_heap_region', '40.0', '**Demura** 补偿，与这块屏强相关'),
        ('cnss_wlan_region', '32.0', 'WiFi/BT 固件区'),
        ('linux,cma', '32.0', 'CMA'),
        ('qseecom_region', '20.0', 'TEE'),
        ('qseecom_ta_region', '20.0', 'TEE'),
        ('sp_region', '16.0', ''),
        ('user_contig_region', '16.0', ''),
        ('va_md_mem_region', '16.0', ''),
        ('adsp_heap_region', '12.0', ''),
        ('cdsp_eva_region', '4.0', ''),
        ('ramoops_region', '2.2', '**建议在主线补一个真正的 `ramoops` 节点**，便于抓崩溃日志')]:
    A('| `%s` | %s MiB | %s |' % (name, sz, note))
A('')
A('> `demura_heap_region`（40 MiB）说明这块屏用了 **Demura 补偿**，')
A('> 写 panel 驱动时要注意主线的 `demura` 支持情况。\n')

A('## 8. 复现命令\n')
A('```bash')
A('# 定位 vendor_boot 里的 4 个基础 DTB')
A('python tools/fdt.py vendor_boot-A14.img --scan')
A('# 解析上游内存图')
A('python tools/resmem.py research/upstream/sm8550.dtsi')
A('# 逐项 diff')
A('python tools/diff_resmem.py vendor_boot-A14.img research/upstream/sm8550.dtsi')
A('# 重新生成本清单')
A('python tools/gen_worklist.py')
A('```')

out = '\n'.join(L) + '\n'
open(os.path.join(WS, 'docs', 'resmem-worklist.md'), 'w', encoding='utf-8', newline='\n').write(out)
print('wrote docs/resmem-worklist.md (%d chars)' % len(out))
print('SAME=%d RESIZED=%d MOVED=%d DELETE=%d ADD=%d RMTFS_KEEP=%d'
      % (len(same), len(resized), len(moved), len(only_up), len(only_ven), len(rmtfs_fix)))

#!/usr/bin/env python3
"""Find a marker location the dtbo overlays NEVER touch.

Why: the dtbo sets `model` on the base root
     ("Qualcomm Technologies, Inc. Kalama MTP,xigua"), which is exactly what the
     live tree shows. So patching `model` in vendor_boot proves nothing -- the
     overlay would overwrite it regardless of which base tree ABL used.

Constraints for a good marker:
  * the node must exist in the vendor base tree (entry0 of vendor_boot's dtb
    section) so I can rename it in place, with NO size change
  * no dtbo fragment may target it, neither by path nor via a __symbols__ label
  * the name must be long enough for a recognisable marker of equal length
  * being a directory entry, its name will be visible in
    /sys/firmware/devicetree/base/... WITHOUT root (property files are
    root-only, but directory listings are readable -- verified on the device)

Also measure how much unused space the base FDT has, in case a different
strategy (adding a node) becomes preferable.
"""
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fdt import FDT, load_entries

WS = r'H:\WorkSpace\PJA110-Mainline'


def depth(p):
    return len([s for s in p.split('/') if s])


def dec(v):
    return v.rstrip(b'\0').decode('ascii', 'replace')


# ---- base tree (the one this device uses) ----
v = open(os.path.join(WS, 'backup', 'vendor_boot_b.img'), 'rb').read()
hsize, dtbsize = struct.unpack_from('<2I', v, 28+2048+4+16)
vrsize = struct.unpack_from('<I', v, 24)[0]
dtb_off = (((hsize+4095)//4096)*4096 + vrsize + 4095)//4096*4096
e0 = struct.unpack_from('>I', v, dtb_off+4)[0]
base_blob = v[dtb_off:dtb_off+e0]
base = FDT(base_blob)
bnodes = base.nodes()

print('=== base tree (vendor_boot_b entry0) ===')
print('  totalsize : %d' % e0)
print('  nodes     : %d' % len(bnodes))

# real content end: struct block + strings block
totalsize, off_struct, off_strings = struct.unpack_from('>3I', base_blob, 4)
size_struct, size_strings = struct.unpack_from('>2I', base_blob, 36)
content_end = off_strings + size_strings
slack = totalsize - content_end
print('  struct blk: off 0x%x size 0x%x' % (off_struct, size_struct))
print('  string blk: off 0x%x size 0x%x' % (off_strings, size_strings))
print('  content end: 0x%x' % content_end)
print('  SLACK      : %d bytes' % slack)

# ---- what the dtbo touches ----
entries, _ = load_entries(os.path.join(WS, 'dtbo-A14.img'))
touched_paths = set()
touched_labels = set()

for label, sub in entries:
    f = FDT(sub)
    n = f.nodes()
    # every path that appears inside any __overlay__
    for p in n:
        if '__overlay__' in p:
            after = p.split('__overlay__', 1)[1].lstrip('/')
            if after:
                touched_paths.add('/' + after)
                # all prefixes too
                segs = after.split('/')
                for i in range(1, len(segs)+1):
                    touched_paths.add('/' + '/'.join(segs[:i]))
    for lab in n.get('/__symbols__', {}):
        touched_labels.add(lab)
    for lab in n.get('/__fixups__', {}):
        touched_labels.add(lab)

print()
print('=== dtbo footprint ===')
print('  distinct overlay paths : %d' % len(touched_paths))
print('  labels referenced      : %d' % len(touched_labels))

# labels point at base-tree nodes; resolve them via the base tree's __symbols__
base_syms = bnodes.get('/__symbols__', {})
label_targets = {}
for lab, val in base_syms.items():
    if len(val) == 4:
        label_targets[lab] = 'phandle 0x%x' % struct.unpack('>I', val)[0]

print('  base __symbols__       : %d' % len(base_syms))

# Which base-tree node paths are referenced by the labels the dtbo uses?
# We cannot map phandle->path without a full walk, so approximate by name match.
referenced_names = set()
for lab in touched_labels:
    referenced_names.add(lab)

# ---- candidate nodes: leaf nodes, not obviously touched ----
print()
print('=== candidate untouched nodes (leaf, name len>=10) ===')
skipped_root = []
cands = []
for p in bnodes:
    if p == '/':
        continue
    leaf = p.split('/')[-1]
    if '@' not in leaf:
        continue
    name = leaf.split('@')[0]
    if len(name) < 10:
        continue
    # not referenced by any overlay path
    if any(p == tp or p.startswith(tp + '/') or tp.startswith(p + '/')
           for tp in touched_paths if tp):
        continue
    # node name not used as a label the dtbo needs
    if name in referenced_names:
        continue
    cands.append((p, leaf))

print('  found %d candidates' % len(cands))
for p, leaf in sorted(cands)[:25]:
    print('    %-58s (name len %d)' % (p[:58], len(leaf.split('@')[0])))

print()
print('=== recommendation ===')
# prefer a leaf whose name is long, generic, and peripheral
good = [(p, l) for p, l in cands if len(l.split('@')[0]) >= 12]
if good:
    print('  best candidates (long names, safe to rename 1:1):')
    for p, l in sorted(good, key=lambda x: -len(x[1]))[:8]:
        print('    %-58s -> rename "%s" (%d chars)'
              % (p[:58], l.split('@')[0], len(l.split('@')[0])))
else:
    print('  none with len>=12; relax to >=10:')
    for p, l in sorted(cands, key=lambda x: -len(x[1]))[:8]:
        print('    %-58s -> "%s"' % (p[:58], l.split('@')[0]))
